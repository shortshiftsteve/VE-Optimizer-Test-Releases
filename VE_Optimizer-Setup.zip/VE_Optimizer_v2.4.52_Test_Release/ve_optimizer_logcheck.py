#!/usr/bin/env python3
"""HP Tuners Log File channel qualification for VE Optimizer.

Standard-library only.  This module does not assume that every VCM Scanner
row contains simultaneous channel values.  Required logical signals may be
represented by a broadcast channel, a polled counterpart, or both.  When more
than one equivalent channel is present their populated timestamps are
coalesced for density measurement; they are not counted as independent sensor
measurements.
"""
from __future__ import annotations

import csv
import math
import re
import statistics
import unicodedata
from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

# Data-quantity floors are signal-class aware.  Fast/dynamic required signals
# retain the original 1,000 populated-observation floor.  Slow state channels
# (LTFT and BARO) use 750 observations because their approved scanner setup is
# 500 ms / 2 Hz for the existing channel-density qualification.
# This allows a clean ~10 minute non-interpolated Log File to qualify when it
# has full temporal coverage, without requiring HP Tuners "Interpolate Data Gaps".
MIN_REQUIRED_UPDATES = 1000
MIN_SLOW_STATE_UPDATES = 750
SLOW_STATE_KEYS = frozenset({'ltft_b1','ltft_b2','baro'})
# In NN-disabled Speed Density, ECT is a slow thermal qualifier (>164 F),
# not a high-frequency airflow or trim signal.  Require an average of at
# least one populated observation per second, at least 30 observations for
# short recordings, and the unchanged >=90% temporal coverage.  Other models
# retain their established requirements.
SPEED_DENSITY_ECT_MIN_HZ = 1.0
SPEED_DENSITY_ECT_MIN_UPDATES = 30
SPEED_DENSITY_ECT_POLL_MS = 500
# Invalidate persisted validation results when channel requirements change.
LOG_VALIDATION_POLICY_REVISION = 'ab-na-knock-map-source-policy-6'
RATE_TOLERANCE = 1.35  # informational only; never a hard PASS/FAIL gate
GAP_WARNING_MULTIPLIER = 12.0
LENGTH_SAFETY_MARGIN = 1.20
MIN_TEMPORAL_COVERAGE = 0.90
STANDARD_POLL_MS = (10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000)

@dataclass(frozen=True)
class SignalSpec:
    key: str
    label: str
    patterns: Tuple[str, ...]
    recommended_ms: Optional[int]
    required: bool = True
    numeric: bool = True
    note: str = ''

# Recommended polled rates are the approved initial guidance.  If the selected
# channel is Broadcast, VCM Scanner should leave polling at 0 ms instead.
SPECS: Tuple[SignalSpec, ...] = (
    SignalSpec('rpm','Engine RPM',(r'\bengine\s*rpm\b',),10),
    SignalSpec('actual_torque','Actual Torque',(r'\bactual\s*torque\b',),10),
    SignalSpec('intake_cam','Intake Cam Center Pos',(r'intake\s*cam.*center',r'intake.*cam.*position'),20),
    SignalSpec('exhaust_cam','Exhaust Cam Center Pos',(r'exhaust\s*cam.*center',r'exhaust.*cam.*position'),20),
    SignalSpec('map','MAP - Hi-Res',(r'^\s*map\s*-\s*hi[ -]?res\s*$',r'^\s*sensed\s+map\s*$',r'^\s*intake\s+manifold\s+absolute\s+pressure(?:\s*\(sae\))?\s*$',r'^\s*calculated\s+manifold\s+absolute\s+pressure\s*$'),20,note='Generic Manifold Absolute Pressure is excluded. MAP/Baro values are validated by the processing pipeline.'),
    SignalSpec('baro','Barometric Pressure - Hi Res',(r'barometric\s+pressure',r'\bbaro\b'),500,note='Slow state channel. Pressure units are validated/converted by the processing pipeline.'),
    SignalSpec('ltft_b1','Long Term Fuel Trim Bank 1 (SAE)',(r'long\s*term\s*fuel\s*trim\s*bank\s*1',),500,note='Slow adaptive state channel.'),
    SignalSpec('ltft_b2','Long Term Fuel Trim Bank 2 (SAE)',(r'long\s*term\s*fuel\s*trim\s*bank\s*2',),500,note='Slow adaptive state channel.'),
    SignalSpec('stft_b1','Short Term Fuel Trim Bank 1 (SAE)',(r'short\s*term\s*fuel\s*trim\s*bank\s*1',),50),
    SignalSpec('stft_b2','Short Term Fuel Trim Bank 2 (SAE)',(r'short\s*term\s*fuel\s*trim\s*bank\s*2',),50),
    # VCM Scanner may label the same coolant signal with or without "(SAE)".
    # Neither spelling is a different requirement; qualified samples from both
    # are coalesced by the existing logical-signal machinery.
    SignalSpec('ect','Engine Coolant Temp',(r'^\s*engine\s*coolant\s*temp(?:\s*\(sae\))?\s*$',r'engine\s*coolant\s*temp'),10),
    SignalSpec('fa_enrichment','FA Enrichment',(r'^\s*fa\s*enrichment\s*$',),20),
    SignalSpec('fa_power_enrichment','FA Power Enrichment',(r'fa\s*power\s*enrichment',),20),
    SignalSpec('fuel_flow','Fuel Flow Rate',(r'fuel\s*flow(?:\s*rate)?',),200,note='Mass-flow units are validated and converted to lb/h by the processing pipeline.'),
    SignalSpec('fuel_status','Fuel System #1 Status (SAE)',(r'fuel\s*system\s*#?\s*1\s*status',),200,required=False,numeric=False,note='Optional diagnostic only. It is not required and is not used as a neural-network gate.'),
    SignalSpec('fuel_air_stoich','FA Stoich',(r'\bfa\s*stoich\b',r'fuel\s*/?\s*air\s*stoich'),500,note='Logged fuel-to-air stoichiometry.'),
    SignalSpec('knock_long','Knock Retard Long Term',(r'knock\s*retard\s*long\s*term',r'long\s*term\s*knock\s*retard'),200,note='Cumulative learned knock retard.'),
    SignalSpec('knock_short','Knock Retard Short Term',(r'knock\s*retard\s*short\s*term',r'short\s*term\s*knock\s*retard'),100,note='Momentary knock retard; WOT assessment target is 0 degrees.'),
    SignalSpec('knock_total','Total Knock Retard',(r'total\s*knock\s*retard',r'knock\s*retard\s*total'),100),
)

# Independent Method A / Method B minimum-channel lists.  Method B begins as
# an independent copy of Method A's full current list.  Neither list contains
# references to the other method's individual SignalSpec objects.
METHOD_A_CHANNELS: Tuple[SignalSpec, ...] = tuple(replace(s) for s in SPECS)
METHOD_B_CHANNELS: Tuple[SignalSpec, ...] = tuple(
    replace(s, required=False) if s.key in ('fuel_flow', 'fuel_air_stoich', 'ltft_b1', 'ltft_b2') else replace(s)
    for s in SPECS
)
METHOD_CHANNEL_LISTS = {
    'neural_network': METHOD_A_CHANNELS,
    'speed_density': METHOD_B_CHANNELS,
}
METHOD_NAMES = {
    'neural_network': 'Neural Network Optimization',
    'speed_density': 'Speed Density Optimization',
}
METHOD_A_MANDATORY_KEYS = frozenset(s.key for s in METHOD_A_CHANNELS if s.required)
# Explicit Method B minimum list.  Presence (and supported units for known
# physical signals) is mandatory; Method A's data-density gate is not copied.
METHOD_B_MANDATORY_KEYS = frozenset({
    'rpm', 'ect', 'actual_torque', 'fa_enrichment', 'fa_power_enrichment',
    'map', 'baro', 'stft_b1', 'stft_b2',
    'knock_long', 'knock_short', 'knock_total',
})

# Each method owns its own checkpoint configuration.  The second checkpoint
# never references the first one's channel-list object.
METHOD_A_CHECKPOINT = {
    'name': 'Method A', 'method': METHOD_NAMES['neural_network'],
    'channels': METHOD_A_CHANNELS, 'strict_required_keys': METHOD_A_MANDATORY_KEYS,
}
METHOD_B_CHECKPOINT = {
    'name': 'Method B', 'method': METHOD_NAMES['speed_density'],
    'channels': METHOD_B_CHANNELS, 'strict_required_keys': METHOD_B_MANDATORY_KEYS,
}
METHOD_CHECKPOINTS = {
    'neural_network': METHOD_A_CHECKPOINT,
    'speed_density': METHOD_B_CHECKPOINT,
}

# Retain this older lookup for users of the established canonical channel IDs.
SPEC_BY_KEY={s.key:s for s in SPECS}

# Required scanner signals depend on the calibration's actual airflow model.
# An NN-disabled Speed Density tune has no active cam-position NN inputs and
# uses STFT event timing and optional two-bank LTFT+STFT without ordinary
# Method A FA/PE/CL status gates.
# Fuel Flow Rate and logged FA Stoich are optional channels for Method B.
# Method B adaptive-trim and Wideband code paths do not consume logged FA Stoich;
# requiring it blocks existing Speed Density logs without a processing benefit.
# Method A retains its independent Fuel Flow and FA Stoich requirements.
# Each method has its own complete, independently instantiated minimum list.
# Method B required channels are presence-qualified rather than subjected to
# Method A's data-density/coverage gates.
SPEED_DENSITY_ADVISORY_KEYS = frozenset()


def _profile_required(spec: SignalSpec, airflow_model: str) -> bool:
    if airflow_model not in ('neural_network', 'speed_density'):
        raise ValueError(f'Unsupported airflow model for Log File qualification: {airflow_model!r}')
    # Method B has its own independently maintained required-presence list.
    if airflow_model == 'speed_density':
        return spec.key in METHOD_B_MANDATORY_KEYS
    return bool(spec.required)


def _profile_advisory(spec: SignalSpec, airflow_model: str) -> bool:
    return airflow_model == 'speed_density' and spec.key in SPEED_DENSITY_ADVISORY_KEYS


def _profile_required_updates(key: str, airflow_model: str, duration_s: float) -> int:
    if airflow_model == 'speed_density' and key == 'ect':
        return max(SPEED_DENSITY_ECT_MIN_UPDATES,
                   math.ceil(max(0.0, duration_s) * SPEED_DENSITY_ECT_MIN_HZ))
    return MIN_SLOW_STATE_UPDATES if key in SLOW_STATE_KEYS else MIN_REQUIRED_UPDATES


def _profile_recommended_ms(spec: SignalSpec, airflow_model: str) -> Optional[int]:
    if airflow_model == 'speed_density' and spec.key == 'ect':
        return SPEED_DENSITY_ECT_POLL_MS
    return spec.recommended_ms

@dataclass
class Metadata:
    ids: List[str]
    names: List[str]
    units: List[str]
    data_start_line: int

@dataclass
class SignalResult:
    key: str
    label: str
    required: bool
    recommended_ms: Optional[int]
    recommended_hz: Optional[float]
    candidates: List[str]
    candidate_indices: List[int]
    units: List[str]
    count: int
    median_ms: Optional[float]
    p95_ms: Optional[float]
    max_gap_ms: Optional[float]
    observed_hz: Optional[float]
    effective_hz: Optional[float]
    rate_pass: bool
    quantity_pass: bool
    coverage_ratio: Optional[float]
    coverage_pass: bool
    minimum_hz_for_current_duration: Optional[float]
    status: str
    note: str


def _fnum(value:str)->Optional[float]:
    try:
        x=float(value)
        return x if math.isfinite(x) else None
    except (TypeError,ValueError):
        return None


def _percentile(values:List[float],p:float)->Optional[float]:
    if not values:return None
    vals=sorted(values)
    idx=max(0,min(len(vals)-1,int(round((len(vals)-1)*p))))
    return vals[idx]


def _format_duration(seconds:float)->str:
    seconds=max(0,int(round(seconds)))
    h,rem=divmod(seconds,3600);m,s=divmod(rem,60)
    if h:return f'{h:d}:{m:02d}:{s:02d}'
    return f'{m:d}:{s:02d}'


def _ceil_duration(seconds:float,step:int=10)->float:
    return math.ceil(max(0.0,seconds)/step)*step


def _native(path):
    from hpl_decoder_v1_0_0 import decode_hpl
    path=Path(path)
    with path.open('rb') as f: magic=f.read(6)
    if magic != b'HPT \x60\x09':return None
    return _decode_cached(str(path.resolve()),path.stat().st_mtime_ns,path.stat().st_size)

from functools import lru_cache
@lru_cache(maxsize=1)
def _decode_cached(path,mtime,size):
    from hpl_decoder_v1_0_0 import decode_hpl
    return decode_hpl(path)

def read_metadata(path:Path)->Metadata:
    native=_native(path)
    if native is not None:
        channels=list(native['channels'].values())
        return Metadata(['0']+[str(c['parameter_id']) for c in channels],['Offset']+[c['name'] for c in channels],['s']+[c['unit'] for c in channels],1)
    rows=[]
    with Path(path).open(newline='',errors='replace') as f:
        reader=csv.reader(f)
        for line_no,row in enumerate(reader,start=1):
            rows.append((line_no,row))
            if row and row[0].strip()=='[Channel Data]':
                marker=len(rows)-1
                if marker<4:raise ValueError('Malformed HP Tuners channel metadata.')
                ids=list(rows[marker-4][1]);names=list(rows[marker-3][1]);units=list(rows[marker-2][1])
                n=max(len(ids),len(names),len(units));ids += ['']*(n-len(ids));names += ['']*(n-len(names));units += ['']*(n-len(units))
                return Metadata(ids,names,units,line_no+1)
    raise ValueError('HP Tuners [Channel Data] marker not found.')


def iter_data(path:Path,start:int)->Iterable[Tuple[float,List[str]]]:
    native=_native(path)
    if native is not None:
        keys=list(native['channels'])
        for frame in native['frames']:
            t=frame['timestamp_ms']/1000
            yield t,[str(t)]+[str(frame['updates'][k]) if k in frame['updates'] else '' for k in keys]
        return
    with Path(path).open(newline='',errors='replace') as f:
        reader=csv.reader(f)
        for line_no,row in enumerate(reader,start=1):
            if line_no<start or not row:continue
            t=_fnum(row[0] if row else '')
            if t is None:continue
            yield t,row


def _matching_indices(meta:Metadata,spec:SignalSpec)->List[int]:
    rx=[re.compile(p,re.I) for p in spec.patterns]
    found=[]
    for i,name in enumerate(meta.names):
        norm=' '.join(str(name).split())
        if norm and any(r.search(norm) for r in rx):found.append(i)
    return found


# Physical-unit conversion is centralized here so log qualification and the
# numerical processing pipeline accept the same international unit spellings.
# Canonical processing units remain those required by Accepted_Processing_Method:
# RPM, kPa, lb-ft, deg F, lb/h, percent and degrees.
UNIT_SENSITIVE_KEYS = frozenset({
    'rpm','actual_torque','ect','map','baro','fuel_flow',
    'ltft_b1','stft_b1','ltft_b2','stft_b2','intake_cam','exhaust_cam',
})


def _unit_token(unit:str)->str:
    u=unicodedata.normalize('NFKC',str(unit or '')).casefold().strip()
    for old,new in (("°","deg"),("º","deg"),("˚","deg"),
                    ("−","-"),("–","-"),("—","-"),
                    ("·",""),("⋅",""),("×",""),("*","")):
        u=u.replace(old,new)
    u=u.replace('degrees','deg').replace('degree','deg')
    u=re.sub(r'\bper\b','/',u)
    u=re.sub(r'\s+','',u)
    return u


def _pressure_factor(unit:str)->Optional[float]:
    u=_unit_token(unit)
    table={
        'kpa':1.0,'pa':0.001,'mpa':1000.0,
        'psi':6.894757293168,'bar':100.0,'mbar':0.1,'hpa':0.1,
        'inhg':3.386389,'mmhg':0.133322387415,'torr':101.325/760.0,
        'atm':101.325,'kgf/cm2':98.0665,'kg/cm2':98.0665,
    }
    return table.get(u)


def canonical_unit(key:str)->Optional[str]:
    return {
        'rpm':'rpm','map':'kPa','baro':'kPa','actual_torque':'lb-ft',
        'ect':'deg F','fuel_flow':'lb/h',
        'ltft_b1':'%','stft_b1':'%','ltft_b2':'%','stft_b2':'%',
        'intake_cam':'deg','exhaust_cam':'deg',
    }.get(key)


def convert_value(key:str,unit:str,value:float)->float:
    """Convert a required numeric signal to the processing canonical unit.

    Unknown keys are intentionally left unchanged because enrichment gates and
    other dimensionless values do not require a physical-unit transform here.
    Unsupported units for a known physical signal fail explicitly rather than
    being silently interpreted in the wrong system.
    """
    value=float(value);u=_unit_token(unit)
    if key in ('map','baro'):
        factor=_pressure_factor(unit)
        if factor is None:raise ValueError(f'Unsupported pressure unit: {unit!r}')
        return value*factor
    if key=='ect':
        if u in ('f','degf','fahrenheit'):return value
        if u in ('c','degc','celsius','centigrade'):return value*1.8+32.0
        if u in ('k','kelvin'):return (value-273.15)*1.8+32.0
        if u in ('r','degr','rankine'):return value-459.67
        raise ValueError(f'Unsupported coolant-temperature unit: {unit!r}')
    if key=='actual_torque':
        if u in ('lbft','lb-ft','lbf-ft','lbfft','ftlb','ft-lb','ftlbf','ft-lbf'):return value
        if u in ('nm','n-m','newtonmeter','newtonmeters','newtonmetre','newtonmetres'):return value/1.35581794833
        if u in ('inlb','in-lb','lbin','lb-in','inlbf','in-lbf'):return value/12.0
        if u in ('kgfm','kgf-m','kgf.m'):return value*7.2330138512099
        raise ValueError(f'Unsupported torque unit: {unit!r}')
    if key=='fuel_flow':
        factors={
            'lb/h':1.0,'lb/hr':1.0,'lbs/h':1.0,'lbs/hr':1.0,'lbm/h':1.0,'lbm/hr':1.0,
            'lb/min':60.0,'lbs/min':60.0,'lbm/min':60.0,'lb/s':3600.0,'lbs/s':3600.0,'lbm/s':3600.0,
            'oz/h':1.0/16.0,'oz/hr':1.0/16.0,'oz/min':3.75,'oz/s':225.0,
            'g/s':7.936641438,'g/min':7.936641438/60.0,'g/h':7.936641438/3600.0,
            'kg/s':2.20462262185*3600.0,'kg/min':2.20462262185*60.0,'kg/h':2.20462262185,
            'mg/s':7.936641438/1000.0,'mg/min':7.936641438/60000.0,'mg/h':7.936641438/3600000.0,
        }
        factor=factors.get(u)
        if factor is None:raise ValueError(f'Unsupported fuel-flow unit: {unit!r}')
        return value*factor
    if key=='rpm':
        if u in ('rpm','r/min','rev/min','revs/min','revolution/min','revolutions/min','1/min','min-1','min^-1'):return value
        if u in ('hz','r/s','rev/s','revs/s','1/s','s-1','s^-1'):return value*60.0
        raise ValueError(f'Unsupported engine-speed unit: {unit!r}')
    if key in ('ltft_b1','stft_b1','ltft_b2','stft_b2'):
        if u in ('','%','pct','percent','percentage'):return value
        if u in ('ratio','fraction','1','unitless','dimensionless'):return value*100.0
        raise ValueError(f'Unsupported fuel-trim unit: {unit!r}')
    if key in ('intake_cam','exhaust_cam'):
        if u in ('','deg','degs','degca','crankdeg','degcrank'):return value
        if u in ('rad','radian','radians'):return math.degrees(value)
        raise ValueError(f'Unsupported cam-angle unit: {unit!r}')
    return value


def unit_is_supported(key:str,unit:str)->bool:
    if key not in UNIT_SENSITIVE_KEYS:return True
    try:
        convert_value(key,unit,1.0)
        return True
    except ValueError:
        return False


def _pressure_stats(path:Path,meta:Metadata)->List[Tuple[int,float,float,float,float]]:
    idxs=[i for i,u in enumerate(meta.units) if _pressure_factor(u) is not None]
    vals={i:[] for i in idxs}
    for _,row in iter_data(path,meta.data_start_line):
        for i in idxs:
            if i>=len(row) or row[i]=='':continue
            x=_fnum(row[i])
            if x is not None:vals[i].append(x*_pressure_factor(meta.units[i]))
    out=[]
    for i,v in vals.items():
        if len(v)<20:continue
        mean=statistics.fmean(v);sd=statistics.pstdev(v);cv=sd/abs(mean) if mean else float('inf')
        out.append((i,mean,sd,cv,max(v)-min(v)))
    return out


def resolve_indices(path:Path,meta:Metadata,airflow_model:str='neural_network')->Dict[str,List[int]]:
    # Map channel names against the selected method's own copied spec list.
    specs=METHOD_CHECKPOINTS[airflow_model]['channels']
    resolved={s.key:_matching_indices(meta,s) for s in specs}
    # MAP/BARO semantic names can collide with non-pressure channels such as
    # Baro Advance.  Keep only columns whose units are convertible pressure.
    for key in ('map','baro'):
        resolved[key]=[i for i in resolved[key] if i < len(meta.units) and _pressure_factor(meta.units[i]) is not None]
    # Native HPL MAP selection is validated once against real Barometric
    # Pressure observations. Never fall back to the generic MAP stream.
    native=_native(path) if Path(path).is_file() else None
    if native is not None:
        from ve_optimizer_map_sources import select_hpl_map
        selected=select_hpl_map(native)
        if selected['valid']:
            indices=list(native['channels'])
            selected_id=selected['source']['channel_index']
            baro_id=selected['baro_index']
            resolved['map']=[indices.index(selected_id)+1]
            resolved['baro']=[indices.index(baro_id)+1]
        else:
            resolved['map']=[]
    # Never infer MAP from arbitrary pressure statistics or use the generic
    # Manifold Absolute Pressure channel as an alternative.
    return resolved


def required_channel_guide(airflow_model: str = 'neural_network')->List[Dict[str,object]]:
    rows=[]
    for s in METHOD_CHECKPOINTS[airflow_model]['channels']:
        required = _profile_required(s, airflow_model)
        advisory = _profile_advisory(s, airflow_model)
        rec_ms = _profile_recommended_ms(s, airflow_model)
        hz=(1000.0/rec_ms) if rec_ms else None
        note = s.note
        if airflow_model == 'speed_density' and s.key == 'ect':
            note = ('Slow thermal-state qualifier: >=1 populated update/s on average, '
                    '>=30 updates, >=90% duration coverage; the >164 F processing gate is unchanged.')
        rows.append(dict(key=s.key,label=s.label,required=required,advisory=advisory,
                         broadcast='0 ms',polled_ms=rec_ms,polled_hz=hz,note=note))
    return rows


def _minimum_poll_for_current_duration(duration_s: float, required_updates: int = MIN_REQUIRED_UPDATES) -> Tuple[int, float]:
    """Return the slowest standard polling interval that can accumulate the
    required observation count in the current log length, including margin.

    This is guidance for a *polled* channel/counterpart only. Broadcast channels
    remain at 0 ms and are judged from the density actually present in the CSV.
    """
    if duration_s <= 0:
        return 10, 100.0
    needed_hz = (required_updates * LENGTH_SAFETY_MARGIN) / duration_s
    viable = [ms for ms in STANDARD_POLL_MS if (1000.0 / ms) >= needed_hz]
    ms = max(viable) if viable else min(STANDARD_POLL_MS)
    return ms, 1000.0 / ms


def analyze_log(path:Path, airflow_model: str = 'neural_network')->Dict[str,object]:
    if airflow_model not in ('neural_network','speed_density'):
        raise ValueError(f'Unsupported airflow model for Log File qualification: {airflow_model!r}')
    path=Path(path)
    if not path.is_file():raise ValueError('Selected Log File does not exist.')
    if path.suffix.lower() != '.hpl':raise ValueError('VE Optimizer requires a supported native .hpl Log File.')
    meta=read_metadata(path)
    resolved=resolve_indices(path,meta,airflow_model)
    native=_native(path)
    if native is not None:
        from ve_optimizer_map_sources import select_hpl_map
        source_check=select_hpl_map(native)
    else:
        source_check={'valid':False,'reason':'Native .hpl Log File required'}
    checkpoint=METHOD_CHECKPOINTS[airflow_model]
    specs=checkpoint['channels']
    strict_keys=checkpoint['strict_required_keys']

    # Record every channel in the HPL, not merely the minimum-channel subset.
    # A metadata channel with no populated observations is still reported.
    physical_updates=[0]*len(meta.names)
    physical_first=[None]*len(meta.names)
    physical_last=[None]*len(meta.names)
    timestamps={s.key:set() for s in specs}
    first=None;last=None;row_count=0
    for t,row in iter_data(path,meta.data_start_line):
        if first is None:first=t
        last=t;row_count+=1
        for i in range(1,min(len(row),len(physical_updates))):
            value=row[i].strip()
            if value:
                physical_updates[i]+=1
                if physical_first[i] is None:physical_first[i]=t
                physical_last[i]=t
        for s in specs:
            idxs=resolved.get(s.key) or []
            populated=False
            for i in idxs:
                if i>=len(row):continue
                raw=row[i].strip()
                if raw=='':continue
                if s.numeric and _fnum(raw) is None:continue
                populated=True;break
            if populated:timestamps[s.key].add(t)
    if first is None or last is None or last<=first:raise ValueError('Log File contains no usable timed channel data.')
    duration=last-first
    results=[];blocking=[];warnings=[];length_needs=[];density_needs=[];missing=[];coverage_needs=[]
    for s in specs:
        required=_profile_required(s, airflow_model)
        strict_required=s.key in strict_keys
        advisory=_profile_advisory(s, airflow_model)
        times=sorted(timestamps[s.key]);count=len(times)
        diffs=[b-a for a,b in zip(times,times[1:]) if b>a]
        med=statistics.median(diffs) if diffs else None
        p95=_percentile(diffs,0.95);maxgap=max(diffs) if diffs else None
        observed=(1.0/med) if med and med>0 else None
        effective=count/duration if duration>0 else None
        span=(times[-1]-times[0]) if len(times)>=2 else 0.0
        coverage=(span/duration) if duration>0 and len(times)>=2 else (1.0 if count else 0.0)
        rec_ms=_profile_recommended_ms(s, airflow_model); rec_hz=(1000.0/rec_ms) if rec_ms else None
        required_updates=_profile_required_updates(s.key, airflow_model, duration)
        min_hz_current=(required_updates/duration) if duration>0 else None
        min_poll_ms,min_poll_hz=_minimum_poll_for_current_duration(duration,required_updates)

        # IMPORTANT: meeting the recommended polled cadence is informational.
        # Broadcast channels can update more slowly and still be perfectly
        # adequate. PASS/FAIL is based on actual populated quantity + coverage.
        rate_pass=(med is not None and med*1000.0 <= rec_ms*RATE_TOLERANCE) if rec_ms else count>0
        # Method A retains its existing quantity/coverage requirements.
        # Method B requires presence of each listed channel but does not use
        # Method A's density and duration-coverage rejection thresholds.
        quantity_pass=(count>=required_updates) if (required or advisory) else True
        coverage_pass=(coverage>=MIN_TEMPORAL_COVERAGE) if (required or advisory) else True
        strict_quantity_pass=quantity_pass if airflow_model=='neural_network' else count>0
        strict_coverage_pass=coverage_pass if airflow_model=='neural_network' else True

        idxs=resolved.get(s.key,[])
        candidates=[meta.names[i] for i in idxs if i<len(meta.names)]
        units=sorted({meta.units[i] for i in idxs if i<len(meta.units) and meta.units[i]})
        unsupported=[]
        if s.key in UNIT_SENSITIVE_KEYS:
            unsupported=[meta.units[i] for i in idxs if i<len(meta.units) and not unit_is_supported(s.key,meta.units[i])]
        unit_pass=not unsupported or any(i<len(meta.units) and unit_is_supported(s.key,meta.units[i]) for i in idxs)
        if count==0:
            if strict_required:
                status='MISSING'
                missing.append(s.label);blocking.append(f'{s.label}: missing')
            elif required:
                status='OPTIONAL' 
            elif advisory:
                status='DEGRADED'
                warnings.append(f'{s.label}: missing; not a general Speed Density log hard failure. '
                                'Adaptive Speed Density trim processing may still require it.')
            else:
                status='OPTIONAL'
            rate_pass=False
        elif strict_required and not unit_pass:
            status='UNSUPPORTED UNIT'
            shown=', '.join(repr(u) for u in sorted(set(unsupported))) or '<blank>'
            target=canonical_unit(s.key) or 'required processing unit'
            blocking.append(f'{s.label}: unsupported unit {shown}; must be convertible to {target}')
        elif advisory and (not unit_pass or not quantity_pass or not coverage_pass):
            status='DEGRADED'
            reasons=[]
            if not unit_pass:reasons.append('unsupported unit')
            if not quantity_pass:reasons.append('low data density')
            if not coverage_pass:reasons.append('limited coverage')
            warnings.append(f"{s.label}: {', '.join(reasons)}; not a general Speed Density log hard failure. "
                            'Adaptive Speed Density trim processing may still require it.')
        elif required and not strict_quantity_pass and not strict_coverage_pass:
            status='LOW DATA DENSITY + LIMITED COVERAGE'
        elif required and not strict_quantity_pass:
            status='LOW DATA DENSITY'
        elif required and not strict_coverage_pass:
            status='LIMITED COVERAGE'
        else:
            status='PASS' if required else 'AVAILABLE'

        if strict_required and count>0:
            if not unit_pass:
                # Unit incompatibility is already a blocking reason above. Keep
                # density/coverage diagnostics independent so the user can fix
                # all log problems in one recording if necessary.
                pass
            if not strict_quantity_pass:
                if effective and effective>0:
                    need=(required_updates/effective)*LENGTH_SAFETY_MARGIN
                    length_needs.append((s.label,_ceil_duration(need)))
                density_needs.append(dict(label=s.label,count=count,effective_hz=effective,
                                          minimum_hz=min_hz_current,poll_ms=min_poll_ms,poll_hz=min_poll_hz))
                blocking.append(f'{s.label}: insufficient populated observations for this log')
            if not strict_coverage_pass:
                coverage_needs.append(dict(label=s.label,coverage=coverage))
                blocking.append(f'{s.label}: populated data does not span enough of the log')
            # A slower-than-recommended cadence is a note only when the actual
            # density is otherwise adequate. This is the normal case for some
            # broadcast channels and must never cause a false failure.
            if strict_quantity_pass and strict_coverage_pass and not rate_pass:
                warnings.append(
                    f'{s.label}: observed cadence is slower than the recommended polled counterpart, '
                    f'but actual data density is adequate; accepted'
                )
        if count>0 and med and maxgap and maxgap > med*GAP_WARNING_MULTIPLIER:
            warnings.append(f'{s.label}: intermittent long gaps observed (max {maxgap*1000.0:.0f} ms)')

        results.append(SignalResult(s.key,s.label,required,rec_ms,rec_hz,candidates,resolved.get(s.key,[]),units,count,
                                    med*1000.0 if med is not None else None,p95*1000.0 if p95 is not None else None,
                                    maxgap*1000.0 if maxgap is not None else None,observed,effective,rate_pass,quantity_pass,
                                    coverage,coverage_pass,min_hz_current,status,s.note))

    # One entry per HPL metadata channel, including unrecognized IDs and
    # channels that were configured but did not record any values.  Separately
    # include any checkpoint logical channel not in the metadata at all.
    assigned={i:[] for i in range(1,len(meta.names))}
    for spec in specs:
        for index in resolved.get(spec.key,[]):
            if index in assigned:assigned[index].append(spec.key)
    outcomes={q.key:q for q in results}
    channel_rows=[]
    covered_keys=set()
    for index in range(1,len(meta.names)):
        related=assigned.get(index,[])
        covered_keys.update(related)
        count=physical_updates[index]
        if count > 1 and physical_first[index] is not None and physical_last[index] is not None:
            actual_span=max(0.0,physical_last[index]-physical_first[index])
            physical_coverage=min(1.0,actual_span/duration) if duration else 0.0
        else:
            physical_coverage=0.0
        mandatory=any(key in strict_keys for key in related)
        # If any logical strict channel matches, show its actual qualification.
        bad=any(outcomes[key].status != 'PASS' for key in related if key in strict_keys)
        state=('No Data' if count==0 else
               'FAILED' if mandatory and bad else
               'Pass' if mandatory else 'Available')
        channel_rows.append({
            'index':index,'parameter_id':str(meta.ids[index]) if index<len(meta.ids) else '',
            'name':str(meta.names[index]),'unit':str(meta.units[index]) if index<len(meta.units) else '',
            'logical_keys':list(related),'required':mandatory,
            'updates':int(count),'status':state,
            'minimum_hz_for_current_duration':MIN_REQUIRED_UPDATES/duration if duration else 0.0,
            'physical_coverage_ratio':physical_coverage,
        })
    for spec in specs:
        if spec.key in covered_keys:continue
        channel_rows.append({
            'index':None,'parameter_id':'','name':spec.label,'unit':'',
            'logical_keys':[spec.key],'required':spec.key in strict_keys,
            'updates':0,'status':'No Data',
            'minimum_hz_for_current_duration':MIN_REQUIRED_UPDATES/duration if duration else 0.0,
            'physical_coverage_ratio':0.0,
        })

    if not source_check['valid']:
        blocking.append(source_check['reason'])
    recommended_duration=max((v for _,v in length_needs),default=None)
    recommendations=[]
    if not source_check['valid']:
        recommendations.append(source_check['reason'])
    if missing:
        recommendations.append('Add the missing required channel(s) to the VCM Scanner configuration and record a new Log File: '+', '.join(missing)+'.')
    if recommended_duration and recommended_duration>duration:
        recommendations.append(f'Increase Log File length from {_format_duration(duration)} to at least {_format_duration(recommended_duration)}.')
    for q in density_needs:
        recommendations.append(
            f"{q['label']}: actual density is {q['effective_hz']:.2f} Hz with {q['count']:,} populated observations. "
            f"To keep approximately the current log length, if using a polled channel/counterpart use {int(q['poll_ms'])} ms "
            f"({q['poll_hz']:.0f} Hz) or faster. If the selected channel is Broadcast, leave it at 0 ms and extend the log instead."
        )
    for q in coverage_needs:
        recommendations.append(
            f"{q['label']}: populated data spans only {q['coverage']*100.0:.1f}% of the Log File. "
            f"Keep the channel enabled for the entire recording; if Broadcast, leave polling at 0 ms."
        )
    passed=not blocking
    return {
        'path':str(path),'duration_s':duration,'duration_text':_format_duration(duration),'row_count':row_count,
        'airflow_model':airflow_model,
        'checkpoint':checkpoint['name'],'optimization_method':checkpoint['method'],
        'logged_channels':channel_rows,
        'validation_policy_revision':LOG_VALIDATION_POLICY_REVISION,
        'map_source_valid':bool(source_check['valid']),
        'map_source_error':source_check.get('reason'),
        'map_source_name':(source_check.get('source') or {}).get('name'),
        'stft_only_allowed':airflow_model=='speed_density',
        'min_required_updates':MIN_REQUIRED_UPDATES,'min_slow_state_updates':MIN_SLOW_STATE_UPDATES,
        'slow_state_keys':sorted(SLOW_STATE_KEYS),'min_temporal_coverage':MIN_TEMPORAL_COVERAGE,
        'minimum_hz_for_current_duration':min_hz_current,'passed':passed,'signals':[asdict(r) for r in results],
        'blocking':blocking,'warnings':warnings,'recommendations':recommendations,
        'recommended_duration_s':recommended_duration,'recommended_duration_text':_format_duration(recommended_duration) if recommended_duration else None,
    }


def summary_text(report:Dict[str,object])->str:
    req=[s for s in report['signals'] if s['required']]
    passed=sum(1 for s in req if s['status']=='PASS')
    return f"{'PASS' if report['passed'] else 'FAIL'} — {passed}/{len(req)} required signals qualified • Log {report['duration_text']}"


# The three knock-retard channels remain required. This opt-in exception
# is available only when ALL three are unlogged and every OTHER required
# channel passes the selected method's checkpoint. The caller must also
# verify the absence of MAP > Baro observations and obtain an affirmative
# naturally-aspirated, closed-loop-only confirmation from the user.
NA_KNOCK_KEYS = frozenset({'knock_long', 'knock_short', 'knock_total'})


def na_knock_exception_eligible(report: dict) -> bool:
    if report.get('airflow_model') not in METHOD_CHECKPOINTS:
        return False
    signals = {s['key']: s for s in report.get('signals', [])}
    if any(k not in signals or int(signals[k]['count']) != 0 for k in NA_KNOCK_KEYS):
        return False
    if any(s['required'] and s['key'] not in NA_KNOCK_KEYS and s['status'] != 'PASS'
           for s in report.get('signals', [])):
        return False
    knock_labels = {signals[k]['label'] for k in NA_KNOCK_KEYS}
    return bool(report.get('blocking')) and all(
        any(str(b).startswith(label + ': missing') for label in knock_labels)
        for b in report['blocking']
    )


def allow_na_closed_loop_only(report: dict) -> dict:
    """Retain No Data knock rows, but accept other qualified channels after consent."""
    if not na_knock_exception_eligible(report):
        raise ValueError('Closed-loop-only exception is not eligible for this channel profile.')
    from copy import deepcopy
    result = deepcopy(report)
    result['passed'] = True
    result['blocking'] = []
    result['na_closed_loop_only'] = True
    result['knock_retard_unavailable'] = True
    result['correction_scope'] = 'closed_loop_only'
    result['recommendations'] = [
        'Knock Retard data are not logged. User approved naturally aspirated closed-loop correction only; '
        'FA Enrichment and FA Power Enrichment must both equal 0.000.'
    ]
    return result


def approved_na_closed_loop_report(report, tune_file, log_file):
    """Validate the evidence again at persistence; the UI's Yes is not enough."""
    if not na_knock_exception_eligible(report):
        raise ValueError('No eligible missing-knock exception for this Log File.')
    from ve_optimizer_boost_review import na_closed_loop_evidence
    verified, _ = na_closed_loop_evidence(tune_file, log_file, report['airflow_model'])
    if not verified:
        raise ValueError('Closed-loop-only exception requires a valid MAP/Baro comparison with no MAP > Baro observations.')
    return allow_na_closed_loop_only(report)
