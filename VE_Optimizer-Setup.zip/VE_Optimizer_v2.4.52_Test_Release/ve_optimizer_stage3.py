#!/usr/bin/env python3
"""VE Optimizer HP Tuners template I/O; no fuel-trim processing.

The active normal neural-network architecture is read from the uploaded HP
Tuners Full Engine .htt.  Engine/model labels are not used to select the NN.
"""
from __future__ import annotations

import json
import math
import struct
import os
import tempfile
from pathlib import Path

Q = 2048.0
MAX_NEURONS = 17
INPUTS = 4
NN_KEYS = {
    "W1": 3589,
    "b1": 3585,
    "W2": 3597,
    "b2": 3593,
    "Wo": 3581,
    "bo": 3577,
}
VVL_NN_KEYS = {
    "W1": 3590,
    "b1": 3586,
    "W2": 3598,
    "b2": 3594,
    "Wo": 3582,
    "bo": 3578,
}
SCALAR_KEYS = {
    "neurons": 3601,
    "neurons_vvl": 3603,
    "exhaust_max": 3388,
    "exhaust_min": 3389,
    "intake_max": 3390,
    "intake_min": 3391,
    "pratio_max": 3394,
    "pratio_min": 3395,
    "rpm_max": 3396,
    "rpm_min": 3397,
    "ve_max": 3398,
    "ve_min": 3399,
    "bank_variation": 3400,
}
ACTIVATION_KEY = 3602
ALL_NN_KEYS = list(NN_KEYS.values()) + list(VVL_NN_KEYS.values()) + [ACTIVATION_KEY]
DEFAULT_TRAINING = {
    "exhaust_max": 128.0,
    "exhaust_min": 85.0,
    "intake_max": 143.5,
    "intake_min": 100.5,
    "pratio_max": 1.0595703125,
    "pratio_min": 0.1396484375,
    "rpm_max": 6100.0,
    "rpm_min": 0.0,
    "ve_max": 101.46484375,
    "ve_min": 0.0,
    "bank_variation": 1.0,
}


def _record_bounds(blob: bytes, key: int):
    marker = b"\x00\x00" + key.to_bytes(2, "little") + b"\x00\x00"
    start = blob.find(marker)
    if start < 0:
        raise KeyError(f"Internal key {key} not found")
    next_positions = []
    for k in ALL_NN_KEYS:
        q = blob.find(b"\x00\x00" + k.to_bytes(2, "little") + b"\x00\x00", start + 8)
        if q > start:
            next_positions.append(q)
    end = min(next_positions) if next_positions else len(blob)
    return start, end


def read_table(path, key):
    blob = Path(path).read_bytes()
    start, end = _record_bounds(blob, key)
    text = blob[start + 8:end].decode("ascii", "ignore")
    values = []
    for line in text.replace("\r", "").split("\n"):
        parts = line.strip().split("\t")
        if len(parts) >= 2 and parts[0].isdigit():
            try:
                values.append(float(parts[1]))
            except ValueError:
                pass
    return values


def read_scalar(path, key, default=None):
    """Read HP Tuners scalar record: uint16 key, uint16 flags, double value, type byte."""
    blob = Path(path).read_bytes()
    pat = int(key).to_bytes(2, "little")
    pos = 0
    candidates = []
    while True:
        q = blob.find(pat, pos)
        if q < 0:
            break
        pos = q + 1
        if q + 13 > len(blob) or blob[q + 2:q + 4] != b"\x00\x00":
            continue
        try:
            value = struct.unpack("<d", blob[q + 4:q + 12])[0]
        except struct.error:
            continue
        if math.isfinite(value):
            candidates.append(value)
    if not candidates:
        if default is not None:
            return default
        raise KeyError(f"Scalar internal key {key} not found")
    return candidates[0]


def read_activation(path):
    """Read the positive-half activation LUT if present."""
    blob = Path(path).read_bytes()
    try:
        start, end = _record_bounds(blob, ACTIVATION_KEY)
    except KeyError:
        return None
    rows = []
    for line in blob[start + 8:end].decode("ascii", "ignore").replace("\r", "").split("\n"):
        vals = []
        for part in line.split("\t"):
            part = part.strip()
            if not part:
                continue
            try:
                vals.append(float(part))
            except ValueError:
                pass
        if vals:
            rows.append(vals)
    if len(rows) >= 2 and len(rows[0]) == len(rows[1]) and len(rows[0]) >= 2:
        return {"x": rows[0], "y": rows[1]}
    return None


def _infer_active_neurons(full_tables):
    """Fallback for NN-only template files that omit the Number of Neurons scalar."""
    eps = 1e-12
    for n in range(1, MAX_NEURONS + 1):
        if len(full_tables["W1"]) < INPUTS * n or len(full_tables["W2"]) < n * n:
            continue
        tails = [
            full_tables["W1"][INPUTS * n:], full_tables["b1"][n:],
            full_tables["W2"][n * n:], full_tables["b2"][n:], full_tables["Wo"][n:],
        ]
        if all(all(abs(float(v)) <= eps for v in tail) for tail in tails):
            active = full_tables["W1"][:INPUTS*n] + full_tables["b1"][:n] + full_tables["W2"][:n*n] + full_tables["b2"][:n] + full_tables["Wo"][:n]
            if any(abs(float(v)) > eps for v in active):
                return n
    raise ValueError("Unable to determine active Neural Network neuron count from the .htt.")


def _reshape_input_major(values, inputs, neurons):
    values = list(values)
    if len(values) < inputs * neurons:
        raise ValueError(f"First Layer Weights contain {len(values)} values; {inputs*neurons} required.")
    return [[values[i * neurons + j] for i in range(inputs)] for j in range(neurons)]


def load_network(path):
    path = Path(path)
    full = {k: read_table(path, key) for k, key in NN_KEYS.items()}
    try:
        n = int(round(read_scalar(path, SCALAR_KEYS["neurons"])))
    except KeyError:
        n = _infer_active_neurons(full)
    if not (1 <= n <= MAX_NEURONS):
        raise ValueError(f"Unsupported Number of Neurons value: {n}. Expected 1-{MAX_NEURONS}.")
    if len(full["W1"]) < INPUTS*n or len(full["b1"]) < n or len(full["W2"]) < n*n or len(full["b2"]) < n or len(full["Wo"]) < n or len(full["bo"]) < 1:
        raise ValueError(f"The .htt does not contain a complete 4-{n}-{n}-1 normal Neural Network.")
    training = {}
    for name, default in DEFAULT_TRAINING.items():
        key = SCALAR_KEYS.get(name)
        if key is None:
            training[name] = default
        else:
            try:
                training[name] = float(read_scalar(path, key))
            except KeyError:
                training[name] = float(default)
    try:
        nvvl = int(round(read_scalar(path, SCALAR_KEYS["neurons_vvl"])))
    except KeyError:
        nvvl = 0
    return {
        "W1": _reshape_input_major(full["W1"][:INPUTS*n], INPUTS, n),
        "b1": full["b1"][:n],
        "W2": _reshape_input_major(full["W2"][:n*n], n, n),
        "b2": full["b2"][:n],
        "Wo": full["Wo"][:n],
        "bo": full["bo"][:1],
        "meta": {"inputs": INPUTS, "neurons": n, "neurons_vvl": nvvl, "training": training, "activation": read_activation(path)},
        "_full_tables": full,
    }


def architecture_summary(path):
    n = load_network(path)
    t = n["meta"]["training"]
    return {
        "inputs": n["meta"]["inputs"], "neurons": n["meta"]["neurons"], "outputs": 1,
        "neurons_vvl": n["meta"].get("neurons_vvl", 0),
        "intake_range": [t["intake_min"], t["intake_max"]],
        "exhaust_range": [t["exhaust_min"], t["exhaust_max"]],
        "pratio_range": [t["pratio_min"], t["pratio_max"]],
        "rpm_range": [t["rpm_min"], t["rpm_max"]],
        "ve_range": [t["ve_min"], t["ve_max"]],
    }


def network_equivalent(a, b, tol=1e-12):
    for key in ("W1", "W2"):
        if len(a[key]) != len(b[key]) or any(len(x) != len(y) for x, y in zip(a[key], b[key])):
            return False
        for ra, rb in zip(a[key], b[key]):
            if any(abs(float(x)-float(y)) > tol for x, y in zip(ra, rb)):
                return False
    for key in ("b1", "b2", "Wo", "bo"):
        if len(a[key]) != len(b[key]) or any(abs(float(x)-float(y)) > tol for x, y in zip(a[key], b[key])):
            return False
    return True


def _fmt(v):
    v = float(v)
    if abs(v) < 0.5 / Q:
        return "0"
    if float(int(v)) == v:
        return str(int(v))
    return f"{v:.12f}".rstrip("0").rstrip(".")


def patch_table(blob: bytes, key: int, active_values):
    # NN table payloads are ULEB128 length-prefixed.  The prefix can change
    # width when a serialized candidate crosses a 128-byte boundary, so it
    # must be decoded/re-encoded rather than treated as a fixed uint16.
    _key_pos, length_pos, payload_start, payload_end = _find_length_payload(blob, key)
    old_text = blob[payload_start:payload_end].decode("ascii", "ignore")
    lines = old_text.splitlines()
    active_values = list(active_values)
    replaced = 0
    out = []
    for line in lines:
        parts = line.split("\t")
        if len(parts) >= 2 and parts[0].isdigit() and replaced < len(active_values):
            parts[1] = _fmt(active_values[replaced])
            line = "\t".join(parts)
            replaced += 1
        out.append(line)
    if replaced != len(active_values):
        raise ValueError(f"Key {key}: replaced {replaced}, expected {len(active_values)}")
    new_text = ("\r\n".join(out) + "\r\n").encode("ascii")
    return blob[:length_pos] + _encode_uleb128(len(new_text)) + new_text + blob[payload_end:]


def _transpose_flat(matrix):
    if not matrix:
        return []
    rows = len(matrix)
    cols = len(matrix[0])
    return [matrix[r][c] for c in range(cols) for r in range(rows)]


def write_candidate(base_htt, output_htt, p):
    blob = Path(base_htt).read_bytes()
    replacements = [
        (NN_KEYS["W1"], _transpose_flat(p["W1"])),
        (NN_KEYS["b1"], p["b1"]),
        (NN_KEYS["W2"], _transpose_flat(p["W2"])),
        (NN_KEYS["b2"], p["b2"]),
        (NN_KEYS["Wo"], p["Wo"]),
        (NN_KEYS["bo"], p["bo"]),
    ]
    positions = []
    for key, vals in replacements:
        pos, _ = _record_bounds(blob, key)
        positions.append((pos, key, vals))
    for _, key, vals in sorted(positions, reverse=True):
        blob = patch_table(blob, key, vals)
    Path(output_htt).write_bytes(blob)


def _active_flat(network, key):
    if key == "W1":
        return _transpose_flat(network["W1"])
    if key == "W2":
        return _transpose_flat(network["W2"])
    return list(network[key])


def _find_length_payload(blob: bytes, key: int):
    """Return (key_pos, length_pos, payload_start, payload_end) for an HP Tuners length-prefixed item."""
    pat = int(key).to_bytes(2, "little") + b"\x00\x00"
    q = blob.find(pat)
    if q < 0:
        raise KeyError(f"Internal key {key} not found")
    if blob.find(pat, q + 1) >= 0:
        raise ValueError(f"Ambiguous HP Tuners record: internal key {key} occurs more than once.")
    pos = q + 4
    value = 0
    shift = 0
    while True:
        if pos >= len(blob) or shift > 28:
            raise ValueError(f"Internal key {key} has an invalid length encoding.")
        byte = blob[pos]
        pos += 1
        value |= (byte & 0x7F) << shift
        if not (byte & 0x80):
            break
        shift += 7
    payload_start = pos
    payload_end = payload_start + value
    if payload_end > len(blob):
        raise ValueError(f"Internal key {key} payload exceeds Template File length.")
    return q, q + 4, payload_start, payload_end


def _encode_uleb128(value: int):
    value = int(value)
    if value < 0:
        raise ValueError("Negative length cannot be encoded.")
    out = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        if value:
            out.append(byte | 0x80)
        else:
            out.append(byte)
            break
    return bytes(out)


def _copy_length_payload(dst_blob: bytes, src_blob: bytes, key: int):
    """Copy one length-prefixed HP Tuners item payload while preserving destination framing."""
    _, dlen, dstart, dend = _find_length_payload(dst_blob, key)
    _, _, sstart, send = _find_length_payload(src_blob, key)
    payload = src_blob[sstart:send]
    return dst_blob[:dlen] + _encode_uleb128(len(payload)) + payload + dst_blob[dend:]


def _patch_scalar_value(blob: bytes, key: int, value: float):
    pat = int(key).to_bytes(2, "little") + b"\x00\x00"
    q = blob.find(pat)
    if q < 0 or q + 12 > len(blob):
        raise KeyError(f"Scalar internal key {key} not found")
    return blob[:q + 4] + struct.pack("<d", float(value)) + blob[q + 12:]


def write_changed_nn_template(base_htt, full_candidate_htt, output_htt, carrier_htt=None):
    """Write a HP Tuners-loadable NN result whose effective changes are limited to changed normal NN tables.

    Candidate 6 proved that hand-splicing only the six raw table records can be
    rejected by HP Tuners Template Applicator.  Candidate 7 therefore preserves
    the complete, known-good NN-only Template structure and synchronizes every
    non-changing NN support item to the stored baseline.  The only effective
    calibration deltas are the normal NN tables that changed.
    """
    base_path = Path(base_htt)
    cand_path = Path(full_candidate_htt)
    base = load_network(base_path)
    cand = load_network(cand_path)
    changed = []
    for name in ("W1", "b1", "W2", "b2", "Wo", "bo"):
        a = _active_flat(base, name)
        b = _active_flat(cand, name)
        if len(a) != len(b):
            raise ValueError(f"NN table {name} shape changed unexpectedly.")
        if any(float(x) != float(y) for x, y in zip(a, b)):
            changed.append(name)
    if not changed:
        raise ValueError("No changed normal Neural Network tables are available for the .htt export.")

    carrier = Path(carrier_htt) if carrier_htt else base_path
    # Fail closed on unfamiliar/ambiguous NN framing before constructing output.
    # This checks the subset of records we understand, not a universal HTT format.
    for label, path in (("baseline", base_path), ("candidate", cand_path), ("carrier", carrier)):
        check_blob = path.read_bytes()
        if len(check_blob) < 28 or not check_blob.startswith(b"HPT R") or check_blob[-8:] != b"\x00" * 8:
            raise ValueError(f"Unsupported HP Tuners .htt framing in {label}.")
        for key in NN_KEYS.values():
            _find_length_payload(check_blob, key)
    if base_path.resolve() == Path(output_htt).resolve() or cand_path.resolve() == Path(output_htt).resolve() or carrier.resolve() == Path(output_htt).resolve():
        raise ValueError("Export destination must not overwrite a source template.")
    blob = carrier.read_bytes()
    base_blob = base_path.read_bytes()
    cand_blob = cand_path.read_bytes()
    if len(blob) < 28 or not blob.startswith(b"HPT R"):
        raise ValueError("NN Template carrier has an unrecognized HP Tuners Template header.")
    if blob[-8:] != b"\x00" * 8:
        raise ValueError("NN Template carrier has an unexpected Template File terminator.")

    # The bundled NN-only carrier is a known complete HP Tuners Template.
    # Synchronize architecture/training scalars to the stored Full Engine baseline.
    for key in SCALAR_KEYS.values():
        try:
            blob = _patch_scalar_value(blob, key, read_scalar(base_path, key))
        except KeyError:
            # Optional keys are allowed to be absent from a platform-specific carrier.
            continue

    # Synchronize the NN enabled/state string when this standard item exists.
    try:
        blob = _copy_length_payload(blob, base_blob, 2088)
    except (KeyError, ValueError):
        pass

    # Activation and VVL/support tables are baseline-equal no-op support content.
    try:
        blob = _copy_length_payload(blob, base_blob, ACTIVATION_KEY)
    except KeyError:
        pass
    for key in VVL_NN_KEYS.values():
        try:
            blob = _copy_length_payload(blob, base_blob, key)
        except KeyError:
            pass

    # Copy the complete normal NN table payloads from the internally verified
    # full candidate. This preserves active candidate values and baseline-equivalent
    # inactive capacity exactly as serialized in the Full Engine Template.
    for key in NN_KEYS.values():
        blob = _copy_length_payload(blob, cand_blob, key)

    # Validate on a temporary file, publishing only after all checks succeed.
    output_path = Path(output_htt)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=".ve_htt_export_", suffix=".htt", dir=output_path.parent)
    os.close(fd)
    validation_path = Path(temp_name)
    try:
        validation_path.write_bytes(blob)

        # Effective-delta validation: candidate normal NN must round-trip exactly.
        exported = load_network(validation_path)
        if not network_equivalent(exported, cand, tol=0.0):
            raise ValueError("NN result Template failed normal-network round-trip verification.")

        # Every support scalar remains equal to the stored version baseline.
        for name, key in SCALAR_KEYS.items():
            try:
                if float(read_scalar(validation_path, key)) != float(read_scalar(base_path, key)):
                    raise ValueError(f"NN result Template support scalar changed unexpectedly: {name}.")
            except KeyError:
                continue

        # VVL/support table payloads, when present, must remain byte-for-byte baseline-equal.
        exported_blob = validation_path.read_bytes()
        for name, key in VVL_NN_KEYS.items():
            try:
                _, _, bs, be = _find_length_payload(base_blob, key)
                _, _, es, ee = _find_length_payload(exported_blob, key)
            except KeyError:
                continue
            if base_blob[bs:be] != exported_blob[es:ee]:
                raise ValueError(f"NN result Template VVL support table changed unexpectedly: {name}.")

        os.replace(validation_path, output_path)
    finally:
        validation_path.unlink(missing_ok=True)

    return changed

def write_active_nn_text(output_txt, network, project_name, version_no):
    """Write clean copy/paste text containing active normal NN cells only."""
    n = int(network.get("meta", {}).get("neurons") or len(network.get("Wo", [])))
    full = network.get("_full_tables") or {}
    sections = [
        ("Neural Network First Layer Weights", list(full.get("W1", _transpose_flat(network["W1"])))[:INPUTS*n]),
        ("Neural Network First Layer Biases", list(full.get("b1", network["b1"]))[:n]),
        ("Neural Network Second Layer Weights", list(full.get("W2", _transpose_flat(network["W2"])))[:n*n]),
        ("Neural Network Second Layer Biases", list(full.get("b2", network["b2"]))[:n]),
        ("Neural Network Output Layer Weights", list(full.get("Wo", network["Wo"]))[:n]),
        ("Neural Network Output Layer Biases", list(full.get("bo", network["bo"]))[:1]),
    ]
    lines = [
        "VE Optimizer Neural Network Result",
        f"Project: {str(project_name).strip()}",
        f"Version: V{int(version_no)}",
        f"Architecture: 4-{n}-{n}-1",
        "Active normal Neural Network cells only; inactive table capacity is omitted.",
        "",
    ]
    for heading, vals in sections:
        lines.append(heading)
        for i, value in enumerate(vals):
            lines.append(f"{i}\t{_fmt(value)}")
        lines.append("")
    Path(output_txt).write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return Path(output_txt)
