from __future__ import annotations

import json, os, shutil, re
from pathlib import Path


def install(g):
    DB=g['ReviewDatabase']; s5=g['s5']; s3=g['s3']; logcheck=g['logcheck']
    validate_hp_tuners_log=g['validate_hp_tuners_log']
    orig_init=DB._init_schema

    def _init_schema(self):
        orig_init(self)
        self.conn.executescript('''
        CREATE TABLE IF NOT EXISTS project_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            version_no INTEGER NOT NULL,
            baseline_htt_path TEXT NOT NULL DEFAULT '',
            baseline_htt_sha256 TEXT NOT NULL DEFAULT '',
            log_source_path TEXT NOT NULL DEFAULT '',
            log_local_path TEXT NOT NULL DEFAULT '',
            log_sha256 TEXT NOT NULL DEFAULT '',
            log_validation_json TEXT NOT NULL DEFAULT '',
            run_completed INTEGER NOT NULL DEFAULT 0,
            baseline_trim_mae REAL,
            baseline_trim_median REAL,
            metrics_json TEXT NOT NULL DEFAULT '',
            accepted_csv_path TEXT NOT NULL DEFAULT '',
            result_htt_path TEXT NOT NULL DEFAULT '',
            result_htt_sha256 TEXT NOT NULL DEFAULT '',
            export_htt_path TEXT NOT NULL DEFAULT '',
            export_htt_sha256 TEXT NOT NULL DEFAULT '',
            result_txt_path TEXT NOT NULL DEFAULT '',
            result_txt_sha256 TEXT NOT NULL DEFAULT '',
            summary_path TEXT NOT NULL DEFAULT '',
            technical_path TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(project_id) REFERENCES projects(id),
            UNIQUE(project_id,version_no)
        );
        CREATE INDEX IF NOT EXISTS idx_project_versions_project ON project_versions(project_id,version_no);
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );
        ''')
        cols={str(r[1]) for r in self.conn.execute('PRAGMA table_info(project_setup)').fetchall()}
        for name,decl in (
            ('project_name',"TEXT NOT NULL DEFAULT ''"),
            ('initial_htt_source_path',"TEXT NOT NULL DEFAULT ''"),
            ('initial_htt_local_path',"TEXT NOT NULL DEFAULT ''"),
            ('initial_htt_sha256',"TEXT NOT NULL DEFAULT ''"),
        ):
            if name not in cols:self.conn.execute(f'ALTER TABLE project_setup ADD COLUMN {name} {decl}')
        vcols={str(r[1]) for r in self.conn.execute('PRAGMA table_info(project_versions)').fetchall()}
        for name,decl in (
            ('export_htt_path',"TEXT NOT NULL DEFAULT ''"),
            ('export_htt_sha256',"TEXT NOT NULL DEFAULT ''"),
            ('preview_ready',"INTEGER NOT NULL DEFAULT 0"),
            ('preview_json_path',"TEXT NOT NULL DEFAULT ''"),
            ('application_percent',"REAL NOT NULL DEFAULT 0"),
        ):
            if name not in vcols:self.conn.execute(f'ALTER TABLE project_versions ADD COLUMN {name} {decl}')
        # Preserve stable pre-versioning projects. They are migrated as V0 records;
        # if no original Full Engine .htt was stored by the old build, Setup will require
        # a one-time initial .htt attachment before the project can run.
        rows=self.conn.execute('SELECT p.id,p.name,s.* FROM projects p LEFT JOIN project_setup s ON s.project_id=p.id').fetchall()
        for r in rows:
            pid=int(r['id'])
            if self.conn.execute('SELECT 1 FROM project_versions WHERE project_id=?',(pid,)).fetchone():continue
            if r['project_id'] is None:continue
            pname=str(r['project_name'] or r['name'] or '').strip()
            self.conn.execute('UPDATE project_setup SET project_name=? WHERE project_id=?',(pname,pid))
            self.conn.execute('''INSERT INTO project_versions(project_id,version_no,log_source_path,log_local_path,log_sha256,log_validation_json)
                              VALUES(?,?,?,?,?,?)''',(pid,0,str(r['log_source_path'] or ''),str(r['log_local_path'] or ''),str(r['log_sha256'] or ''),str(r['log_validation_json'] or '')))
        self.conn.commit()
        # Version 2.0.1 protected-storage migration.  This runs after the
        # schema is available and before any project is opened by the UI.
        self._migrate_project_storage()
        # Older releases accidentally stored native HPL bytes as Log.csv.
        # Repair the project references without changing any recorded data.
        self._restore_stored_hpl_extensions()
    DB._init_schema=_init_schema

    def _default_project_base(self):
        # Project data is intentionally separated from user-owned Documents.
        # On Windows this resolves exactly to:
        #   %LOCALAPPDATA%\Programs\Short Shift Garage\Projects
        local=os.environ.get('LOCALAPPDATA','').strip()
        local_root=Path(local) if local else Path.home()/'AppData'/'Local'
        p=local_root/'Programs'/'Short Shift Garage'/'Projects'
        p.mkdir(parents=True,exist_ok=True)
        return p
    DB._default_project_base=_default_project_base

    def _legacy_project_base(self):
        return Path.home()/'Documents'/'VE Optimizer'
    DB._legacy_project_base=_legacy_project_base

    def _copy_verified(self,src,dst):
        src=Path(src);dst=Path(dst)
        if not src.is_file():return None
        try:
            if src.resolve()==dst.resolve():return dst
        except Exception:
            pass
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists():
            if not dst.is_file() or s5.sha256_file(src)!=s5.sha256_file(dst):
                raise ValueError(f'Project migration destination conflict: {dst}')
            return dst
        shutil.copy2(src,dst)
        if s5.sha256_file(src)!=s5.sha256_file(dst):
            try:dst.unlink()
            except OSError:pass
            raise ValueError(f'Project migration integrity check failed: {dst}')
        return dst
    DB._copy_verified=_copy_verified

    def _restore_stored_hpl_extensions(self):
        """Repair historical .csv filenames used for actual native HPL bytes.

        Only copied log files bearing the supported native HPL signature are
        migrated. The original file is retained; new copy and DB references
        have the identical SHA-256. Real CSV files are never reclassified.
        """
        for table, key in (('project_versions', 'id'), ('project_setup', 'project_id')):
            rows=self.conn.execute(
                f'SELECT {key},log_local_path,log_sha256 FROM {table}'
            ).fetchall()
            for row in rows:
                raw=str(row['log_local_path'] or '').strip()
                if not raw:continue
                source=Path(raw)
                if source.suffix.lower()!='.csv' or not source.is_file():continue
                with source.open('rb') as handle:
                    if handle.read(6)!=b'HPT \x60\x09':continue
                stored_hash=str(row['log_sha256'] or '')
                actual_hash=s5.sha256_file(source)
                if stored_hash and actual_hash!=stored_hash:
                    raise ValueError(f'Stored Log File integrity check failed: {source}')
                target=source.with_suffix('.hpl')
                self._copy_verified(source,target)
                if s5.sha256_file(target)!=actual_hash:
                    raise ValueError(f'Native HPL storage repair failed: {target}')
                self.conn.execute(
                    f'UPDATE {table} SET log_local_path=? WHERE {key}=?',
                    (str(target),int(row[key]))
                )
        self.conn.commit()
    DB._restore_stored_hpl_extensions=_restore_stored_hpl_extensions

    def _migrate_project_storage(self):
        canonical=self._default_project_base().resolve()
        marker=self.conn.execute("SELECT value FROM app_settings WHERE key='project_storage_layout'").fetchone()
        layout=str(marker['value'] or '').strip() if marker else ''
        root_row=self.conn.execute("SELECT value FROM app_settings WHERE key='project_root'").fetchone()
        configured=str(root_row['value'] or '').strip() if root_row else ''
        # A completed v2 migration is idempotent.  Still force the canonical
        # root if an older setting survived an interrupted upgrade.
        if layout=='protected_v2':
            if not configured or os.path.normcase(os.path.abspath(configured))!=os.path.normcase(str(canonical)):
                self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_root',?)",(str(canonical),));self.conn.commit()
            return canonical

        projects=self.conn.execute('SELECT id,output_dir FROM projects ORDER BY id').fetchall()
        updates=[]
        for pr in projects:
            pid=int(pr['id']);target=(canonical/self._folder_name(pid)).resolve();target.mkdir(parents=True,exist_ok=True)
            versions=self.conn.execute('SELECT * FROM project_versions WHERE project_id=? ORDER BY version_no',(pid,)).fetchall()
            latest_no=max([int(v['version_no']) for v in versions],default=0)
            latest_log=''
            v0_baseline=''
            for v in versions:
                vn=int(v['version_no']);vd=target/f'V{vn}';vd.mkdir(parents=True,exist_ok=True);prefix=self.version_result_prefix(pid,vn)
                fields={}
                bp=Path(str(v['baseline_htt_path'] or ''))
                if bp.is_file():
                    dst=self._copy_verified(bp,vd/'Baseline.htt');fields['baseline_htt_path']=str(dst)
                    if vn==0:v0_baseline=str(dst)
                lp=Path(str(v['log_local_path'] or ''))
                if lp.is_file():
                    dst=self._copy_verified(lp,vd/'Log.hpl' if lp.suffix.lower()=='.hpl' else vd/'Log.csv');fields['log_local_path']=str(dst)
                    if vn==latest_no:latest_log=str(dst)
                # User-visible result artifacts stay directly in the version folder.
                for col in ('export_htt_path','result_txt_path','summary_path','technical_path'):
                    raw=str(v[col] or '') if col in v.keys() else ''
                    src=Path(raw) if raw else None
                    if src and src.is_file():
                        dst=self._copy_verified(src,vd/src.name);fields[col]=str(dst)
                # Internal diagnostics stay protected under the same version.
                diag=vd/'_Diagnostics'
                for col in ('result_htt_path','accepted_csv_path'):
                    raw=str(v[col] or '') if col in v.keys() else ''
                    src=Path(raw) if raw else None
                    if src and src.is_file():
                        dst=self._copy_verified(src,diag/src.name);fields[col]=str(dst)
                raw_metrics=str(v['metrics_json'] or '') if 'metrics_json' in v.keys() else ''
                mp=Path(raw_metrics) if raw_metrics else None
                if mp and mp.is_file():
                    dst=self._copy_verified(mp,diag/mp.name);fields['metrics_json']=str(dst)
                raw_preview=str(v['preview_json_path'] or '') if 'preview_json_path' in v.keys() else ''
                pp=Path(raw_preview) if raw_preview else None
                if pp and pp.is_file():
                    pd=vd/'_Application_Preview';pd.mkdir(parents=True,exist_ok=True)
                    # Preserve all preview siblings because the JSON references them.
                    for child in pp.parent.iterdir():
                        if child.is_file():self._copy_verified(child,pd/child.name)
                        elif child.is_dir():shutil.copytree(child,pd/child.name,dirs_exist_ok=True)
                    fields['preview_json_path']=str(pd/pp.name)
                if fields:
                    sets=','.join(f'{k}=?' for k in fields);vals=list(fields.values())+[int(v['id'])]
                    self.conn.execute(f'UPDATE project_versions SET {sets} WHERE id=?',vals)
            setup=self.get_project_setup(pid)
            if setup:
                latest=self.get_version(pid,latest_no) if versions else None
                setup_log=str(latest['log_local_path'] or '') if latest else latest_log
                self.conn.execute('''UPDATE project_setup SET initial_htt_local_path=?,log_local_path=?,updated_at=CURRENT_TIMESTAMP WHERE project_id=?''',
                                  (v0_baseline or str(setup['initial_htt_local_path'] or ''),setup_log,pid))
            self.conn.execute('UPDATE projects SET output_dir=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(str(target),pid))
            updates.append(pid)
        self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_root',?)",(str(canonical),))
        self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_storage_layout','protected_v2')")
        self.conn.commit()
        return canonical
    DB._migrate_project_storage=_migrate_project_storage

    def get_project_base(self):
        row=self.conn.execute("SELECT value FROM app_settings WHERE key='project_root'").fetchone()
        raw=str(row['value']).strip() if row and row['value'] else ''
        p=Path(raw) if raw else self._default_project_base()
        p.mkdir(parents=True,exist_ok=True)
        if not raw:
            self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_root',?)",(str(p),));self.conn.commit()
        return p
    DB.get_project_base=get_project_base

    def _folder_name(self,pid):
        name=str(self.project_display_name(pid) or f'Project {int(pid)}').strip()
        name=re.sub(r'[<>:"/\\|?*]+','_',name).rstrip(' .') or f'Project {int(pid)}'
        # Avoid filesystem collisions if two user accounts reuse the same display name.
        candidate=name
        rows=self.conn.execute('SELECT project_id,project_name FROM project_setup WHERE project_id<>?',(int(pid),)).fetchall()
        if any(str(r['project_name'] or '').strip().casefold()==name.casefold() for r in rows):candidate=f'{name} [{int(pid)}]'
        return candidate
    DB._folder_name=_folder_name

    def project_root(self,pid,create=True):
        pr=self.get_project(int(pid))
        stored=str(pr.output_dir or '').strip() if pr else ''
        p=Path(stored) if stored else self.get_project_base()/self._folder_name(pid)
        if create:p.mkdir(parents=True,exist_ok=True)
        return p
    DB.project_root=project_root

    def set_output(self,pid,uid,path=None):
        # Protected storage is fixed.  Retain this legacy API for older callers,
        # but never allow it to redirect active project files outside Projects.
        self._assert_owner(pid,uid)
        target=self.get_project_base()/self._folder_name(pid)
        target.mkdir(parents=True,exist_ok=True)
        self.conn.execute('UPDATE projects SET output_dir=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(str(target),int(pid)))
        self.conn.commit()
        return target
    DB.set_output=set_output

    def move_project_base(self,new_base):
        new_base=Path(new_base).expanduser().resolve();new_base.mkdir(parents=True,exist_ok=True)
        old_base=self.get_project_base().resolve()
        if os.path.normcase(str(old_base))==os.path.normcase(str(new_base)):return new_base
        projects=[int(r['id']) for r in self.conn.execute('SELECT id FROM projects ORDER BY id').fetchall()]
        moves=[]
        # Capture existing roots before changing the setting.
        old_roots={pid:self.project_root(pid,create=False) for pid in projects}
        self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_root',?)",(str(new_base),));self.conn.commit()
        try:
            for pid in projects:
                src=old_roots[pid];dst=new_base/self._folder_name(pid)
                if src.exists() and os.path.normcase(str(src.resolve()))!=os.path.normcase(str(dst.resolve())):
                    if dst.exists():raise ValueError(f'Project destination already exists: {dst}')
                    dst.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(src),str(dst));moves.append((pid,src,dst))
                else:dst.mkdir(parents=True,exist_ok=True)
                old=str(src);new=str(dst)
                # Rewrite every stored internal project path that moved with the folder.
                for table,col in (
                    ('project_setup','initial_htt_local_path'),('project_setup','log_local_path'),
                    ('project_versions','baseline_htt_path'),('project_versions','log_local_path'),('project_versions','accepted_csv_path'),
                    ('project_versions','result_htt_path'),('project_versions','export_htt_path'),('project_versions','result_txt_path'),('project_versions','summary_path'),('project_versions','technical_path')):
                    rows=self.conn.execute(f'SELECT rowid AS _rid,{col} AS p FROM {table} WHERE project_id=?',(pid,)).fetchall()
                    for r in rows:
                        val=str(r['p'] or '')
                        if val and os.path.normcase(val).startswith(os.path.normcase(old)):
                            nv=new+val[len(old):]
                            self.conn.execute(f'UPDATE {table} SET {col}=? WHERE rowid=?',(nv,int(r['_rid'])))
                self.conn.execute('UPDATE projects SET output_dir=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(new,pid))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            self.conn.execute("INSERT OR REPLACE INTO app_settings(key,value) VALUES('project_root',?)",(str(old_base),));self.conn.commit()
            for pid,src,dst in reversed(moves):
                try:
                    if dst.exists() and not src.exists():shutil.move(str(dst),str(src))
                except Exception:pass
            raise
        return new_base
    DB.move_project_base=move_project_base

    def version_dir(self,pid,version_no):
        p=self.project_root(pid)/f'V{int(version_no)}';p.mkdir(parents=True,exist_ok=True);return p
    DB.version_dir=version_dir

    def version_result_prefix(self,pid,version_no):
        name=str(self.project_display_name(pid) or f'Project_{int(pid)}').strip()
        name=re.sub(r'[<>:"/\\|?*]+','_',name)
        name=re.sub(r'\s+','_',name).strip(' ._') or f'Project_{int(pid)}'
        if len(name)>80:name=name[:80].rstrip(' ._')
        return f'{name}_V{int(version_no)}'
    DB.version_result_prefix=version_result_prefix

    def validate_htt(self,path):
        path=Path(path)
        if path.suffix.lower()!='.htt' or not path.is_file():raise ValueError('A valid Full Engine .htt Template File is required.')
        net=s3.load_network(path)
        n=int(net.get('meta',{}).get('neurons') or len(net.get('Wo',[])))
        if n<1 or n>s3.MAX_NEURONS or len(net['W1'])!=n or any(len(x)!=s3.INPUTS for x in net['W1']) or len(net['b1'])!=n or len(net['W2'])!=n or any(len(x)!=n for x in net['W2']) or len(net['b2'])!=n or len(net['Wo'])!=n or len(net['bo'])!=1:
            raise ValueError(f'The Full Engine .htt does not contain a complete supported 4-{n}-{n}-1 normal Neural Network.')
        return s5.sha256_file(path)
    DB.validate_initial_htt=validate_htt

    def get_version(self,pid,version_no):
        return self.conn.execute('SELECT * FROM project_versions WHERE project_id=? AND version_no=?',(int(pid),int(version_no))).fetchone()
    DB.get_version=get_version

    def list_versions(self,pid):
        return self.conn.execute('SELECT * FROM project_versions WHERE project_id=? ORDER BY version_no',(int(pid),)).fetchall()
    DB.list_versions=list_versions

    def latest_version(self,pid):
        return self.conn.execute('SELECT * FROM project_versions WHERE project_id=? ORDER BY version_no DESC LIMIT 1',(int(pid),)).fetchone()
    DB.latest_version=latest_version

    def project_display_name(self,pid):
        r=self.get_project_setup(pid)
        return (str(r['project_name']).strip() if r and 'project_name' in r.keys() and str(r['project_name']).strip() else self.get_project(pid).name)
    DB.project_display_name=project_display_name

    def _unique_name_for_user(self,uid,name,exclude=None):
        name=str(name).strip()
        if not name:raise ValueError('Project Name is required.')
        rows=self.conn.execute('''SELECT p.id,COALESCE(s.project_name,p.name) AS display_name FROM projects p LEFT JOIN project_setup s ON s.project_id=p.id WHERE p.created_by=?''',(int(uid),)).fetchall()
        for r in rows:
            if exclude is not None and int(r['id'])==int(exclude):continue
            if str(r['display_name']).strip().casefold()==name.casefold():raise ValueError('Project Name must be unique for the logged-in user.')
        return name
    DB._unique_name_for_user=_unique_name_for_user

    def create_initial_project(self,uid,project_name,year,model,vin,engine,transmission,initial_htt,log_source,**mods):
        project_name=self._unique_name_for_user(uid,project_name)
        htt_sha=self.validate_initial_htt(initial_htt)
        p=self.create_project_draft(uid,year,model,vin,engine)
        try:
            self.save_project_setup(p.id,uid,vin,year,model,engine,transmission,Path(log_source),tune_path=Path(initial_htt),**mods)
            setup=self.get_project_setup(p.id)
            root=self.project_root(p.id);vdir=root/'V0';vdir.mkdir(parents=True,exist_ok=True)
            base=vdir/'Baseline.htt';shutil.copy2(initial_htt,base)
            vlog=vdir/'Log.hpl';shutil.copy2(Path(setup['log_local_path']),vlog)
            # projects.name is still globally unique in the legacy table. Keep a hidden suffix only if needed across users.
            internal_name=project_name
            clash=self.conn.execute('SELECT id FROM projects WHERE name=? AND id<>?',(internal_name,p.id)).fetchone()
            if clash:internal_name=f'{project_name} [u{int(uid)} p{p.id}]'
            self.conn.execute('UPDATE projects SET name=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(internal_name,p.id))
            # Protected project storage is automatic: <Projects>\<ProjectName>\V0.
            final_root=self.project_root(p.id,create=False)
            if os.path.normcase(str(root.resolve()))!=os.path.normcase(str(final_root.resolve())):
                if final_root.exists():raise ValueError(f'Project folder already exists: {final_root}')
                final_root.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(root),str(final_root));root=final_root
                base=root/'V0'/'Baseline.htt';vlog=root/'V0'/'Log.hpl'
            else:
                final_root.mkdir(parents=True,exist_ok=True);root=final_root
            self.conn.execute('UPDATE projects SET output_dir=? WHERE id=?',(str(root),p.id))
            self.conn.execute('''UPDATE project_setup SET project_name=?,initial_htt_source_path=?,initial_htt_local_path=?,initial_htt_sha256=?,log_local_path=? WHERE project_id=?''',
                              (project_name,str(initial_htt),str(base),htt_sha,str(vlog),p.id))
            self.conn.execute('''INSERT INTO project_versions(project_id,version_no,baseline_htt_path,baseline_htt_sha256,log_source_path,log_local_path,log_sha256,log_validation_json)
                              VALUES(?,?,?,?,?,?,?,?)''',(p.id,0,str(base),htt_sha,str(log_source),str(vlog),setup['log_sha256'],setup['log_validation_json']))
            self.conn.commit()
            self.record_event(p.id,'VERSION_0_CREATED',f'Project {project_name}; initial Full Engine Template and Log File stored.',uid)
            return self.get_project(p.id)
        except Exception:
            try:
                self.conn.execute('DELETE FROM project_setup WHERE project_id=?',(p.id,));self.conn.execute('DELETE FROM projects WHERE id=?',(p.id,));self.conn.commit()
                shutil.rmtree(self.project_root(p.id,create=False),ignore_errors=True)
            except Exception:pass
            raise
    DB.create_initial_project=create_initial_project

    def attach_initial_htt(self,pid,uid,htt_source):
        self._assert_owner(pid,uid);v=self.get_version(pid,0)
        if not v or int(v['version_no'])!=0:raise ValueError('Version 0 not found.')
        if str(v['baseline_htt_path'] or '').strip():raise ValueError('The initial Full Engine .htt is already stored and cannot be replaced.')
        sha=self.validate_initial_htt(htt_source);vd=self.version_dir(pid,0);dest=vd/'Baseline.htt';shutil.copy2(htt_source,dest)
        self.conn.execute('UPDATE project_versions SET baseline_htt_path=?,baseline_htt_sha256=? WHERE id=?',(str(dest),sha,int(v['id'])))
        self.conn.execute('UPDATE project_setup SET initial_htt_source_path=?,initial_htt_local_path=?,initial_htt_sha256=? WHERE project_id=?',(str(htt_source),str(dest),sha,int(pid)))
        self.conn.commit();self.record_event(pid,'LEGACY_INITIAL_HTT_ATTACHED','Initial Full Engine .htt attached during Version 4 migration.',uid);return self.get_version(pid,0)
    DB.attach_initial_htt=attach_initial_htt

    def assign_version_log(self,pid,uid,log_source,version_no=None,*,na_closed_loop_only=False):
        self._assert_owner(pid,uid);v=self.latest_version(pid) if version_no is None else self.get_version(pid,version_no)
        if not v:raise ValueError('Project version not found.')
        if int(v['run_completed']):raise ValueError('Historical versions are locked and read-only.')
        if int(v['version_no']) != int(self.latest_version(pid)['version_no']):raise ValueError('Only the current project version can accept a new Log File.')
        ok,msg=validate_hp_tuners_log(Path(log_source))
        if not ok:raise ValueError(msg)
        baseline=Path(str(v['baseline_htt_path'] or ''))
        if not baseline.is_file():
            raise ValueError('The project Full Engine .htt is missing; cannot determine Log File channel requirements.')
        # Match the generic log-density profile to the calibration model;
        # otherwise an NN-disabled Speed Density log is judged as NN-enabled.
        wideband=g.get('wideband')
        if wideband is None:
            import ve_optimizer_wideband as wideband
        standard_validation=logcheck.analyze_log(
            Path(log_source),airflow_model=wideband.detect_airflow_model(baseline))
        if na_closed_loop_only:
            standard_validation=logcheck.approved_na_closed_loop_report(
                standard_validation,baseline,Path(log_source))
        validation=standard_validation
        if standard_validation['airflow_model']=='speed_density' or not standard_validation['passed'] or na_closed_loop_only:
            integration=g.get('wideband_integration')
            if integration is None or not baseline.is_file():
                details='\n'.join('• '+x for x in standard_validation.get('recommendations',[])[:8])
                raise ValueError('Log File failed required channel/data-density qualification.'+((('\n\n'+details) if details else '')))
            qualification=integration.qualify_log_for_tune(
                Path(log_source),baseline,standard_validation,
                closed_loop_only=bool(na_closed_loop_only))
            if not qualification.get('passed'):
                details='\n'.join('• '+x for x in standard_validation.get('recommendations',[])[:8])
                raise ValueError('Log File failed both adaptive and wideband qualification.'+((('\n\n'+details) if details else '')))
            validation=qualification
        h=s5.sha256_file(Path(log_source))
        prior=self.get_version(pid,int(v['version_no'])-1) if int(v['version_no'])>0 else None
        prior_hash=str(prior['log_sha256'] or '') if prior else ''
        if prior_hash and h==prior_hash:raise ValueError('The new Log File is identical to the prior stored Log File. Select a different VCM Scanner Log File.')
        vn=int(v['version_no']);vd=self.version_dir(pid,vn);dest=vd/'Log.hpl';shutil.copy2(log_source,dest)
        js=json.dumps(validation,separators=(',',':'))
        # Replacing/assigning the current Log File invalidates the stored candidate preview.
        self.conn.execute('''UPDATE project_versions SET log_source_path=?,log_local_path=?,log_sha256=?,log_validation_json=?,preview_ready=0,preview_json_path='',application_percent=0 WHERE id=?''',(str(log_source),str(dest),h,js,int(v['id'])))
        preview_dir=self.version_dir(pid,int(v['version_no']))/'_Application_Preview'
        if preview_dir.exists():shutil.rmtree(preview_dir,ignore_errors=True)
        self.conn.execute('''UPDATE project_setup SET log_source_path=?,log_local_path=?,log_sha256=?,log_density_pass=1,log_validation_json=?,updated_at=CURRENT_TIMESTAMP WHERE project_id=?''',(str(log_source),str(dest),h,js,int(pid)))
        self.conn.commit();self.record_event(pid,'VERSION_LOG_ASSIGNED',f"V{int(v['version_no'])} Log File {Path(log_source).name}; SHA-256 {h}",uid);return self.get_version(pid,int(v['version_no']))
    DB.assign_version_log=assign_version_log

    def version_setup_complete(self,pid,version_no=None):
        p=self.get_project(pid);s=self.get_project_setup(pid);v=self.latest_version(pid) if version_no is None else self.get_version(pid,version_no)
        if not p or not s or not v:return False
        if not str(s['project_name'] or '').strip():return False
        if not Path(v['baseline_htt_path']).is_file():return False
        if not str(v['baseline_htt_sha256']) or s5.sha256_file(Path(v['baseline_htt_path']))!=v['baseline_htt_sha256']:return False
        if not str(v['log_local_path'] or '').strip() or not Path(v['log_local_path']).is_file():return False
        if str(v['log_sha256'] or '') and s5.sha256_file(Path(v['log_local_path']))!=v['log_sha256']:return False
        return True
    DB.version_setup_complete=version_setup_complete

    orig_complete=DB.project_setup_complete
    def project_setup_complete(self,pid):
        if self.latest_version(pid):return self.version_setup_complete(pid)
        return orig_complete(self,pid)
    DB.project_setup_complete=project_setup_complete

    orig_state=DB.project_state
    def project_state(self,pid,version_no=None):
        latest=self.latest_version(pid)
        if not latest:return orig_state(self,pid)
        v=latest if version_no is None else self.get_version(pid,version_no)
        if not v:return {'state':'SETUP_REQUIRED','next':'Select a valid project version.'}
        p=self.get_project(pid)
        if int(v['run_completed']):
            try:stored_method=json.loads(Path(v['metrics_json']).read_text()).get('method_id')
            except (OSError,ValueError):stored_method=None
            current_methods={g['processing'].METHOD_ID}
            integration=g.get('wideband_integration')
            if integration is not None:current_methods.update(integration.CURRENT_METHOD_IDS)
            if stored_method not in current_methods:
                return {'state':'HISTORICAL_RESULT','next':'Historical result uses a superseded processing method.'}
            hp=Path(v['result_htt_path'])
            export_raw=str(v['export_htt_path'] or '') if 'export_htt_path' in v.keys() else ''
            ep=Path(export_raw) if export_raw else hp
            export_sha=str(v['export_htt_sha256'] or '') if 'export_htt_sha256' in v.keys() else ''
            ok=(hp.is_file() and ep.is_file()
                and (not v['result_htt_sha256'] or s5.sha256_file(hp)==v['result_htt_sha256'])
                and (not export_sha or s5.sha256_file(ep)==export_sha))
            return {'state':'READY_FOR_REVIEW' if ok else 'SETUP_REQUIRED','next':'Review this version results.' if ok else 'Stored version results are incomplete.'}
        if int(v['preview_ready'] or 0):
            pj=Path(str(v['preview_json_path'] or ''))
            if pj.is_file():
                try:method=json.loads(pj.read_text()).get('method_id')
                except (OSError,ValueError):method=None
                current_methods={g['processing'].METHOD_ID}
                integration=g.get('wideband_integration')
                if integration is not None:current_methods.update(integration.CURRENT_METHOD_IDS)
                if method in current_methods:
                    return {'state':'READY_TO_APPLY','next':'Review the candidate, then Apply Changes.'}
            # Superseded previews are never used as candidate or fit inputs.
            if self.version_setup_complete(pid,int(v['version_no'])):
                return {'state':'READY_TO_RUN','next':'Run the accepted processing method.'}
            return {'state':'SETUP_REQUIRED','next':'Complete input setup.'}
        if not p or not str(p.output_dir).strip():return {'state':'SETUP_REQUIRED','next':'Choose the project output directory.'}
        if not self.version_setup_complete(pid,int(v['version_no'])):
            return {'state':'SETUP_REQUIRED','next':'Select a new qualified Log File for this current version.'}
        return {'state':'READY_TO_RUN','next':f"Run V{int(v['version_no'])} review."}
    DB.project_state=project_state

    def commit_version_result(self,pid,version_no,uid,result_htt,export_htt,summary,technical,accepted_csv,metrics,mae,median):
        v=self.get_version(pid,version_no)
        if not v or int(v['run_completed']):raise ValueError('Version result cannot be committed.')
        vd=self.version_dir(pid,version_no);diag=vd/'_Diagnostics';diag.mkdir(parents=True,exist_ok=True)
        prefix=self.version_result_prefix(pid,version_no)
        visible={
            'export_htt':(Path(export_htt),vd/f'{prefix}_Result.htt'),
            'summary':(Path(summary),vd/f'{prefix}_Summary.txt'),
            'technical':(Path(technical),vd/f'{prefix}_Technical.txt'),
        }
        internal={
            'result_htt':(Path(result_htt),diag/f'{prefix}_Full_Internal.htt'),
            'accepted_csv':(Path(accepted_csv),diag/f'{prefix}_Accepted.csv'),
        }
        stored={}
        for key,(src,dst) in {**visible,**internal}.items():
            if not src.is_file():raise FileNotFoundError(f'Result artifact is missing: {src}')
            shutil.copy2(src,dst);stored[key]=dst
        mfile=diag/f'{prefix}_Metrics.json';mfile.write_text(json.dumps(metrics,indent=2),encoding='utf-8')
        rh=s5.sha256_file(stored['result_htt']);eh=s5.sha256_file(stored['export_htt'])
        self.conn.execute("""UPDATE project_versions SET run_completed=1,preview_ready=0,baseline_trim_mae=?,baseline_trim_median=?,metrics_json=?,accepted_csv_path=?,result_htt_path=?,result_htt_sha256=?,export_htt_path=?,export_htt_sha256=?,result_txt_path='',result_txt_sha256='',summary_path=?,technical_path=?,completed_at=CURRENT_TIMESTAMP WHERE id=?""",
                          (float(mae),float(median),str(mfile),str(stored['accepted_csv']),str(stored['result_htt']),rh,str(stored['export_htt']),eh,str(stored['summary']),str(stored['technical']),int(v['id'])))
        self.conn.commit();self.record_event(pid,'VERSION_COMMITTED',f'V{version_no} results stored with .htt-only tune output. The next version is created only after a successful Build It export.',uid)
        return self.get_version(pid,version_no)
    DB.commit_version_result=commit_version_result

    def verify_full_successor_source(self,pid,source):
        """Require an entire original Tune File plus the prior applied change set.

        The HP Tuners customer export may intentionally contain only changed
        records.  Such an export MUST NOT become a later version's input .htt.
        Compare the complete switch/scalar/table record inventory with the
        project's untouched Version 0 original and reject any missing record.
        The caller separately authenticates the prior internal result hash.
        """
        from ve_optimizer_htt_codec import parse_htt, UnsupportedHTTFormat
        original=self.get_version(pid,0)
        if original is None:raise ValueError('Original V0 Tune File is unavailable.')
        first=Path(str(original['baseline_htt_path'] or ''))
        expected=str(original['baseline_htt_sha256'] or '')
        if not first.is_file() or not expected or s5.sha256_file(first)!=expected:
            raise ValueError('Original V0 full Tune File is missing or failed integrity verification.')
        try:
            base_doc=parse_htt(first.read_bytes())
            candidate_doc=parse_htt(Path(source).read_bytes())
        except (UnsupportedHTTFormat,OSError) as exc:
            raise ValueError(f'Cannot verify the complete inherited Tune File: {exc}') from exc
        def inventory(doc):
            return {kind:frozenset(r.key for r in doc.group(kind))
                    for kind in ('switch','scalar','table')}
        if inventory(base_doc)!=inventory(candidate_doc):
            raise ValueError('V0 applied data is not a full original Tune File. '
                             'A changed-record-only HP Tuners export must never be used as the next version baseline.')
        return True
    DB.verify_full_successor_source=verify_full_successor_source

    def create_successor_after_build(self,pid,version_no,uid,baseline_source=None):
        # Create the next blank project version only after Build It succeeds.
        # Licensed mode advances from the full applied internal result. DEMO mode
        # may provide the unchanged input/baseline .htt so project lineage matches
        # the file actually delivered to the user.
        self._assert_owner(pid,uid);pid=int(pid);version_no=int(version_no)
        v=self.get_version(pid,version_no)
        if not v or not int(v['run_completed'] or 0):raise ValueError(f'V{version_no} must have a committed result before the next version can be created.')
        if baseline_source is None:
            source=Path(str(v['result_htt_path'] or ''));sha=str(v['result_htt_sha256'] or '')
            lineage_note='full applied .htt'
        else:
            source=Path(baseline_source);sha=s5.sha256_file(source) if source.is_file() else ''
            lineage_note='unchanged DEMO input .htt'
        if not source.is_file() or not sha or s5.sha256_file(source)!=sha:raise ValueError(f'V{version_no} lineage source failed integrity validation. The next version was not created.')
        # The full internal Vn result (not the customer-facing selective .htt)
        # must inherit every record of the original V0 full engine Tune File.
        self.verify_full_successor_source(pid,source)
        next_no=version_no+1;existing=self.get_version(pid,next_no)
        if existing:
            if str(existing['baseline_htt_sha256'] or '')!=sha:raise ValueError(f'V{next_no} already exists with a different baseline. Project lineage was not changed.')
            stored=Path(str(existing['baseline_htt_path'] or ''))
            expected_location=self.version_dir(pid,next_no)/'Baseline.htt'
            if stored!=expected_location:
                raise ValueError(f'V{next_no} baseline path does not match its protected project storage.')
            if stored.exists():
                if not stored.is_file() or s5.sha256_file(stored)!=sha:
                    raise ValueError(f'V{next_no} baseline failed integrity validation. Project lineage was not changed.')
            else:
                # Safe idempotent restoration of a previously recorded successor
                # when its protected file was lost. Never overwrite differing bytes.
                shutil.copy2(source,stored)
                if s5.sha256_file(stored)!=sha:
                    try:stored.unlink()
                    except OSError:pass
                    raise ValueError(f'V{next_no} restored baseline failed integrity verification.')
                self.record_event(pid,'SUCCESSOR_BASELINE_RESTORED',
                                  f'V{next_no} missing protected Baseline.htt recreated from verified V{version_no} applied full Tune File.',uid)
            return self.get_version(pid,next_no)
        later=self.conn.execute('SELECT version_no FROM project_versions WHERE project_id=? AND version_no>? ORDER BY version_no LIMIT 1',(pid,next_no)).fetchone()
        if later:raise ValueError('Project version lineage is not sequential. Build It was blocked to protect continuity.')
        next_dir=self.version_dir(pid,next_no);baseline=next_dir/'Baseline.htt';shutil.copy2(source,baseline)
        if s5.sha256_file(baseline)!=sha:
            try:baseline.unlink()
            except OSError:pass
            raise ValueError(f'V{next_no} baseline copy failed integrity validation. The next version was not created.')
        self.conn.execute("INSERT INTO project_versions(project_id,version_no,baseline_htt_path,baseline_htt_sha256) VALUES(?,?,?,?)",(pid,next_no,str(baseline),sha))
        self.conn.execute("UPDATE project_setup SET log_source_path='',log_local_path='',log_sha256='',log_density_pass=0,log_validation_json='',updated_at=CURRENT_TIMESTAMP WHERE project_id=?",(pid,))
        self.conn.commit();self.record_event(pid,'NEXT_VERSION_CREATED_AFTER_BUILD',f'Build It completed for V{version_no}; V{next_no} created from the V{version_no} {lineage_note} with no Log File.',uid)
        return self.get_version(pid,next_no)
    DB.create_successor_after_build=create_successor_after_build

    def delete_project_tree(self,pid,uid):
        self._assert_owner(pid,uid);root=self.project_root(pid)
        for table in ('project_artifacts','project_runs','project_events','project_versions','project_setup'):
            self.conn.execute(f'DELETE FROM {table} WHERE project_id=?',(int(pid),))
        self.conn.execute('DELETE FROM projects WHERE id=?',(int(pid),));self.conn.commit();shutil.rmtree(root,ignore_errors=True)
    DB.delete_project_tree=delete_project_tree

    def delete_version_suffix(self,pid,uid,start_version):
        """Delete Vstart and every later version without orphaning lineage.

        V0 is the project root and may only be removed through whole-project deletion.
        When a suffix is removed, a fresh current workspace with the same start
        number is recreated from the last surviving completed parent's internal
        Full Engine result.  This preserves the Version 4 sequential chain.
        """
        self._assert_owner(pid,uid);pid=int(pid);start=int(start_version)
        if start<=0:raise ValueError('V0 is the project baseline. Delete the project root to remove V0 and its entire version tree.')
        versions=self.list_versions(pid)
        if not versions:raise ValueError('Project has no stored versions.')
        numbers=[int(v['version_no']) for v in versions]
        if numbers!=list(range(numbers[-1]+1)):raise ValueError('Project version lineage is not sequential. Deletion was blocked to protect continuity.')
        latest=numbers[-1]
        if start>latest:raise ValueError(f'V{start} does not exist in this project.')
        parent=self.get_version(pid,start-1)
        if not parent or not int(parent['run_completed']):raise ValueError(f'V{start-1} is not a completed surviving parent. Deletion was blocked to protect continuity.')
        parent_result=Path(str(parent['result_htt_path'] or ''))
        parent_sha=str(parent['result_htt_sha256'] or '')
        if not parent_result.is_file() or not parent_sha or s5.sha256_file(parent_result)!=parent_sha:
            raise ValueError(f'V{start-1} stored internal result failed integrity validation. Deletion was blocked.')

        root=self.project_root(pid);delete_numbers=list(range(start,latest+1))
        delete_dirs=[root/f'V{n}' for n in delete_numbers]
        # Stage a verified surviving-parent baseline outside the directories being deleted.
        rollback_tmp=root/f'._V{start}_baseline_recovery.htt'
        shutil.copy2(parent_result,rollback_tmp)
        if s5.sha256_file(rollback_tmp)!=parent_sha:
            try:rollback_tmp.unlink()
            except OSError:pass
            raise ValueError('Rollback baseline staging failed integrity validation.')
        fresh_dir=root/f'V{start}';fresh_baseline=fresh_dir/'Baseline.htt'

        # Precompute version-scoped audit rows before modifying the database.
        run_ids=[]
        for r in self.conn.execute('SELECT id,run_type FROM project_runs WHERE project_id=?',(pid,)).fetchall():
            m=re.fullmatch(r'VERSION_(\d+)',str(r['run_type'] or '').strip(),re.I)
            if m and int(m.group(1))>=start:run_ids.append(int(r['id']))
        artifact_ids=[]
        delete_dir_norm=[os.path.normcase(os.path.abspath(str(q))) for q in delete_dirs]
        for r in self.conn.execute('SELECT id,path FROM project_artifacts WHERE project_id=?',(pid,)).fetchall():
            ap=os.path.normcase(os.path.abspath(str(r['path'] or '')))
            if any(ap==d or ap.startswith(d+os.sep) for d in delete_dir_norm):artifact_ids.append(int(r['id']))

        try:
            self.conn.execute('BEGIN')
            if run_ids:self.conn.executemany('DELETE FROM project_runs WHERE id=?',[(x,) for x in run_ids])
            if artifact_ids:self.conn.executemany('DELETE FROM project_artifacts WHERE id=?',[(x,) for x in artifact_ids])
            self.conn.execute('DELETE FROM project_versions WHERE project_id=? AND version_no>=?',(pid,start))
            self.conn.execute('''INSERT INTO project_versions(project_id,version_no,baseline_htt_path,baseline_htt_sha256) VALUES(?,?,?,?)''',(pid,start,str(fresh_baseline),parent_sha))
            self.conn.execute('''UPDATE project_setup SET log_source_path='',log_local_path='',log_sha256='',log_density_pass=0,log_validation_json='',updated_at=CURRENT_TIMESTAMP WHERE project_id=?''',(pid,))
            self.conn.execute('''UPDATE projects SET baseline_trim_mae=?,baseline_trim_median=?,stage3_candidate_applied=1,updated_at=CURRENT_TIMESTAMP WHERE id=?''',(parent['baseline_trim_mae'],parent['baseline_trim_median'],pid))
            self.conn.commit()
        except Exception:
            self.conn.rollback();raise

        # Files are removed only after the database lineage has committed. A
        # filesystem cleanup failure can leave harmless orphan files, but cannot
        # leave the database pointing at a deleted surviving parent.
        for q in delete_dirs:shutil.rmtree(q,ignore_errors=True)
        fresh_dir.mkdir(parents=True,exist_ok=True)
        shutil.move(str(rollback_tmp),str(fresh_baseline))
        if s5.sha256_file(fresh_baseline)!=parent_sha:
            raise ValueError('Fresh rollback version baseline failed integrity validation after filesystem cleanup.')
        self.record_event(pid,'VERSION_SUFFIX_DELETED',f'V{start}-V{latest} deleted; rolled back to completed V{start-1}; fresh V{start} workspace recreated from V{start-1} internal result.',uid)
        return self.get_version(pid,start)
    DB.delete_version_suffix=delete_version_suffix

    def delete_all_user_projects(self,uid):
        ids=[int(r['id']) for r in self.conn.execute('SELECT id FROM projects WHERE created_by=?',(int(uid),)).fetchall()]
        for pid in ids:self.delete_project_tree(pid,uid)
        return len(ids)
    DB.delete_all_user_projects=delete_all_user_projects

    def recover_version_outputs(self,pid,version_no,destination):
        v=self.get_version(pid,version_no)
        if not v or not int(v['run_completed']):raise ValueError('That version has no stored review results to recover.')
        dest=Path(destination);dest.mkdir(parents=True,exist_ok=True);copied=[]
        export_raw=str(v['export_htt_path'] or '') if 'export_htt_path' in v.keys() else ''
        src=Path(export_raw) if export_raw else Path(v['result_htt_path'])
        if src.is_file():
            target=dest/src.name;shutil.copy2(src,target);copied.append(target)
        if not copied:raise ValueError('Stored .htt result is unavailable.')
        return copied
    DB.recover_version_outputs=recover_version_outputs

    # Candidate 3: preserve the product version supplied by the host application.
    # Version 4 lifecycle installation must not replace 1.0.1 with the historical
    # Stage 3 development identifier.
    current_version=str(g.get('APP_VERSION') or '1.0.1')
    g['APP_VERSION']=current_version
    g['s4'].APP_VERSION=g['s5'].APP_VERSION=current_version
