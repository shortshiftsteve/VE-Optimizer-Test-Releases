"""Select a recorded MAP pressure channel for either optimization method.

The generic VCM Scanner 'Manifold Absolute Pressure' channel is not an
acceptable calibration input. Prefer a logged, unit-valid alternative whose
values can actually be paired with Barometric Pressure. This module never
infers that MAP > Baro is an error: that can be real boost and requires the
existing hardware review.
"""
from __future__ import annotations

from bisect import bisect_right
import math
from typing import Dict

from ve_optimizer_logcheck import convert_value


BAD_MAP_NAMES = frozenset({
    'manifold absolute pressure',
    'manifold absolute pressure (sae)',
})


def _name(value):
    return ' '.join(str(value or '').strip().lower().split())


def _rank_map_name(name):
    n = _name(name)
    if n in BAD_MAP_NAMES:
        return None
    if n in ('map - hi-res', 'map - hi res', 'map - high resolution', 'map - high res'):
        return 0
    if n == 'sensed map':
        return 1
    if n in ('intake manifold absolute pressure (sae)', 'intake manifold absolute pressure'):
        return 2
    if n == 'calculated manifold absolute pressure':
        return 3
    return None


def _rank_baro_name(name):
    n = _name(name)
    if n in ('barometric pressure - hi res', 'barometric pressure - hi-res'):
        return 0
    if n in ('barometric pressure', 'barometric pressure (sae)', 'baro'):
        return 1
    return None


def _as_kpa(meta, value):
    if not isinstance(value, (int, float)) or not math.isfinite(value):
        return None
    try:
        x = convert_value('map', str(meta.get('unit', '')), value)
        return float(x) if math.isfinite(x) and x > 0 else None
    except (TypeError, ValueError):
        return None


def eligible_map_indices(channels: Dict[int, dict]):
    ranked = [(_rank_map_name(c.get('name')), i) for i, c in channels.items()]
    return [i for rank, i in sorted((rank, i) for rank, i in ranked if rank is not None)]


def _baro_indices(channels):
    ranked = [(_rank_baro_name(c.get('name')), i) for i, c in channels.items()]
    return [i for rank, i in sorted((rank, i) for rank, i in ranked if rank is not None)]


def select_hpl_map(decoded, *, boost_pratio_threshold: float = 1.06):
    """Validate alternatives against logged Baro, selecting one unambiguous source.

    Return a primary source and validated alternatives. A pair of positive,
    finite measurements at compatible timestamps is necessary. MAP > Baro is
    explicitly permitted: the boosted/NA distinction is handled separately.
    """
    channels = decoded['channels']
    candidates = eligible_map_indices(channels)
    baro_candidates = _baro_indices(channels)
    generic_present = [c.get('name') for c in channels.values()
                       if _name(c.get('name')) in BAD_MAP_NAMES]
    if not candidates:
        reason = ('The generic Manifold Absolute Pressure channel is not a valid MAP source. '
                  'Choose a different MAP channel in VCM Scanner.' if generic_present else
                  'No supported MAP pressure channel was recorded. Choose a different MAP channel in VCM Scanner.')
        return dict(valid=False, reason=reason, source=None, baro_source=None,
                    alternatives=[], generic_present=bool(generic_present))
    if not baro_candidates:
        return dict(valid=False, reason='No Barometric Pressure channel was recorded for MAP validation.',
                    source=None, baro_source=None, alternatives=[],generic_present=bool(generic_present))

    interested = set(candidates + baro_candidates)
    histories = {i: ([], []) for i in interested}
    for frame in decoded['frames']:
        t = int(frame['timestamp_ms'])
        for i, v in frame['updates'].items():
            if i in histories:
                histories[i][0].append(t)
                histories[i][1].append(v)
    baro = None
    for i in baro_candidates:
        ts, vs = histories[i]
        valid = [(t, _as_kpa(channels[i], v)) for t, v in zip(ts, vs)]
        valid = [(t, x) for t, x in valid if x is not None]
        if valid:
            baro = (i, [t for t, _ in valid], [v for _, v in valid])
            break
    if baro is None:
        return dict(valid=False, reason='Barometric Pressure has no valid pressure readings.',
                    source=None, baro_source=None, alternatives=[],generic_present=bool(generic_present))
    bi, bt, bv = baro
    verified = []
    for i in candidates:
        ts, vs = histories[i]
        count = 0
        over = 0
        above_boost_threshold = 0
        max_map = None
        max_ratio = None
        for t, v in zip(ts, vs):
            m = _as_kpa(channels[i], v)
            if m is None:
                continue
            j = bisect_right(bt, t) - 1
            if j < 0:
                continue
            b = bv[j]
            ratio = m / b
            if not math.isfinite(ratio):
                continue
            count += 1
            if m > b:
                over += 1
            if ratio > boost_pratio_threshold:
                above_boost_threshold += 1
            max_map = m if max_map is None else max(max_map, m)
            max_ratio = ratio if max_ratio is None else max(max_ratio, ratio)
        if count:
            verified.append(dict(channel_index=i, name=channels[i].get('name', ''),
                                 compared=count, exceeds_baro=over,
                                 boost_pratio_hits=above_boost_threshold,
                                 max_map_kpa=max_map, max_pratio=max_ratio))
    if not verified:
        return dict(valid=False,
                    reason='No alternative MAP source could be validated against Barometric Pressure. '
                           'Choose a different MAP channel in VCM Scanner.',
                    source=None, baro_source=channels[bi]['name'], alternatives=[],
                    generic_present=bool(generic_present))
    return dict(valid=True, source=verified[0], baro_index=bi,
                baro_source=channels[bi]['name'], alternatives=verified[1:],
                reason=None, generic_present=bool(generic_present))
