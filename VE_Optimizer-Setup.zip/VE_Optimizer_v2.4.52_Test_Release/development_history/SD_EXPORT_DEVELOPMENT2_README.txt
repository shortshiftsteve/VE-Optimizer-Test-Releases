VE OPTIMIZER 2.3.0 — HTT COMPATIBILITY DEVELOPMENT 2
STATUS: EXPERIMENTAL; NOT PRODUCTION-APPROVED

Source baseline: v2.3.0 HTT Compatibility Development 1.
User report: NN-enabled VCM Editor import is clean; NN-disabled Speed Density export marks unrelated unchanged calibration parameters.

ROOT CAUSE
- Speed Density output stores the complete Full Engine candidate as export_htt.
- The patcher's byte-exact restoration check proves only Bank 1/Bank 2 VE records are modified; it does NOT prevent VCM Editor from interpreting the presence of all other records as changes.

CHANGES
- New export_speed_density_changed_tables() constructs an experimental .htt template from the original version header, only altered VE table records (internal keys 44273 and 44274), and terminator.
- The internal candidate remains a full-engine .htt for processing, comparison and Results surfaces.
- Wideband SD and Adaptive SD primary and reduced (25%) export paths use the new template when no prerequisite calibration preparation or PRatio rescale was required.
- Workflows needing airflow/PE preparation or PRatio rescaling preserve the full-engine export; their extra required records must not be silently omitted. Such workflows remain potentially 'dirty'.
- NN-enabled workflow and solver/fuel-trim/HPL processing unchanged.

TESTING
- Python source compilation passed.
- 1 dedicated changed-only SD record test passed (on supplied 2023 5.7L Full Engine template), including local decoding, single changed-table selection, and byte-identical changed VE payload.
- 4 previous NN HTT safety tests passed.
- No VCM Editor Template Applicator test has been performed. Format acceptance of the minimal SD template is UNVERIFIED.

REQUIRED WINDOWS ACCEPTANCE
1. With Neural Network disabled, use a correction without airflow/PE preparation or PRatio regridding.
2. Build It; import the .htt result into VCM Editor on a disposable tune copy.
3. Confirm only changed VE Bank 1/Bank 2 tables are marked changed, and that the correct values import.
4. If VCM Editor rejects the import, preserve error text/screenshots. Do not apply it to a PCM.
5. Repeat with only one VE bank changed and both VE banks changed.
6. Separately test preparation and rescale scenarios before claiming all SD outputs are clean.

This is a format experiment, not a certified HP Tuners template representation.
