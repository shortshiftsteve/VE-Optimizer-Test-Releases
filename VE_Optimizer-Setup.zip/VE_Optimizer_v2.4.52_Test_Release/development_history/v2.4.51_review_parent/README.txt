VE OPTIMIZER v2.4.51 — REVIEW SOURCE / WINDOWS BUILD KIT
=========================================================
Date: 2026-10-15
APP_VERSION: 2.4.51 | BUILD_ID: 2.4.51-Review | Windows EXE: 2.4.51.0
PRIVATE REVIEW SOURCE/BUILD KIT. NOT A SIGNED WINDOWS INSTALLER.
NOT AN AUTHORIZED CUSTOMER RELEASE. NO GITHUB OR CLOUDFLARE PUBLICATION.

AUTHORITATIVE INPUTS
Stable production source: VE_Optimizer_v2.4.5_Release_Source.zip
SHA-256: 664831e5ba5da228d0f9ad24290f238afc163c6eb7d97c386b3bcf1b4433da0a
Authorized development patch: VE_Optimizer_v2.4.51_Updates_Installer_Development.patch
SHA-256: 8e089ed05e040862d542cc5589dc5c7198f12837abb5769cbefeb259d902727c
Release 2.4.5 remains stable and unchanged. It was based on the accepted
v2.4.5 Review Update 13. No later v2.4.5 Review changes have been reapplied.

APPROVED CHANGES, NOW IN THIS REVIEW CANDIDATE
1. Windows Inno Setup EULA memo uses the Refund Policy memo dimensions.
2. Help > Check for Updates reads published GitHub latest Release metadata
   and compares numeric release versions (with or without tag prefix v).
3. Customer must approve download and installation. Updater uses the matching
   version-specific VE-Optimizer-Setup.zip asset; checks ZIP restrictions and
   digest if supplied, and verifies signed Setup publisher/version on Windows.
4. An independent update helper closes the old app, backs up installed data,
   silently uninstalls the old application without prompting, retains all
   user projects/settings/license/trial data, starts standard interactive
   Setup at the same location, and uses normal postinstall application launch.
5. Normal user-requested uninstall offers YES = retain user information,
   NO = remove managed local VE Optimizer information including activation.
6. No tuning method, VE math, NN/Speed Density, VIN, HPL/HTT, selective export,
   project schema, signing policies, legal text or license validation changes.

CUSTOMER DISTRIBUTION (USER PUBLISHES RELEASES ONLY)
GitHub repository: https://github.com/shortshiftsteve/Software-Distribution
Release API: https://api.github.com/repos/shortshiftsteve/Software-Distribution/releases/latest
Asset name: VE-Optimizer-Setup.zip
Website: https://ve-optimizer.pages.dev/
Review builds are never automatically published. Existing v2.4.5 customers
need one manual upgrade to the first updater-enabled customer Release.

BUILD / FIELD ACCEPTANCE FROM FRESH EXTRACTION ON WINDOWS
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.51_Installer.bat
Expected only after successful native build and signing:
  installer\Output\VE Optimizer v2.4.51 Review Setup.exe

Before promotion to a customer Release: verify actual installer EULA/Refund
memo dimensions, GitHub metadata and real signed assets, UAC, Authenticode
publisher/version, version-specific ZIP, helper process permissions, managed
project preservation, custom install directory, manual-uninstall both choices,
and full VCM Editor/Scanner and Method A/B acceptance on Windows.
See BUILD_AND_RELEASE_CHECKLIST.txt and REVIEW_SOURCE_VERIFICATION_2.4.51.txt.
The prior 2.4.5 Release source verification is preserved unchanged under
  development_history/stable_v2.4.5_release_parent/.
