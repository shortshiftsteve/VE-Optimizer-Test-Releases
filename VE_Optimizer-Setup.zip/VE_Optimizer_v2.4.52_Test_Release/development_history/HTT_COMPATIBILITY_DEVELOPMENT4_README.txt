VE OPTIMIZER v2.3.0 — HTT COMPATIBILITY DEVELOPMENT 4
STATUS: EXPERIMENTAL USER TEST PACKAGE — NOT A PRODUCTION RELEASE

PRODUCTION BASELINE
- VE_Optimizer_v2.3.0_Release.zip, SHA-256:
  4c45269c263d98a083e99b1640462fc68ee1e290ee6f7830115b069bb1741320
- Development 4 builds on the previous Development 3 selective-export changes.
- v2.3.0 remains the product version; this is an experimental engineering checkpoint.

THE DEFECT FOUND
Development 3 concatenated changed calibration records after the 20-byte
'HPT R' header and appended eight zero bytes. The output was invalid because
it omitted the switch/scalar/table section counts, incorrectly captured two
bytes preceding each selected record, and omitted the required two-byte table
terminators at their proper locations. It did not honor the observed v3
container format, even though individual VE payloads were readable.

OBSERVED FORMAT (HPT R, version 3)
- 20-byte header.
- uint16 switch count; each switch is a key/flags/ULEB128 length/payload.
- uint16 scalar count; each scalar is a key/flags/float64/type byte.
- uint16 table count; each table is a key/flags/ULEB128 length/payload/
  two zero terminator bytes.
- Six zero bytes after the last table record.
This grammar was checked for lossless byte-for-byte reconstruction against:
- The supplied earlier full-engine 2023 Challenger 5.7L template.
- The VCM Suite-updated '5.7L with a Maggi' full-engine template.
- A 2016 6.4L full-engine template.
- A second 2023 5.7L full-engine template.
- Two older 5.7L/6.4L cam-only partial templates.
- The application's NN-only template (stock_nn.htt).
No unsupported VCM Suite format change was detected in the outer structure.

IMPLEMENTED
- New standalone safe codec: ve_optimizer_htt_codec.py.
- Read exact sections, counts, record boundaries, and trailers before export.
- Preserve complete original record bytes, including scalar type metadata and
  the two-byte suffix after each individual table.
- Compare every original/candidate record. Only these changed records may be
  written: Sensed MAP Enable switch 44433, PE Select switch 34229, Pressure
  Ratio Max scalar 18912, VE Banks 1/2 tables 44273/44274, and PE PRatio
  table 34243. An unrelated record change stops export.
- Group changed records by section and write accurate uint16 section counts.
- Verify generated file by exact parsed-record comparison and byte-for-byte
  parser/rebuild round trip before publishing atomically.
- Fail closed if the format version is unfamiliar or records are malformed.
- Do not overwrite original .htt files or full-engine candidate files.
- The complete candidate is still generated internally for verification.
- All applicable NN-disabled Adaptive SD, Wideband SD, Combined SD and reduced
  output paths continue using this shared exporter.
- Normal NN export is unchanged.
- Accepted fuel-trim rules, solver, correction mathematics, and HPL processing
  have NOT changed.

LOCAL VERIFICATION
- 79 tests passed in the local complete Python unittest discovery suite.
- Seven verified HP Tuners files reconstructed byte-for-byte.
- Additional tests cover changed bank selection, multiple tables, mixed switch/
  scalar/table, unrelated changes, invalid headers/counts/suffixes, duplicate
  IDs, no-op export, and source overwrite protection.
- Reframed the exact five calibration payloads from the rejected user's
  'Test 3 NN Off.htt' into the observed format for an optional VCM Editor test.

USER-SIDE ACCEPTANCE STILL REQUIRED
1. Use this Development 4 package to rerun NN-disabled processing.
2. Open the generated .htt in VCM Editor Template Applicator.
3. Confirm the file opens without 'Unable to open file. Invalid file'.
4. Confirm the Applicator includes ONLY intended changed calibration records,
   every intended record succeeds, and unrelated parameters remain unmodified.
5. Do not flash or drive on an output until its imported values have been
   independently checked against the original tune and the correction report.

If VCM Editor rejects the new template, preserve the screenshot and .htt.
Local grammar checks cannot conclusively prove VCM Editor import acceptance.
Do not promote Development 4 to the production release until accepted on the
actual user's VCM Suite and tune.
