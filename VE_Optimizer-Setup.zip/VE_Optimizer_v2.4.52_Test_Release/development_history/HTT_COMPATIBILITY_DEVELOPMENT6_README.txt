VE OPTIMIZER v2.3.0 — HTT COMPATIBILITY DEVELOPMENT 6
Date: 2026-10-09
Status: DEVELOPMENT / VCM EDITOR IDENTITY PREVIEW PENDING — NOT A PRODUCTION RELEASE

Production baseline: VE_Optimizer_v2.3.0_Release.zip
SHA-256: 4c45269c263d98a083e99b1640462fc68ee1e290ee6f7830115b069bb1741320
Development 6 continues Development 5; the accepted VE correction/solver methodology is unchanged.

USER-SUPPLIED PARAMETER IDENTIFICATION
VCM Editor ECM parameter ID reported for "Sensed MAP Enable": 2100.
Prior Development 4 grouped-export VCM Editor preview identified switch 44433
as "MDS Enable" — this parameter must NOT be used as Sensed MAP Enable.

DIRECT REFERENCE-FILE OBSERVATIONS
In the 5.7L with a Maggi after VCM Suite Update.htt:
- 2100: switch, Enabled
- 44433: switch, Disabled
In the previously supplied 2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt:
- 2100: switch, Disabled
- 44433: switch, Enabled
The updated Maggi calibration ALREADY has Sensed MAP enabled under the
user-provided 2100 mapping. No 2100 switch edit is needed in that calibration.

DEVELOPMENT 6 CHANGES
- Sensed MAP read/preflight now uses switch 2100, not 44433.
- Preflight checks the actual parsed HTT record kind (switch), and accepts only
  exact Enabled/Disabled text; an absent or unexpected record remains UNKNOWN.
- Where boosted preflight calls for Sensed MAP activation, it can prepare
  switch 2100 only from Disabled to Enabled; it never automatically disables it.
- Selective Speed Density export allows that one switch transition, in addition
  to the previously approved VE bank tables, PE and Pressure Ratio settings.
- MDS switch 44433 remains quarantined: any proposed change blocks export
  without overwriting an existing import file.
- Original full-engine candidates remain for internal verification; the user
  import template contains changed records only.
- Neural Network-enabled exporter, accepted half-step correction/solver, and
  .hpl log decoding are unchanged.

VCM EDITOR SEMANTIC PREVIEW — DO THIS FIRST
Preview file: VCM_2100_Sensed_MAP_Preview_Only.htt
This was built from the NEW Maggi VCM Suite export using exact record 2100
(Enabled); it has one switch and zero scalar/table records, with correct HPT R
v3 framing and no MDS or unrelated records.
Open it in VCM Editor Template Applicator, use Preview ONLY. Do NOT apply it
or flash anything. Verify the ONE switch is described as "Sensed MAP Enable",
not MDS or another parameter, and its value is Enabled.
If VCM Editor rejects a one-record switch template, that means this particular
single-record probe is not accepted; it does not by itself prove 2100 is wrong.
Please retain the screenshot in either case.

AFTER THE PREVIEW, run normal NN-disabled boosted processing and confirm:
- Only genuinely changed calibration records are listed.
- "MDS Enable" is not included unless it is a deliberately authorized change
  by a future explicit feature (none is authorized in this development).
- The output imports without failures; numeric changes agree with the intended
  VE / PRatio / PE correction report. No flash or driving validation is claimed.

LOCAL VERIFICATION
- 87 Python unittest tests passed, including eight new identity/safety tests.
- New tests confirm user-supplied ID 2100 exists as a switch in both source
  templates, old Disabled vs new Maggi Enabled, no change when already Enabled,
  permitted Disabled -> Enabled, MDS untouched, protective rejection of MDS,
  rejection of reverse/unknown transitions, and preservation of prior output.
- Full HPT R container parsing and binary round-trip verification retained.
- VCM Editor preview/import of Development 6 has NOT been performed here.

DO NOT treat previous Development 3/4 exported test files as valid calibrations.
Those packages are retained only for historical investigation and should not
be used to import or flash vehicle calibrations.
