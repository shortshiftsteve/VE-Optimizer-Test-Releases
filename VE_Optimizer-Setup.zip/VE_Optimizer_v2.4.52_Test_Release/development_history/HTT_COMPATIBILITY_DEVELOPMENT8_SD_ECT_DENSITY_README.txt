VE OPTIMIZER v2.3.0 — DEVELOPMENT 8: SPEED DENSITY ECT DENSITY FIX
Date: 2026-10-09
Status: DEVELOPMENT / WINDOWS UI ACCEPTANCE PENDING — NOT A PRODUCTION RELEASE

STARTING PACKAGE
  VE_Optimizer_v2.3.0_Development7_SD_Log_Validation.zip
PRODUCTION BASELINE (UNCHANGED)
  VE_Optimizer_v2.3.0_Release.zip
  SHA-256: 4c45269c263d98a083e99b1640462fc68ee1e290ee6f7830115b069bb1741320

REPRODUCTION / ROOT CAUSE
  The NN-disabled Speed Density screenshot showed Engine Coolant Temp (SAE)
  detected correctly with 377 native populated observations across 5:00,
  1.26 Hz effective density, and 100% temporal coverage, yet a red FAILED.
  Development 7 applied its generic >=1000-observation required-signal floor
  to ECT, implying a 3.33 Hz minimum for a five-minute log. That floor is
  inappropriate for the slow thermal-state channel in Speed Density mode.
  This was NOT a missing-channel or SAE channel-name-mapping error.

DEVELOPMENT 8 CHANGES
  1. In NN-disabled Speed Density ONLY, qualify Engine Coolant Temp using:
       >=1.0 populated ECT observation per second on average,
       >=30 populated ECT observations in total,
       >=90% temporal coverage (pre-existing gate),
       existing supported-unit validation.
     The required ECT count scales with actual log duration. For 300.0 s,
     minimum required is 300 observations; 377 spread through the recording
     qualifies. A missing ECT channel, insufficient observations, or poor
     temporal coverage still fails.
  2. The recommended polled counterpart for ECT in Speed Density is now
     500 ms / 2 Hz, instead of 10 ms / 100 Hz. Broadcast channels still
     use 0 ms as in the accepted guidance.
  3. Both Engine Coolant Temp and Engine Coolant Temp (SAE) remain recognized.
  4. Validation results now include a policy revision. On viewing Validation
     Details for an existing project, obsolete cached profiles are recomputed
     against the stored log and active Full Engine .htt, even when the airflow
     model is unchanged. Correction-source qualification also rejects stale
     report policies and recalculates validation.
  5. Updated the static recommended-channel guidance with the Speed Density
     coolant exception; Neural Network guidance remains unchanged.

UNCHANGED / SAFETY
  - NN-enabled ECT requirement remains >=1000 populated observations,
    subject to the established coverage gate.
  - Actual accepted processing ECT >164 F conditioning is NOT changed.
  - Fuel Flow remains DEGRADED advisory in generic Speed Density validation;
    adaptive-specific Fuel Flow and other correction-source gates remain.
  - >=5-hit qualification, 50%-step corrections, fixed-point NN and solver,
    native .hpl decoding, and all .htt export/safety code are unchanged.
  - Development 6 selective .htt export and ECM 2100 / MDS 44433 safeguards
    remain intact.
  - Production v2.3.0 Release, installer and signing are unchanged.

LOCAL VERIFICATION
  74 tests passed plus 7 subtests in the focused and broader compatibility,
  validation and UI regression run. 20 fixture-dependent tests skipped.
  The literal screenshot conditions were reproduced using a synthetic
  300.0-second log with 377 distributed ECT updates, both native/SAE names,
  and a missing Fuel Flow Rate: ECT=PASS, Fuel Flow=DEGRADED, no ECT block.
  Sparse and clustered ECT updates remain failures. The same 377-event log
  fails the unchanged NN-enabled ECT density floor. Stale policy requalification
  has its own regression. Python syntax compilation succeeds.
  A complete end-to-end release suite and the user's exact 5-minute HPL file
  were NOT run. Windows UI acceptance is still pending.

WINDOWS ACCEPTANCE
  1. Open Development 8 using the original NN-disabled Maggi calibration and
     the same 5-minute log shown in the reported Validation screenshot.
  2. Open Validation Details in the existing project; do not create a new log.
  3. Verify Engine Coolant Temp (SAE) -> PASS, 377 updates, ~1.26 Hz,
     Minimum ~1.00 Hz, 100% coverage, Polled setup 500 ms / 2 Hz.
  4. Verify Fuel Flow Rate remains DEGRADED when missing, NN-required cam and
     LTFT channels remain absent, and final correction-source preflight still
     controls actual processing eligibility.
  5. This is channel qualification validation; do not infer safe vehicle
     operation or completed HP Tuners export acceptance from these tests.
