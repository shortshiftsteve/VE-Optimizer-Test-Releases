VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 6
=======================================
Parent: VE_Optimizer_v2.4.0_UI_Development5_Source.zip
Parent SHA-256: a203199d43cf2a8e9c91cbd1f053a11bd8071843e39a7d798bd899c66cfddda0

USER-REQUESTED REVISIONS
1. Existing project Version 1+ Build: the large native HPL revalidation,
   hashing and copying into the version's protected storage now execute in a
   background worker with that worker's own SQLite connection. The Tk UI
   event loop remains free for display and inputs. This addresses a known
   source-level cause of Windows "Not Responding" during large-log Build.
2. A single-flight Build guard prevents duplicate submission from rapid
   double clicks, queued button events, or direct repeated invocation.
   Build, Submit, Tune File and Log File selection controls are disabled
   during staging and restored after completion/failure. V0 staging uses
   the same guard. Busy progress appears in the existing lower panel.
3. The final qualified Correction Source button is "Run", not "Continue
   to Run/Review". It opens the normal Run/Review display and starts the
   existing worker directly (one click). Existing correction-source and
   MAP/PE readiness checks remain in force. Run is disabled without a
   qualified source and duplicate launch requests are ignored.

PROCESSING SAFETY
- Existing Method A NN, Method B Speed Density, solver, fixed-point,
  HPL/HTT decoding, MAP validation, target math and export paths unchanged.
- Existing V0/V1 full .htt baseline/lineage integrity checks unchanged.
- UI changes are restricted to the UI/coordinator source and associated tests.
- Product version and Windows installer/build scripts remain 2.4.0.

VERIFICATION
- New Development 6 UI tests: 6 passed (single-flight, off-main-thread
  large-log simulation, responsive UI pump, direct Run, disabled Run, and
  pending hardware-review gate).
- Six split graphical regression runs: 206 passed, 43 skipped,
  6 additional subtests passed, zero failures.
- Previously monolithic test process completed test cases but did not
  exit cleanly, so that unclean run is not counted as passed.
- Four heavy numerical-only regression suites intentionally excluded,
  consistent with prior Development 5 partial-regression scope.
- Python source syntax compilation passed.
- Manifest-listed SHA-256 checks must all pass before shipping.

UNVERIFIED / FIELD CHECKS
- User's actual large V1 log has not been run through this build on Windows.
- A "Not Responding" condition could have another cause; no field resolution
  claim is made until that actual workflow passes.
- Windows .exe and Authenticode-signed installer not built here.
- Complete numerical regression and native HP Tuners output acceptance remain
  outstanding and are not implied by these UI tests.

STATUS: UI DEVELOPMENT 6 — SOURCE BUILD CANDIDATE, WINDOWS ACCEPTANCE PENDING.
