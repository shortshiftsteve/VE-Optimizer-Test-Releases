VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 4
====================================

PARENT SOURCE
VE_Optimizer_v2.4.0_UI_Development3_Source.zip
SHA-256: be86c612069a847e1fdc2a3164ec71e913444dffe347aae4adce08be0d196cbf
The application version remains 2.4.0. This is the next UI-only source
candidate, not a compiled or signed Windows installer.

THREE ACCEPTED FIELD-SCREEN CHANGES

1. Visible progress when processing is outside the viewport
   - The lower panel now shows a persistent, fixed-position progress strip.
   - During Log File validation, approved missing-knock requalification,
     project staging and Correction Preflight, it reports the active process
     with an indeterminate bar. No invented percentage is shown.
   - During correction processing, the strip displays the real overall
     percentage, current step (of five), and detail supplied by the existing
     solver callback. Completed stages are recorded in Processing Quality.
   - The bar remains visible when the details below it are scrolled, and it
     displays completion/error states without flashing WORKING text.
   - The previous full-screen blinking Setup overlay and blinking action
     labels are no longer used on the approved three-panel workspace.

2. Scope of Log File validation View button
   - View remains available during initial Log File qualification only.
   - When correction preflight or Run/Review begins, View no longer appears
     above the lower panel. Its underlying channel-validation function is
     retained; only the redundant later-stage control is hidden.

3. Run / Review and Results control placement
   - The lower-panel Run / Review action row and Results button are removed.
   - The right message panel dynamically hosts Run before processing and
     Results after a verified review. While processing is active, the action
     is disabled and does not blink. The right panel changes from
     RUN / REVIEW to REVIEW COMPLETE when results are ready.
   - The lower panel remains the scrolling home for quantitative progress,
     verification metrics and live step-completion activity.

UNCHANGED BASELINES
Method A and Method B eligibility, correction-source selection, knock
approval, MAP hardware checks, VE solver, fixed-point math, training assets,
HPL decoding, HTT export, license checks and EULA remain unchanged from
UI Development 3. No version number or customer-facing process changed.

VALIDATION LIMITS
The updated Tk screens and interaction states were tested on a headless
Linux graphical runtime. All native Windows installer, signing, VCM Editor
Template Applicator and field acceptance checks remain pending.
