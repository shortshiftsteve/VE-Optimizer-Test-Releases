VE Optimizer v2.4.0 UI Development 11 — source/build kit.
This package is derived ONLY from UI Development 10, with Results UI edits.
Windows installer compilation and signing remain pending.
Run the existing installer\Build_VE_Optimizer_v2.4.0_Installer.bat on the
configured Windows build/signing machine.

Changes: Build It beside Apply Changes (disabled until applied); PE tab with
PRatio/Aircharge original/candidate views and existing 2D/3D, New/Old/Delta.
See UI_DEVELOPMENT11_VERIFICATION.txt for detailed tests and limitations.
