VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 5
====================================
Parent: VE_Optimizer_v2.4.0_UI_Development4_Source.zip
Parent SHA-256: 154ac02fcbc1ca1331b5dea2cca65609f6f0b76c31739becf5537cb9b010fe87

USER-REPORTED WINDOWS ISSUES

1. Duplicate Run/Review progress
   - During the accepted three-panel Setup workflow, only the existing fixed
     lower-panel progress strip is displayed. It remains visible outside the
     scrolling processing detail. The second in-scroll progress bar, repeated
     step text and associated empty progress card are removed.
   - Standalone Run/Review pages retain their existing standalone progress.

2. V1+ Log File qualification fails with false missing .htt message
   - Found a background-thread violation. The Log File validation worker
     previously re-read the active version's baseline using a main-thread
     SQLite connection, swallowed the exception and could then claim the
     full Tune File was missing.
   - The UI now resolves the project Vn Tune File and verifies its stored
     SHA-256 on the main thread before starting the worker. The worker
     receives that fixed path/hash and never reopens project SQLite or Tk
     state to discover the Tune File. A changed or missing source fails closed.
   - For licensed/trial builds, V1 is created from the V0 committed full
     internal .htt candidate, which includes the original complete V0 record
     inventory plus applied V0 calibration changes. V1 does not use the
     changed-record-only HP Tuners export. V0 original remains immutable.
   - Successor creation checks the original V0/full-result record inventory
     and both source and copied baseline digests. Existing V1 baselines may
     be restored if their protected file is missing AND their stored digest
     exactly matches the verified full parent result; corrupted or mismatched
     files are never overwritten silently. DEMO lineage remains unchanged
     (the unchanged original input becomes the successor).

ACCEPTED PROCESSING UNCHANGED
No changes were made to Method A/B math, NN activation/scaling, VE solver,
STFT/Wideband correction, MAP/PE processing, HPL decoder, .htt export codec,
license enforcement, installer, training calibration values or EULA.

TESTS & LIMITS
Development5 focused: 5 tests passed (including full-Tune V0->V1 record
inventory, missing-baseline restoration and actual worker-thread Tk test).
Combined non-heavy suite: 202 passed, 43 skipped, 6 additional subtests,
0 failures. Native Windows installer, field behavior and VCM Editor .htt
import/vehicle acceptance remain unverified. Heavy standalone numerical solver
suites were not rerun. V1 native HPL sample was parsed as Method A using
synthetic full applied source; log qualification itself did not pass and is
not represented as accepted tune data.

This ZIP is the updated SOURCE/BUILD KIT and is NOT a customer installer.
Application version remains 2.4.0.
