VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 8
=======================================
Parent: VE_Optimizer_v2.4.0_UI_Development7_Source.zip
Parent SHA-256: 6685509b24a87df3d80484cca54561f87e61ecf99f51105ae6e7f085b68be2d4

USER CHANGE
Processing Quality -> Correction source reported "Adaptive Fuel Trims" during
Speed Density (Method B) processing, although Method B uses STFT only.

IMPLEMENTATION
- When selected source ID is "adaptive" and active airflow model is
  "speed_density", present the correction-source label as "STFT".
- Neural Network (Method A) retains "Adaptive Fuel Trims" as appropriate.
- Wideband retains "Wideband O2".
- Apply the same label rule to current and stored/loaded result metrics.
- Historical source IDs, calculation inputs, solver, data qualifications,
  stored calibration records, export and version lineage remain untouched.

SCOPE AND VERIFICATION
- Only ve_optimizer_revision9_review.py modified among previous source files.
- One dedicated four-case display-label test file added.
- Focused UI/method regression: 46 passed, 16 skipped, no failures.
- Source syntax compilation and archive manifest/SHA-256 checks required.
- Full continuous numerical regression and real Windows installer field
  acceptance not repeated for this display-only change.
- No changes to product version, licensing, legal notices or installer scripts.

STATUS: UI DEVELOPMENT 8 SOURCE BUILD CANDIDATE — WINDOWS FIELD ACCEPTANCE PENDING.
