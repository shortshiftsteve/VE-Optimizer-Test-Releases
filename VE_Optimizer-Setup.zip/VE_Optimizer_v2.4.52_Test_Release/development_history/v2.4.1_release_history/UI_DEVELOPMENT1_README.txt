VE OPTIMIZER v2.4.0 — APPROVED START-SCREEN UI DEVELOPMENT 1
=============================================================

This package applies the approved UI to the original v2.4.0 Release
source/build kit. Application identity remains Version 2.4.0 Release.
This is an unsigned DEVELOPMENT source/build candidate, not a customer installer.

The upper-right panel is a dynamic message host. On opening, its current
message is a centered WARNING with the user's exact emissions disclaimer.
That warning is not a static Setup widget: it is replaced completely as soon
as another message, warning or review prompt is posted. Headings and content
can vary; the panel itself remains in place. The lower panel is reserved for
process information and is blank until an actual process event occurs.

Traditional File/Edit/Tools/Help menu, upper-left Vehicle Info, empty lower
panel, no sidebar, no Setup title/subtitle, no customer photo, no Settings
photo control, and no redundant channel buttons follow the accepted preview.
Submit remains visible. Build/Validation appear only when relevant.

There is no Project Name field in Setup. When the Build action is available
and selected for a new project, the existing required project name is requested
in a small input dialog, maintaining explicit naming and database validation.

All existing log validation, NN, Speed Density, PE and Wideband processing
methods remain unchanged. Other (non-Setup) screens retain their existing
working content and are accessible through the new top menus while subsequent
UI development is pending.

See UI_DEVELOPMENT1_VERIFICATION.txt for actual tests and remaining limits.
Build on the existing configured Windows build/signing computer using
installer\Build_VE_Optimizer_v2.4.0_Installer.bat when ready.
