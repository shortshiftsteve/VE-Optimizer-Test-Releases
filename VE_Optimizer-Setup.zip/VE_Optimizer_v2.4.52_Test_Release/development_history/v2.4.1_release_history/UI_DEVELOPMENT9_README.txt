VE OPTIMIZER 2.4.0 — UI DEVELOPMENT 9 SOURCE CANDIDATE
===================================================
Parent package: VE_Optimizer_v2.4.0_UI_Development8_Source.zip
Product/app version: 2.4.0 Release (unchanged)

Approval: User approved the VCM Scanner-inspired three-panel design preview on
2026-10-11, following the five preceding screenshot instructions.

IMPLEMENTED USER-APPROVED ITEMS
1. Build It naming: append _V0, _V1, etc. after the user's project name;
   example: Fred 1_V0.htt for V0; Fred 1_V1.htt for V1. The selected
   export location remains user-controlled. Existing internal full-tune
   baseline names and the accepted selective-export logic remain unchanged.
2. MAP review: remove the long summary and the exposed MAP1/MAP2 calibration
   radio controls. Preserve internal Tune File sensor values and all explicit
   hardware, Sensed MAP, PE, and sensor-scaling confirmation guards.
3. Progress: retain ONE bar, pin Progress with activity text at the top of
   the scrollable lower-panel processing area, remove duplicated activity in
   Processing Quality, and condense eight informational tiles into one row.
4. Approved appearance: Windows-native Microsoft Sans Serif controls within
   navy/blue visual panels, white vehicle-entry surface, dark processing and
   summary headers, compact spacing. This is an application UI change, not
   a change in solver, fuel, or calibration logic.
5. Performance Summary: Max RPM, Max Torque (lb-ft), and Max HP from the
   actual native HPL. Peak torque is converted from the HPL signal unit;
   estimated peak HP uses torque x RPM / 5252 for time-matched positive
   torque/RPM samples, with at most 250 ms staleness to handle sparse logging.
   Peak HP is NOT computed from separately observed peak RPM and torque.
   Log-derived peaks are engine-computer estimates, not dynamometer data.
   Measurements persist independently for each project version keyed to the
   exact log SHA-256, and V1+ shows differences against the previous version.
   Missing channels or sufficiently synchronized data show unavailable values.
   Existing historical versions may populate their summaries when their stored
   logs are next processed by the updated application.

SECURITY AND SAFETY
- Corrected values, VE mathematical processing, Method A/Method B correction
  algorithms, coefficient quantization and the native HPL/HTT decoding remain
  unchanged. No additional numeric tuning gates or calibration edits.
- Performance calculations are informational and do not gate calibration.
- Version lineage continues to inherit the FULL applied Tune File, never the
  selective customer .htt export. Existing hashes and integrity gates remain.
- The permanent body of the upper-right pane remains an event-specific message;
  the performance summary is a separate persistent informational section.
- No product version upgrade was made. Authenticode signing, real Windows
  installer build, and in-vehicle/VCM Editor field acceptance are outstanding.
