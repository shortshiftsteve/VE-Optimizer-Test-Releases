VE OPTIMIZER v2.4.1 — CHANNEL LIST DEVELOPMENT 1
==================================================

SOURCE BASELINE
  VE_Optimizer_v2.4.1_Release.zip
  SHA-256: 2d020a832193c68a6461aadc8c09be9e1ca8236f6b5713b2b6bb6ac94a5cee40
  This development candidate preserves the 2.4.1 release identity; it does not
  replace the original release archive or assert a newly signed Windows release.

USER-REQUESTED FEATURE
  New Tools -> Channel List menu item in the existing Windows GUI.
  Bundled application resource:
    help/Updated VE Optimizer Channels.Channels.xml
  Bundled XML SHA-256:
    9d5ee8ccadc9f586cfe4c7e9e985b376a3d549020a59c213bfbac934025b9693
  This resource is copied byte-for-byte from the user-provided XML. Its
  Channel IDs, polling intervals and other XML attributes are not edited.

BEHAVIOR
  - Tools -> Channel List copies the bundled file to the logged-in Windows
    user's Downloads folder. The Windows Known Folder API is used to honor a
    redirected Downloads folder, with a standard home-folder fallback.
  - The downloaded filename remains unchanged.
  - SHA-256 of the bundled source and the copied destination is validated.
  - An up-to-date destination is left untouched.
  - Replacing a different existing file requires explicit Yes confirmation.
  - Success, already-current, errors and cancellation are handled in the GUI.
  - The menu action does not require a Tune File, Log File or network connection.

PACKAGE AND BUILD
  - The preexisting PyInstaller spec already includes the help/ directory,
    which now holds the XML. The new Python export helper is imported by the
    main GUI coordinator and therefore included by normal PyInstaller analysis.
  - No modification to the PyInstaller spec, installer/signing scripts, legal
    files, calibration engines or processing code is needed.
  - Build normally with installer/Build_VE_Optimizer_v2.4.1_Installer.bat on
    the configured Windows build and Azure signing machine.

TEST EVIDENCE (THIS DEVELOPMENT SOURCE)
  - Focused Channel List suite: 9 passed.
  - Complete available graphical pytest suite (Xvfb): 259 passed, 43 skipped,
    and 14 additional subtests passed; no failures.
  - Python compile and application --smoke-test: passed.
  - Release version preflight: passed for 2.4.1.
  - Manifest/source ZIP SHA-256 audit: see package verification.

NOT PERFORMED IN THIS ENVIRONMENT
  - Native Windows installer compilation or signature verification.
  - Real Windows Known Folder Downloads write and UI confirmation.
  - Actual HP Tuners VCM Scanner channel-list import.
  - Vehicle-based or customer field acceptance.

WINDOWS ACCEPTANCE
  1. Build and sign the installer using the existing approved build process.
  2. Launch VE Optimizer and select Tools -> Channel List on an idle Setup page.
  3. Confirm Updated VE Optimizer Channels.Channels.xml appears in Downloads.
  4. Check SHA-256 against the bundled XML digest above.
  5. Select Channel List again (already-current message); replace the file with
     different content and test the No and Yes overwrite decisions.
  6. Import the resulting channel list into HP Tuners VCM Scanner and verify
     its channel configuration. No scanner import has been tested here.
