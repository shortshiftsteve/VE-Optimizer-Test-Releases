VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 7
=======================================
Parent: VE_Optimizer_v2.4.0_UI_Development6_Source.zip
Parent SHA-256: 5a1ab8ca6678ad062afe5988faf9111fa686cd6981b9817d4f9fa0b1b85b70ae

FIELD DEFECT
A completed Version 1 review could show REVIEW COMPLETE / Results and
simultaneously raise this misleading Setup dialog when a late or repeated
Run callback arrived:
  "Select the current version and a qualified Log File before running the review."

ROOT CAUSE
The start_review handler required the project to still be READY_TO_RUN.
A successful review legitimately changes the database to READY_TO_APPLY,
or READY_FOR_REVIEW after application. A stale Run event was therefore
incorrectly diagnosed as missing Setup, despite an available stored result.

USER-REQUESTED CORRECTION
1. Reject redundant Run requests immediately while a worker or Build is active.
2. Recognize READY_TO_APPLY / READY_FOR_REVIEW as completed states only when
   a matching verified application payload is available for the active version.
3. Keep REVIEW COMPLETE and its Results action unchanged on a late Run event,
   or show the existing Results action when navigation needs refreshing.
4. Prevent the correction-source Run action from launching a second review
   once the current version already has a stored completed candidate.
5. Continue to block genuinely unqualified or incomplete V1 inputs and show
   their accurate SETUP REQUIRED explanation in the upper-right message panel
   instead of a misleading modal dialog.
6. Tolerate partial UI test objects which have no project attribute.

PROCESSING SAFETY
- No changes to HPL decoding, .htt baseline lineage, Method A/B qualification,
  NN optimization, Speed Density/wideband math, coefficients, MAP/PE logic,
  licensing, build scripts or exported calibration records.
- Existing build single-flight and direct Run behaviors remain established.
- No project data or customer .htt/.hpl files are shipped in this archive.
- Product and Windows metadata retain version 2.4.0.

VERIFICATION
- New Development 7 tests: 5 passed. Tests include a real SQLite V0/V1
  saved-candidate state (using packaged test bytes, no optimizer execution),
  a late Run callback after completion, queued Run after completed review,
  duplicate callback during an active worker and fail-closed missing setup.
- Focused graphical regression split into seven groups: 211 passed,
  43 skipped, six additional subtests passed; zero failures.
- Four heavy standalone numerical-only suites are excluded from this scope,
  as they were in Development 6. Full numerical regression not rerun.
- Source Python syntax compilation passed.
- Parent/source comparison: only the UI/coordinator module changed among
  previous files. All other original application Python modules identical.
- ZIP integrity and each manifest-listed SHA-256 checksum verified after build.

OPEN FIELD ACCEPTANCE
- The user’s real saved V1 project and full Windows log were not available
  in this sandbox. The exact on-vehicle V1 Run/Results workflow is not field-accepted.
- Windows installer/executable not compiled or Authenticode-signed here.
- Calibration output/VCM Editor checks not repeated; no tuning safety claim.

STATUS: UI DEVELOPMENT 7 SOURCE BUILD CANDIDATE — WINDOWS FIELD ACCEPTANCE PENDING.
