VE OPTIMIZER 2.4.0 — UI DEVELOPMENT 10 SOURCE CANDIDATE
======================================================
Parent package: VE_Optimizer_v2.4.0_UI_Development9_Source.zip
Product version: 2.4.0 Release (unchanged)
Status: Source/build kit. Windows installer build, signing, and field acceptance pending.

APPROVED GUI CHANGES
1. Opening emissions WARNING: preserve exact approved warning text, use a centered
   WARNING heading, and display larger, bold, left-justified, word-wrapped body
   text inside the upper-right message area. It remains a replaceable message,
   not permanently embedded content.
2. Missing knock-data confirmation: preserve the previously approved wording,
   use a centered KNOCK DATA NOT FOUND heading, left-justified/word-wrapped body,
   and show the existing Yes / No controls alongside the message. The existing
   naturally aspirated closed-loop-only qualification gate is unchanged.
3. Replace the Performance Summary label and the individual delta/% display
   with a compact history matrix headed V0 (Baseline), V1, V2, V3 and additional
   columns as required. Rows: Max RPM, Max Torque (lb-ft), Max HP. Never display
   invented sample values or performance-comparison percentages.
4. During processing of V1 and higher, previously processed and saved versions
   remain visible. A newly staged Log File's column remains blank until its
   review is verified (preview_ready) or the version is applied (run_completed).
   Version metrics remain tied to the exact native HPL SHA-256. The table can
   scroll horizontally for additional project versions.
5. Preserve the accepted dark navy / blue three-panel appearance, Windows menu,
   vehicle form, lower Progress area, and independent Processing Quality data.

CALIBRATION AND PROCESSING
- No change to Method A, Method B, NN solvers, VE fixed-point arithmetic, PE,
  MAP qualification, native HPL decoder, HTT codec, output calibration,
  version lineage, or installer/license logic.
- Existing read-only HPL performance calculations remain unchanged, including
  unit conversion and contemporaneous Torque x RPM / 5252 horsepower estimate.
- No performance field is a calibration/correction/acceptance gate.

FILES CHANGED
- ve_optimizer_revision9_review.py (message presentation and performance table)
- tests/test_ui_development10_messages_and_versions.py (new UI/history tests)
- This README and UI_DEVELOPMENT10_VERIFICATION.txt
