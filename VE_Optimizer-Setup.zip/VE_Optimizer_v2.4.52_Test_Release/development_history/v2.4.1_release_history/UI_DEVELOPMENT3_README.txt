VE OPTIMIZER v2.4.0 — UI DEVELOPMENT 3
====================================

SOURCE BASELINE
Current change set is based solely on:
    VE_Optimizer_v2.4.0_UI_Development2_Source.zip
SHA-256:
    803cc234e91022f354fbddf49c251a78cf90bf8397ac18c3ef6f3ba04f7bdd97
The original 2.4.0 Release archive and all accepted processing specifications remain unchanged.

FIVE ACCEPTED SCREENSHOT CHANGES

1. Windows installer EULA checkbox:
   "   I have read and I understand the End User License Agreement"
   The prior long acknowledgement sentence has been removed. The
   explicit checkbox and the Next-button acceptance gate are preserved.

2. Missing-knock message:
   The upper-right pane shows heading KNOCK DATA NOT FOUND, with the
   user's exact wording centered:
   "The current log file does not include montioring knock status.
   Without this information, it would be too risky to attempt anything
   other than a closed loop tune. Wide Open Throttle, (WOT), data will
   not be included. Select Yes to proceed or No to select a different
   log file."
   Yes retains the prior explicitly approved NA closed-loop-only gate.
   No does NOT authorize an alternate source; it clears the unapproved
   log selection and opens the .hpl file picker for a different log.
   The zero-FA-enrichment/zero-PE restriction and no-WOT rule are
   enforced in the existing log qualification/processing modules.

3. Processing Quality panel:
   Removed the generic explanatory statement beginning "This panel is
   used for every correction method". The quantitative cards, live
   processing activity and quality metrics are preserved.

4. MAP hardware review:
   The separate MAP/PE confirmation popup and its lower-panel Review
   button are removed. The upper-right message area now hosts a scrollable
   MAP / POWER ENRICHMENT REVIEW form with hardware choice, sensor choice,
   MAP1/MAP2 value comparison, editable proposed specifications,
   Use Current Values, optional logged-voltage estimate, and Confirm and
   Continue. The existing safeguards for invalid MAP, 1-bar boosted
   sensors, Sensed MAP, PE selector, and Tune File scaling remain.
   Confirmation is explicit. No calibration data are written by review.

5. Correction source:
   The STFT/adaptive versus Wideband choice is entirely in the upper-right
   message area, along with Continue to Run/Review. The old source card
   and redundant Continue buttons have been removed from the lower panel.
   The lower panel remains dedicated to scrollable correction preflight
   evidence and subsequent processing. Combined correction is not offered.

PREVIOUSLY ACCEPTED UI
Three-panel workspace, Microsoft Sans Serif, replaceable right-hand
messages, scrollable lower panel, deferred permanent project naming,
submit-to-build workflow and View-on-demand log validation remain intact.

CHANGED PRODUCTION FILES RELATIVE TO DEVELOPMENT 2
    ve_optimizer_revision9_review.py  (GUI + workflow coordinator only)
    installer/VE_Optimizer_v2.4.0.iss (EULA checkbox caption only)
No solver, VE calculation, HPL/HTT codec, training asset, MAP science,
PE processing, STFT/Wideband processing, licensing, or purchase module changed.

PACKAGE STATUS
UI Development 3 is a tested source/build candidate. It is not a native
Windows installer or a signed customer package. Windows GUI, installer
EULA presentation, field workflow, and VCM Editor acceptance still need
Windows-side confirmation. The app and release version remain 2.4.0.
