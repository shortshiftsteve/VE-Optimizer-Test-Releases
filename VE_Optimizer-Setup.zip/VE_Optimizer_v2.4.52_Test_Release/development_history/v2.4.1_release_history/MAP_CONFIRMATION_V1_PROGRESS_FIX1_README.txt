VE OPTIMIZER 2.4.1 — MAP CONFIRMATION / V1 PROGRESS FIX 1
================================================================

PARENT SOURCE BASELINE
  VE_Optimizer_v2.4.1_ChannelList_Dev1_Source.zip
  SHA-256: 4c635ea9634a4bb2db18475ef5d3a554311a29d07b63e2b0f93b02624348b413
  Version identity remains 2.4.1 Release, with Channel List included.

CHANGE 1 — BOOSTED MAP SENSOR CONFIRMATION
  When logged MAP/PRatio exceeds Baro, require explicit verification that
  the installed physical MAP sensor matches the current Tune File settings.
  The current MAP1/MAP2 tuning scalars and Dodge Hellcat 2-bar references are
  displayed read-only. A label notes when MAP sensor voltage was not logged.

  No longer ask which compressor type is installed (Supercharger/Turbo/Neither),
  ask for a 1/2/3-bar sensor type, or permit proposal/voltage estimation edits.

  For non-Hellcat-reference Tune Files, ask:
    "Have you positively verified that a non-standard MAP sensor is installed
     and its specifications match the Tune File settings?"
  For verified Hellcat-reference Tune Files, ask confirmation that the installed
  Hellcat 2-bar sensor matches the tune instead of mislabeling it non-standard.

  YES — Recheck correction preflight with explicit user confirmation bound to
  the active project version, tune hash and log hash. Do not change MAP data.
  Existing sensed-MAP and PE routing safeguards remain in effect.

  NO — Revoke approval, clear active preflight/source selection, and STOP.
  Display the conditional Hellcat 2-bar reference:
    MAP Sensor Linear: 45.4200 kPa/V
    MAP Offset: 7.0000 kPa
    MAP Sensor Offset: 0.1001 V
  The physical sensor MUST be checked. Apply this reference only for an actual
  matching Hellcat 2-bar sensor; for other sensors use verified manufacturer
  specifications. Save a NEW .htt and record a NEW native .hpl before continuing.
  The refusal and correct reference values remain visible in a scrollable panel.
  The previous log is not re-used to approve an altered sensor calibration.

CHANGE 2 — V1+ LIVE PROGRESS
  Each active version gets its own pinned UI progress context (project ID,
  version number). Opening V1 or later clears the prior V0/V1 completed event
  lines, timestamps, elapsed time and 100% progress bar. The panel displays
  "V1 ready" (or the active version), followed by fresh qualification, preflight
  and review processing progress. Rerendering the same active version does NOT
  clear a live progress stream. Stored versions, datasets and performance
  histories are unchanged.

FILE/SCOPE SUMMARY
  - Application coordinator/UI: ve_optimizer_revision9_review.py
  - Updated two old UI tests to reflect this user-approved replacement.
  - Added focused map/progress regression tests.
  - MANIFEST.json updated for all current packaged files.
  - Accepted optimization mathematics, frozen models, solver, Wideband and
    Speed Density processing, licensing, Channel List resource, and .htt export
    code are byte-for-byte unchanged from the preceding accepted baseline.

VALIDATION LIMITATIONS
  Automated Tk UI tests and static checks are not a native signed Windows build,
  an installed-customer workflow, verification of a physically installed sensor,
  or HP Tuners field acceptance. Windows compilation/signing and a V1 live run
  remain required before final field acceptance.

BUILD ON APPROVED WINDOWS MACHINE
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.1_Installer.bat
