VE OPTIMIZER v2.4.0 — USER-APPROVED UI DEVELOPMENT 2
==================================================

Version identity remains v2.4.0 Release. This development source/build kit
supersedes UI Development 1 as the new candidate, without replacing the
original verified v2.4.0 Release source archive.

APPROVED SIX-ITEM USER WORKFLOW
1. The upper-right panel is the single dynamic message, warning and review
   host. Only the latest message appears. The opening centered WARNING is
   initial content, not a fixed heading or permanent component. Missing
   Knock Retard yes/no approval is requested in the same message panel.
   Duplicate status text is not shown in the lower panel.
2. The visible Working overlay covers the bottom processing viewport only,
   leaving vehicle setup and the message/review panel accessible/visible.
3. Submit does not automatically open the Log File Channel / Density
   Validation window. The complete channel report is available when the
   user requests it with View in the bottom panel.
4. Once initial Log File qualification passes, the upper-left Submit button
   is replaced in place with Build. View replaces Validation and is at the
   left side of the bottom panel. Neither is an additional Build button.
5. Building a new project creates a database/filesystem staging record with
   an internal temporary identifier and no user-assigned permanent name.
   The Project Name dialog is shown only when Apply Changes commits a
   candidate at the final application step. After successful Apply Changes,
   the project folder and stored project-local file references are renamed.
6. Correction Preflight and Run/Review processing are embedded in the main
   page's vertically scrollable lower panel rather than appearing as full
   standalone pages. The right panel holds the preflight status/review text.

PRESERVATION
- Main application executable name, version labels and build scripts still
  describe VE Optimizer v2.4.0 Release. No upgrade to v4.3.0 was applied.
- The original .hpl-only log import, accepted NN Method A, Speed Density
  Method B, wideband, MAP, PE, safety and .htt export modules are unchanged.
- Historical UI Development 1 documentation remains as an audit record;
  its earlier Build-time naming description is superseded by this document.
- This is a source/build development candidate and is not a signed Windows
  installer. Native Windows application/installer testing and HP Tuners
  field acceptance remain required.

See UI_DEVELOPMENT2_VERIFICATION.txt for checks performed and limitations.
