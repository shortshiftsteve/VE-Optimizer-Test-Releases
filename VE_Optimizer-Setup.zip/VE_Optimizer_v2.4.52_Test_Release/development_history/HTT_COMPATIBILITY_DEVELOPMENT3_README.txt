VE OPTIMIZER 2.3.0 — HTT COMPATIBILITY DEVELOPMENT 3
EXPERIMENTAL USER TEST PACKAGE, NOT PRODUCTION RELEASE

Purpose: NN-disabled Speed Density outputs must NOT use a full Engine/Fuel
System .htt as their user-facing export.

Export changes:
- Both banks' modified Speed Density VE tables (44273, 44274)
- Airflow prerequisite Pressure Ratio Max scalar (18912)
- Airflow prerequisite Sensed MAP Enable switch (44433)
- Power Enrichment selector (34229) and PRatio PE table (34243)
- Each record included ONLY if its serialized value changed versus the
  ORIGINAL user baseline, not the intermediate prepared baseline.
- Whitelisted byte-restoration check fails closed if the candidate also
  changes an unapproved calibration record.
- Full Engine .htt retained ONLY as internal candidate for exact mathematical
  checks; it is not selected for user-facing export in NN-disabled paths.
- Adaptive SD, Wideband SD, Combined SD and their 25% reduced paths updated.
- NN enabled, accepted solver, VE correction and HPL processing unchanged.

Verification in this environment:
- Python compile passed.
- Original 2023 Challenger .htt: one changed VE bank -> changed-only template.
- Standalone scalar, switch, PE selector and PE table record round trips passed.
- Compound VE + scalar + switches record round trip passed.
- Unknown/out-of-scope byte change rejected.

LIMITATIONS:
The reduced templates have not been accepted through HP Tuners VCM Editor.
Do not flash an ECU on the strength of internal parsing tests alone.
If the candidate contains an unsupported modified record, generation will STOP
rather than silently deliver the full-engine export or discard modifications.
If VCM Editor reports an error, preserve the Template Applicator screen and
compare the selected changes before proceeding.
