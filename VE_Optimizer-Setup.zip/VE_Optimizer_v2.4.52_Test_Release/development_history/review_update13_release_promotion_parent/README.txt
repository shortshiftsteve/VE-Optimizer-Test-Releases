VE OPTIMIZER v2.4.5 REVIEW UPDATE 13 — DOWNLOADS SUBMENU / AUTOMATIC WORKFLOW STATUS
Date: 2026-10-14 (project local date)
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE: 2.4.5.0
PRIVATE WINDOWS REVIEW SOURCE/BUILD KIT — NOT A SIGNED CUSTOMER INSTALLER.

AUTHORITATIVE PARENT / APPROVED PATCH
- Parent: VE_Optimizer_v2.4.5_Review_Update12_Source.zip
  SHA-256: 7068444b2349d04c2409a27361bca511f0b7e2792f22af9ba06e27ecbf52c8c2
- Approved patch: VE_Optimizer_v2.4.5_Downloads_Submenu_Auto_Progress_Development.patch
  SHA-256: 11f20514838520006ca5b2cf6f2270f944f7c2f2528cf305f960906be8c89beb
- Update 13 includes all accepted Review Updates 1–12. Do NOT reapply earlier patches.

REVIEW UPDATE 13 — AUTHORIZED SCOPE
- Tools now contains an expandable Downloads submenu. The first and currently
  only command is Channel List (Tools -> Downloads -> Channel List). This still
  exports the verified bundled Scanner .Channels.xml without changing its
  bytes or existing overwrite-confirmation behavior. Future Downloads entries
  can be added without changing the menu hierarchy.
- Removed obsolete Processing Quality activity prompting users to select Run.
  Automatic processing continues following Submit, pausing only for required
  user actions. Updated the V1+ log-stage message to say correction preflight
  is being prepared, not that the log is 'ready to run'.
- Help updated to describe nested Downloads and the automatic workflow.
- No processing, tuning method, log decoder, calibration, project lineage,
  VE surface, results, licensing, trial, legal, signing or installer change.

SOURCE SCOPE RELATIVE TO UPDATE 12
- Modified UI: ve_optimizer_revision9_review.py
- Modified Help: help/VE_Optimizer_Help_Version_2.txt
- Modified tests: tests/test_channel_list_dev1.py and
  tests/test_review_update12_menu_and_activity.py
- Updated four Review documents and regenerated MANIFEST.json.
- All other original source files remain unchanged.

VERIFICATION / WINDOWS BUILD
- Full regression and clean-extraction test evidence recorded in the external
  VE_Optimizer_v2.4.5_Review_Update13_Verification.txt and test logs.
- Freshly extract VE_Optimizer_v2.4.5_Review_Update13_Source.zip, then run:
    py -3 installer\verify_release_versions.py
    py -3 ve_optimizer_revision9_review.py --smoke-test
    installer\Build_VE_Optimizer_v2.4.5_Installer.bat
- Expected native Windows signed setup only after successful build/signing:
    installer\Output\VE Optimizer v2.4.5 Review Setup.exe
- Preserve Azure signing, installer/uninstaller signing, EULA, legal text,
  trial/license, project database and upgrade protections.
- No native Windows build/signing, VCM Scanner/Editor/vehicle field acceptance
  or customer production Release is claimed by this source-only package.

UPDATE 12 AND EARLIER REVIEW NOTES BELOW ARE HISTORICAL.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 12 — PROCESSING PRESENTATION / TOOLS MENU
Date: 2026-10-14 (project local date)
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE: 2.4.5.0
PRIVATE WINDOWS REVIEW SOURCE/BUILD KIT — NOT A SIGNED CUSTOMER INSTALLER.

AUTHORITATIVE PARENT
- VE_Optimizer_v2.4.5_Review_Update11_Source.zip
  SHA-256: d1dd77fe0cd588b0987f97a70eef3d7f11b607b123e19be70bbe0d3878569e00
- Update 12 carries forward every accepted Update 1-11 change. Do not
  reapply earlier development patches or use a historical Review baseline.

REVIEW UPDATE 12 — AUTHORIZED SCOPE
- Upper-right PROCESSING activity records are now presented as concise,
  word-wrapped, visually differentiated status entries rather than raw
  DATA / WORKING / COMPLETE logging labels or clipped monospaced lines.
- User-facing activity states VIN availability, vehicle information, logged
  channel count, fuel-trim/Wideband qualification and actual processing stages
  without disclosing HPL metadata/VIN extraction details. No invented
  progress, events, or confirmation; actionable MESSAGE/Continue unchanged.
- Tools: rename Channel List to precisely "Downloads _ Channel List" while
  retaining its existing Downloads export. Remove the Tools menu entries
  "VE Surface Viewer" and "Diagnostics" only; no underlying processing,
  diagnostics, datasets, or calibration functionality is deleted.
- In-app Help navigation updated to match the Tools menu.
- No changes to Method A/Method B calculations, native HPL decoding,
  VIN optionality and Verify, user prompts, project storage,
  selective HTT export, results/dyno curve, licensing, trial, legal files,
  installer/build scripts, signing, or version identity.

SOURCE SCOPE
- Modified application module: ve_optimizer_revision9_review.py
- Modified Help: help/VE_Optimizer_Help_Version_2.txt
- Modified existing regression test: tests/test_channel_list_dev1.py
- New focused test: tests/test_review_update12_menu_and_activity.py
- Updated Review documents: README.txt, RELEASE_NOTES.txt,
  REVIEW_SOURCE_VERIFICATION_2.4.5.txt, BUILD_AND_RELEASE_CHECKLIST.txt.
- MANIFEST.json regenerated using actual bytes. All other files retained
  verbatim from Update 11.

VERIFICATION
- Full isolated source regression and clean-extraction results are recorded
  in VE_Optimizer_v2.4.5_Review_Update12_Verification.txt (provided alongside
  this ZIP). Native Windows installer compilation, signature verification,
  VCM Editor/Scanner and vehicle field acceptance are NOT performed here.

WINDOWS REVIEW BUILD
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Only after successful native Windows compilation and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Existing EULA, signature/timestamp, project database and three-day Review
trial safeguards remain mandatory. No trial reset or production Release.

UPDATE 11 AND EARLIER REVIEW NOTES BELOW ARE HISTORICAL.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 11 — NATIVE HPL VIN, STATUS AND HELP
Date: 2026-10-14 (project local date)
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE version: 2.4.5.0
PRIVATE WINDOWS REVIEW SOURCE/BUILD KIT — NOT A CUSTOMER INSTALLER OR RELEASE.

AUTHORITATIVE REVIEW SOURCE / PATCH
- Immediate parent: VE_Optimizer_v2.4.5_Review_Update10_Source.zip
  SHA-256: fe775a88d15f859fedb801c102badb313a5ed1a477123f8e2d0f95b27c5e08d0
- Approved development patch: VE_Optimizer_v2.4.5_HPL_VIN_Autofill_Processing_Help_Development.patch
  SHA-256: 67f26b9186a62d4fc0caca4ef6f926e0544d28eb86370358def99172fdca2be8
- Verified parent ZIP CRC and all 191 original manifest hashes. The approved
  patch applies cleanly to the new extraction of Update 10.
- This Update 11 already includes all accepted changes from Review Updates
  1-10. Do not reapply those older patches, and do not use older Review sources
  as the new baseline.

UPDATE 11 — APPROVED FUNCTIONALITY
- HPL VIN: Recover optional VIN from supported native VCM Scanner HPL MET
  records using bounded raw-DEFLATE metadata inflation; preserve all native
  HPL channel, sample and frame decoding. VIN is read-only, informational,
  NOT required for VE corrections. An unrecognized MET format or missing VIN
  leaves it blank and must never block processing.
- Vehicle prefill: Existing optional VIN lookup may populate Model Year,
  Vehicle Type, Engine, and Transmission. Do not restrict decoded vehicle
  type strings to a fixed dropdown selection. Remove the visible manual VIN
  entry and Decode / Autofill button. User Verify remains mandatory, includes
  VIN and transmission, and is invalidated by changing the selected log or
  confirmed vehicle data. Never silently override user-confirmed engine from
  the Engine-General value in the uploaded .htt.
- VIN lookup network availability/timeout is nonblocking. Guard callbacks
  against changed log/tune/vehicle selections. A missing or undecodable VIN
  cannot change Method A/B selection; switch ID 2088 in the Tune File controls
  the accepted separate Neural Network or Speed Density pathway.
- Method A Processing Quality adaptive-trim label: LTFT+STFT (not generic
  Adaptive Fuel Trims). Method B reports actual LTFT+STFT or STFT-only mode.
  Wideband selection remains independent; no tuning arithmetic is changed.
- Upper-right PROCESSING panel: display additional REAL milestones and counts
  from existing validation/correction operations; MESSAGE prompts still take
  precedence and pause for required action using the fixed primary button.
  Do not fabricate activity or completion percentages.
- Help: updated for VIN-from-HPL and nonblocking fallback, vehicle Verify,
  Submit/Continue/VIEW/Results, completed main dyno graph, independent
  Method A/B source labels and composite estimated-curve qualifications.

SOURCE SCOPE RELATIVE TO UPDATE 10
- Modified 2 application modules: hpl_decoder_v1_0_0.py and
  ve_optimizer_revision9_review.py.
- Modified 1 Help file: help/VE_Optimizer_Help_Version_2.txt.
- Modified 2 tests: tests/test_vin_trackhawk_verify_fix_245.py and
  tests/test_ui_development8_stft_source_display.py.
- Added 1 test: tests/test_hpl_vin_profile_development_245.py.
- Updated 4 Review documents: README.txt, RELEASE_NOTES.txt,
  REVIEW_SOURCE_VERIFICATION_2.4.5.txt, BUILD_AND_RELEASE_CHECKLIST.txt,
  plus regenerated MANIFEST.json. All other previous source files preserved.
- No changes to Method A/Method B correction math, NN coefficients, Speed
  Density tables, Wideband, MAP/boost/knock qualification, PE exclusion,
  native HTT writeback, project/database lineage, licensing, trial/EULA,
  build installer/signing, version or metadata identity.

VERIFICATION AND LIMITATIONS
- Earlier development verification (prior to packaging): 405 passed,
  56 skipped, 0 failures in 66 isolated test modules; 56 focused tests passed
  after clean application. Two further VIN checks passed independently.
- Independent package and regression results are recorded in
  VE_Optimizer_v2.4.5_Review_Update11_Verification.txt.
- HPL MET VIN retrieval was observed in two supplied real logs. Other HPL
  versions may not contain the same optional record; missing VIN is valid.
  External VIN service was tested with mocks, not live availability.
- Native Windows PyInstaller/Inno Setup compilation, Azure signing, VCM
  Editor/Scanner acceptance and vehicle testing are NOT established here.

WINDOWS REVIEW BUILD — USE ONLY A FRESH UPDATE 11 EXTRACTION
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Only after successful native build/signing expect:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve license state and nonresetting 3-day Review trial history, user
projects, and executable/installer/uninstaller signature/timestamp guards.

OLDER REVIEW UPDATE 10 AND EARLIER MATERIAL FOLLOWS FOR HISTORY ONLY.
The above Update 11 instructions supersede inconsistent historical details.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 10 — COMPOSITE / FAUX DYNO AND RESULTS NAVIGATION
Date: 2026-10-14
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE / APPROVED PATCH
- Immediate parent: VE_Optimizer_v2.4.5_Review_Update9_Source.zip
  SHA-256: 11227889ffa0873246d6daf95e4bdc4018033bd9d8821136eabb619f3a0a18ec
- Approved development: VE_Optimizer_v2.4.5_Composite_Faux_Dyno_Development.patch
  SHA-256: 7a040bc13ecda03ec6401c73d248b92fc022a85bfccc5390f04b55c3069c2a14
- Parent ZIP CRC, all 191 manifest-listed file hashes, and git patch apply
  were checked before creating this private Review source/build kit.
- This Update 10 source INCLUDES prior Review Updates 1-9. Do not reapply
  patches for those prior Updates; they are historical ancestors only.

UPDATE 10 — AUTHORIZED BEHAVIOR
- COMPOSITE DYNO: Replace the previous single selected-sweep graph with a
  best-effort composite from valid native-HPL WOT instances throughout the log.
  Short WOT tip-ins count; no complete gear-specific pull is required. Collate
  timestamp-aligned RPM and PCM Actual Torque in RPM bins, and combine usable
  observations across operating events. RPM areas without WOT evidence may
  use available other-load points as constraints and expressly illustrative
  interpolation/extension. Do not call such portions measured WOT performance.
- GRAPH DISPLAY: Plot PCM-estimated HP (left) and torque lb-ft (right) against
  RPM using identical numeric vertical scales (5252-RPM equality); observed
  portions solid, simulated or cross-event continuation dashed. Preserve the
  upper-right V0/V1/... independent whole-log Max RPM, Max Torque and Max HP.
  Synthetic points NEVER change actual stored maxima, tuning or calibration.
- LOWER PANEL: Remove the duplicate white Correction Preflight display; retain
  the full-width dyno graph, Processing Quality, and actual preflight checking.
  Real actionable messages / required choices stay in the flashing upper-right
  MESSAGE area and continue to interrupt the automatic processing workflow.
- FINISHED PROCESS: Submit still advances automatically through validation,
  qualification and correction, but processing now STOPS on the main dyno view.
  The fixed-size multifunction control becomes RESULTS; Results opens only when
  clicked, allowing time to inspect the dyno chart and Processing Quality.
- RESULTS BACK: Return reliably from Results to the completed main dyno page,
  preserve project/correction context, and permit repeated Results <-> Back
  navigation without recomputing or requiring a prior history entry.
- V1+ CHANGE GUARD: Changing the active project version still invalidates old
  preflight/source selection even though its redundant card was removed.
- SAFETY/ARCHITECTURE: No Method A NN solver, Method B Speed Density, fuel-trim,
  Wideband, knock/MAP/PE safety, export, persisted project, licensing, trial,
  EULA, version stamping, or installer/signing changes. No automatic Apply or
  selective .htt export, and no reintroduction of removed PE calibration UI.

FILE SCOPE VS. UPDATE 9
- 2 modified production/UI-analysis modules: ve_optimizer_dyno.py and
  ve_optimizer_revision9_review.py.
- 3 modified test modules: tests/test_dyno_curve_development_245.py,
  tests/test_submit_to_results_auto_development_245.py, and
  tests/test_ui_development2_workflow.py.
- 4 updated Review documents (README, RELEASE_NOTES,
  REVIEW_SOURCE_VERIFICATION_2.4.5 and BUILD_AND_RELEASE_CHECKLIST), plus
  regenerated MANIFEST.json. All 182 other manifest-listed files unchanged.

VERIFICATION / LIMITATIONS
- Development verification before packaging: 398 passed, 56 skipped, zero
  failed assertions in 65 isolated Linux/Xvfb test modules; 64 focused
  clean-parent checks passed (historical development record).
- Independent Review Update 10 package validation and clean-extraction tests
  are recorded in VE_Optimizer_v2.4.5_Review_Update10_Verification.txt.
- Native Windows PyInstaller/Inno compilation, Azure signature/timestamp,
  actual VCM Editor/Scanner import, customer installation, and vehicle dyno
  validation have NOT been conducted in this source packaging environment.

WINDOWS REVIEW BUILD — ONLY FROM FRESH UPDATE 10 EXTRACTION
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY AFTER a fully successful native Windows build and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve EULA hashes, existing trial/license history, project databases,
installer/uninstaller signing, and timestamp checks.

HISTORICAL UPDATE 9 AND EARLIER DOCUMENTATION FOLLOWS. Any references
below to old Review source ZIPs or superseded graph/navigation behavior are
for history ONLY; the above Update 10 instructions control.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 9 — AUTOMATIC SUBMIT / DYNO PRESENTATION
Date: 2026-10-14
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE AND CHANGE CONTROL
- Immediate parent: VE_Optimizer_v2.4.5_Review_Update8_Source.zip
  SHA-256: 4294a0f2283d2654145623316ee4ca2c14500e44cd400e824d4bc04966da2ad0
- Authorized development patch:
  VE_Optimizer_v2.4.5_Submit_Auto_Dyno_Display_Development.patch
  SHA-256: 8d7f45dc3321dff0c33af3a6d514b2de5954286341001acef35e8759d9a91af6
- Original Update 8 archive CRC and all 190 source manifest hashes verified;
  approved git patch applied cleanly to a NEW extraction of Update 8.
- Review Update 9 includes all Updates 1-8 and retains the SAME 2.4.5-Review
  identity, 72-hour Review trial history, license, EULA and build/signing rules.
  Neither the earlier archived Updates nor the patch need to be reapplied.

UPDATE 9 — UI AND PRESENTATION SCOPE
- DYNO: Use a common numerical scale on both HP and lb-ft vertical axes so
  their actual calculated curves intersect at 5252 RPM; retain original
  HP = torque(lb-ft)*RPM/5252 arithmetic and read-only HPL provenance.
  Remove the redundant HP-formula explanatory footer. Keep measured/simulated
  distinctions, selected-sweep data and PCM-derived estimate qualification.
- METHOD B LABEL: Processing Quality displays LTFT+STFT when actual
  completed Speed Density correction used valid combined trims on both banks.
  Otherwise it displays STFT for an STFT-only adaptive run; Wideband and
  Method A remain separate. Only the presentation label changes, not math.
- SUBMIT AUTO: After verified vehicle details and Submit, continue automatically
  through native-HPL channel validation, project/version preparation, safety
  and correction preflight, correction execution, and successful Results view.
  Do NOT automatically apply changes or export an HTT calibration.
- PAUSE/CONTINUE: Required user choices or safety decisions interrupt automatic
  progress in the upper-right flashing MESSAGE panel, then the single fixed-
  position multifunction button resumes with Continue. Never bypass failed
  preflight, user confirmation or mandatory source/safety requirements.
- CHANNEL FAILURE VIEW: Do NOT offer the optional initial channel View on
  successful HPL validation. If validation fails, show the real failure in
  the upper-right MESSAGE area and switch the SAME fixed-size primary action
  button to VIEW, opening diagnostics only on demand; VIEW is not a bypass.
- STALE CALLBACK: An HPL validation result for a replaced tune, log or vehicle
  must not advance an outdated selection. Errors stop auto-progression.
- Existing full-width lower dyno chart and upper-right V0/V1 peak summary
  retain their original locations and distinct data definitions.

EXACT FILE SCOPE FROM UPDATE 8
- 2 modified production/UI-analysis modules: ve_optimizer_revision9_review.py,
  ve_optimizer_dyno.py.
- 13 revised existing regression test modules and 1 new module:
  tests/test_submit_to_results_auto_development_245.py.
- 4 Review documents updated; MANIFEST.json regenerated.
- Other 171 parent manifest-listed files unchanged. No NN solver, Speed
  Density correction, Wideband math, knock/MAP/PE safety, tuning/export,
  customer licensing, persistent project database, legal or build changes.

VERIFICATION
- Prior development verification (historical): 389 passed, 56 skipped,
  11 additional subtests passed, zero failures across 65 separate pytest
  modules; 76 focused clean-parent tests passed.
- Independent Update 9 packaged-source verification, ZIP manifest hashes,
  clean-extraction testing and limitations are documented in the separate
  VE_Optimizer_v2.4.5_Review_Update9_Verification.txt report.
- Native Windows build/signing, actual VCM Editor/Scanner acceptance and
  vehicle/physical dyno validation are NOT independently performed here.

WINDOWS REVIEW BUILD — FRESH UPDATE 9 EXTRACTION ONLY
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected only AFTER successful native Windows compilation/signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve existing trial/license/customer database, EULA, Azure signing,
installer/uninstaller signing and Authenticode/timestamp safeguards.

HISTORICAL REVIEW UPDATE 8 AND EARLIER MATERIAL FOLLOWS; references below
that instruct building older source archives are SUPERSEDED by Update 9.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 8 — READ-ONLY DYNO-STYLE PERFORMANCE CHART
Date: 2026-10-14
Product: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE AND CHANGE CONTROL
- Immediate parent: VE_Optimizer_v2.4.5_Review_Update7_Source.zip
  SHA-256: dc1109190b07270eb4b35a7a6d25d280a5df0197c2d135ef5295d62e68ffb829
- Authorized dyno-chart development patch:
  VE_Optimizer_v2.4.5_Dyno_Chart_Development.patch
  SHA-256: c1c23656c9940e1b534fb199f7f8a401a5d53766399ca64a4e200fa3451e817e
- Parent ZIP CRC/manifest checks and patch application verified.
- Review Update 8 retains all Update 1–7 behavior and unchanged product,
  three-day Review trial identity, license, EULA and Windows build/signing.

UPDATE 8 — DISPLAY / ANALYTICS ONLY
- Add a dyno-style RPM vs horsepower / torque graph in the FULL-WIDTH LOWER
  PANEL, above the existing Processing Quality display. Do not move this graph
  to the upper-right performance summary panel.
- Preserve the existing upper-right V0/V1/... Max RPM, Max Torque lb-ft and
  calculated Max HP matrix with the same original whole-log peak definitions.
- Provide graph selection for completed project versions with available
  native-HPL performance records; preserve project version and source lineage.
- Calculate curve points from native HPL RPM and logged PCM Actual Torque
  samples paired within 250 ms; convert N*m torque to lb-ft with existing
  application factor; HP = time-paired torque_lbft * RPM / 5252.
- Select sustained acceleration episodes, avoiding shift transients and RPM
  discontinuities. Show logged portions as continuous curves; any internally
  interpolated gaps or illustrative low-RPM continuation are explicitly
  dashed and labelled SIMULATED. No extrapolation beyond observed max RPM.
- Simulated points do not affect reported measured peaks, qualification,
  fuel corrections, optimization, or calibration/HTT output.
- All graph values are PCM-derived estimated performance, not measured
  chassis-dyno wheel horsepower or verified engine-dyno torque/power.
- HPL curve extraction occurs asynchronously, with digest-based caching;
  insufficient usable samples show unavailable rather than fake curves.

SOURCE FILES CHANGED FROM UPDATE 7
- ve_optimizer_revision9_review.py — lower-panel chart UI and version selector
- ve_optimizer_dyno.py — NEW independent read-only HPL curve analysis/rendering
- tests/test_dyno_curve_development_245.py — NEW 9-case development regression
- Four Review document headers, plus MANIFEST.json rebuilt for all packaged files.
- No other production modules, Method A/B correction algorithms, Wideband,
  calibration exports, trial/licensing, frozen NN assets, EULA, or build scripts.

DEVELOPMENT VERIFICATION (HISTORICAL, PRE-PACKAGING)
- 379 tests passed, 56 skipped and 11 additional subtests passed in 64
  isolated Linux/Xvfb test modules; zero failures. The development patch
  passed clean-parent application, version preflight, application smoke test,
  compilation, and 20 focused tests.
- Review Update 8 package verification and clean-extraction results are in
  the separate VE_Optimizer_v2.4.5_Review_Update8_Verification.txt.
- The reference DynoMax PDF is visual context only; do not fit estimates to
  its physical dynamometer readings. The supplied native Trackhawk HPL was
  used in development testing, not for alteration of tune files.
- Native Windows build/signing, VCM Editor/Scanner field acceptance, actual
  dyno-equivalence and customer Release are NOT claimed.

WINDOWS REVIEW BUILD (FRESH UPDATE 8 EXTRACTION ONLY)
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected file ONLY after successful native Windows build and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Do not reset the existing v2.4.5-Review trial, overwrite customer projects,
weaken EULA/license gates, or bypass Azure/Authenticode verification.

HISTORICAL UPDATE 7 AND EARLIER SECTIONS FOLLOW. Their instructions to
build earlier source ZIPs are superseded by the Update 8 instruction above.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 7 — CENTRAL PROGRESS / FIXED ACTION
Date: 2026-10-14
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE REVIEW SOURCE
- Parent Review source: VE_Optimizer_v2.4.5_Review_Update6_Source.zip
  SHA-256: 1d467eb37139eb624850d16db945cdb208b05b24df210831b973715ed837f325
- User-approved UI development patch: VE_Optimizer_v2.4.5_UI_Fixed_Action_Progress_Development.patch
  SHA-256: 725e1af201596144db1ad08ea68711d6a369475f8ca678250500ab1abe9a0fab
- Parent manifest/CRC verified and the authorized patch applied cleanly.

UPDATE 7 SCOPE — UI / WORKFLOW PRESENTATION ONLY
- The upper-right information panel displays persistent progress status, progress
  bar and timestamped processing activity while no user-action prompt is active.
- Prompts that require a user decision take priority in the same upper-right
  area. Progress data are retained and automatically redisplayed after the
  required user action is resolved.
- The upper-right header flashes PROCESSING during active work and MESSAGE
  during actionable messages. It displays static PROGRESS when neither applies.
  The original opening WARNING is retained and yields when processing begins.
- One fixed-size, fixed-position multifunction button at the previous Build
  location handles Verify, Submit, Build, Run, Results and necessary
  confirmation/retry actions. Button dimensions do not change with the label.
- Log/Tune File picker controls stay beside their original fields; message
  choices (e.g. selection radios, Yes/No) remain with the message.
- The redundant lower Progress section is removed. The lower Processing Quality
  section and its content remain available.
- Header/Verify flashing callbacks clean up when the Tk window closes.

PRESERVED / NOT PART OF UPDATE 7
- Review Update 6 optional Method B LTFT+STFT with STFT-only fallback, independent
  Speed Density processing, and all earlier Review Updates 1-5.
- Method A Neural Network formulas, weights/biases, activation and solver;
  Method B correction math and direct VE bank tables; Wideband independence.
- Native HPL/.htt parsing/export, MAP/knock/boost/PE safeguards, versioned
  project lineage, licenses/trial first-use, EULA, installer and signing.
- Product 2.4.5 / Build ID 2.4.5-Review / Windows metadata 2.4.5.0;
  no 2.4.5-Review trial reset. v2.4.4 remains last accepted production Release.

VERIFICATION / STATUS
- Development verification: 370 passed, 56 skipped and 11 additional subtests
  passed in isolated Linux/Xvfb regression processes, with no failures.
- Independent packaged-source checks are documented in the accompanying
  Review Update 7 verification report (archive hashes, clean extraction,
  version preflight, smoke and focused regression checks).
- This ZIP is a PRIVATE REVIEW SOURCE/WINDOWS BUILD KIT. Native Windows installer
  compilation, signing, VCM Editor import and vehicle acceptance are not claimed.

WINDOWS REVIEW BUILD (FRESH EXTRACTION)
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected signed file ONLY after a successful native Windows build:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve EULA, licensing/trial first use, project data, and signing gates.

Historical Update 1-6 documentation follows. Previous UI references to
separate Run/Results/Verify buttons and the lower Progress display are
superseded by this Update 7 presentation, not by unrelated processing changes.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 6 — METHOD B OPTIONAL LTFT
Date: 2026-10-14
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE
- Parent Review: VE_Optimizer_v2.4.5_Review_Update5_Source.zip
  SHA-256: a04e781476c710c02806af673869f9e4a77226535c826015834f9edbdbc02d0b
- Applied user-authorized Method B development patch: VE_Optimizer_v2.4.5_MethodB_Optional_LTFT_Development.patch
  SHA-256: 5fc3cc17cf3cc7d9ebaa194ee044399c0d2d11b1179c53ea7942c8dc40e5fc95
- Parent manifest/ZIP identity verified; patch applies cleanly without overlap.

UPDATE 6 SCOPE
- Method B (switch 2088 DISABLED) uses its own Speed Density analysis; if BOTH
  Bank 1 and Bank 2 LTFT streams contain usable finite readings with at least
  five subsequent STFT events per bank, bank total = LTFT + STFT.
- Otherwise Method B falls back to STFT-only processing for BOTH banks; LTFT
  remains optional, and slower LTFT updates do not multiply STFT hit counts.
- Preserve independent five-hit/bank/cell qualification, MAX qualifying-bank
  target, bank-bias protection and 50% application, correcting only the two
  native Speed Density VE tables. The independent Method B sample gates,
  RPM/PRatio axes, pressure/boost/knock checks and PE exclusions remain.
- Method A Neural Network inputs, solver, weights/biases, fixed activation,
  filters and exported calibration behavior are NOT changed.
- Wideband and trim corrections remain mutually exclusive. No new dual-WB
  blending, sensor changes, PE writebacks, MDS changes or tune-file updates.
- Review Update 6 includes the previously accepted Updates 1-5, including the
  VIN Decode -> Verify -> Submit fix confirmed by the user.

VALIDATION AND REVIEW STATUS
- Source development verification: 366 passed, 56 skipped and 11 additional
  subtests passed (62 isolated modules: 57 collected tests; 5 had no tests),
  with no failed assertions. External Update 6 report records the actual
  packaged-source, manifest and clean-extraction checks.
- Product/build identity, existing 2.4.5-Review trial first-use record,
  purchased licenses, legal terms, signing and install/upgrade protections are
  unchanged. The latest accepted production Release remains v2.4.4.
- This ZIP is a PRIVATE REVIEW SOURCE/WINDOWS BUILD KIT only; no native signed
  Windows installer, VCM Editor import or on-vehicle acceptance is established.

WINDOWS REVIEW BUILD (FRESH EXTRACTION)
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY after successful native Windows build and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Never bypass EULA, trial/licensing, signing/timestamp or project safeguards.

The following Update 1-5 sections document HISTORICAL Review stages. Any older
STFT-only description of Method B is superseded by the Update 6 rules above.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 5 — VIN TRACKHAWK VERIFICATION
Date: 2026-10-14
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE
- Parent Review: VE_Optimizer_v2.4.5_Review_Update4_Source.zip
  SHA-256: 441a1a596805d8e766c8d877b371deb1fb31f6f3bfcf0d9490e8522f4f2adf77
- Applied approved development patch: VE_Optimizer_v2.4.5_VIN_Trackhawk_Verify_Development.patch
  SHA-256: ab79f5c8b94f915279d9ced2d45f3d48a6c01d4d811693691ddc6f4a125488e8
- Patch cleanly applied; corrected module and new test are byte-for-byte identical
  to the previously verified development copy.

UPDATE 5 SCOPE
- NHTSA VIN responses of 'JEEP Grand Cherokee Trackhawk' resolve to the existing
  supported Setup Vehicle Type 'Trackhawk' instead of a non-selectable full name.
- VIN Decode and manual vehicle selection now share the same functioning
  Verify -> Submit gate. Verification still resets when vehicle fields change.
- Preserve user-selected Engine as authoritative, including 6.2L support.
- Retain all v2.4.5 Review Update 4 changes and earlier fixes unchanged.
- NO changes to NN/Speed Density VE math, PE calibration exclusion, MAP/knock
  safeguards, injector settings, licensing/trial, signing or project lineage.
- Review source/build kit only; no native Windows installer or Release created.

VALIDATION
- Prior development regression: 371 passed, 39 skipped, 11 additional
  subtests passed across 11 groups, zero failures.
- New package integrity, clean-extraction, version preflight, smoke and focused
  test verification recorded in separate Update 5 verification report.
- Native Windows compilation/signing and VCM Editor/Scanner acceptance remain
  NOT independently established.

The existing 2.4.5-Review trial identity and original first-use date are
UNCHANGED. No Review trial reset and no use of a future v2.4.5 Release trial.

WINDOWS REVIEW BUILD
Extract into a FRESH directory. From the source root run:
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY after native Windows compilation and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve EULA, licensing, Windows signing/timestamp and upgrade safeguards.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 4 — TMAP RPM ENDPOINT ADVISORY
Date: 2026-10-13
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE
- Parent: VE_Optimizer_v2.4.5_Review_Update3_Source.zip
  SHA-256: cac22db0c85ffeb7af483f19b22f78acadc5641104fc374f17ec50aec4eecb00
- Applied verified development patch: VE_Optimizer_v2.4.5_TMAP_RPM_Endpoint_Development.patch
  SHA-256: 76b1f42ff7f546a8f3753358365336df265e648815a06bb1d8ad6ef2ebf6783f

UPDATE 4 SCOPE
- The Throttle Based MAP Multiplier (44395) RPM-axis final breakpoint is not
  enforced as an independently verified maximum engine operating RPM.
- Logged RPM beyond that final breakpoint produces a NONBLOCKING RPM AXIS NOTICE,
  including the actual RPM and table endpoint; the PCM's beyond-endpoint lookup
  behavior has not been independently verified.
- An airflow-axis overrun of this table REMAINS BLOCKING. Independent MAP/Baro,
  sensor calibration range, knock, Speed Density VE domain, and required-channel
  checks are unchanged.
- The TMAP multiplier table and its axes/values remain UNCHANGED. Sensed MAP
  Enable 2100 remains UNCHANGED; only established qualified Pressure Ratio Max
  preparation may occur as before.
- The available tuned Trackhawk reaches 6259 RPM with table endpoint 6208 RPM;
  its TMAP airflow observations stay inside the table's 1152 g/s upper limit.
- Retain all accepted Review Update 3 wideband recognition, Update 2 Sensed MAP
  preservation, Update 1 duplicate-channel resolution, and 6.2L/Setup support.
- No PE calibration generation, new wideband mathematics, NN/VE model changes,
  trial/licensing changes, installer changes or Windows release promotion.

VALIDATION
- Verified development patch applies without rejects to Update 3 source.
- Development regression evidence: 367 tests passed, 39 skipped, 11 additional
  subtests passed across 10 isolated Linux GUI-capable groups, with zero failures.
- New Review source package is separately reverified for ZIP/manifest integrity,
  version preflight, smoke test, and focused and broader regressions.
- Native Windows signing/installation and HP Tuners field acceptance are NOT
  established here.

This remains a PRIVATE REVIEW source/build kit, NOT a customer Release.
The existing 2.4.5-Review trial identity and original first-use date remain
unchanged; the future 2.4.5 Release trial remains separate.

WINDOWS REVIEW BUILD
Extract into a FRESH directory and run from the extracted source root:
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY after successful native Windows build and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Preserve EULA, licensing, native signing, timestamping and upgrade safeguards.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 3 — WIDEBAND SOURCE RECOGNITION
Date: 2026-10-13
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORITATIVE SOURCE
- Parent: VE_Optimizer_v2.4.5_Review_Update2_Source.zip
  SHA-256: 73f1b91f993bdef3a9fd2c75babfe027a87907258e04b331dd9dce2cf9cc0777
- Applied verified development patch: VE_Optimizer_v2.4.5_Wideband_Source_Selection_Development.patch
  SHA-256: f06d30ed6e7db0adb99172399076836ececf8b1e2b093404d9d010d2d49d9c78

UPDATE 3 SCOPE
- Recognize native 'WB EQ Ratio 1' alongside 'WB EQ Ratio 1 (SAE)' for the
  EXISTING primary single-stream wideband correction source.
- Recognize native 'Engine Coolant Temp' as well as the SAE-labelled ECT channel
  in wideband processing.
- Identify WB EQ Ratio 2 as a distinct, UNUSED secondary channel: no averaging,
  substitution, cross-bank mixing, or new wideband correction mathematics.
- Display the selected source explicitly in MESSAGES when exactly one method
  qualifies; present correction-source choice only when BOTH qualify.
- Preserve all correction-source, Method A/B, knock, MAP/Baro, sensor and PE
  safeguards. The user's Trackhawk tune/log remains blocked if an independent
  MAP preflight failure applies, irrespective of recognized wideband channels.
- Preserve all earlier Review Update 2 Sensed MAP/2100 controls, Update 1
  duplicate HPL-channel controls, and original v2.4.5 Setup/6.2L improvements.

TEST STATUS
- Source regression: 363 passed, 39 skipped, 11 additional subtests passed, zero failures across 10 isolated GUI-capable groups.
- Native Windows compilation, signing, installation and VCM Editor/Scanner
  acceptance are NOT established by these Linux tests.

This is a PRIVATE REVIEW source/build kit, NOT a Release or signed installer.
The existing 2.4.5-Review trial identity is unchanged. No new trial starts from
this Review update and the future 2.4.5 Release trial remains separate.

WINDOWS BUILD
Extract into a NEW folder. From the source root run:
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY after native successful signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Do not weaken EULA, licensing, build/signing or upgrade safeguards.

==============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 2 — SENSED MAP PRESERVATION
Date: 2026-10-13
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

AUTHORIZED SOURCE
- Parent: VE_Optimizer_v2.4.5_Review_Update1_Source.zip
  SHA-256: a2cf53b0cc334fc4022ded57edc0aabb3a9da96aec7c1f9c788044dbe79dd5bc
- Applied verified: VE_Optimizer_v2.4.5_SensedMAP_Preservation_Development.patch
  SHA-256: 71433cccc5b04c9239f9cfb19279bac7c19b15d56621076c47c784516dc3d248

UPDATE 2 CHANGES
- Preserve Sensed MAP Enable (switch 2100) EXACTLY as found in uploaded .htt.
- Boosted operation alone does not justify enabling Sensed MAP.
- Evaluate MAP table coverage for the existing Sensed MAP routing and threshold.
- Keep independent sensor pressure-range, MAP/Baro and boost safety checks.
- Block processing during preflight if applicable table coverage is inadequate;
  do not present Run to a log lacking a qualifying correction source.
- Preserve existing permitted Pressure Ratio Max scalar-only preparation where
  preflight qualifies; never modify MAP sensor transfer values or switch 2100.
- Reject selective .htt export if switch 2100 changed from the original tune.
- Retain all prior Review Update 1 duplicate-HPL-channel resolution and v2.4.5
  6.2L/Setup verification functionality without change.

TEST STATUS
- 357 tests passed, 39 skipped, 11 additional subtests passed in 10 isolated GUI-capable groups; zero failures.
- Clean patch, source-only version preflight and runtime smoke test pass.
- These tests are Linux source tests, not native Windows or VCM acceptance.

This remains a PRIVATE REVIEW source/build kit. Existing 2.4.5-Review trial
identity is unchanged. It does not reset the Review trial or consume the future
v2.4.5 Release trial. The accepted customer Release remains v2.4.4.

WINDOWS REVIEW BUILD
Extract into a NEW directory. From the source root run:
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected only after native Windows compilation and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe
Do not bypass the EULA, licensing, signing, timestamping or upgrade safeguards.

=============================================================================

VE OPTIMIZER v2.4.5 REVIEW UPDATE 1 — PRIVATE SOURCE/BUILD KIT
Date: 2026-10-13
Version: 2.4.5 | Build ID: 2.4.5-Review | Windows EXE metadata: 2.4.5.0

UPDATE 1: DUPLICATE HPL CHANNEL CORRECTION
- Based on VE_Optimizer_v2.4.5_Review_Source.zip
  Parent SHA-256: bd4d85d61ddd9c7bc9955e664651af697d687208f7d8127ee864f2d328515a59
- Applied VE_Optimizer_v2.4.5_Duplicate_HPL_Channel_Development.patch
  Patch SHA-256: 48b5e5949136d556b8dba484e9418d4c818abfd4fbf2d18ad82feba732d0da08
- Corrects failure when native Scanner HPL logs contain multiple distinct
  channels with the same display name, including Engine RPM.
- Resolves a qualified native channel by identity, units, sample coverage and
  consistency; rejects materially conflicting or unverifiable duplicates.
- Never merges redundant channel-event streams into additional log hits.
- Preserves Method A/B qualification rules, MAP/Baro safety and VE algorithms.
- This is an updated PRIVATE REVIEW, not a Release or signed Windows installer.
- Same Review/trial identity as prior v2.4.5 Review; it does not restart that
  trial or consume the future v2.4.5 Release trial.
- Build from a NEW folder containing THIS updated source, not the prior Review.

EARLIER REVIEW CONTENT (RETAINED)

VE OPTIMIZER v2.4.5 REVIEW — PRIVATE WINDOWS SOURCE / BUILD KIT
Date: 2026-10-13
Version: 2.4.5  |  Build ID: 2.4.5-Review  |  Windows EXE version: 2.4.5.0

AUTHORIZED BASIS
Accepted release parent: VE_Optimizer_v2.4.4_Release_Source.zip
SHA-256: 1ea362e9b60e92d10d38350c46e8708e0e0f65d8bfb622585188896eb253861b
Cumulative development patch: VE_Optimizer_v2.4.4_6_2L_Setup_Verification_Development.patch
SHA-256: 0f177a24b570cae83dbc2d824eecb2b71ab4de9302c56bd38f9762e3bc8bee07
This Review contains both the earlier approved 6.2L/Method A/B correction and
Setup vehicle-verification changes. It does not include unrelated tuning changes.
The accepted v2.4.4 release source remains unchanged.

CHANGES FOR USER REVIEW
- Use Neural Network switch record 2088, not unrelated switch 47500:
  Enabled -> Method A; Disabled -> Method B independent of tuned engine ID.
- Setup includes 6.2L Supercharged Hemi and Hellcat/Trackhawk vehicle types.
- Emissions WARNING message body is centered while displayed.
- Selecting a .hpl clears WARNING, shows MESSAGES with selected model year,
  vehicle type and engine, and presents a flashing yellow Verify control.
  Submit becomes available only after verification. Relevant changes require
  verification again. The user's selected engine is authoritative, not
  the easily edited Engine > General > Engine field from a tune.
- All unrelated tuning logic and existing PE calibration exclusion are preserved.

REVIEW-ONLY TRIAL SAFEGUARD
- This 2.4.5-Review build has a separate first-launch 72-hour review trial key;
  it does not consume the future 2.4.5 Release trial key.
- Existing old release trial starts, purchased licenses, and project databases
  remain preserved; same-Review reinstallation does not restart the trial.

WINDOWS REVIEW BUILD / SIGNING
Extract privately to a fresh folder on the authorized Windows build computer.
From the source root run:
  py -3 installer\verify_release_versions.py
  py -3 ve_optimizer_revision9_review.py --smoke-test
  installer\Build_VE_Optimizer_v2.4.5_Installer.bat
Expected ONLY AFTER successful native compilation and signing:
  installer\Output\VE Optimizer v2.4.5 Review Setup.exe

Do not relax or bypass EULA, refund policy, licensing, Azure signing, time
stamping, compiled EXE smoke test, uninstaller signing or signature verification.
This ZIP is PRIVATE source/build tooling, NOT a Windows installer or a public
Release. Native Windows signing, real VCM Editor/Scanner import, Windows trial
and GUI field acceptance have NOT been performed here.
