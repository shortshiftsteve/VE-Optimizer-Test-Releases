VE OPTIMIZER v2.3.0 — HTT COMPATIBILITY DEVELOPMENT 5 / MDS SAFETY HOLD
DATE: 2026-10-09
STATUS: DEVELOPMENT ONLY — NOT ACCEPTED FOR VEHICLE CALIBRATION IMPORT

WHAT THE USER'S VCM EDITOR TEST ESTABLISHED
- Development 4 grouped selective .htt formatting is recognized by VCM Editor.
- However, the NN-disabled import preview showed MDS Enable = Enabled.
- The previous code assumed internal switch key 44433 was Sensed MAP Enable.
- The earlier Development 3 payload, reframed as a valid v3 template, contains
  a single switch record with key 44433 and payload Enabled. The five-record
  selection otherwise contains scalar 18912 and tables 44273/44274/34243.
- The reported VCM Editor label shows that the assumed switch-to-parameter
  mapping is UNSAFE for this calibration. Key 44433 is QUARANTINED.
- Binary decoding and byte-level round-trip checks alone cannot establish
  the semantic meaning of a manufacturer calibration record.

CHANGES IN THIS SAFETY DEVELOPMENT PACKAGE
- Removed key 44433 from the list of allowable NN-disabled export changes.
- A changed 44433 in an otherwise eligible candidate causes a clear error;
  an existing import output is not overwritten.
- Stopped reading key 44433 as the Sensed MAP Enable state.
- The ID for Sensed MAP Enable is now UNVERIFIED/UNKNOWN (not guessed).
- When boosted operation is detected, pressure-model preflight blocks until
  this ID is independently verified. No auto-switch preparation is allowed.
- Non-boost workflows remain eligible, provided existing preflight is satisfied.
- The accepted VE, fuel-trim, solver, neural-network export and HPL decoding
  processes are unchanged. Pressure Ratio Max, VE bank tables, PE selector,
  and PE PRatio remain governed by the Development 4 record-difference checker.
- This is a SAFETY HOLD for boosted modes, not a claim that boosted calibration
  functionality has been fully restored.

REQUIRED VCM EDITOR IDENTIFICATION — NO TUNE CHANGES NEEDED
1. Open this vehicle's ORIGINAL tune in VCM Editor (not the failing template).
2. Navigate to Engine > Airflow > General and select Sensed MAP Enable.
3. Read the [ECM] parameter ID displayed in VCM Editor's bottom status bar,
   or make a screenshot of that status bar and the selected parameter.
4. Provide that parameter ID for code review and validation against the .htt.
5. If Sensed MAP Enable is not available, report that; do not substitute an
   unrelated switch or guess a key.

NO IMPORT OR FLASH AUTHORIZATION
The Development 4 template that enabled MDS must not be applied or flashed.
Development 5 is not a final calibration correction; no vehicle-side acceptance
claim is made. A follow-on package can be built once the correct parameter ID
has been validated and new VCM Editor preview/import tests pass.

PRODUCTION BASELINE
VE_Optimizer_v2.3.0_Release.zip
SHA256 4c45269c263d98a083e99b1640462fc68ee1e290ee6f7830115b069bb1741320
