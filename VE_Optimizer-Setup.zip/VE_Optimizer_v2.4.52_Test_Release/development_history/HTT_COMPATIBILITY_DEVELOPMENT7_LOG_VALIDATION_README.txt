VE OPTIMIZER v2.3.0 — DEVELOPMENT 7: LOG CHANNEL VALIDATION
Date: 2026-10-09
Status: DEVELOPMENT / WINDOWS UI ACCEPTANCE PENDING — NOT A PRODUCTION RELEASE

SOURCE PACKAGE
  VE_Optimizer_v2.3.0_HTT_Compatibility_Development6_Sensed_MAP_2100_Test.zip
  SHA-256: 018705b2e267ae4109ea2b8aa70bce0d52be1f54762e452dd2178680aa7dca1e
PRODUCTION BASELINE REMAINS
  VE_Optimizer_v2.3.0_Release.zip
  SHA-256: 4c45269c263d98a083e99b1640462fc68ee1e290ee6f7830115b069bb1741320

USER-REPORTED BUG
  Log File Channel / Density Validation showed the Neural Network-enabled
  required-channel profile for a vehicle with Use Neural Network disabled.
  Consequently Intake/Exhaust Cam Center Pos, LTFT B1/B2, and Fuel Flow Rate
  could appear as failed required channels even when an eligible Speed Density
  source had been detected and the Log File was otherwise ready.

DEVELOPMENT 7 CHANGES
  1. Detect active NN/Speed Density mode from the selected Full Engine .htt
     BEFORE running channel/density qualification; apply this to new setup,
     changed logs, required-channel guidance and persisted project validation.
  2. In Speed Density mode, Intake Cam Center Pos and Exhaust Cam Center Pos
     are not required and no longer appear as required-status rows.
  3. In Speed Density mode, LTFT B1/B2 are not required; optional logged LTFT
     remains available to the underlying processing methods as before.
  4. In Speed Density mode, Fuel Flow Rate is an advisory channel. It appears
     as DEGRADED rather than FAILED if missing, too sparse, insufficiently
     covered, or with unsupported units.  It cannot alone fail generic Log
     File validation.  When present and adequate its status is AVAILABLE.
  5. Engine Coolant Temp and Engine Coolant Temp (SAE) are explicitly treated
     as equivalent channel-name aliases. This does not bypass coolant data
     density or temporal coverage checks.
  6. The validation dialog states the detected airflow mode; it shows required
     channels and the Fuel Flow advisory for Speed Density. The Required
     Channels guide is model-dependent. Older saved NN-default results for
     SD projects are revalidated on viewing the details.
  7. Saved Speed Density logs must still qualify through adaptive or Wideband
     correction-source preflight, even if generic Log File validation passes.
     Fuel Flow may be advisory for the overall Log File but required by the
     unchanged adaptive Speed Density filter. This distinction is intentional.
  8. The NN-enabled required-channel profile and its strict gates remain
     unchanged. Original v2.3.0 export and Development 6 safety logic remain.

IMPORTANT COOLANT-DENSITY DISTINCTION
  In the user screenshot, Engine Coolant Temp (SAE) is ALREADY recognized:
  377 samples over approximately 5 minutes (1.26 Hz, complete coverage).
  The strict required-channel density floor for ECT is 1,000 observations,
  not 377, so it may still be displayed FAILED for INSUFFICIENT DENSITY.
  The "(SAE)" name is not the reason. This checkpoint deliberately does not
  weaken the approved ECT quantity gate without a separate threshold decision.
  A correction method can still independently qualify the Log File, in which
  case the dialog may report LOG FILE READY with a strict density warning.

WHAT DID NOT CHANGE
  - .hpl decoder, record extraction, unit conversions, conditioning gates.
  - Accepted >=5-hit, 50% half-step trim and NN solver/calculation methods.
  - Speed Density adaptive accepted event filter and Wideband event filter.
  - All .htt export payloads/serialization, MDS protection and Sensed MAP 2100.
  - Production v2.3.0 Release archive and its Windows installer/signature.

LOCAL VERIFICATION
  Targeted regression run: 70 tests passed, 16 external-fixture skips,
  plus 7 subtests passed. Python source compilation passed.
  The broad all-tests attempt did not complete before the execution limit;
  no claim of full-suite release verification is made.
  The local test suite includes synthetic native/SAE ECT channels, NN/SD
  required-channel differences, missing/sparse Fuel Flow DEGRADED handling,
  stale report correction and observed Maggi .htt mode detection.

WINDOWS ACCEPTANCE CHECK
  1. Use the actual Maggi Full Engine .htt with NN disabled and the same log.
  2. Open Log File Channel / Density Validation (including a saved project's
     Validation Details, which should refresh a stale stored NN profile).
  3. Confirm "Speed Density / NN disabled" and absence of the cam/ltft rows.
  4. Confirm missing Fuel Flow Rate is marked DEGRADED, never red FAILED.
  5. Confirm native or SAE coolant names are detected; if data are below the
     density floor, an honest density failure can remain regardless of name.
  6. Confirm the correction-source preflight still gates an actual processing
     run and that the Development 6 selective .htt exports remain clean.
  Do not flash a vehicle based solely on these source-level tests.
