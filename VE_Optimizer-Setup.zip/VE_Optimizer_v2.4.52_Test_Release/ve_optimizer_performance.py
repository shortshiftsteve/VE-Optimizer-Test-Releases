"""Read-only project performance summary from native VCM Scanner HPL updates.

Peak horsepower is computed per time-matched positive torque/RPM observation,
not by multiplying independently observed maxima. Sparse channels may update
asynchronously: use the latest values within a bounded 250 ms age window; no
interpolation, guessed values, smoothing, or changes to VE optimization inputs.
"""
from __future__ import annotations

import math
import re
from pathlib import Path

from ve_optimizer_logcheck import convert_value, _native

PAIR_MAX_AGE_MS = 250


def _channel_index(channels, kind):
    if kind == 'rpm':
        preferred = ('engine rpm',)
        matcher = re.compile(r'^engine\s+rpm(?:\s*\(sae\))?$', re.I)
    else:
        preferred = ('actual torque', 'actual torque (sae)')
        matcher = re.compile(r'^actual(?:\s+engine)?\s+torque(?:\s*\(sae\))?$', re.I)
    matches = [(index, data) for index, data in channels.items()
               if matcher.match(' '.join(str(data.get('name') or '').split()))]
    matches.sort(key=lambda pair:((' '.join(str(pair[1].get('name') or '').lower().split()) not in preferred),pair[0]))
    return matches[0] if matches else (None, None)


def summarize_log_performance(path: Path) -> dict:
    """Return finite observed peaks and provenance, preserving unavailable values.

    Torque is normalized to lb-ft using the existing accepted unit converter.
    The horsepower formula is Torque (lb-ft) × RPM ÷ 5252. A horsepower point
    requires sufficiently recent samples of *both* signals, so unsynchronized
    independent maxima are never multiplied together.
    """
    # Reuse the qualified native HPL decoder's one-entry cache to avoid
    # decoding another full copy of a potentially large Log File in memory.
    decoded=_native(Path(path))
    if decoded is None:raise ValueError('A native HP Tuners .hpl Log File is required.')
    rpm_index,rpm_meta=_channel_index(decoded['channels'],'rpm')
    torque_index,torque_meta=_channel_index(decoded['channels'],'torque')
    peak_rpm=peak_torque=peak_hp=None
    rpm_count=torque_count=paired_count=0
    last_rpm=last_torque=None
    for frame in decoded['frames']:
        ms=frame['timestamp_ms']; updates=frame['updates']
        if rpm_index is not None and rpm_index in updates:
            val=updates[rpm_index]
            try:val=convert_value('rpm',rpm_meta['unit'],val)
            except (ValueError,TypeError):val=None
            if val is not None and math.isfinite(val) and val >= 0:
                last_rpm=(ms,val);rpm_count+=1
                peak_rpm=val if peak_rpm is None else max(peak_rpm,val)
            else:last_rpm=None
        if torque_index is not None and torque_index in updates:
            val=updates[torque_index]
            try:val=convert_value('actual_torque',torque_meta['unit'],val)
            except (ValueError,TypeError):val=None
            if val is not None and math.isfinite(val):
                last_torque=(ms,val);torque_count+=1
                peak_torque=val if peak_torque is None else max(peak_torque,val)
            else:last_torque=None
        if ((rpm_index in updates if rpm_index is not None else False) or
            (torque_index in updates if torque_index is not None else False)):
            if last_rpm and last_torque and ms-last_rpm[0] <= PAIR_MAX_AGE_MS and ms-last_torque[0] <= PAIR_MAX_AGE_MS:
                rpm=last_rpm[1];torque=last_torque[1]
                if rpm > 0 and torque >= 0:
                    hp=torque*rpm/5252.0
                    peak_hp=hp if peak_hp is None else max(peak_hp,hp)
                    paired_count+=1
    return {
        'max_rpm':peak_rpm,'max_torque_lbft':peak_torque,'max_hp':peak_hp,
        'rpm_samples':rpm_count,'torque_samples':torque_count,'paired_samples':paired_count,
        'log_sha256':decoded['source_sha256'],
        'rpm_channel':rpm_meta['name'] if rpm_meta else '',
        'torque_channel':torque_meta['name'] if torque_meta else '',
        'pair_max_age_ms':PAIR_MAX_AGE_MS,
    }


def performance_export_stem(project_name:str,version_no:int)->str:
    """Produce project-version filenames without user-controlled path syntax."""
    name=re.sub(r'[<>:"/\\|?*\x00-\x1f]+','_',str(project_name or '').strip()).rstrip(' .') or 'VE_Optimizer'
    name=re.sub(r'_V\d+$','',name,flags=re.I).rstrip(' _') or 'VE_Optimizer'
    return f'{name}_V{int(version_no)}'
