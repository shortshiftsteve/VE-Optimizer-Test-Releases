"""Package and export the approved HP Tuners VCM Scanner channel list.

This module is deliberately independent of Tune File/Log File processing.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import hashlib
import os
from pathlib import Path
import shutil
import sys
import tempfile
import uuid


CHANNEL_LIST_FILENAME = 'Updated VE Optimizer Channels.Channels.xml'
CHANNEL_LIST_SHA256 = '9d5ee8ccadc9f586cfe4c7e9e985b376a3d549020a59c213bfbac934025b9693'
_WINDOWS_DOWNLOADS_KNOWN_FOLDER = uuid.UUID('374de290-123f-4565-9164-39c4925e467b')


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def bundled_channel_list(app_dir: Path) -> Path:
    """Fail closed if the distributed resource is missing or altered."""
    source = Path(app_dir) / 'help' / CHANNEL_LIST_FILENAME
    if not source.is_file():
        raise FileNotFoundError(f'Bundled Channel List is missing: {source}')
    if sha256_file(source) != CHANNEL_LIST_SHA256:
        raise ValueError('Bundled Channel List failed SHA-256 integrity verification.')
    return source


def downloads_folder() -> Path:
    """Resolve the current Windows user's Downloads *known folder*.

    The Windows shell API accounts for Downloads-folder redirection. Fallback
    retains compatibility with systems on which the shell API is unavailable.
    """
    if sys.platform == 'win32':
        class GUID(ctypes.Structure):
            _fields_ = [
                ('Data1', wintypes.DWORD),
                ('Data2', wintypes.WORD),
                ('Data3', wintypes.WORD),
                ('Data4', ctypes.c_ubyte * 8),
            ]
        guid = GUID.from_buffer_copy(_WINDOWS_DOWNLOADS_KNOWN_FOLDER.bytes_le)
        path_ptr = ctypes.c_void_p()
        try:
            shell = ctypes.windll.shell32
            shell.SHGetKnownFolderPath.argtypes = (
                ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                ctypes.POINTER(ctypes.c_void_p),
            )
            shell.SHGetKnownFolderPath.restype = ctypes.c_long
            result = shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(path_ptr))
            if result == 0 and path_ptr.value:
                return Path(ctypes.wstring_at(path_ptr.value))
        except (AttributeError, OSError, ValueError):
            pass
        finally:
            if path_ptr.value:
                ole32 = ctypes.windll.ole32
                ole32.CoTaskMemFree.argtypes = (ctypes.c_void_p,)
                ole32.CoTaskMemFree.restype = None
                ole32.CoTaskMemFree(path_ptr)
    return Path.home() / 'Downloads'


def channel_list_destination(downloads_dir: Path | None = None) -> Path:
    base = downloads_folder() if downloads_dir is None else Path(downloads_dir)
    return base / CHANNEL_LIST_FILENAME


def export_channel_list(app_dir: Path, downloads_dir: Path | None = None,
                        overwrite: bool = False) -> tuple[Path, str]:
    """Copy the unmodified channel XML to Downloads, checking SHA-256.

    Returns (destination, 'saved' | 'already_current'). A different existing
    file is never replaced without the caller's explicit overwrite=True.
    """
    source = bundled_channel_list(app_dir)
    destination = channel_list_destination(downloads_dir)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if not destination.is_file():
            raise OSError(f'Channel List destination is not a file: {destination}')
        if sha256_file(destination) == CHANNEL_LIST_SHA256:
            return destination, 'already_current'
        if not overwrite:
            raise FileExistsError(f'A different Channel List file already exists: {destination}')

    staged_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='wb', prefix='.ve_channels_', suffix='.tmp',
            dir=destination.parent, delete=False,
        ) as staged:
            staged_path = Path(staged.name)
            with source.open('rb') as content:
                shutil.copyfileobj(content, staged)
        if sha256_file(staged_path) != CHANNEL_LIST_SHA256:
            raise ValueError('Channel List copy failed integrity verification.')
        # One fully-written file becomes visible. Never write into source files.
        if destination.exists() and not overwrite:
            raise FileExistsError(f'A different Channel List file already exists: {destination}')
        os.replace(staged_path, destination)
        staged_path = None
        if sha256_file(destination) != CHANNEL_LIST_SHA256:
            raise ValueError('Downloaded Channel List failed integrity verification.')
        return destination, 'saved'
    finally:
        if staged_path is not None:
            staged_path.unlink(missing_ok=True)
