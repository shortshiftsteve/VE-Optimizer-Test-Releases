# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

ROOT = Path(SPECPATH).parent

# Fail before Analysis if release/EXE metadata disagree, including direct spec builds.
import runpy
runpy.run_path(str(ROOT / "installer" / "verify_release_versions.py"))["verify_release_versions"](ROOT)

datas = [(str(ROOT / name), name) for name in ('a','help','legal','purchase','data','ui')]
datas += [(str(ROOT / name), '.') for name in ('README.txt','RELEASE_NOTES.txt','VALIDATION.json','MANIFEST.json','RUNTIME_ASSETS.json','Accepted_Processing_Method.txt')]

a = Analysis(
    [str(ROOT / 've_optimizer_revision9_review.py')],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=['tkinter', 'tkinter.ttk', 'tkinter.filedialog', 'tkinter.messagebox'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='VE_Optimizer',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    version=str(Path(SPECPATH) / 'version_info.txt'),
    contents_directory='.',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='VE_Optimizer',
)
