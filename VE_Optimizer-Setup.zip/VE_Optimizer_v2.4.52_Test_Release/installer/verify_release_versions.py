"""Read-only release-version preflight; no application imports or dependencies.

APP_VERSION in ve_optimizer_revision9_review.py is the comparison authority.
Run directly before building, or call verify_release_versions(root) from the
PyInstaller spec. An inconsistent/missing version fails the build, not silently
rewrites source files. This module is a build tool, not a runtime dependency.
"""
from __future__ import annotations

import argparse
import ast
import json
from pathlib import Path
import re
import sys


class VersionMismatch(ValueError):
    """Release metadata is missing, ambiguous, or inconsistent."""


def _one(values: list, label: str):
    if len(values) != 1:
        raise VersionMismatch(f"{label}: expected exactly one value; found {len(values)}")
    return values[0]


def _literal_constant(path: Path, name: str) -> str:
    tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    values = []
    for node in tree.body:
        if isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        elif isinstance(node, ast.AnnAssign):
            targets, value = [node.target], node.value
        else:
            continue
        if any(isinstance(target, ast.Name) and target.id == name for target in targets):
            if value is None:
                raise VersionMismatch(f"{path.name}: {name} has no literal value")
            values.append(ast.literal_eval(value))
    result = _one(values, f"{path.name}: {name}")
    if not isinstance(result, str):
        raise VersionMismatch(f"{path.name}: {name} must be a literal version string")
    return result


def _expect(actual, expected, label: str) -> None:
    if actual != expected:
        raise VersionMismatch(f"{label}: found {actual!r}; expected {expected!r}")


def verify_release_versions(root: Path) -> str:
    """Check release identity and all four Windows EXE version fields.

    Returns the application version on success. Raises on any discrepancy.
    Supports future three/four-component numeric releases without hardcoded
    version numbers. Deliberately ignores historical stage-module versions.
    """
    root = Path(root).resolve()
    version = _literal_constant(root / "ve_optimizer_revision9_review.py", "APP_VERSION")
    if not re.fullmatch(r"(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){2,3}", version):
        raise VersionMismatch(f"APP_VERSION must contain 3 or 4 numeric parts: {version!r}")
    parts = tuple(int(part) for part in version.split("."))
    if any(part > 65535 for part in parts):
        raise VersionMismatch("APP_VERSION components must be between 0 and 65535")
    numeric = parts + (0,) * (4 - len(parts))
    windows_version = ".".join(str(part) for part in numeric)

    stage = _literal_constant(root / "ve_optimizer_revision9_review.py", "RELEASE_STAGE")
    if stage not in ("Review", "Release"):
        raise VersionMismatch(f"Unsupported release stage: {stage!r}")
    _expect(_literal_constant(root / "ve_optimizer_license.py", "RELEASE_STAGE"),
            stage, "ve_optimizer_license.py: RELEASE_STAGE")
    _expect(_literal_constant(root / "ve_optimizer_revision9_review.py", "BUILD_ID"),
            f"{version}-{stage}", "ve_optimizer_revision9_review.py: BUILD_ID")
    metadata = root / "installer" / "version_info.txt"
    tree = ast.parse(metadata.read_text(encoding="utf-8-sig"), filename=str(metadata))
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Name)]
    fixed = _one([node for node in calls if node.func.id == "FixedFileInfo"],
                 "version_info.txt: FixedFileInfo")
    for field in ("filevers", "prodvers"):
        node = _one([kw.value for kw in fixed.keywords if kw.arg == field],
                    f"version_info.txt: {field}")
        value = ast.literal_eval(node)
        if not isinstance(value, tuple) or len(value) != 4 or any(type(v) is not int for v in value):
            raise VersionMismatch(f"version_info.txt: {field} must be a four-integer tuple")
        _expect(value, numeric, f"version_info.txt: {field}")
    for field in ("FileVersion", "ProductVersion"):
        values = [ast.literal_eval(node.args[1]) for node in calls
                  if node.func.id == "StringStruct" and len(node.args) == 2
                  and isinstance(node.args[0], ast.Constant) and node.args[0].value == field]
        _expect(_one(values, f"version_info.txt: {field}"), windows_version,
                f"version_info.txt: {field}")

    for filename, constant in (("ve_optimizer_license.py", "RELEASE_VERSION"),
                               ("ve_optimizer_purchase.py", "PRODUCT_VERSION")):
        _expect(_literal_constant(root / filename, constant), version,
                f"{filename}: {constant}")
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8-sig"))
    _expect(manifest.get("app_version"), version, "MANIFEST.json: app_version")
    _expect(manifest.get("build_id"), f"{version}-{stage}", "MANIFEST.json: build_id")

    iss = root / "installer" / f"VE_Optimizer_v{version}.iss"
    text = iss.read_text(encoding="utf-8-sig")
    declared = _one(re.findall(r'^\s*#define\s+MyAppVersion\s+"([^"]+)"\s*$',
                              text, re.MULTILINE), f"{iss.name}: MyAppVersion")
    _expect(declared, version, f"{iss.name}: MyAppVersion")
    setup = _one(re.findall(r'^\[Setup\]\s*\n(.*?)(?=^\[|\Z)',
                           text, re.MULTILINE | re.DOTALL), f"{iss.name}: [Setup]")
    for key, expected in (("AppVersion", version),
                          ("OutputBaseFilename", f"VE Optimizer v{version} {stage} Setup"),
                          ("UninstallDisplayName", f"VE Optimizer {version} {stage}")):
        actual = _one(re.findall(rf'^\s*{key}\s*=\s*([^\r\n]+)$', setup, re.MULTILINE),
                      f"{iss.name}: {key}").strip().replace("{#MyAppVersion}", version)
        _expect(actual, expected, f"{iss.name}: {key}")
    # Inno derives its numeric version from AppVersion when this override is absent.
    overrides = re.findall(r'^\s*VersionInfoVersion\s*=\s*([^\r\n]+)$', setup, re.MULTILINE)
    if overrides:
        actual = _one(overrides, f"{iss.name}: VersionInfoVersion").strip()
        actual = actual.replace("{#MyAppVersion}", version)
        if actual not in (version, windows_version):
            raise VersionMismatch(f"{iss.name}: VersionInfoVersion {actual!r} conflicts with {version}")
    return version


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent,
                        help="Release source directory; defaults to the parent of installer")
    args = parser.parse_args()
    try:
        version = verify_release_versions(args.root)
    except (OSError, ValueError, SyntaxError) as exc:
        print(f"ERROR: Release version preflight failed: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: application, license, purchase, manifest, installer and Windows EXE versions agree ({version}).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
