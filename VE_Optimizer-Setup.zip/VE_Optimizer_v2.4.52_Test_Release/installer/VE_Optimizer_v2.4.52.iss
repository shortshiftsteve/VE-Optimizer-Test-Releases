; VE Optimizer Version 2.4.52 - Release installer
; Build flow: Build_VE_Optimizer_v2.4.52_Installer.bat -> PyInstaller -> Azure Artifact Signing -> Inno Setup -> Azure Artifact Signing
#define MyAppName "VE Optimizer"
#define MyAppVersion "2.4.52"
#define MyAppPublisher "Stephen B. Schefer"
#define MyAppExe "VE_Optimizer.exe"

[Setup]
AppId={{6D4E4C12-8E21-4D2A-9A8C-0E0100000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName=VE Optimizer {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Short Shift Garage
DefaultGroupName=VE Optimizer
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=Output
OutputBaseFilename=VE Optimizer v2.4.52 Release Setup
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayName=VE Optimizer 2.4.52 Release
UninstallDisplayIcon={app}\{#MyAppExe}
WizardStyle=modern
LicenseFile=..\legal\VE_EULA_1.4.txt
InfoBeforeFile=..\legal\REFUND_POLICY_1.2.txt
CloseApplications=yes
RestartApplications=no
UsePreviousAppDir=yes
SetupLogging=yes
SignTool=VEArtifactSign
SignedUninstaller=yes
SignToolRetryCount=3
SignToolRetryDelay=1500
SignToolMinimumTimeBetween=1000

[Files]
Source: "dist\VE_Optimizer\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Icons]
Name: "{group}\VE Optimizer"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"
Name: "{userdesktop}\VE Optimizer"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Launch VE Optimizer"; WorkingDir: "{app}"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
; Retain database, license and trial state during all updates, and by default
; during manual uninstall. CurUninstallStepChanged deletes application-managed
; user data ONLY if the user explicitly selects NO at normal uninstall.
Type: filesandordirs; Name: "{app}\__pycache__"

[Code]

type
  TSystemTime = record
    wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds: Word;
  end;

procedure GetSystemTime(var lpSystemTime: TSystemTime);
  external 'GetSystemTime@kernel32.dll stdcall';

function TrialInstallUtc: String;
var
  ST: TSystemTime;
begin
  GetSystemTime(ST);
  Result := Format('%.4d-%.2d-%.2dT%.2d:%.2d:%.2dZ', [ST.wYear, ST.wMonth, ST.wDay, ST.wHour, ST.wMinute, ST.wSecond]);
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Existing: String;
begin
  if CurStep = ssPostInstall then
  begin
    if (not RegQueryStringValue(HKCU, 'Software\VEOptimizer', 'TrialInstalledUtc', Existing)) or (Trim(Existing) = '') then
      RegWriteStringValue(HKCU, 'Software\VEOptimizer', 'TrialInstalledUtc', TrialInstallUtc);
  end;
end;

var
  InfoAcceptCheck: TNewCheckBox;
  InfoAcceptLabel: TNewStaticText;
  LicenseAcceptCheck: TNewCheckBox;
  LicenseAcceptLabel: TNewStaticText;

procedure InitializeWizard;
var
  AcceptTop: Integer;
begin
  { Refund Policy / Information page: keep Next clickable, but do not advance unless Accept is checked. }
  WizardForm.InfoBeforeMemo.Height := WizardForm.InfoBeforeMemo.Height - ScaleY(44);
  InfoAcceptCheck := TNewCheckBox.Create(WizardForm.InfoBeforePage);
  InfoAcceptCheck.Parent := WizardForm.InfoBeforePage;
  InfoAcceptCheck.Caption := '';
  InfoAcceptCheck.Checked := False;
  InfoAcceptCheck.Left := WizardForm.InfoBeforeMemo.Left;
  InfoAcceptCheck.Top := WizardForm.InfoBeforeMemo.Top + WizardForm.InfoBeforeMemo.Height + ScaleY(8);
  InfoAcceptCheck.Width := ScaleX(16);
  InfoAcceptCheck.Height := ScaleY(18);

  InfoAcceptLabel := TNewStaticText.Create(WizardForm.InfoBeforePage);
  InfoAcceptLabel.Parent := WizardForm.InfoBeforePage;
  InfoAcceptLabel.Caption := '  I have read and accept the terms of the VE Optimizer Refund Policy Version 1.2';
  InfoAcceptLabel.Left := InfoAcceptCheck.Left + ScaleX(18);
  InfoAcceptLabel.Top := InfoAcceptCheck.Top + ScaleY(1);
  InfoAcceptLabel.Width := WizardForm.InfoBeforeMemo.Width - ScaleX(18);
  InfoAcceptLabel.Height := ScaleY(34);
  InfoAcceptLabel.AutoSize := False;
  InfoAcceptLabel.WordWrap := True;

  { License page: replace the built-in Accept/Decline radio choices with one Accept checkbox.
    Keep the hidden built-in acceptance selected so Inno leaves Next enabled; NextButtonClick below
    is the only gate visible to the customer. }
  WizardForm.LicenseMemo.Width := WizardForm.InfoBeforeMemo.Width;
  WizardForm.LicenseMemo.Height := WizardForm.InfoBeforeMemo.Height;
  AcceptTop := WizardForm.LicenseMemo.Top + WizardForm.LicenseMemo.Height + ScaleY(8);
  WizardForm.LicenseAcceptedRadio.Checked := True;
  WizardForm.LicenseAcceptedRadio.Visible := False;
  WizardForm.LicenseNotAcceptedRadio.Visible := False;

  LicenseAcceptCheck := TNewCheckBox.Create(WizardForm.LicensePage);
  LicenseAcceptCheck.Parent := WizardForm.LicensePage;
  LicenseAcceptCheck.Caption := '';
  LicenseAcceptCheck.Checked := False;
  LicenseAcceptCheck.Left := WizardForm.LicenseMemo.Left;
  LicenseAcceptCheck.Top := AcceptTop;
  LicenseAcceptCheck.Width := ScaleX(16);
  LicenseAcceptCheck.Height := ScaleY(18);

  LicenseAcceptLabel := TNewStaticText.Create(WizardForm.LicensePage);
  LicenseAcceptLabel.Parent := WizardForm.LicensePage;
  LicenseAcceptLabel.Caption := '   I have read and I understand the End User License Agreement';
  LicenseAcceptLabel.Left := LicenseAcceptCheck.Left + ScaleX(18);
  LicenseAcceptLabel.Top := LicenseAcceptCheck.Top + ScaleY(1);
  LicenseAcceptLabel.Width := WizardForm.LicenseMemo.Width - ScaleX(18);
  LicenseAcceptLabel.Height := ScaleY(34);
  LicenseAcceptLabel.AutoSize := False;
  LicenseAcceptLabel.WordWrap := True;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if (CurPageID = wpInfoBefore) and (InfoAcceptCheck <> nil) and (not InfoAcceptCheck.Checked) then
  begin
    Result := False;
    Exit;
  end;
  if (CurPageID = wpLicense) and (LicenseAcceptCheck <> nil) and (not LicenseAcceptCheck.Checked) then
  begin
    Result := False;
    Exit;
  end;
end;


{ Normal user-initiated uninstall: one Yes/No user-data question.  The silent
  updater path intentionally never asks and never erases anything. }
var
  RemoveUserDataOnUninstall: Boolean;

function InitializeUninstall(): Boolean;
begin
  Result := True;
  RemoveUserDataOnUninstall := False;
  if not UninstallSilent then
    RemoveUserDataOnUninstall :=
      (MsgBox('Do you want to keep your VE Optimizer user data?' + #13#10 +
              'YES: Keep projects, settings, and purchased license.' + #13#10 +
              'NO: Remove all local VE Optimizer data, including licensing.',
              mbConfirmation, MB_YESNO or MB_DEFBUTTON1) = IDNO);
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if (CurUninstallStep = usPostUninstall) and RemoveUserDataOnUninstall then
  begin
    { Only application-managed locations. Do not touch exported HP Tuners files. }
    DelTree(ExpandConstant('{app}\data'), True, True, True);
    DelTree(ExpandConstant('{localappdata}\VEOptimizer'), True, True, True);
    RegDeleteKeyIncludingSubkeys(HKCU, 'Software\VEOptimizer');
  end;
end;
