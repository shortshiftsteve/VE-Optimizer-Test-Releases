Windows Test Release build

Use Python 3.12 x64 with Tcl/Tk and the pinned requirements. Run the supplied
reference integration test first. The build script retains the existing signing
configuration and license behavior, and installs NumPy/SciPy for packaging.
Windows GUI, frozen executable, installer and signing have not been run here.
Confirm the five cam views, Apply Changes, Build It, fresh-log successor setup,
and HP Tuners template application on the Windows build before release.

BUILD FAILURE LOGGING
The installer build now creates installer\VE_Optimizer_v2.4.52_BUILD_LOG.txt before any build or signing work begins. If the first signing, signature verification, Inno Setup discovery, installer compile, or final signing fails, the build window remains open and the complete diagnostic log is preserved.

RELEASE VERSION PREFLIGHT
installer\version_info.txt has numeric filevers/prodvers (2, 4, 51, 0),
matching FileVersion/ProductVersion 2.4.52.0 and the 2.4.52 Release application.

Both the normal build batch and direct PyInstaller spec builds run the new
verify_release_versions.py check before compiling the executable. It checks
the application, license/purchase versions, manifest app_version, Inno Setup
version/name fields, and all four Windows EXE version fields. A mismatch stops
the build before a new executable can be compiled or signed.

For a future version bump, update APP_VERSION and the matching release metadata
including BOTH numeric tuples and BOTH displayed strings in version_info.txt.
The check derives its expected version from APP_VERSION; it does not contain a
hardcoded 2.4.52 comparison and does not silently rewrite your source.

Optional standalone check, from the release root:
  py -3 installer\verify_release_versions.py
Regression tests, from the release root:
  py -3 -m unittest discover -s tests -p test_release_version_metadata.py -v
