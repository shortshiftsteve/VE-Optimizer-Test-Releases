@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

rem Keep a persistent build/signing log outside Output so early failures are never lost.
if /I not "%~1"=="--logged" (
  set "BUILD_LOG=%~dp0VE_Optimizer_v2.4.52_BUILD_LOG.txt"
  > "!BUILD_LOG!" echo VE Optimizer 2.4.52 build started: !DATE! !TIME!
  call "%~f0" --logged >> "!BUILD_LOG!" 2>&1
  set "BUILD_RC=!ERRORLEVEL!"
  echo.
  if "!BUILD_RC!"=="0" (
    echo Build completed successfully.
    echo Full build log: !BUILD_LOG!
  ) else (
    echo =============================================================
    echo BUILD FAILED - exit code !BUILD_RC!
    echo Full build/signing log: !BUILD_LOG!
    echo =============================================================
    echo.
    type "!BUILD_LOG!"
    echo.
    echo The window will remain open so the failure can be reviewed.
    pause
  )
  exit /b !BUILD_RC!
)
shift

set "BUILD_LOG=%~dp0VE_Optimizer_v2.4.52_BUILD_LOG.txt"
set "VENV=%~dp0.buildenv"
set "SPEC=%~dp0VE_Optimizer.spec"
set "ISS=%~dp0VE_Optimizer_v2.4.52.iss"
set "APP_EXE=%~dp0dist\VE_Optimizer\VE_Optimizer.exe"
set "SETUP=%~dp0Output\VE Optimizer v2.4.52 Release Setup.exe"
set "RECORD=%~dp0Output\VE_Optimizer_v2.4.52_SIGNING_RECORD.txt"

rem Azure Artifact Signing configuration for the release build computer.
set "SIGNTOOL=C:\Program Files (x86)\Windows Kits\10\bin\10.0.26100.0\x64\signtool.exe"
set "AZURE_DLIB=C:\ArtifactSigning\Microsoft.ArtifactSigning.Client\bin\x64\Azure.CodeSigning.Dlib.dll"
set "AZURE_METADATA=C:\ArtifactSigning\metadata.json"
set "TIMESTAMP_URL=http://timestamp.acs.microsoft.com"
set "AZURE_TENANT_ID=e6471c53-1194-4879-9aff-77bac521588c"

rem Inno Setup SignTool name. The command is supplied to ISCC below.
set "INNO_SIGN_NAME=VEArtifactSign"

echo =============================================================
echo VE Optimizer Version 2.4.52 - Release Build
echo =============================================================
echo.
echo Release signing sequence:
echo   1. Build VE_Optimizer.exe with PyInstaller
echo   2. Sign + timestamp VE_Optimizer.exe with Azure Artifact Signing
echo   3. Verify VE_Optimizer.exe Authenticode signature
echo   4. Build Inno Setup installer
echo   5. Inno signs the uninstaller and Setup.exe with Azure Artifact Signing
echo   6. Verify Setup.exe Authenticode signature
echo   7. Record SHA-256 hashes and signing status
echo.

call :Preflight
if errorlevel 1 exit /b 1

echo Verifying finalized EULA integrity...
py -3 -c "import hashlib,pathlib; p=pathlib.Path(r'%~dp0..\legal\VE_EULA_1.4.txt'); a=hashlib.sha256(p.read_bytes()).hexdigest(); e='1c924f199a0d1c6f67500051dd1502e74bbbc51a23dd8ae2ae5dbc683efe1aab'; print('EULA SHA-256:',a); assert a==e, 'Finalized EULA hash does not match application integrity constant'"
if errorlevel 1 (
  echo ERROR: EULA integrity preflight failed. Do not sign this build.
  exit /b 1
)

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher ^(py.exe^) is required on the BUILD computer.
  echo Install 64-bit Python 3 with Tcl/Tk, then run this script again.
  exit /b 1
)

echo Verifying release version consistency...
py -3 "%~dp0verify_release_versions.py"
if errorlevel 1 (
  echo ERROR: Release version metadata disagree. Correct the reported fields before building.
  exit /b 1
)

py -3 -c "import struct,tkinter,sys; assert struct.calcsize('P')==8, '64-bit Python is required'; print(sys.version); print('Tk', tkinter.TkVersion)"
if errorlevel 1 (
  echo ERROR: A 64-bit Python installation with Tcl/Tk is required on the BUILD computer.
  exit /b 1
)

if not exist "%VENV%\Scripts\python.exe" (
  echo Creating isolated build environment...
  py -3 -m venv "%VENV%"
  if errorlevel 1 exit /b 1
)

call "%VENV%\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install "pyinstaller>=6,<7" -r "%~dp0..\requirements.txt"
if errorlevel 1 exit /b 1

if exist "%~dp0build" rmdir /s /q "%~dp0build"
if exist "%~dp0dist" rmdir /s /q "%~dp0dist"
if exist "%~dp0Output" rmdir /s /q "%~dp0Output"

echo.
echo Building self-contained VE Optimizer application...
pyinstaller --noconfirm --clean "%SPEC%"
if errorlevel 1 exit /b 1
if not exist "%APP_EXE%" (
  echo ERROR: PyInstaller did not produce VE_Optimizer.exe.
  exit /b 1
)


echo.
echo Launch-testing packaged VE_Optimizer.exe before signing...
"%APP_EXE%" --smoke-test
if errorlevel 1 (
  echo ERROR: Packaged VE_Optimizer.exe failed its startup test. Do not sign this build.
  exit /b 1
)

echo.
echo Signing VE_Optimizer.exe with Azure Artifact Signing...
call :SignFile "%APP_EXE%"
if errorlevel 1 exit /b 1
echo First signing stage completed successfully.

echo.
echo Verifying VE_Optimizer.exe signature...
call :VerifyFile "%APP_EXE%"
if errorlevel 1 exit /b 1
echo First signature verification completed successfully.

echo.
echo Locating Inno Setup compiler...
call :FindISCC
if not defined ISCC (
  echo Inno Setup 6/7 was not found in the standard machine or per-user locations.
  echo Attempting installation with winget...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo ERROR: Install Inno Setup and rerun this script.
    echo https://jrsoftware.org/isinfo.php
    exit /b 1
  )
  winget install --id JRSoftware.InnoSetup -e --silent --accept-source-agreements --accept-package-agreements
  call :FindISCC
)

if not defined ISCC (
  echo ERROR: Inno Setup appears to be installed, but ISCC.exe could not be located.
  echo Checked PATH, LocalAppData, Program Files, Program Files ^(x86^), and Inno Setup registry entries.
  exit /b 1
)

echo.
echo Using Inno Setup compiler:
echo %ISCC%
echo.
echo Compiling and signing customer installer...
rem $q and $f below are Inno Setup SignTool substitutions: $q = quote, $f = quoted file name.
set "INNO_SIGN_COMMAND=$q%SIGNTOOL%$q sign /v /debug /fd SHA256 /tr $q%TIMESTAMP_URL%$q /td SHA256 /dlib $q%AZURE_DLIB%$q /dmdf $q%AZURE_METADATA%$q $f"
"%ISCC%" "-s%INNO_SIGN_NAME%=%INNO_SIGN_COMMAND%" "%ISS%"
if errorlevel 1 (
  echo ERROR: Inno Setup compile/signing failed.
  exit /b 1
)

if not exist "%SETUP%" (
  echo ERROR: Expected setup executable was not created.
  exit /b 1
)

echo.
echo Verifying final Setup.exe signature...
call :VerifyFile "%SETUP%"
if errorlevel 1 exit /b 1

echo.
echo Writing release signing record...
(
  echo VE Optimizer Version 2.4.52 - Signed Release Record
  echo ========================================================
  echo Build date/time: %DATE% %TIME%
  echo.
  echo SignTool:
  echo !SIGNTOOL!
  echo.
  echo Azure Artifact Signing dlib:
  echo !AZURE_DLIB!
  echo.
  echo Azure metadata:
  echo !AZURE_METADATA!
  echo.
  echo Timestamp service:
  echo !TIMESTAMP_URL!
  echo.
  echo APPLICATION SIGNATURE VERIFICATION
) > "%RECORD%"
"%SIGNTOOL%" verify /pa /v "%APP_EXE%" >> "%RECORD%" 2>&1
(
  echo.
  echo INSTALLER SIGNATURE VERIFICATION
) >> "%RECORD%"
"%SIGNTOOL%" verify /pa /v "%SETUP%" >> "%RECORD%" 2>&1
(
  echo.
  echo APPLICATION SHA-256
) >> "%RECORD%"
certutil -hashfile "%APP_EXE%" SHA256 >> "%RECORD%"
(
  echo.
  echo INSTALLER SHA-256
) >> "%RECORD%"
certutil -hashfile "%SETUP%" SHA256 >> "%RECORD%"

echo.
echo =============================================================
echo SIGNED REVIEW BUILD COMPLETE
echo =============================================================
echo Installer:
echo %SETUP%
echo.
echo Signing record:
echo %RECORD%
echo.
echo Final installer SHA-256:
certutil -hashfile "%SETUP%" SHA256
exit /b 0

:Preflight
if not exist "%SIGNTOOL%" (
  echo ERROR: x64 SignTool was not found:
  echo !SIGNTOOL!
  exit /b 1
)
if not exist "%AZURE_DLIB%" (
  echo ERROR: Azure Artifact Signing x64 dlib was not found:
  echo !AZURE_DLIB!
  exit /b 1
)
if not exist "%AZURE_METADATA%" (
  echo ERROR: Azure Artifact Signing metadata file was not found:
  echo !AZURE_METADATA!
  exit /b 1
)

echo Signing prerequisites found:
echo   SignTool : !SIGNTOOL!
echo   dlib     : !AZURE_DLIB!
echo   metadata : !AZURE_METADATA!
echo.
"%SIGNTOOL%" /? >nul 2>nul
if errorlevel 1 (
  echo ERROR: SignTool could not be executed.
  exit /b 1
)
exit /b 0

:SignFile
set "SIGN_TARGET=%~1"
"%SIGNTOOL%" sign /v /debug /fd SHA256 /tr "%TIMESTAMP_URL%" /td SHA256 /dlib "%AZURE_DLIB%" /dmdf "%AZURE_METADATA%" "!SIGN_TARGET!"
if errorlevel 1 (
  echo ERROR: Azure Artifact Signing failed for:
  echo(!SIGN_TARGET!
  echo.
  echo Confirm Azure authentication and the Artifact Signing Certificate Profile Signer role.
  exit /b 1
)
exit /b 0

:VerifyFile
set "VERIFY_TARGET=%~1"
"%SIGNTOOL%" verify /pa /v "!VERIFY_TARGET!"
if errorlevel 1 (
  echo ERROR: Authenticode verification failed for:
  echo(!VERIFY_TARGET!
  exit /b 1
)
exit /b 0

:FindISCC
set "ISCC="

rem First try PATH.
for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"

rem Common per-user installs.
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 7\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 7\ISCC.exe"
if not defined ISCC if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

rem Common machine-wide install locations.
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"

rem Registry discovery for per-user and machine-wide installs.
if not defined ISCC call :FindISCCRegistry HKCU "Inno Setup 7_is1"
if not defined ISCC call :FindISCCRegistry HKCU "Inno Setup 6_is1"
if not defined ISCC call :FindISCCRegistry HKLM "Inno Setup 7_is1"
if not defined ISCC call :FindISCCRegistry HKLM "Inno Setup 6_is1"
exit /b 0

:FindISCCRegistry
for /f "tokens=2,*" %%A in ('reg query "%~1\Software\Microsoft\Windows\CurrentVersion\Uninstall\%~2" /v InstallLocation 2^>nul ^| find /i "InstallLocation"') do (
  if exist "%%B\ISCC.exe" set "ISCC=%%B\ISCC.exe"
)
if not defined ISCC (
  for /f "tokens=2,*" %%A in ('reg query "%~1\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\%~2" /v InstallLocation 2^>nul ^| find /i "InstallLocation"') do (
    if exist "%%B\ISCC.exe" set "ISCC=%%B\ISCC.exe"
  )
)
exit /b 0
