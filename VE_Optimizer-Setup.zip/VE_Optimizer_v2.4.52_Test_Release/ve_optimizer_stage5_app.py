#!/usr/bin/env python3
"""Account, project and audit storage. Numerical processing lives in ve_optimizer_processing."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sqlite3
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

import ve_optimizer_stage4_app as s4

# Reuse Tk import state from Stage 4.
tk = s4.tk
ttk = s4.ttk
filedialog = s4.filedialog
messagebox = s4.messagebox

APP_NAME = "VE Optimizer"
APP_VERSION = "0.0.1-stage5.1"
DB_NAME = "ve_optimizer.db"

# Make inherited Stage 4 screens display the Stage 5 version where applicable.
s4.APP_NAME = APP_NAME
s4.APP_VERSION = APP_VERSION


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


class Database(s4.Database):
    """Stage 4 database plus append-only project audit records."""

    def __init__(self, path: Path):
        super().__init__(path)
        self._init_stage5_schema()

    def _init_stage5_schema(self):
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS project_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                run_type TEXT NOT NULL,
                source_path TEXT NOT NULL,
                source_sha256 TEXT NOT NULL,
                conditioned_path TEXT,
                accepted_path TEXT,
                report_path TEXT,
                accepted_count INTEGER,
                trim_mean REAL,
                trim_median REAL,
                trim_mae REAL,
                trim_p95_abs REAL,
                operator_mature_confirmed INTEGER NOT NULL DEFAULT 0,
                validation_status TEXT,
                improvement_pct REAL,
                created_by INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id),
                FOREIGN KEY(created_by) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS project_artifacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                artifact_type TEXT NOT NULL,
                path TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                note TEXT DEFAULT '',
                created_by INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id),
                FOREIGN KEY(created_by) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS project_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                detail TEXT NOT NULL,
                created_by INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id),
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            CREATE INDEX IF NOT EXISTS idx_project_runs_project ON project_runs(project_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_project_artifacts_project ON project_artifacts(project_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_project_events_project ON project_events(project_id, created_at);
            """
        )
        self.conn.commit()

    def record_event(self, project_id: int, event_type: str, detail: str, created_by: Optional[int]):
        self.conn.execute(
            "INSERT INTO project_events(project_id,event_type,detail,created_by,created_at) VALUES(?,?,?,?,?)",
            (project_id, event_type, detail, created_by, utc_now()),
        )
        self.conn.commit()

    def record_run(
        self,
        project_id: int,
        run_type: str,
        source_path: Path,
        result: Dict[str, object],
        created_by: Optional[int],
        mature_confirmed: bool = False,
        validation: Optional[Dict[str, object]] = None,
    ) -> int:
        m = result["metrics"]
        validation = validation or {}
        cur = self.conn.execute(
            """INSERT INTO project_runs(
                project_id,run_type,source_path,source_sha256,conditioned_path,accepted_path,report_path,
                accepted_count,trim_mean,trim_median,trim_mae,trim_p95_abs,operator_mature_confirmed,
                validation_status,improvement_pct,created_by,created_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                project_id,
                run_type,
                str(source_path),
                sha256_file(source_path),
                str(result["conditioned"]),
                str(result["accepted"]),
                str(result["report"]),
                int(m["count"]),
                float(m["mean"]),
                float(m["median"]),
                float(m["mae"]),
                float(m["p95_abs"]),
                int(bool(mature_confirmed)),
                validation.get("status"),
                validation.get("improvement_pct"),
                created_by,
                utc_now(),
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def add_artifact(self, project_id: int, artifact_type: str, path: Path, note: str, created_by: Optional[int]) -> int:
        path = Path(path)
        cur = self.conn.execute(
            "INSERT INTO project_artifacts(project_id,artifact_type,path,sha256,note,created_by,created_at) VALUES(?,?,?,?,?,?,?)",
            (project_id, artifact_type, str(path), sha256_file(path), note, created_by, utc_now()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def list_runs(self, project_id: int):
        return self.conn.execute(
            "SELECT * FROM project_runs WHERE project_id=? ORDER BY id DESC", (project_id,)
        ).fetchall()

    def list_artifacts(self, project_id: int):
        return self.conn.execute(
            "SELECT * FROM project_artifacts WHERE project_id=? ORDER BY id DESC", (project_id,)
        ).fetchall()

    def list_events(self, project_id: int):
        return self.conn.execute(
            "SELECT * FROM project_events WHERE project_id=? ORDER BY id DESC", (project_id,)
        ).fetchall()



    def export_manifest(self, project_id: int) -> Dict[str, object]:
        p = self.conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        if not p:
            raise ValueError("Project not found.")
        project_dict = {k: p[k] for k in p.keys()}
        return {
            "format": "VE Optimizer Project Package",
            "format_version": 1,
            "app_version": APP_VERSION,
            "exported_at": utc_now(),
            "project": project_dict,
            "state": self.project_state(project_id),
            "runs": [{k: r[k] for k in r.keys()} for r in reversed(self.list_runs(project_id))],
            "artifacts": [{k: r[k] for k in r.keys()} for r in reversed(self.list_artifacts(project_id))],
            "events": [{k: r[k] for k in r.keys()} for r in reversed(self.list_events(project_id))],
        }


def export_project_package(db: Database, project: s4.Project, destination: Path) -> Path:
    """Export manifest and generated project artifacts; deliberately excludes user/password DB."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    manifest = db.export_manifest(project.id)
    root = Path(project.output_dir).resolve()

    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("project_manifest.json", json.dumps(manifest, indent=2, default=str))
        seen = set()
        candidates = []
        for r in db.list_runs(project.id):
            for col in ("conditioned_path", "accepted_path", "report_path"):
                if r[col]:
                    candidates.append(Path(r[col]))
        for a in db.list_artifacts(project.id):
            candidates.append(Path(a["path"]))
        for p in candidates:
            try:
                resolved = p.resolve()
                # Export only project-output artifacts; never sweep arbitrary source paths.
                if not resolved.exists() or not resolved.is_file() or root not in resolved.parents:
                    continue
                if resolved in seen:
                    continue
                seen.add(resolved)
                rel = resolved.relative_to(root)
                zf.write(resolved, arcname=str(Path("artifacts") / rel))
            except Exception:
                continue
    return destination

