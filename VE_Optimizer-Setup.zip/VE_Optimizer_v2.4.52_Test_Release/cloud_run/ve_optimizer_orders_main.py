import json
import os
import re
import smtplib
from datetime import datetime
from email.message import EmailMessage
from html import escape

import functions_framework
from flask import jsonify


PO_PATTERN = re.compile(r"^[A-Za-z0-9_-]{6,80}$")
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def money(value):
    try:
        return f"${float(value):,.2f}"
    except (TypeError, ValueError):
        return str(value or "")


def clean(value):
    return escape(str(value or "").strip())


def format_date(value):
    if not value:
        return ""
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt.strftime("%B %d, %Y %H:%M UTC")
    except Exception:
        return str(value)


@functions_framework.http
def purchase_order(request):
    if request.method == "GET":
        return jsonify({
            "service": "VE Optimizer Purchase Order Service",
            "status": "online"
        }), 200

    if request.method != "POST":
        return jsonify({"error": "Method not allowed"}), 405

    if request.content_length and request.content_length > 32768:
        return jsonify({"error": "Request too large"}), 413

    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({"error": "JSON request body required"}), 400

    po_number = str(data.get("po_number", "")).strip()
    buyer_email = str(
        data.get("buyer_email")
        or data.get("email")
        or ""
    ).strip()

    if not PO_PATTERN.fullmatch(po_number):
        return jsonify({"error": "Invalid Purchase Order number"}), 400

    if not EMAIL_PATTERN.fullmatch(buyer_email):
        return jsonify({"error": "Invalid buyer email"}), 400

    gmail_user = os.environ.get("GMAIL_USER", "").strip()
    gmail_password = os.environ.get("GMAIL_APP_PASSWORD", "").strip()
    order_to = os.environ.get("ORDER_TO_EMAIL", "").strip()

    if not gmail_user or not gmail_password or not order_to:
        return jsonify({"error": "Mail service is not configured"}), 500

    order = data.get("order") or {}
    buyer = order.get("buyer") or {}
    items = order.get("items") or []

    buyer_name = (
        data.get("buyer_name")
        or f"{buyer.get('first_name', '')} {buyer.get('last_name', '')}".strip()
    )

    address_lines = [
        buyer.get("address"),
        " ".join(
            x for x in [
                str(buyer.get("city", "")).strip(),
                str(buyer.get("state", "")).strip(),
                str(buyer.get("postal_code", "")).strip()
            ] if x
        ),
        buyer.get("country")
    ]
    address_text = "\n".join(str(x) for x in address_lines if x)

    item = items[0] if items else {}

    product = item.get("product") or data.get("product") or "VE Optimizer"
    version = item.get("version") or data.get("version") or ""
    quantity = item.get("quantity") or 1
    unit_price = item.get("unit_price_usd") or ""
    total = order.get("total_usd") or item.get("line_total_usd") or ""
    scope = item.get("license_scope") or ""

    status = order.get("status") or "AWAITING_PAYMENT"
    payment_status = order.get("payment_status") or "AWAITING_PAYMENT"
    license_status = order.get("license_status") or "NOT_ISSUED"
    created = order.get("created_utc") or ""

    terms = order.get("terms") or []

    # Plain-text fallback
    plain = f"""VE OPTIMIZER PURCHASE ORDER

Purchase Order: {po_number}
Date: {format_date(created)}
Status: {status.replace("_", " ").title()}

BUYER
{buyer_name}
{address_text}
Email: {buyer_email}
Phone: {buyer.get("phone", "")}

ORDER
Product: {product}
Version: {version}
Quantity: {quantity}
Unit Price: {money(unit_price)}
Total: {money(total)}

LICENSE
{scope}

Payment Status: {payment_status.replace("_", " ").title()}
License Status: {license_status.replace("_", " ").title()}

TERMS
"""

    for n, term in enumerate(terms, start=1):
        plain += f"{n}. {term}\n"

    plain += """
Payment instructions are sent automatically to the buyer. Confirm payment before issuing a license.
"""

    # HTML email
    terms_html = "".join(
        f"<li style='margin-bottom:8px'>{clean(term)}</li>"
        for term in terms
    )

    address_html = "<br>".join(
        clean(x) for x in address_lines if x
    )

    html_body = f"""
<!DOCTYPE html>
<html>
<body style="margin:0;padding:24px;background:#f4f6f8;
             font-family:Arial,Helvetica,sans-serif;color:#202124">

<div style="max-width:760px;margin:auto;background:white;
            border:1px solid #d9dde3;border-radius:8px;overflow:hidden">

    <div style="background:#174ea6;color:white;padding:22px 28px">
        <div style="font-size:13px;letter-spacing:1px">
            VE OPTIMIZER
        </div>
        <div style="font-size:26px;font-weight:bold;margin-top:4px">
            PURCHASE ORDER
        </div>
    </div>

    <div style="padding:26px 30px">

        <table style="width:100%;border-collapse:collapse;margin-bottom:24px">
            <tr>
                <td style="font-weight:bold">Purchase Order</td>
                <td style="text-align:right;font-weight:bold">
                    {clean(po_number)}
                </td>
            </tr>
            <tr>
                <td style="padding-top:7px">Date</td>
                <td style="padding-top:7px;text-align:right">
                    {clean(format_date(created))}
                </td>
            </tr>
            <tr>
                <td style="padding-top:7px">Status</td>
                <td style="padding-top:7px;text-align:right">
                    {clean(status.replace("_", " ").title())}
                </td>
            </tr>
        </table>

        <div style="font-size:16px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            Buyer
        </div>

        <div style="padding:12px 0 24px;line-height:1.55">
            <strong>{clean(buyer_name)}</strong><br>
            {address_html}<br>
            Email:
            <a href="mailto:{clean(buyer_email)}">
                {clean(buyer_email)}
            </a>
            <br>
            Phone: {clean(buyer.get("phone", ""))}
        </div>

        <div style="font-size:16px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            Order
        </div>

        <table style="width:100%;border-collapse:collapse;margin:12px 0 24px">
            <tr style="background:#f3f5f7">
                <th style="padding:10px;text-align:left">Product</th>
                <th style="padding:10px;text-align:center">Qty</th>
                <th style="padding:10px;text-align:right">Unit Price</th>
                <th style="padding:10px;text-align:right">Total</th>
            </tr>
            <tr>
                <td style="padding:12px 10px;border-bottom:1px solid #ddd">
                    <strong>{clean(product)}</strong><br>
                    Version {clean(version)}
                </td>
                <td style="padding:12px 10px;text-align:center;
                           border-bottom:1px solid #ddd">
                    {clean(quantity)}
                </td>
                <td style="padding:12px 10px;text-align:right;
                           border-bottom:1px solid #ddd">
                    {clean(money(unit_price))}
                </td>
                <td style="padding:12px 10px;text-align:right;
                           border-bottom:1px solid #ddd;font-weight:bold">
                    {clean(money(total))}
                </td>
            </tr>
        </table>

        <div style="text-align:right;font-size:21px;font-weight:bold;
                    margin-bottom:28px">
            Total: {clean(money(total))}
        </div>

        <div style="font-size:16px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            License
        </div>

        <div style="padding:12px 0;line-height:1.5">
            {clean(scope)}
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:26px">
            <tr>
                <td style="padding:5px 0"><strong>Payment Status</strong></td>
                <td style="text-align:right">
                    {clean(payment_status.replace("_", " ").title())}
                </td>
            </tr>
            <tr>
                <td style="padding:5px 0"><strong>License Status</strong></td>
                <td style="text-align:right">
                    {clean(license_status.replace("_", " ").title())}
                </td>
            </tr>
        </table>

        <div style="font-size:16px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            Terms
        </div>

        <ol style="line-height:1.45;padding-left:22px">
            {terms_html}
        </ol>

        <div style="margin-top:24px;padding:14px 16px;background:#fff8e1;
                    border-left:4px solid #f9ab00;line-height:1.45">
            <strong>Payment Instructions Sent Automatically</strong><br>
            Confirm payment independently before issuing a license.
        </div>

    </div>
</div>

</body>
</html>
"""

    msg = EmailMessage()
    msg["From"] = gmail_user
    msg["To"] = order_to
    msg["Reply-To"] = buyer_email
    msg["Subject"] = f"VE Optimizer Purchase Order {po_number}"

    msg.set_content(plain)
    msg.add_alternative(html_body, subtype="html")

    # Keep the machine-readable record, but as an attachment instead of
    # cluttering the email.
    json_record = json.dumps(
        data,
        indent=2,
        sort_keys=True,
        ensure_ascii=False
    )

    msg.add_attachment(
        json_record.encode("utf-8"),
        maintype="application",
        subtype="json",
        filename=f"{po_number}.json"
    )

    # Buyer invoice-style payment email.
    # The seller receives a CC copy so there is a complete sent record.
    payment_to = os.environ.get(
        "PAYMENT_TO_EMAIL",
        "shortshiftsteve@gmail.com"
    ).strip()

    invoice_status = "PAYMENT DUE"
    seller_name = "Short Shift Garage"
    seller_email = gmail_user
    invoice_date = format_date(created)

    payment_plain = f"""VE OPTIMIZER INVOICE

Invoice / PO: {po_number}
Invoice Date: {invoice_date}
Status: {invoice_status}

SELLER
{seller_name}
{seller_email}

BILL TO
{buyer_name}
{address_text}
Email: {buyer_email}

ITEM
Product: {product}
Version: {version}
Quantity: {quantity}
Unit Price: {money(unit_price)}
Total Due: {money(total)}

PAYMENT
Method: PayPal
PayPal Address: {payment_to}
Reference: {po_number}

Please include Purchase Order {po_number} in the PayPal payment notes.

Your VE Optimizer license will be issued after payment has been
independently confirmed.

Thank you,
Short Shift Garage
"""

    payment_html = f"""
<!DOCTYPE html>
<html>
<body style="margin:0;padding:24px;background:#f4f6f8;
             font-family:Arial,Helvetica,sans-serif;color:#202124">

<div style="max-width:760px;margin:auto;background:white;
            border:1px solid #d9dde3;border-radius:8px;overflow:hidden">

    <div style="background:#174ea6;color:white;padding:22px 28px">
        <div style="font-size:13px;letter-spacing:1px">
            VE OPTIMIZER
        </div>
        <div style="font-size:28px;font-weight:bold;margin-top:4px">
            INVOICE
        </div>
    </div>

    <div style="padding:28px 30px;line-height:1.5">

        <table style="width:100%;border-collapse:collapse;margin-bottom:26px">
            <tr>
                <td style="vertical-align:top;width:55%">
                    <div style="font-size:14px;color:#5f6368">SELLER</div>
                    <div style="font-size:17px;font-weight:bold;margin-top:4px">
                        {clean(seller_name)}
                    </div>
                    <div>{clean(seller_email)}</div>
                </td>
                <td style="vertical-align:top;text-align:right">
                    <div><strong>Invoice / PO:</strong> {clean(po_number)}</div>
                    <div style="margin-top:5px">
                        <strong>Date:</strong> {clean(invoice_date)}
                    </div>
                    <div style="margin-top:8px;display:inline-block;
                                padding:6px 10px;background:#fff3cd;
                                border:1px solid #ffe69c;border-radius:4px;
                                font-weight:bold;color:#664d03">
                        {clean(invoice_status)}
                    </div>
                </td>
            </tr>
        </table>

        <div style="font-size:15px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            Bill To
        </div>

        <div style="padding:12px 0 24px;line-height:1.55">
            <strong>{clean(buyer_name)}</strong><br>
            {address_html}<br>
            {clean(buyer_email)}
        </div>

        <table style="width:100%;border-collapse:collapse;margin:0 0 16px">
            <tr style="background:#f3f5f7">
                <th style="padding:10px;text-align:left">Description</th>
                <th style="padding:10px;text-align:center">Qty</th>
                <th style="padding:10px;text-align:right">Unit Price</th>
                <th style="padding:10px;text-align:right">Amount</th>
            </tr>
            <tr>
                <td style="padding:13px 10px;border-bottom:1px solid #ddd">
                    <strong>{clean(product)}</strong><br>
                    Version {clean(version)}
                </td>
                <td style="padding:13px 10px;text-align:center;
                           border-bottom:1px solid #ddd">
                    {clean(quantity)}
                </td>
                <td style="padding:13px 10px;text-align:right;
                           border-bottom:1px solid #ddd">
                    {clean(money(unit_price))}
                </td>
                <td style="padding:13px 10px;text-align:right;
                           border-bottom:1px solid #ddd;font-weight:bold">
                    {clean(money(total))}
                </td>
            </tr>
        </table>

        <table style="width:100%;border-collapse:collapse;margin:0 0 28px">
            <tr>
                <td style="text-align:right;font-size:22px;font-weight:bold;
                           padding-top:8px">
                    Total Due: {clean(money(total))}
                </td>
            </tr>
        </table>

        <div style="font-size:15px;font-weight:bold;color:#174ea6;
                    border-bottom:1px solid #ddd;padding-bottom:6px">
            Payment Instructions
        </div>

        <table style="width:100%;border-collapse:collapse;margin:12px 0 20px">
            <tr>
                <td style="padding:5px 0"><strong>Payment Method</strong></td>
                <td style="padding:5px 0;text-align:right">PayPal</td>
            </tr>
            <tr>
                <td style="padding:5px 0"><strong>PayPal Address</strong></td>
                <td style="padding:5px 0;text-align:right;font-weight:bold">
                    {clean(payment_to)}
                </td>
            </tr>
            <tr>
                <td style="padding:5px 0"><strong>Payment Reference</strong></td>
                <td style="padding:5px 0;text-align:right">
                    {clean(po_number)}
                </td>
            </tr>
        </table>

        <div style="padding:14px 16px;background:#fff8e1;
                    border-left:4px solid #f9ab00;margin:20px 0">
            <strong>Important:</strong><br>
            Include Purchase Order <strong>{clean(po_number)}</strong>
            in the PayPal payment notes.
        </div>

        <div style="padding:14px 16px;background:#f3f5f7;
                    border-radius:6px;margin-top:20px">
            Your VE Optimizer license will be issued after payment has been
            independently confirmed.
        </div>

        <p style="margin-top:28px">
            Thank you,<br>
            <strong>Short Shift Garage</strong>
        </p>
    </div>
</div>

</body>
</html>
"""

    payment_msg = EmailMessage()
    payment_msg["From"] = gmail_user
    payment_msg["To"] = buyer_email
    payment_msg["Cc"] = order_to
    payment_msg["Reply-To"] = gmail_user
    payment_msg["Subject"] = f"VE Optimizer Invoice - {po_number}"
    payment_msg.set_content(payment_plain)
    payment_msg.add_alternative(payment_html, subtype="html")

    try:
        with smtplib.SMTP_SSL(
            "smtp.gmail.com",
            465,
            timeout=20
        ) as smtp:
            smtp.login(gmail_user, gmail_password)

            # 1. Seller receives the Purchase Order.
            smtp.send_message(msg)

            # 2. Buyer receives payment instructions; seller is CC'd.
            try:
                smtp.send_message(payment_msg)
                payment_email_status = "sent"
            except Exception as exc:
                # The seller PO has already been delivered. Return HTTP 200
                # so the Windows client does not retry and duplicate the PO.
                payment_email_status = "failed"
                print(
                    f"Payment instructions email failure: "
                    f"{type(exc).__name__}: {exc}"
                )

    except Exception as exc:
        print(
            f"Purchase Order email failure: "
            f"{type(exc).__name__}: {exc}"
        )
        return jsonify({
            "status": "error",
            "message": "Purchase Order could not be delivered."
        }), 502

    response = {
        "status": "submitted",
        "po_number": po_number,
        "message": "Purchase Order submitted successfully.",
        "payment_email_status": payment_email_status
    }

    if payment_email_status != "sent":
        response["warning"] = (
            "Purchase Order was delivered, but payment instructions "
            "could not be emailed to the buyer."
        )

    return jsonify(response), 200
