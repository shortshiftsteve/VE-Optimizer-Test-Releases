"""Accepted HPL import baseline v1.0.0. Standard library only.

Supports the observed HPT header 0x0960 profile. It returns sparse native
updates in native units, without interpolation, filters, bins or averaging.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import struct
import zlib

VERSION = '1.0.0'


class HplDecodeError(ValueError):
    pass


class Reader:
    def __init__(self, data, pos=0):
        self.data, self.pos = data, pos

    def take(self, size):
        if size < 0 or self.pos + size > len(self.data):
            raise HplDecodeError(f'Truncated record at byte {self.pos}')
        value = self.data[self.pos:self.pos + size]
        self.pos += size
        return value

    def unpack(self, fmt):
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))

    def string(self):
        # Only the observed one-byte length encoding is supported here.
        size = self.take(1)[0]
        if size & 128:
            raise HplDecodeError('Unsupported extended string length')
        try:
            return self.take(size).decode('utf-8')
        except UnicodeDecodeError as exc:
            raise HplDecodeError('Invalid UTF-8 string') from exc



# Scanner stores the vehicle profile in a compressed MET record immediately
# after the channel directory.  VIN is optional metadata, never a qualification
# input; malformed/unknown MET profiles must not affect native log processing.
VIN_RECORD = b'\x01\x30\x0b\x11'
VIN_BYTES = re.compile(rb'[A-HJ-NPR-Z0-9]{17}\Z')
MAX_METADATA_BYTES = 1024 * 1024


def extract_hpl_vin(path):
    """Return the native HPL vehicle-profile VIN, or '' if unavailable.

    Only the two observed MET header profiles are supported. The metadata is
    decompressed independently of frame decoding and never changes channel
    selection, time alignment, or tuning qualification.
    """
    try:
        data = Path(path).read_bytes()
        if len(data) < 41 or data[:6] != b'HPT \x60\x09':
            return ''
        if data[10:14] != b'SYNC' or data[20:22] != b'SC':
            return ''
        reader = Reader(data, 39)
        count = reader.unpack('<H')[0]
        if not count:
            return ''
        for _ in range(count):
            reader.take(6 + 16)  # index, parameter ID, type, scale, offset
            reader.string()
            reader.string()
        start = reader.pos
        if data[start:start + 4] != b'MET\x00':
            return ''
        # +4: observed metadata type=1; +8: big-endian compressed length;
        # +12..14: observed record flags; +15: little-endian decoded size.
        if data[start + 4:start + 8] != b'\x01\x00\x00\x00':
            return ''
        if data[start + 12:start + 15] != b'\x01\x00\x00':
            return ''
        compressed_length = struct.unpack_from('>I', data, start + 8)[0]
        decoded_length = struct.unpack_from('<I', data, start + 15)[0]
        payload_start = start + 19
        if (not 1 <= compressed_length <= MAX_METADATA_BYTES or
                not 1 <= decoded_length <= MAX_METADATA_BYTES or
                payload_start + compressed_length > len(data)):
            return ''
        payload = data[payload_start:payload_start + compressed_length]
        inflater = zlib.decompressobj(-15)
        metadata = inflater.decompress(payload, decoded_length + 1)
        if (len(metadata) != decoded_length or not inflater.eof or
                inflater.unused_data or inflater.unconsumed_tail):
            return ''
        vins = set()
        pos = 0
        while True:
            pos = metadata.find(VIN_RECORD, pos)
            if pos < 0:
                break
            raw = metadata[pos + len(VIN_RECORD):pos + len(VIN_RECORD) + 17]
            if VIN_BYTES.fullmatch(raw):
                vins.add(raw.decode('ascii'))
            pos += len(VIN_RECORD)
        # Ambiguous VIN records fail safely. No requirement for VIN data.
        return next(iter(vins)) if len(vins) == 1 else ''
    except (OSError, HplDecodeError, struct.error, ValueError, zlib.error):
        return ''


def decode_hpl(path):
    data = Path(path).read_bytes()
    if len(data) < 41 or data[:6] != b'HPT \x60\x09':
        raise HplDecodeError('Unsupported HPL header/profile')
    if data[10:14] != b'SYNC' or data[20:22] != b'SC':
        raise HplDecodeError('Unsupported channel header layout')
    reader = Reader(data, 39)
    channel_count = reader.unpack('<H')[0]
    if channel_count == 0:
        raise HplDecodeError('Log contains no channel definitions')
    channels = {}
    for _ in range(channel_count):
        index, parameter_id, type_code = reader.unpack('<HHH')
        scale, offset = reader.unpack('<dd')
        name, unit = reader.string(), reader.string()
        if index in channels or type_code >> 8 not in (10, 11):
            raise HplDecodeError('Unsupported or duplicate channel definition')
        if not math.isfinite(scale) or not math.isfinite(offset):
            raise HplDecodeError('Invalid channel scale/offset')
        # Nonidentity transformations were not present in the accepted fixture.
        if scale != 1.0 or offset != 0.0:
            raise HplDecodeError('Nonidentity channel scaling is not yet supported')
        channels[index] = dict(parameter_id=parameter_id, type_code=type_code,
                               scale=scale, offset=offset, name=name, unit=unit)
    # The HPL record directory holds a 16-bit channel count and 16-bit indices.
    # Data blocks use a one-byte channel reference (high bit = repeat) while
    # all indices fit in 7 bits. With wider indices they use two-byte references
    # (high bit of the 16-bit word = repeat). The 128-channel application cap was
    # not an HPL format limit and rejected valid Scanner files.
    extended_channel_refs = any(index >= 128 for index in channels)
    if any(index >= 0x8000 for index in channels):
        raise HplDecodeError('Channel index exceeds HPL data-block addressing')
    repeat_bit = 0x8000 if extended_channel_refs else 0x80
    index_mask = repeat_bit - 1
    frames, blocks, last = [], [], {}
    cursor, prior_time = reader.pos, -1
    while True:
        start = data.find(b'CDG\x00', cursor)
        if start < 0:
            break
        # The marker must follow the observed synchronization preamble.
        if start != cursor and (start < 14 or data[start-14:start-6] != b'SS\x00\x00SYNC'):
            raise HplDecodeError('Unexpected data block framing')
        block_reader = Reader(data, start + 4)
        compressed_size, decoded_size = block_reader.unpack('<II')
        if not 1 <= decoded_size <= 64 * 1024 * 1024:
            raise HplDecodeError('Unsupported data block size')
        payload = block_reader.take(compressed_size)
        try:
            inflater = zlib.decompressobj(-15)
            decoded = inflater.decompress(payload, decoded_size + 1)
        except zlib.error as exc:
            raise HplDecodeError('Invalid raw DEFLATE block') from exc
        if len(decoded) != decoded_size or not inflater.eof or inflater.unused_data or inflater.unconsumed_tail:
            raise HplDecodeError('Data block length or stream mismatch')
        native = Reader(decoded)
        frame_count = native.unpack('<H')[0]
        if not frame_count:
            raise HplDecodeError('Empty data block')
        first_time = None
        for _ in range(frame_count):
            timestamp_ms = int.from_bytes(native.take(3), 'little')
            if timestamp_ms < prior_time:
                raise HplDecodeError('Native timestamps are not monotonic')
            prior_time = timestamp_ms
            if first_time is None:
                first_time = timestamp_ms
            update_count = native.take(1)[0]
            updates = {}
            for _ in range(update_count):
                channel_ref = (native.unpack('<H')[0] if extended_channel_refs
                               else native.take(1)[0])
                index = channel_ref & index_mask
                if index not in channels or index in updates:
                    raise HplDecodeError('Unknown or duplicate channel update')
                if channel_ref & repeat_bit:
                    if index not in last:
                        raise HplDecodeError('Repeat value before channel initialization')
                    value = last[index]
                elif channels[index]['type_code'] >> 8 == 11:
                    value = native.string()
                else:
                    value = native.unpack('<d')[0]
                    if not math.isfinite(value):
                        raise HplDecodeError('Nonfinite channel value')
                updates[index] = value
                last[index] = value
            frames.append(dict(timestamp_ms=timestamp_ms, updates=updates))
        if native.pos != len(decoded):
            raise HplDecodeError('Unconsumed bytes in decoded data block')
        blocks.append(dict(file_offset=start, compressed_bytes=compressed_size,
                           decoded_bytes=decoded_size, frame_count=frame_count,
                           first_timestamp_ms=first_time, last_timestamp_ms=prior_time))
        cursor = block_reader.pos
    if not blocks:
        raise HplDecodeError('No supported data blocks')
    return dict(decoder_version=VERSION, source_sha256=hashlib.sha256(data).hexdigest(),
                source_size_bytes=len(data), channels=channels, blocks=blocks,
                frames=frames, timestamp_basis='native elapsed milliseconds')


def summary(result):
    return {key: result[key] for key in ('decoder_version', 'source_sha256', 'source_size_bytes', 'timestamp_basis')} | {
        'channel_count': len(result['channels']), 'block_count': len(result['blocks']),
        'frame_count': len(result['frames']), 'first_timestamp_ms': result['frames'][0]['timestamp_ms'],
        'last_timestamp_ms': result['frames'][-1]['timestamp_ms'], 'blocks': result['blocks']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, help='Optional sparse JSON output')
    args = parser.parse_args()
    try:
        result = decode_hpl(args.input)
    except (OSError, HplDecodeError) as exc:
        parser.exit(1, f'HPL import failed: {exc}\n')
    if args.output:
        args.output.write_text(json.dumps(result, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    print(json.dumps(summary(result), indent=2))
