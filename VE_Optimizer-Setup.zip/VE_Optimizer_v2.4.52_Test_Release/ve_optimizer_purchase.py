#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Tuple
import urllib.error
import urllib.request
import urllib.parse

PRODUCT_NAME = 'VE Optimizer'
PRODUCT_VERSION = '2.4.52'
UNIT_PRICE_USD = '49.99'
SELLER_EMAIL = 'shortshiftsteve@gmail.com'
ORDER_FORMAT = 'VEOPTIMIZER-PO-1'
PURCHASE_SERVICE_URL = 'https://ve-optimizer-orders-526226636310.us-west2.run.app'

_EMAIL_RE = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')


ZIP_LOOKUP_BASE_URL = 'https://api.zippopotam.us/us/'
_US_ZIP_RE = re.compile(r'^\s*(\d{5})(?:-\d{4})?\s*$')


def lookup_us_zip(postal_code: str, *, timeout: float = 8.0, opener=None) -> Dict[str, str]:
    """Resolve a US ZIP/ZIP+4 to USPS-style city and two-letter state.

    The lookup is a convenience only. Network/service failures raise ValueError
    so the Purchase page can leave City/State editable and allow manual entry.
    """
    raw = str(postal_code or '').strip()
    m = _US_ZIP_RE.fullmatch(raw)
    if not m:
        raise ValueError('Enter a valid 5-digit US ZIP code or ZIP+4.')
    zip5 = m.group(1)
    url = ZIP_LOOKUP_BASE_URL + urllib.parse.quote(zip5, safe='')
    req = urllib.request.Request(
        url,
        headers={
            'Accept': 'application/json',
            'User-Agent': f'VE-Optimizer/{PRODUCT_VERSION}',
        },
        method='GET',
    )
    open_fn = opener or urllib.request.urlopen
    try:
        with open_fn(req, timeout=timeout) as response:
            status = int(getattr(response, 'status', response.getcode()))
            raw_body = response.read()
    except urllib.error.HTTPError as exc:
        if int(getattr(exc, 'code', 0)) == 404:
            raise ValueError(f'ZIP code {zip5} was not found.') from exc
        raise ValueError(f'ZIP lookup returned HTTP {exc.code}.') from exc
    except urllib.error.URLError as exc:
        raise ValueError('ZIP lookup is unavailable. Enter City and State manually.') from exc
    except TimeoutError as exc:
        raise ValueError('ZIP lookup timed out. Enter City and State manually.') from exc
    except OSError as exc:
        raise ValueError('ZIP lookup is unavailable. Enter City and State manually.') from exc

    if status < 200 or status >= 300:
        raise ValueError(f'ZIP lookup returned HTTP {status}.')
    try:
        data = json.loads(raw_body.decode('utf-8'))
        places = data.get('places') if isinstance(data, dict) else None
        place = places[0] if isinstance(places, list) and places else None
        city = str((place or {}).get('place name') or '').strip()
        state = str((place or {}).get('state abbreviation') or '').strip().upper()
    except Exception as exc:
        raise ValueError('ZIP lookup returned an invalid response.') from exc
    if not city or not re.fullmatch(r'[A-Z]{2}', state):
        raise ValueError('ZIP lookup did not return a usable City and State.')
    return {'postal_code': zip5, 'city': city, 'state': state}


def _clean(value: str, limit: int = 160) -> str:
    value = ' '.join(str(value or '').replace('\r', ' ').replace('\n', ' ').split()).strip()
    return value[:limit]


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso_utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def validate_buyer(data: Dict[str, str]) -> Dict[str, str]:
    out = {k: _clean(v) for k, v in data.items()}
    required = {
        'first_name': 'First Name',
        'last_name': 'Last Name',
        'email': 'Email',
        'address': 'Address',
        'city': 'City',
        'state': 'State / Region',
        'postal_code': 'ZIP / Postal Code',
    }
    missing = [label for key, label in required.items() if not out.get(key)]
    if missing:
        raise ValueError('Required purchase information is missing: ' + ', '.join(missing) + '.')
    if not _EMAIL_RE.match(out['email']):
        raise ValueError('Enter a valid buyer email address.')
    return out


def create_purchase_order(buyer: Dict[str, str], *, now: datetime | None = None) -> Dict[str, object]:
    buyer = validate_buyer(buyer)
    now = now or _utc_now()
    stamp = now.astimezone(timezone.utc).strftime('%Y%m%d-%H%M%S')
    po_number = f'VEO-{stamp}-{uuid.uuid4().hex[:6].upper()}'
    return {
        'format': ORDER_FORMAT,
        'po_number': po_number,
        'created_utc': _iso_utc(now),
        'status': 'AWAITING_PAYMENT',
        'seller_email': SELLER_EMAIL,
        'buyer': buyer,
        'items': [{
            'product': PRODUCT_NAME,
            'version': PRODUCT_VERSION,
            'license_scope': 'Personal-account license; one authorized account may be used on multiple computers.',
            'quantity': 1,
            'unit_price_usd': UNIT_PRICE_USD,
            'line_total_usd': UNIT_PRICE_USD,
        }],
        'subtotal_usd': UNIT_PRICE_USD,
        'total_usd': UNIT_PRICE_USD,
        'payment_status': 'AWAITING_PAYMENT',
        'license_status': 'NOT_ISSUED',
        'terms': [
            'This Purchase Order records the buyer request and is not an invoice.',
            'Payment instructions are emailed automatically to the confirmed buyer email address after successful submission.',
            'A license is issued only after the seller independently verifies payment.',
        ],
    }


def render_purchase_order(order: Dict[str, object]) -> str:
    buyer = dict(order['buyer'])
    item = dict(order['items'][0])
    company = buyer.get('company') or '(none)'
    phone = buyer.get('phone') or '(not provided)'
    lines = [
        'VE OPTIMIZER PURCHASE ORDER',
        '===========================',
        f"PO Number: {order['po_number']}",
        f"Created (UTC): {order['created_utc']}",
        f"Status: {order['status']}",
        '',
        'BUYER',
        f"Name: {buyer.get('first_name','')} {buyer.get('last_name','')}",
        f"Email: {buyer.get('email','')}",
        f"Company: {company}",
        f"Address: {buyer.get('address','')}",
        f"City/State/Postal: {buyer.get('city','')}, {buyer.get('state','')} {buyer.get('postal_code','')}",
        f"Country: {buyer.get('country') or 'United States'}",
        f"Phone: {phone}",
        '',
        'ORDER',
        f"Product: {item['product']} Version {item['version']}",
        f"Quantity: {item['quantity']}",
        f"Unit Price: ${item['unit_price_usd']} USD",
        f"Total: ${order['total_usd']} USD",
        f"License Scope: {item['license_scope']}",
        '',
        'PURCHASE PROCESS',
        '1. This Purchase Order is submitted securely to the seller.',
        '2. Payment instructions are emailed automatically to the confirmed buyer email address; the seller receives a copy.',
        '3. Buyer sends payment using those instructions and includes the Purchase Order number in the payment notes.',
        '4. Seller independently verifies payment.',
        '5. Seller issues the signed VE Optimizer license to the buyer.',
        '',
        'IMPORTANT',
        'This Purchase Order is not an invoice.',
        'Use only the payment instructions sent for this Purchase Order.',
        'License activation occurs only after payment is independently verified by the seller.',
    ]
    return '\n'.join(lines) + '\n'


def purchase_order_dir(base_dir: Path | None = None) -> Path:
    if base_dir is not None:
        root = Path(base_dir)
    else:
        override = os.environ.get('VE_OPTIMIZER_PURCHASE_ORDER_DIR')
        if override:
            root = Path(override)
        elif os.name == 'nt':
            local = os.environ.get('LOCALAPPDATA') or str(Path.home() / 'AppData' / 'Local')
            root = Path(local) / 'VEOptimizer' / 'PurchaseOrders'
        else:
            root = Path.home() / '.ve_optimizer' / 'PurchaseOrders'
    root.mkdir(parents=True, exist_ok=True)
    return root


def save_purchase_order(order: Dict[str, object], base_dir: Path | None = None) -> Tuple[Path, Path]:
    root = purchase_order_dir(base_dir)
    stem = str(order['po_number'])
    txt = root / f'{stem}.txt'
    js = root / f'{stem}.json'
    # Never overwrite an existing PO number. UUID suffixes make collisions exceptionally unlikely;
    # this check also prevents accidental mutation of an already-issued local record.
    if txt.exists() or js.exists():
        raise FileExistsError(f'Purchase Order already exists: {stem}')
    txt.write_text(render_purchase_order(order), encoding='utf-8')
    js.write_text(json.dumps(order, indent=2, sort_keys=True), encoding='utf-8')
    return txt, js



def purchase_service_payload(order: Dict[str, object]) -> Dict[str, object]:
    """Build the HTTPS payload expected by the VE Optimizer order service.

    Keep buyer/order detail in the payload while also exposing the small set of
    top-level fields used by the Cloud Run validation layer.  No payment or
    email credentials are ever included.
    """
    buyer = dict(order.get('buyer') or {})
    items = list(order.get('items') or [])
    item = dict(items[0]) if items else {}
    buyer_name = ' '.join(x for x in (
        str(buyer.get('first_name') or '').strip(),
        str(buyer.get('last_name') or '').strip(),
    ) if x).strip()
    return {
        'po_number': str(order.get('po_number') or '').strip(),
        'buyer_email': str(buyer.get('email') or '').strip(),
        'buyer_name': buyer_name,
        'product': str(item.get('product') or PRODUCT_NAME),
        'version': str(item.get('version') or PRODUCT_VERSION),
        'price': f"${order.get('total_usd', UNIT_PRICE_USD)} USD",
        'order': order,
    }


def submit_purchase_order(
    order: Dict[str, object],
    endpoint: str = PURCHASE_SERVICE_URL,
    *,
    timeout: float = 20.0,
    opener=None,
) -> Dict[str, object]:
    """Submit a Purchase Order to the HTTPS order service.

    A successful return means the service explicitly confirmed ``submitted``.
    Network/HTTP/service failures raise RuntimeError so the UI never reports a
    Purchase Order as submitted merely because a request was attempted.
    """
    payload = purchase_service_payload(order)
    body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    req = urllib.request.Request(
        str(endpoint),
        data=body,
        headers={
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': f'VE-Optimizer/{PRODUCT_VERSION}',
        },
        method='POST',
    )
    open_fn = opener or urllib.request.urlopen
    try:
        with open_fn(req, timeout=timeout) as response:
            status = int(getattr(response, 'status', response.getcode()))
            raw = response.read()
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode('utf-8', errors='replace')[:500]
        except Exception:
            detail = ''
        raise RuntimeError(f'Purchase Order service returned HTTP {exc.code}. {detail}'.strip()) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f'Unable to reach the Purchase Order service: {exc.reason}') from exc
    except TimeoutError as exc:
        raise RuntimeError('Purchase Order service timed out.') from exc
    except OSError as exc:
        raise RuntimeError(f'Unable to reach the Purchase Order service: {exc}') from exc

    if status < 200 or status >= 300:
        raise RuntimeError(f'Purchase Order service returned HTTP {status}.')
    try:
        result = json.loads(raw.decode('utf-8'))
    except Exception as exc:
        raise RuntimeError('Purchase Order service returned an invalid response.') from exc
    if not isinstance(result, dict):
        raise RuntimeError('Purchase Order service returned an invalid response.')
    if str(result.get('status') or '').lower() != 'submitted':
        msg = str(result.get('message') or result.get('error') or 'Purchase Order was not accepted.')
        raise RuntimeError(msg)
    if str(result.get('po_number') or '') != str(order.get('po_number') or ''):
        raise RuntimeError('Purchase Order service confirmation did not match the submitted PO number.')
    return result
