#!/usr/bin/env python3
"""VE Optimizer wideband O2 processing development core.

This module is intentionally separate from the accepted closed-loop fuel-trim
processing path.  It provides:

* automatic airflow-model detection from the Full Engine .htt;
* active PE table-axis detection (Aircharge or PRatio);
* read-only boosted-PE selector/table compatibility preflight;
* no PE FAR-adder, selector, or PE table calibration generation;
* native-HPL wideband/commanded-Lambda alignment;
* explicit dual enrichment gating;
* Speed Density VE-table correction and .htt export;
* strict rejection of samples outside the active VE-table domain;
* MAF preflight classification as a validation/reference signal;
* Speed Density STFT-only processing, independent of LTFT and NN-only gates;
* Neural-Network wideband fitting through the existing quantized NN solver.
"""
from __future__ import annotations

import bisect
import itertools
import math
import statistics
import struct
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

import ve_optimizer_stage3 as htt
import ve_optimizer_processing as processing
from hpl_decoder_v1_0_0 import decode_hpl

VERSION = "0.9.0-dev"
MIN_HITS = 5
CORRECTION_FRACTION = 0.50
VE_QUANTUM = 0.09765625

# VCM Editor identifies 2088 as Engine/Airflow/Neural Network/General/
# Use Neural Network. Verified against stock 5.7L, 6.4L and 6.2L Full Engine
# .htt sources and the tuned 6.2L Trackhawk: 2088 is Disabled in that tune,
# while unrelated switch 47500 remains Enabled. Never select a method with
# switch 47500. The existing .htt NN carrier export also copies record 2088.
USE_NEURAL_NETWORK_SWITCH = 2088
PE_TABLE_SELECT_SWITCH = 34229
PE_AIRCHARGE_TABLE = 34230
PE_PRATIO_TABLE = 34243
VE_BANK1_TABLE = 44273
VE_BANK2_TABLE = 44274

# Current wideband validation channels.  Channel *names* are resolved from HPL
# metadata; numeric HPL channel IDs are deliberately not hard-coded.
WB_NAME = "WB EQ Ratio 1 (SAE)"
WB_PRIMARY_NAMES = (WB_NAME, "WB EQ Ratio 1")
WB_SECONDARY_NAMES = ("WB EQ Ratio 2 (SAE)", "WB EQ Ratio 2")
CMD_LAMBDA_NAME = "Equivalence Ratio Commanded (SAE)"
RPM_NAME = "Engine RPM"
MAP_NAME = "MAP - Hi-Res"  # preferred verified HPL MAP source
BARO_NAME = "Barometric Pressure"
ECT_NAME = "Engine Coolant Temp (SAE)"
FA_ENRICH_NAME = "FA Enrichment"
FA_PE_NAME = "FA Power Enrichment"
TORQUE_NAME = "Actual Torque"
INTAKE_CAM_NAME = "Intake Cam Center Pos"
EXHAUST_CAM_NAME = "Exhaust Cam Center Pos"

NARROWBAND_B1_NAME = "O2 Voltage B1S1 (SAE)"
NARROWBAND_B2_NAME = "O2 Voltage B2S1 (SAE)"
MAF_PREFERRED_NAMES = (
    "Mass Airflow Sensor 1",
    "Mass Air Flow Sensor 1",
    "Mass Airflow Sensor",
    "Mass Airflow (SAE)",
    "Mass Air Flow (SAE)",
    "MAF (SAE)",
)
LTFT_B1_NAME = "Long Term Fuel Trim Bank 1 (SAE)"
LTFT_B2_NAME = "Long Term Fuel Trim Bank 2 (SAE)"
STFT_B1_NAME = "Short Term Fuel Trim Bank 1 (SAE)"
STFT_B2_NAME = "Short Term Fuel Trim Bank 2 (SAE)"
FUEL_FLOW_PID = 6509

RESCALE_HEADROOM_STEP = 0.05
BOOST_PRATIO_THRESHOLD = 1.06
BOOST_MIN_PE_SAMPLES = 5

# Airflow/MAP reference IDs.  For the user's 2023 Challenger with a Maggi,
# VCM Editor identifies Sensed MAP Enable as ECM parameter 2100 (2026-10-09).
# Full Engine .htt files confirm record 2100 is an Enabled/Disabled switch.
# Crucially, switch 44433 was shown by VCM Editor as MDS Enable in the
# Development 4 import and remains QUARANTINED.  Do not conflate these IDs.
# A standalone 2100-only VCM Editor preview is still needed before customer
# release, because local binary parsing alone cannot prove semantic mapping.
# MAP sensors are 0-5 V transfer functions:
# pressure = offset_kPa + slope_kPa_per_V * (V - offset_V).
PRESSURE_RATIO_MAX_SCALAR = 18912
SENSED_MAP_ENABLE_SWITCH = 2100  # user-identified VCM Editor ECM ID, pending isolated preview
QUARANTINED_SWITCH_ID = 44433  # VCM Editor displayed MDS Enable
SENSED_MAP_PRATIO_THRESHOLD_SCALAR = 45645
THROTTLE_BASED_MAP_MULTIPLIER_TABLE = 44395
MAP1_LINEAR_SCALAR = 44271
MAP1_OFFSET_KPA_SCALAR = 4011
MAP1_OFFSET_V_SCALAR = 44272
MAP2_LINEAR_SCALAR = 14088
MAP2_OFFSET_KPA_SCALAR = 14089
MAP2_OFFSET_V_SCALAR = 14090
BARO_LINEAR_SCALAR = 3646
BARO_OFFSET_KPA_SCALAR = 3647
BARO_OFFSET_V_SCALAR = 3574
SEA_LEVEL_BARO_KPA = 101.325
SEA_LEVEL_REVIEW_DELTA_KPA = 3.0
MAP_FULL_SCALE_VOLTAGE = 5.0
MAXIMUM_RPM_SCALAR = 44490  # Maximum RPM (not Drive, P/N, VE, or NN Training)


class DomainRescaleRequired(ValueError):
    """Raised when valid SD correction data exceed the active VE-table axes."""
    def __init__(self, details: dict):
        self.details = dict(details)
        msg = details.get("message") or "Speed Density VE table rescaling is required before correction."
        super().__init__(msg)


def _read_length_payload(path: Path, key: int) -> bytes:
    blob = Path(path).read_bytes()
    _, _, start, end = htt._find_length_payload(blob, key)
    return blob[start:end]


def read_switch(path: Path, key: int) -> str:
    """Read a length-prefixed switch/select record as ASCII text."""
    return _read_length_payload(Path(path), key).decode("ascii", "strict").strip()


def _airflow_model_switch_status(path: Path) -> dict:
    """Resolve the active airflow model, including legacy full-engine templates.

    Some older HP Tuners Full Engine .htt exports omit the ``Use Neural
    Network`` switch record even though they contain a complete normal neural
    network.  VE Optimizer accepted those files before the Speed Density /
    Wideband preflight work was added.  Treat that specific legacy condition as
    Neural Network compatibility mode rather than hard-failing preflight.

    A stored explicit switch always wins.  The legacy fallback is allowed only
    when the switch record itself is missing *and* the normal NN can be decoded
    completely.  Other decoding failures remain errors.
    """
    path = Path(path)
    try:
        raw = read_switch(path, USE_NEURAL_NETWORK_SWITCH).strip()
    except KeyError:
        try:
            net = htt.load_network(path)
            neurons = int((net.get("meta") or {}).get("neurons") or len(net.get("Wo") or []))
        except Exception as exc:
            raise ValueError(
                "Use Neural Network is not stored in this Full Engine .htt and "
                "the legacy Neural Network compatibility check also failed. "
                "Export a complete Full Engine .htt before Correction Preflight."
            ) from exc
        if neurons < 1:
            raise ValueError(
                "Use Neural Network is not stored in this Full Engine .htt and "
                "no active normal Neural Network could be verified."
            )
        return {
            "airflow_model": "neural_network",
            "use_neural_network": "Enabled (legacy compatibility)",
            "detection_source": "legacy_nn_compatibility",
            "warning": (
                "Use Neural Network is not stored in this legacy Full Engine .htt; "
                "a complete normal Neural Network was verified and is being used."
            ),
        }

    value = raw.lower()
    if value in {"enabled", "enable"}:
        model = "neural_network"
    elif value in {"disabled", "disable"}:
        model = "speed_density"
    else:
        raise ValueError(f"Unsupported Use Neural Network switch value: {raw!r}")
    return {
        "airflow_model": model,
        "use_neural_network": raw,
        "detection_source": "tune_switch",
        "warning": None,
    }


def detect_airflow_model(path: Path) -> str:
    """Return ``neural_network`` or ``speed_density`` for the calibration."""
    return str(_airflow_model_switch_status(Path(path))["airflow_model"])


def _pe_table_axis_status(path: Path) -> dict:
    """Read the PE-table selector without making legacy files a hard failure.

    HP Tuners exports are not uniform across model years / operating-system
    families.  Some otherwise valid Full Engine templates omit the selector
    record entirely.  Correction Preflight must therefore distinguish
    "not stored" from "stored but invalid" instead of leaking an internal-key
    exception to the user.

    This helper does *not* guess the active PE strategy when the selector is
    absent.  It reports that condition explicitly so source-specific preflight
    logic can decide whether the missing record is actually required.
    """
    path = Path(path)
    try:
        raw = read_switch(path, PE_TABLE_SELECT_SWITCH).strip()
    except KeyError:
        return {
            "present": False,
            "value": None,
            "valid": True,
            "detection_source": "not_stored",
            "warning": (
                "FA Power Enrich Table Select is not stored in this calibration. "
                "VE Optimizer will not infer an Aircharge/PRatio selection from "
                "an absent record."
            ),
        }
    except Exception as exc:
        return {
            "present": True,
            "value": None,
            "valid": False,
            "detection_source": "decode_error",
            "warning": f"FA Power Enrich Table Select could not be decoded: {exc}",
        }

    if raw not in {"Aircharge", "PRatio"}:
        return {
            "present": True,
            "value": None,
            "valid": False,
            "detection_source": "stored_value",
            "warning": f"Unsupported FA Power Enrich Table Select value: {raw!r}",
        }
    return {
        "present": True,
        "value": raw,
        "valid": True,
        "detection_source": "tune_switch",
        "warning": None,
    }


def detect_pe_table_axis(path: Path) -> str:
    """Return 'Aircharge' or 'PRatio' when the selector is explicitly stored.

    Callers that can operate in compatibility mode should use
    :func:`_pe_table_axis_status` instead.  This strict accessor is retained for
    write/verification paths where the selector must physically exist.
    """
    status = _pe_table_axis_status(Path(path))
    if status.get("value") in {"Aircharge", "PRatio"}:
        return str(status["value"])
    warning = status.get("warning") or "FA Power Enrich Table Select is unavailable."
    raise ValueError(str(warning))


def _resolve_exact(channels: Dict[int, dict], name: str, *, decoded: dict = None) -> int:
    index = _resolve_optional_name(channels, name, decoded=decoded)
    if index is None:
        raise ValueError(f"Required HPL channel {name!r} was not found")
    return index


def _history(decoded: dict, index: int) -> Tuple[List[int], List[object]]:
    times: List[int] = []
    values: List[object] = []
    for frame in decoded["frames"]:
        if index in frame["updates"]:
            times.append(int(frame["timestamp_ms"]))
            values.append(frame["updates"][index])
    if not times:
        raise ValueError(f"HPL channel index {index} has no data")
    return times, values


def _latest(history: Tuple[List[int], List[object]], timestamp_ms: int):
    times, values = history
    pos = bisect.bisect_right(times, int(timestamp_ms)) - 1
    return None if pos < 0 else values[pos]


def _infer_stoich_far(cmd_hist, fa_hist) -> Tuple[float, int]:
    estimates: List[float] = []
    for t, lam in zip(*cmd_hist):
        if not isinstance(lam, (int, float)):
            continue
        lam = float(lam)
        if not (0.75 < lam < 0.995):
            continue
        fa = _latest(fa_hist, t)
        if not isinstance(fa, (int, float)) or float(fa) <= 0:
            continue
        fa = float(fa)
        estimate = lam * fa / (1.0 - lam)
        if 0.06 < estimate < 0.08:
            estimates.append(estimate)
    if len(estimates) < 10:
        raise ValueError("Insufficient enriched log data to infer stoichiometric FAR")
    return round(float(statistics.median(estimates)), 4), len(estimates)


def _split_table(payload: bytes):
    sep = b"\r\n" if b"\r\n" in payload else b"\n"
    ends = payload.endswith(sep)
    core = payload[:-len(sep)] if ends else payload
    lines = core.split(sep)
    if len(lines) < 2:
        raise ValueError("Unexpected HP Tuners table serialization")
    return sep, ends, lines[0], lines[1:]


def parse_ve_table(path: Path, key: int):
    payload = _read_length_payload(Path(path), key)
    _, _, header_b, rows_b = _split_table(payload)
    header = header_b.decode("utf-8").split("\t")
    rpm_axis = np.array([float(v) for v in header[1:-1]], dtype=float)
    pratio_axis: List[float] = []
    values: List[List[float]] = []
    for row_b in rows_b:
        fields = row_b.decode("utf-8").split("\t")
        pratio_axis.append(float(fields[0]))
        values.append([float(v) for v in fields[1:]])
    z = np.asarray(values, dtype=float)
    if z.shape != (len(pratio_axis), len(rpm_axis)):
        raise ValueError(f"VE table {key} shape mismatch: {z.shape}")
    return payload, rpm_axis, np.asarray(pratio_axis, dtype=float), z


def parse_numeric_2d_table(path: Path, key: int):
    """Parse an HP Tuners numeric 2D table and preserve any trailing footer.

    PE Aircharge tables carry a trailing ``mg`` footer while the PRatio table
    does not.  This parser deliberately separates numeric rows from such
    metadata so the table can be rewritten without changing its dimensions.
    """
    payload = _read_length_payload(Path(path), key)
    sep, ends, header_b, rows_b = _split_table(payload)
    header_fields = header_b.decode("utf-8").split("\t")
    x_axis = np.asarray([float(v) for v in header_fields[1:] if v.strip()], dtype=float)
    y_axis: List[float] = []
    values: List[List[float]] = []
    footer: List[bytes] = []
    numeric_done = False
    for row_b in rows_b:
        fields = row_b.decode("utf-8").split("\t")
        try:
            y = float(fields[0])
            row = [float(v) for v in fields[1:] if v.strip()]
        except (TypeError, ValueError):
            numeric_done = True
            footer.append(row_b)
            continue
        if numeric_done:
            raise ValueError(f"Numeric row found after footer in table {key}")
        y_axis.append(y)
        values.append(row)
    z = np.asarray(values, dtype=float)
    if z.shape != (len(y_axis), len(x_axis)):
        raise ValueError(f"2D table {key} shape mismatch: {z.shape}")
    return {
        "payload": payload,
        "sep": sep,
        "ends": ends,
        "header": header_b,
        "footer": footer,
        "x_axis": x_axis,
        "y_axis": np.asarray(y_axis, dtype=float),
        "z": z,
    }


def _rebuild_numeric_2d_table(parsed: dict, new_y_axis: np.ndarray, new_z: np.ndarray) -> bytes:
    new_y_axis = np.asarray(new_y_axis, dtype=float)
    new_z = np.asarray(new_z, dtype=float)
    if new_z.shape != (len(new_y_axis), len(parsed["x_axis"])):
        raise ValueError("2D table rewrite shape mismatch")
    rows: List[bytes] = []
    previous = None
    for y, values in zip(new_y_axis, new_z):
        y = float(y)
        if previous is not None and y <= previous:
            raise ValueError("2D table Y axis must be strictly increasing")
        previous = y
        tokens = [repr(float(v)) for v in values]
        rows.append((repr(y) + "\t" + "\t".join(tokens)).encode("utf-8"))
    result = parsed["sep"].join([parsed["header"]] + rows + list(parsed["footer"]))
    if parsed["ends"]:
        result += parsed["sep"]
    return result


def _replace_length_payload(blob: bytes, key: int, payload: bytes) -> bytes:
    """Replace one length-prefixed HTT record payload."""
    _, length_pos, payload_start, payload_end = htt._find_length_payload(blob, key)
    return (
        blob[:length_pos]
        + htt._encode_uleb128(len(payload))
        + payload
        + blob[payload_end:]
    )


def _find_scalar_record(blob: bytes, key: int) -> int:
    """Locate the scalar record that stage3.read_scalar() would read."""
    pat = int(key).to_bytes(2, "little")
    pos = 0
    while True:
        q = blob.find(pat, pos)
        if q < 0:
            break
        pos = q + 1
        if q + 13 > len(blob) or blob[q + 2:q + 4] != b"\x00\x00":
            continue
        try:
            value = struct.unpack("<d", blob[q + 4:q + 12])[0]
        except struct.error:
            continue
        if math.isfinite(value):
            return q
    raise KeyError(f"Scalar internal key {key} not found")


def _replace_scalar_value(blob: bytes, key: int, value: float) -> bytes:
    q = _find_scalar_record(blob, key)
    return blob[:q + 4] + struct.pack("<d", float(value)) + blob[q + 12:]


def _rebuild_ve_table(original_payload: bytes, new_z: np.ndarray) -> bytes:
    sep, ends, header_b, rows_b = _split_table(original_payload)
    if len(rows_b) != new_z.shape[0]:
        raise ValueError("VE row count mismatch")
    out_rows: List[bytes] = []
    for row_b, values in zip(rows_b, new_z):
        fields = row_b.decode("utf-8").split("\t")
        if len(fields) - 1 != len(values):
            raise ValueError("VE column count mismatch")
        tokens = []
        for value in values:
            q = round(float(value) / VE_QUANTUM) * VE_QUANTUM
            tokens.append(f"{q:.8f}".rstrip("0").rstrip("."))
        # Preserve the source PRatio token exactly.
        out_rows.append((fields[0] + "\t" + "\t".join(tokens)).encode("utf-8"))
    result = sep.join([header_b] + out_rows)
    if ends:
        result += sep
    return result


def _axis_signature(payload: bytes):
    _, _, header_b, rows_b = _split_table(payload)
    return header_b, tuple(row.split(b"\t", 1)[0] for row in rows_b)


def _nearest_index(axis: np.ndarray, value: float) -> int:
    return int(np.argmin(np.abs(axis - float(value))))


def _resolve_wideband_primary(channels: Dict[int, dict], *, decoded: dict = None):
    """Resolve the existing single-stream wideband input without mixing banks.

    VCM Scanner exports the native PCM input as ``WB EQ Ratio 1`` (PID 6181),
    while older logging layouts use ``WB EQ Ratio 1 (SAE)``. Do not silently
    substitute ``WB EQ Ratio 2``: independent bank processing requires a
    separately approved correction algorithm.
    """
    for name in WB_PRIMARY_NAMES:
        index = _resolve_optional_name(channels, name, decoded=decoded)
        if index is not None:
            return index
    return None


def _wideband_secondary_name(channels: Dict[int, dict]):
    """Report a second logged Lambda stream; never use it as a hidden fallback."""
    for name in WB_SECONDARY_NAMES:
        if any(row.get('name') == name for row in channels.values()):
            return name
    return None


def _build_histories(decoded: dict):
    channels = decoded["channels"]
    from ve_optimizer_map_sources import select_hpl_map
    pressure = select_hpl_map(decoded)
    if not pressure['valid']:
        raise ValueError(pressure['reason'])
    wb_index = _resolve_wideband_primary(channels, decoded=decoded)
    if wb_index is None:
        raise ValueError("Required wideband Lambda channel 'WB EQ Ratio 1' was not found")
    ect_index, _ = _resolve_first_available(channels, (ECT_NAME, "Engine Coolant Temp"), decoded=decoded)
    if ect_index is None:
        raise ValueError("Required HPL channel 'Engine Coolant Temp' was not found")
    indices = {
        "wb": wb_index,
        "cmd_sae": _resolve_exact(channels, CMD_LAMBDA_NAME, decoded=decoded),
        "rpm": _resolve_exact(channels, RPM_NAME, decoded=decoded),
        "map": pressure['source']['channel_index'],
        "baro": pressure['baro_index'],
        "ect": ect_index,
        "fa": _resolve_exact(channels, FA_ENRICH_NAME, decoded=decoded),
        "pe": _resolve_exact(channels, FA_PE_NAME, decoded=decoded),
        "torque": _resolve_exact(channels, TORQUE_NAME, decoded=decoded),
    }
    return indices, {name: _history(decoded, idx) for name, idx in indices.items()}



def _duplicate_unit_factor(name: str, unit: str):
    """Normalize units only when their equivalence is explicitly established.

    Unknown unit conversions must never be silently compared or accepted.
    This function affects comparison only; the selected native channel and its
    original units are preserved for existing correction math.
    """
    u = ' '.join(str(unit).lower().replace('°', 'deg ').replace('·', ' ').split())
    if name == RPM_NAME:
        return ('rpm', 1.0, 0.0) if u in ('rpm', 'r/min') else None
    if name == TORQUE_NAME:
        if u in ('n m', 'nm', 'n-m'):
            return 'torque-nm', 1.0, 0.0
        if u in ('lb-ft', 'lb ft', 'ft-lb', 'ft lb'):
            return 'torque-nm', 1.35581794833, 0.0
        return None
    if name in (ECT_NAME, 'Engine Coolant Temp'):
        if u in ('deg f', 'f', 'fahrenheit'):
            return 'temp-f', 1.0, 0.0
        if u in ('deg c', 'c', 'celsius'):
            return 'temp-f', 1.8, 32.0
        return None
    # Other duplicated channels must have exactly matching units.  We cannot
    # presume that non-identical units describe equivalent numeric quantities.
    return u, 1.0, 0.0


def _duplicate_value_tolerance(name: str, reference: float, other: float) -> float:
    """Allow ordinary asynchronous Scanner sampling without hiding conflicts."""
    magnitude = max(abs(reference), abs(other))
    if name == RPM_NAME:
        return max(150.0, 0.08 * magnitude)
    if name == TORQUE_NAME:
        return max(40.0, 0.20 * magnitude)
    return max(0.10, 0.15 * magnitude)


def _resolve_duplicate_channel(decoded: dict, name: str, indices: list[int]) -> int:
    """Select one populated native HPL channel without combining its events.

    Distinct HPL indices may legitimately share a Scanner display name or PID.
    Prefer a valid native PID with complete coverage and higher sample density.
    Disagreeing, independently populated inputs remain a user-visible error.
    """
    channels = decoded['channels']
    cached = decoded.setdefault('_resolved_duplicate_channels', {})
    signature = (name, tuple(sorted(indices)))
    if signature in cached:
        return cached[signature]
    streams = {index: ([], []) for index in indices}
    for frame in decoded['frames']:
        timestamp = int(frame['timestamp_ms'])
        for index, value in frame['updates'].items():
            if index in streams and isinstance(value, (int, float)) and math.isfinite(float(value)):
                streams[index][0].append(timestamp)
                streams[index][1].append(float(value))
    available = [i for i in indices if streams[i][0]]
    if not available:
        raise ValueError(
            f"Duplicate HPL channel {name!r} has no populated numeric data. "
            "Correct the Scanner channel selection and record a new log."
        )
    # An invalid or incompatible unit on a populated duplicate is unsafe to
    # ignore, even if another occurrence has many more observations.
    units = {i: _duplicate_unit_factor(name, channels[i].get('unit', '')) for i in available}
    if any(value is None for value in units.values()) or len({u[0] for u in units.values()}) != 1:
        detail = ', '.join(f"index {i}: {channels[i].get('unit', '')!r}" for i in sorted(available))
        raise ValueError(f"Incompatible units for duplicate HPL channel {name!r}: {detail}. "
                         "Correct the Scanner channel list before processing.")
    preferred_pid = {RPM_NAME: 2135, TORQUE_NAME: 2706}.get(name)
    end_time = int(decoded['frames'][-1]['timestamp_ms']) if decoded['frames'] else 0
    start_time = int(decoded['frames'][0]['timestamp_ms']) if decoded['frames'] else 0
    duration = max(1, end_time - start_time)
    def priority(index):
        ts = streams[index][0]
        coverage = (ts[-1] - ts[0]) / duration
        # A preferred PID is meaningful only when it has useful coverage.
        expected_pid = bool(preferred_pid is not None and
                            int(channels[index].get('parameter_id', -1)) == preferred_pid)
        return (coverage >= 0.9, expected_pid, len(ts), coverage, -index)
    selected = max(available, key=priority)
    selected_ts, selected_values = streams[selected]
    selected_unit_factor, selected_unit_offset = units[selected][1:]
    # Cross-check only independent, meaningfully populated alternate streams;
    # low-rate duplicate observations must never add correction/log hits.
    for index in available:
        if index == selected or len(streams[index][0]) < 5:
            continue
        other_ts, other_values = streams[index]
        factor, offset = units[index][1:]
        compared = disagreed = 0
        for t, v in zip(other_ts, other_values):
            j = bisect.bisect_right(selected_ts, t) - 1
            # The source timestamps are asynchronous.  Compare only recent
            # values to avoid treating acceleration as a contradictory signal.
            if j < 0 or t - selected_ts[j] > 75:
                continue
            a = selected_values[j] * selected_unit_factor + selected_unit_offset
            b = v * factor + offset
            compared += 1
            if abs(a - b) > _duplicate_value_tolerance(name, a, b):
                disagreed += 1
        if compared < 5 and len(other_ts) >= 20 and (other_ts[-1] - other_ts[0]) / duration >= 0.5:
            raise ValueError(
                f"Duplicate HPL channel {name!r} could not be cross-checked between "
                f"indices {selected} and {index}. Correct the Scanner channel list."
            )
        if compared >= 5 and disagreed >= 5 and disagreed / compared > 0.10:
            raise ValueError(
                f"Conflicting duplicate HPL channel {name!r}: native indices "
                f"{selected} and {index} disagree in {disagreed}/{compared} "
                "time-matched samples. Correct the Scanner channel list."
            )
    cached[signature] = int(selected)
    decoded.setdefault('_duplicate_channel_selections', []).append({
        'name': name, 'selected_index': int(selected),
        'ignored_indices': [int(i) for i in indices if i != selected],
        'selected_parameter_id': channels[selected].get('parameter_id'),
        'selected_updates': len(streams[selected][0]),
    })
    return int(selected)


def _resolve_optional_name(channels: Dict[int, dict], name: str, *, decoded: dict = None):
    matches = [int(idx) for idx, meta in channels.items() if meta.get('name') == name]
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]
    if decoded is None:
        raise ValueError(f"Duplicate HPL channel {name!r} requires populated HPL data "
                         "for safe automatic resolution")
    return _resolve_duplicate_channel(decoded, name, matches)


def _resolve_trim_channel(channels: Dict[int, dict], kind: str, bank: int, *, decoded: dict = None):
    """Resolve VCM Scanner SAE and native-name trim channels identically.

    Depending on the logged PID selection, HP Tuners names a bank-trim stream
    either 'Short Term Fuel Trim Bank 1 (SAE)' or 'Short Term Fuel Trim Bank 1'.
    The log-density validator already recognizes both spellings.  Correction
    preflight and actual SD processing must recognize the same streams, while
    preserving the selected airflow-model input rules.

    When both equivalent sources are present, prefer the established SAE name.
    Do not merge their asynchronous event streams or inflate hit counts.
    """
    if kind not in ("Short Term", "Long Term") or bank not in (1, 2):
        raise ValueError("Unsupported trim channel kind/bank")
    plain = f"{kind} Fuel Trim Bank {bank}"
    sae = _resolve_optional_name(channels, plain + " (SAE)", decoded=decoded)
    if sae is not None:
        return sae
    return _resolve_optional_name(channels, plain, decoded=decoded)


def _resolve_trim_inputs(channels: Dict[int, dict], *, decoded: dict = None) -> dict:
    """Canonical LTFT/STFT channel map shared by preflight and SD processing."""
    return {
        "stft_b1": _resolve_trim_channel(channels, "Short Term", 1, decoded=decoded),
        "stft_b2": _resolve_trim_channel(channels, "Short Term", 2, decoded=decoded),
        "ltft_b1": _resolve_trim_channel(channels, "Long Term", 1, decoded=decoded),
        "ltft_b2": _resolve_trim_channel(channels, "Long Term", 2, decoded=decoded),
    }


def _speed_density_trim_inputs(decoded: dict) -> tuple[dict, str]:
    """Select Method B trim inputs independently of Method A qualification.

    Both banks must have populated LTFT streams before Method B uses total
    adaptive trims. Otherwise both banks use STFT alone, avoiding asymmetric
    bank corrections. STFT remains the event clock in either mode.
    """
    channels = decoded["channels"]
    idx = {
        f"{kind}_b{bank}": _resolve_trim_channel(
            channels, "Long Term" if kind == "ltft" else "Short Term",
            bank, decoded=decoded)
        for kind in ("stft", "ltft") for bank in (1, 2)
    }
    ltft_available = all(idx[f"ltft_b{bank}"] is not None for bank in (1, 2))
    if ltft_available:
        for bank in (1, 2):
            try:
                ltft_times, ltft_values = _history(decoded, idx[f"ltft_b{bank}"])
                first_valid_ltft = next(
                    (int(t) for t, v in zip(ltft_times, ltft_values)
                     if isinstance(v, (int, float)) and np.isfinite(float(v))), None)
                if first_valid_ltft is None:
                    ltft_available = False
                    break
                # A populated but extremely late slow LTFT channel must not
                # disqualify otherwise-usable Method B STFT correction. Require
                # five STFT event times with a known LTFT state per bank.
                stft_idx = idx[f"stft_b{bank}"]
                if stft_idx is not None:
                    stft_times, _ = _history(decoded, stft_idx)
                    paired_hits = sum(t >= first_valid_ltft for t in set(stft_times))
                    if paired_hits < MIN_HITS:
                        ltft_available = False
                        break
            except ValueError:  # Optional metadata-only stream with no updates.
                ltft_available = False
                break
    if not ltft_available:
        idx["ltft_b1"] = idx["ltft_b2"] = None
    return idx, ("ltft_plus_stft" if ltft_available else "stft_only")


def _resolve_optional_pid(channels: Dict[int, dict], parameter_id: int, *, decoded: dict = None):
    matches = [int(idx) for idx, meta in channels.items()
               if int(meta.get('parameter_id', -1)) == int(parameter_id)]
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]
    if decoded is None:
        raise ValueError(f"Duplicate HPL parameter ID {parameter_id} requires populated HPL data")
    # All records with this PID are duplicates of the same logical source.
    return _resolve_duplicate_channel(decoded, channels[matches[0]]['name'], matches)


def _numeric_history_stats(decoded: dict, index: int) -> dict:
    times, values = _history(decoded, index)
    nums = [float(v) for v in values if isinstance(v, (int, float)) and np.isfinite(float(v))]
    if not nums:
        return {
            "updates": 0, "minimum": None, "maximum": None, "span": None,
            "nonzero_updates": 0, "unique_values": 0,
        }
    nonzero = sum(1 for v in nums if abs(v) > 1e-12)
    return {
        "updates": len(nums),
        "minimum": float(min(nums)),
        "maximum": float(max(nums)),
        "span": float(max(nums) - min(nums)),
        "nonzero_updates": int(nonzero),
        "unique_values": int(len(set(nums))),
    }


def _maf_candidate_indices(channels: Dict[int, dict]) -> List[int]:
    """Return likely runtime MAF channels without confusing modeled airflow signals."""
    ordered: List[int] = []
    for preferred in MAF_PREFERRED_NAMES:
        for idx, meta in channels.items():
            if meta.get("name") == preferred and int(idx) not in ordered:
                ordered.append(int(idx))
    for idx, meta in channels.items():
        name = str(meta.get("name", "")).strip().lower()
        if not name:
            continue
        is_mass_airflow = ("mass airflow" in name or "mass air flow" in name)
        is_maf_name = name == "maf" or name.startswith("maf ") or name.startswith("maf(")
        if (is_mass_airflow or is_maf_name) and int(idx) not in ordered:
            ordered.append(int(idx))
    return ordered


def _maf_status(decoded: dict) -> dict:
    """Classify logged MAF as not logged, present/invalid, or present/valid.

    A valid MAF is only an additional airflow reference here. Presence of a
    populated channel does not prove that the PCM is using MAF for fueling.
    """
    channels = decoded["channels"]
    candidates = _maf_candidate_indices(channels)
    if not candidates:
        return {
            "present": False,
            "valid": False,
            "status": "not_logged",
            "usable_as_airflow_reference": False,
            "pcm_use_inferred": False,
            "reason": "No MAF runtime channel was found in the log.",
            "candidates": [],
        }

    rows = []
    for idx in candidates:
        stats = _numeric_history_stats(decoded, idx)
        meta = channels[idx]
        valid = bool(
            stats["updates"] >= MIN_HITS and
            stats["nonzero_updates"] >= MIN_HITS and
            stats["maximum"] is not None and stats["maximum"] > 0 and
            stats["span"] is not None and stats["span"] > 1e-9 and
            stats["unique_values"] >= 2
        )
        rows.append({
            "channel_index": int(idx),
            "parameter_id": int(meta.get("parameter_id", -1)),
            "name": str(meta.get("name", "")),
            "unit": str(meta.get("unit", "")),
            **stats,
            "valid": valid,
        })

    valid_rows = [r for r in rows if r["valid"]]
    if valid_rows:
        primary = max(valid_rows, key=lambda r: (r["nonzero_updates"], r["updates"], r["span"]))
        return {
            "present": True,
            "valid": True,
            "status": "valid",
            "usable_as_airflow_reference": True,
            "pcm_use_inferred": False,
            "primary": primary,
            "candidates": rows,
            "reason": None,
        }

    primary = max(rows, key=lambda r: r["updates"])
    if primary["updates"] and primary["nonzero_updates"] == 0:
        reason = (
            f"MAF channel '{primary['name']}' is logged but every populated sample is 0.000; "
            "the MAF data are not usable."
        )
    else:
        reason = (
            f"MAF channel '{primary['name']}' is present but does not contain enough nonzero, varying data "
            "to use as an airflow reference."
        )
    return {
        "present": True,
        "valid": False,
        "status": "invalid",
        "usable_as_airflow_reference": False,
        "pcm_use_inferred": False,
        "primary": primary,
        "candidates": rows,
        "reason": reason,
    }


def _sd_pressure_input_indices(channels: Dict[int, dict], decoded: dict = None) -> dict:
    """Use the validated alternative MAP/Baro source in both SD processing paths."""
    from ve_optimizer_map_sources import eligible_map_indices, select_hpl_map
    if decoded is not None:
        pressure = select_hpl_map(decoded)
        if not pressure['valid']:
            return {'map':None, 'baro':pressure.get('baro_index')}
        return {'map':pressure['source']['channel_index'], 'baro':pressure['baro_index']}
    available = eligible_map_indices(channels)
    baro_idx, _ = _resolve_first_available(channels, (
        'Barometric Pressure - Hi Res', BARO_NAME, 'Barometric Pressure (SAE)',
    ), decoded=decoded)
    return {'map':available[0] if available else None, 'baro':baro_idx}


def _sd_stft_sample_valid(*, rpm: float, ect_f: float, torque_lbft: float,
                          baro: float) -> bool:
    """Method B STFT sample conditions; no NN or Fuel Flow Rate gate."""
    return bool(
        float(rpm) > 1000 and float(ect_f) > 164 and
        float(torque_lbft) > 1 and float(baro) > 0
    )


def _adaptive_trim_status(decoded: dict, airflow_model: str = "neural_network",
                          closed_loop_only: bool = False) -> dict:
    """Qualify the selected tune's fuel-trim input without mixing airflow models.

    Neural Network enabled: preserve the accepted LTFT + STFT event/filter path.
    Neural Network disabled: STFT-timed events with both-bank LTFT + STFT
    when LTFT is populated; otherwise STFT-only. Method B's independent
    enrichment, Fuel Flow and channel-density rules are preserved.
    """
    if airflow_model not in ("neural_network", "speed_density"):
        raise ValueError(f"Unsupported airflow model: {airflow_model!r}")
    speed_density = airflow_model == "speed_density"
    channels = decoded["channels"]
    names = {"rpm": RPM_NAME, "torque": TORQUE_NAME}
    if not speed_density or closed_loop_only:
        names.update({"fa": FA_ENRICH_NAME, "pe": FA_PE_NAME})
    idx = {k: _resolve_optional_name(channels, v, decoded=decoded) for k, v in names.items()}
    if speed_density:
        idx.update(_sd_pressure_input_indices(channels, decoded))
        trim_indices, mode = _speed_density_trim_inputs(decoded)
        idx.update(trim_indices)
    else:
        idx.update(_resolve_trim_inputs(channels, decoded=decoded))
        mode = "ltft_plus_stft"
    idx["fuel_flow"] = _resolve_optional_pid(channels, FUEL_FLOW_PID, decoded=decoded)
    idx["ect"] = _resolve_optional_name(channels, ECT_NAME, decoded=decoded)
    if idx["ect"] is None:
        idx["ect"] = _resolve_optional_name(channels, "Engine Coolant Temp", decoded=decoded)

    # For NN, the required inputs and gate are unchanged from v2.3.1.
    required = ["stft_b1", "stft_b2", "rpm", "torque"]
    if speed_density:
        required.extend(["map", "baro", "ect"])
        if closed_loop_only:
            required.extend(["fa", "pe"])
    else:
        required.extend(["fa", "pe", "fuel_flow", "ect", "ltft_b1", "ltft_b2"])
    missing = [k for k in required if idx.get(k) is None]
    present = all(idx.get(k) is not None for k in ("stft_b1", "stft_b2")) and (
        speed_density or all(idx.get(k) is not None for k in ("ltft_b1", "ltft_b2"))
    )
    # Report the actual selected STFT stream. The resolver already prefers SAE
    # when SAE and native PIDs are both logged; this is display metadata only.
    stft_channels = {
        f"bank{bank}": (channels[idx[f"stft_b{bank}"]]["name"]
                        if idx.get(f"stft_b{bank}") is not None else None)
        for bank in (1, 2)
    }
    # Report STFT measurements independently of correction qualification.
    # Method B never requires Fuel Flow Rate for STFT qualification.
    stft_updates = {
        f"bank{bank}": (_numeric_history_stats(decoded, idx[f"stft_b{bank}"])["updates"]
                        if idx.get(f"stft_b{bank}") is not None else 0)
        for bank in (1, 2)
    }
    stft_data_available = all(stft_updates[f"bank{bank}"] > 0 for bank in (1, 2))
    if missing:
        return {
            "present": present, "valid": False,
            "accepted_events_bank1": 0, "accepted_events_bank2": 0,
            "missing": missing, "mode": mode, "stft_channels": stft_channels,
            "stft_updates": stft_updates, "stft_data_available": stft_data_available,
            "ltft_available": bool(idx.get("ltft_b1") is not None and idx.get("ltft_b2") is not None),
            "reason": (
                "Missing channel(s) required by Speed Density STFT processing: "
                if speed_density else
                "Missing channel(s) required by the closed-loop trim gate: "
            ) + ", ".join(missing),
        }

    histories = {k: _history(decoded, v) for k, v in idx.items() if v is not None}
    triggers = {
        bank: (sorted(set(histories[f"stft_b{bank}"][0])) if speed_density else
               sorted(set(histories[f"stft_b{bank}"][0]) |
                      set(histories[f"ltft_b{bank}"][0])))
        for bank in (1, 2)
    }
    ect_unit = str(channels[idx["ect"]].get("unit", ""))
    torque_unit = str(channels[idx["torque"]].get("unit", ""))
    flow_unit = str(channels[idx["fuel_flow"]].get("unit", "")) if not speed_density else ''

    def ect_f(v):
        v = float(v)
        return v * 1.8 + 32.0 if "c" in ect_unit.lower() else v

    def torque_lbft(v):
        v = float(v)
        return v / 1.35581794833 if "n" in torque_unit.lower() and "m" in torque_unit.lower() else v

    def flow_lbh(v):
        v = float(v)
        u = flow_unit.lower().replace(" ", "")
        if "g/s" in u:
            return v * 7.936641438
        if "kg/h" in u:
            return v * 2.20462262185
        return v

    accepted = {1: 0, 2: 0}
    for bank in (1, 2):
        for t in triggers[bank]:
            rpm = _latest(histories["rpm"], t)
            torque = _latest(histories["torque"], t)
            ect = _latest(histories["ect"], t)
            flow = _latest(histories["fuel_flow"], t) if not speed_density else None
            stft = _latest(histories[f"stft_b{bank}"], t)
            if closed_loop_only:
                fa = _latest(histories["fa"], t)
                pe = _latest(histories["pe"], t)
                if fa is None or pe is None or abs(float(fa)) > 1e-9 or abs(float(pe)) > 1e-9:
                    continue
            if speed_density:
                baro = _latest(histories["baro"], t)
                map_value = _latest(histories["map"], t)
                ltft = (_latest(histories[f"ltft_b{bank}"], t)
                        if mode == "ltft_plus_stft" else None)
                if (any(v is None for v in (rpm, torque, ect, stft, baro, map_value)) or
                    (mode == "ltft_plus_stft" and ltft is None)):
                    continue
                if not _sd_stft_sample_valid(
                    rpm=rpm, ect_f=ect_f(ect), torque_lbft=torque_lbft(torque),
                    baro=baro,
                ):
                    continue
                if not (np.isfinite(float(stft)) and
                        (mode == "stft_only" or np.isfinite(float(ltft)))):
                    continue
            else:
                fa = _latest(histories["fa"], t)
                pe = _latest(histories["pe"], t)
                if any(v is None for v in (rpm, torque, ect, fa, pe, flow, stft)):
                    continue
                if not (
                    float(rpm) > 1000 and
                    ect_f(ect) > 164 and
                    torque_lbft(torque) > 1 and
                    flow_lbh(flow) > 0.01
                ):
                    continue
            accepted[bank] += 1

    valid = accepted[1] >= MIN_HITS and accepted[2] >= MIN_HITS
    return {
        "present": present, "valid": bool(valid),
        "mode": mode,
        "stft_channels": stft_channels,
        "stft_updates": stft_updates, "stft_data_available": stft_data_available,
        "ltft_available": bool(idx.get("ltft_b1") is not None and idx.get("ltft_b2") is not None),
        "accepted_events_bank1": int(accepted[1]),
        "accepted_events_bank2": int(accepted[2]),
        "missing": [],
        "reason": None if valid else (
            "Too few fuel-trim events meet the Speed Density sample conditions."
            if speed_density else
            "Fuel-trim channels are present, but too few events meet the Method A sample conditions."
        ),
    }


def _narrowband_status(decoded: dict) -> dict:
    """Validate upstream narrowband activity as a diagnostic source.

    Raw narrowband voltage is deliberately NOT converted directly to a VE
    percentage here.  It is reported so the UI can show that the stock O2
    sensors are present/healthy while LTFT+STFT remain the quantitative
    closed-loop correction source.
    """
    channels = decoded["channels"]
    b1 = _resolve_optional_name(channels, NARROWBAND_B1_NAME, decoded=decoded)
    b2 = _resolve_optional_name(channels, NARROWBAND_B2_NAME, decoded=decoded)
    if b1 is None or b2 is None:
        return {
            "present": False,
            "valid": False,
            "correction_supported": False,
            "reason": "Both upstream narrowband O2 voltage channels were not found.",
        }
    s1 = _numeric_history_stats(decoded, b1)
    s2 = _numeric_history_stats(decoded, b2)
    plausible = (
        s1["updates"] >= 100 and s2["updates"] >= 100 and
        s1["minimum"] is not None and s2["minimum"] is not None and
        -0.05 <= s1["minimum"] <= 1.5 and -0.05 <= s2["minimum"] <= 1.5 and
        0.0 <= s1["maximum"] <= 1.5 and 0.0 <= s2["maximum"] <= 1.5 and
        s1["span"] >= 0.10 and s2["span"] >= 0.10
    )
    return {
        "present": True,
        "valid": bool(plausible),
        "correction_supported": False,
        "bank1": s1,
        "bank2": s2,
        "reason": (
            None if plausible else
            "Upstream narrowband channels were found, but their populated voltage data did not pass the activity/plausibility check."
        ),
    }


def _wideband_data_status(decoded: dict) -> dict:
    channels = decoded["channels"]
    wb = _resolve_wideband_primary(channels, decoded=decoded)
    wb2_name = _wideband_secondary_name(channels)
    fa = _resolve_optional_name(channels, FA_ENRICH_NAME, decoded=decoded)
    pe = _resolve_optional_name(channels, FA_PE_NAME, decoded=decoded)
    if wb is None:
        return {"present": bool(wb2_name), "valid": False,
                "secondary_channel_name": wb2_name, "secondary_used_for_correction": False,
                "reason": ("WB EQ Ratio 2 is logged, but the existing wideband method requires "
                           "WB EQ Ratio 1; the second stream is not substituted automatically."
                           if wb2_name else "Wideband Lambda channel not found.")}
    if fa is None or pe is None:
        return {
            "present": True,
            "valid": False,
            "reason": "Wideband is present, but FA Enrichment and FA Power Enrichment are both required.",
        }
    wb_hist = _history(decoded, wb)
    fa_hist = _history(decoded, fa)
    pe_hist = _history(decoded, pe)
    endpoint_valid = 0
    dual_gate = 0
    for t, value in zip(*wb_hist):
        if not isinstance(value, (int, float)):
            continue
        value = float(value)
        if not (0.5505 < value < 1.9995):
            continue
        endpoint_valid += 1
        fav = _latest(fa_hist, t)
        pev = _latest(pe_hist, t)
        if isinstance(fav, (int, float)) and isinstance(pev, (int, float)) and float(fav) > 0 and float(pev) > 0:
            dual_gate += 1
    valid = endpoint_valid >= MIN_HITS and dual_gate >= MIN_HITS
    return {
        "present": True,
        "valid": bool(valid),
        "channel_name": channels[wb]["name"],
        "secondary_channel_name": wb2_name,
        "secondary_used_for_correction": False,
        "wideband_updates": len(wb_hist[0]),
        "endpoint_valid_updates": int(endpoint_valid),
        "dual_gate_updates": int(dual_gate),
        "reason": None if valid else "Wideband channel is present, but too little valid dual-gated PE data is available.",
    }



def _read_optional_scalar(path: Path, key: int):
    try:
        return float(htt.read_scalar(Path(path), int(key)))
    except (KeyError, ValueError):
        return None


def _sensor_transfer_status(path: Path, *, label: str, linear_key: int, offset_kpa_key: int, offset_v_key: int) -> dict:
    """Describe one calibrated absolute-pressure sensor transfer.

    Sensor class is referenced to standard sea-level absolute pressure
    (101.325 kPa), not to logged/learned Baro.  Logged Baro may be derived
    from MAP and therefore cannot independently validate MAP scaling.
    """
    slope = _read_optional_scalar(path, linear_key)
    offset_kpa = _read_optional_scalar(path, offset_kpa_key)
    offset_v = _read_optional_scalar(path, offset_v_key)
    if None in (slope, offset_kpa, offset_v):
        return {
            "label": label, "present": False, "valid": False, "sensor_class": None,
            "slope_kpa_per_v": slope, "offset_kpa": offset_kpa, "offset_v": offset_v,
            "full_scale_kpa": None, "sea_level_pratio_capacity": None,
            "sea_level_boost_capacity_kpa": None, "sea_level_boost_capacity_psi": None,
            "reason": "Complete pressure-sensor transfer calibration was not found in the tune.",
        }
    full_scale = float(offset_kpa + slope * (MAP_FULL_SCALE_VOLTAGE - offset_v))
    sea_ratio = full_scale / SEA_LEVEL_BARO_KPA if full_scale > 0 else float("nan")
    nearest = int(round(sea_ratio)) if math.isfinite(sea_ratio) else 0
    if nearest in (1, 2, 3) and abs(sea_ratio - nearest) <= 0.40:
        sensor_class = f"{nearest}-bar"
    else:
        sensor_class = "custom"
    valid = bool(slope > 0 and 0 <= offset_v < MAP_FULL_SCALE_VOLTAGE and full_scale > 0)
    boost_kpa = max(0.0, full_scale - SEA_LEVEL_BARO_KPA) if valid else None
    return {
        "label": label, "present": True, "valid": valid, "sensor_class": sensor_class,
        "slope_kpa_per_v": float(slope), "offset_kpa": float(offset_kpa), "offset_v": float(offset_v),
        "full_scale_kpa": full_scale,
        "sea_level_reference_kpa": SEA_LEVEL_BARO_KPA,
        "sea_level_pratio_capacity": float(sea_ratio) if valid else None,
        "sea_level_boost_capacity_kpa": float(boost_kpa) if boost_kpa is not None else None,
        "sea_level_boost_capacity_psi": float(boost_kpa / 6.894757293168) if boost_kpa is not None else None,
        "reason": None if valid else "Pressure-sensor transfer values are not physically plausible.",
    }


def _parse_throttle_based_map_multiplier(path: Path) -> dict:
    payload = _read_length_payload(Path(path), THROTTLE_BASED_MAP_MULTIPLIER_TABLE)
    sep = b"\r\n" if b"\r\n" in payload else b"\n"
    lines = payload.rstrip(sep).split(sep)
    if len(lines) < 3:
        raise ValueError("Throttle Based MAP Multiplier table is malformed")
    header = lines[0].decode("ascii", "strict").split("\t")
    # Leading blank cell, numeric airflow breakpoints, trailing unit token.
    airflow_axis = []
    for token in header[1:]:
        try:
            airflow_axis.append(float(token))
        except ValueError:
            break
    rpm_axis = []
    for line in lines[1:]:
        token = line.decode("ascii", "strict").split("\t", 1)[0]
        try:
            rpm_axis.append(float(token))
        except ValueError:
            break
    if not airflow_axis or not rpm_axis:
        raise ValueError("Throttle Based MAP Multiplier axes could not be decoded")
    return {
        "airflow_axis_gps": np.asarray(airflow_axis, dtype=float),
        "rpm_axis": np.asarray(rpm_axis, dtype=float),
        "shape": (len(rpm_axis), len(airflow_axis)),
    }


def _resolve_first_available(channels: Dict[int, dict], names: Iterable[str], *, decoded: dict = None):
    for name in names:
        idx = _resolve_optional_name(channels, name, decoded=decoded)
        if idx is not None:
            return idx, name
    return None, None


def airflow_map_preflight(
    hpl_path: Path,
    tune_path: Path,
    *,
    sea_level_reference_kpa: float = SEA_LEVEL_BARO_KPA,
    assume_sea_level: bool = False,
) -> dict:
    """Validate pressure-model setup before correction.

    MAP sensor class/range is referenced to fixed standard sea-level pressure
    (101.325 kPa).  Logged Baro is *not* used to validate MAP scaling because
    this PCM may derive Baro from MAP at startup and real Baro varies with
    altitude/weather.  Logged Baro is used only for the operating
    PRatio = MAP / Baro calculation.

    Deterministic calibration errors are returned as automatic-preparation
    actions.  Only conditions that cannot be repaired safely from the tune/log
    data remain blocking.  ``assume_sea_level`` is retained for API
    compatibility but deliberately does not change validation behavior.
    """
    del assume_sea_level  # no location assumption is valid for generic logs
    hpl_path = Path(hpl_path)
    tune_path = Path(tune_path)
    decoded = decode_hpl(hpl_path)
    channels = decoded["channels"]

    from ve_optimizer_map_sources import select_hpl_map
    selected_map = select_hpl_map(decoded)
    if not selected_map['valid']:
        return {'valid':False, 'blocking':True, 'auto_fix_required':False,
                'auto_actions':[], 'issues':[selected_map['reason']], 'warnings':[],
                'message':selected_map['reason'], 'map_channel':None}
    map_idx = selected_map['source']['channel_index']
    map_name = selected_map['source']['name']
    baro_idx = selected_map['baro_index']
    baro_name = selected_map['baro_source']
    rpm_idx, rpm_name = _resolve_first_available(channels, (RPM_NAME,), decoded=decoded)
    airflow_idx, airflow_name = _resolve_first_available(channels, (
        "Total Airflow", "Desired Engine Airflow", "Throttle Body Airflow",
    ), decoded=decoded)

    missing = [name for name, idx in (("MAP", map_idx), ("Baro", baro_idx), ("RPM", rpm_idx)) if idx is None]
    if missing:
        return {
            "valid": False, "blocking": True, "missing": missing,
            "auto_fix_required": False, "auto_actions": [],
            "issues": ["Missing channel(s) required for pressure-model preflight: " + ", ".join(missing)],
            "warnings": [],
            "message": "Missing channel(s) required for pressure-model preflight: " + ", ".join(missing),
        }

    map_stats = _numeric_history_stats(decoded, map_idx)
    baro_stats = _numeric_history_stats(decoded, baro_idx)
    rpm_stats = _numeric_history_stats(decoded, rpm_idx)
    airflow_stats = _numeric_history_stats(decoded, airflow_idx) if airflow_idx is not None else None

    map_hist = _history(decoded, map_idx)
    baro_hist = _history(decoded, baro_idx)
    rpm_hist = _history(decoded, rpm_idx)
    airflow_hist = _history(decoded, airflow_idx) if airflow_idx is not None else None
    operating = []
    for t, map_value in zip(*map_hist):
        if not isinstance(map_value, (int, float)):
            continue
        baro = _latest(baro_hist, t)
        rpm = _latest(rpm_hist, t)
        if not isinstance(baro, (int, float)) or float(baro) <= 0 or not isinstance(rpm, (int, float)):
            continue
        airflow = _latest(airflow_hist, t) if airflow_hist is not None else None
        operating.append({
            "timestamp_ms": int(t),
            "map_kpa": float(map_value),
            "baro_kpa": float(baro),
            "pratio": float(map_value) / float(baro),
            "rpm": float(rpm),
            "airflow_gps": float(airflow) if isinstance(airflow, (int, float)) else None,
        })
    pr_values = [x["pratio"] for x in operating]

    map1 = _sensor_transfer_status(
        tune_path, label="MAP1", linear_key=MAP1_LINEAR_SCALAR,
        offset_kpa_key=MAP1_OFFSET_KPA_SCALAR, offset_v_key=MAP1_OFFSET_V_SCALAR,
    )
    map2 = _sensor_transfer_status(
        tune_path, label="MAP2", linear_key=MAP2_LINEAR_SCALAR,
        offset_kpa_key=MAP2_OFFSET_KPA_SCALAR, offset_v_key=MAP2_OFFSET_V_SCALAR,
    )
    baro_sensor = _sensor_transfer_status(
        tune_path, label="Baro", linear_key=BARO_LINEAR_SCALAR,
        offset_kpa_key=BARO_OFFSET_KPA_SCALAR, offset_v_key=BARO_OFFSET_V_SCALAR,
    )

    observed_map_max = float(map_stats["maximum"]) if map_stats["maximum"] is not None else None
    observed_pratio_max = float(max(pr_values)) if pr_values else None
    observed_pratio_min = float(min(pr_values)) if pr_values else None
    baro_median = None
    if baro_stats["updates"]:
        _, vals = _history(decoded, baro_idx)
        nums = [float(v) for v in vals if isinstance(v, (int, float)) and np.isfinite(float(v))]
        if nums:
            baro_median = float(statistics.median(nums))

    pressure_ratio_max = _read_optional_scalar(tune_path, PRESSURE_RATIO_MAX_SCALAR)
    sensed_map_threshold = _read_optional_scalar(tune_path, SENSED_MAP_PRATIO_THRESHOLD_SCALAR)
    # Read only the user-identified Sensed MAP switch (2100).  Do not consult
    # MDS switch 44433.  Reject missing/wrong-type/unknown switch values rather
    # than guessing its current state or silently toggling another parameter.
    sensed_map_switch = None
    if SENSED_MAP_ENABLE_SWITCH is not None:
        try:
            from ve_optimizer_htt_codec import parse_htt
            record = parse_htt(Path(tune_path).read_bytes()).by_key().get(SENSED_MAP_ENABLE_SWITCH)
            if record is not None and record.kind == "switch":
                value = read_switch(tune_path, SENSED_MAP_ENABLE_SWITCH)
                if value in {"Enabled", "Disabled"}:
                    sensed_map_switch = value
        except Exception:
            sensed_map_switch = None

    warnings: List[str] = []
    blocking_issues: List[str] = []
    auto_actions: List[str] = []

    # Sensor calibration is classified against fixed sea-level pressure.  The
    # observed MAP comparison is only a range/headroom check; it is not treated
    # as independent proof that slope/offset are correct.
    covering = []
    sensor_transfers = [sensor for sensor in (map1, map2) if sensor.get("present") and sensor.get("valid")]
    for sensor in sensor_transfers:
        if observed_map_max is not None:
            sensor["observed_headroom_kpa"] = float(sensor["full_scale_kpa"] - observed_map_max)
            sensor["observed_utilization_pct"] = float(observed_map_max / sensor["full_scale_kpa"] * 100.0)
            sensor["covers_observed_map"] = bool(observed_map_max <= sensor["full_scale_kpa"] + 0.5)
            if sensor["covers_observed_map"]:
                covering.append(sensor["label"])
            if sensor["observed_utilization_pct"] >= 97.5:
                warnings.append(f"{sensor['label']} is within 2.5% of its calibrated full-scale pressure.")
    if observed_map_max is not None and sensor_transfers and not covering:
        blocking_issues.append("Observed MAP exceeds the calibrated range of the available MAP sensor transfer(s); installed sensor/scaling must be verified.")
    elif observed_map_max is not None and not sensor_transfers:
        warnings.append(
            "MAP1/MAP2 transfer calibration is not stored completely in this tune, so sensor full-scale range cannot be independently verified. "
            "This compatibility condition is not treated as a failure by itself."
        )

    boosted_samples = [x for x in operating if x["pratio"] > BOOST_PRATIO_THRESHOLD]
    boosted_detected = len(boosted_samples) >= BOOST_MIN_PE_SAMPLES

    # Pressure Ratio Max is deterministic from the observed operating range and
    # can be repaired automatically with one 0.05 step of headroom.
    recommended_pratio_max = pressure_ratio_max
    pratio_change_required = False
    if observed_pratio_max is not None:
        if pressure_ratio_max is None:
            if boosted_detected:
                blocking_issues.append("Pressure Ratio Max is unavailable in the tune; boosted pressure-model coverage cannot be prepared automatically.")
        elif observed_pratio_max > float(pressure_ratio_max) + 0.02:
            recommended_pratio_max = float(np.ceil(observed_pratio_max / RESCALE_HEADROOM_STEP) * RESCALE_HEADROOM_STEP + RESCALE_HEADROOM_STEP)
            pratio_change_required = True
            auto_actions.append(
                f"raise Pressure Ratio Max from {pressure_ratio_max:.3f} to {recommended_pratio_max:.3f}"
            )

    # Read Sensed MAP solely to evaluate the strategy *already stored* in the
    # uploaded tune.  A boosted HPL is never authorization to enable switch 2100.
    # The stock supercharged 6.2L Trackhawk itself has this switch Disabled.
    sensed_enabled = sensed_map_switch == "Enabled"
    if boosted_detected and sensed_map_switch is None:
        blocking_issues.append(
            "Sensed MAP Enable (2100) is missing or unrecognized in the tune; "
            "the existing boosted MAP routing cannot be verified."
        )
    if boosted_detected and sensed_enabled and sensed_map_threshold is None:
        blocking_issues.append(
            "Sensed MAP PRatio Threshold is unavailable; existing boosted MAP routing cannot be validated."
        )

    # Throttle-based MAP coverage is evaluated against the *existing* routing.
    # When Sensed MAP is Disabled, all logged points remain in the coverage
    # check.  When Enabled, only points at or below the stored threshold do.
    tmap = None
    try:
        tmap = _parse_throttle_based_map_multiplier(tune_path)
    except KeyError:
        warnings.append(
            "Throttle Based MAP Multiplier is not stored in this tune; that optional coverage check is skipped."
        )
    except Exception as exc:
        warnings.append(f"Throttle Based MAP Multiplier could not be decoded: {exc}")
    tmap_coverage = None
    if tmap is not None:
        if sensed_enabled and sensed_map_threshold is not None:
            estimate_samples = [x for x in operating if x["pratio"] <= float(sensed_map_threshold)]
            coverage_basis = f"PRatio <= {float(sensed_map_threshold):.3f} with Sensed MAP Enabled in the uploaded tune"
        else:
            estimate_samples = operating
            coverage_basis = (
                "all logged MAP samples because the stored Sensed MAP state is unverified"
                if sensed_map_switch is None else
                "all logged MAP samples because Sensed MAP is Disabled in the uploaded tune"
            )
        rpm_vals = [x["rpm"] for x in estimate_samples]
        airflow_vals = [x["airflow_gps"] for x in estimate_samples if x["airflow_gps"] is not None]
        rpm_max = max(rpm_vals) if rpm_vals else None
        airflow_max = max(airflow_vals) if airflow_vals else None
        rpm_ok = rpm_max is None or rpm_max <= float(tmap["rpm_axis"][-1]) + 1e-9
        airflow_ok = airflow_max is None or airflow_max <= float(tmap["airflow_axis_gps"][-1]) + 1e-9
        tmap_coverage = {
            "rpm_axis_min": float(tmap["rpm_axis"][0]),
            "rpm_axis_max": float(tmap["rpm_axis"][-1]),
            "airflow_axis_min_gps": float(tmap["airflow_axis_gps"][0]),
            "airflow_axis_max_gps": float(tmap["airflow_axis_gps"][-1]),
            "observed_rpm_max": rpm_max,
            "observed_airflow_max_gps": airflow_max,
            "coverage_basis": coverage_basis,
            "sample_count": len(estimate_samples),
            "rpm_covered": bool(rpm_ok),
            "airflow_covered": bool(airflow_ok),
            "covered": bool(rpm_ok and airflow_ok),
            "rpm_endpoint_advisory": bool(not rpm_ok),
        }
        # The factory 2016 6.4L calibration ends this 17x17 table at 6016
        # RPM, despite Maximum RPM=6600.  Stock 6.2L similarly ends at 6208
        # with Maximum RPM=6400.  These source tunes disprove the assumption
        # that the final TMAP breakpoint must equal the usable RPM limit.
        # PCM beyond-endpoint lookup semantics are not independently verified:
        # report RPM overrun, but do not rewrite a factory-style table or
        # prohibit VE corrections solely for this unproven requirement.
        if not rpm_ok and rpm_max is not None:
            warnings.append(
                f"Throttle Based MAP Multiplier RPM endpoint advisory: observed "
                f"{rpm_max:.0f} RPM exceeds the last breakpoint "
                f"{tmap['rpm_axis'][-1]:.0f} RPM. Factory tunes can end this "
                "table below Maximum RPM; PCM endpoint behavior has not been "
                "verified. No table rescaling is performed."
            )
        # Preserve the existing independent airflow-range protection. This
        # change concerns only the unsupported *RPM* hard-stop.
        if not airflow_ok and airflow_max is not None:
            blocking_issues.append(
                "Throttle Based MAP Multiplier does not cover the logged "
                f"airflow applicable to the existing Sensed MAP configuration "
                f"(airflow {airflow_max:.1f} > {tmap['airflow_axis_gps'][-1]:.1f} g/s)."
            )

    auto_fix_required = bool(auto_actions)
    blocking = bool(blocking_issues)
    return {
        "valid": not blocking,
        "blocking": blocking,
        "missing": [],
        "map_channel": map_name,
        "baro_channel": baro_name,
        "rpm_channel": rpm_name,
        "airflow_channel": airflow_name,
        "observed_map_min_kpa": map_stats["minimum"],
        "observed_map_max_kpa": observed_map_max,
        "observed_pratio_min": observed_pratio_min,
        "observed_pratio_max": observed_pratio_max,
        "logged_baro_median_kpa": baro_median,
        "logged_baro_role": "operating_pratio_only",
        "sea_level_reference_kpa": float(sea_level_reference_kpa),
        "map_validation_baseline": "standard_sea_level_absolute_pressure",
        "baro_status": "operating_reference_only" if baro_median is not None else "not_available",
        "baro_delta_from_sea_level_kpa": None,
        "map1": map1,
        "map2": map2,
        "baro_sensor": baro_sensor,
        "map_sensors_covering_observed_range": covering,
        "boosted_detected": bool(boosted_detected),
        "boosted_sample_count": len(boosted_samples),
        "pressure_ratio_max": pressure_ratio_max,
        "recommended_pressure_ratio_max": recommended_pratio_max,
        "pressure_ratio_max_change_required": bool(pratio_change_required),
        "pressure_ratio_max_valid": bool(not pratio_change_required),
        "sensed_map_enable": sensed_map_switch,
        "recommended_sensed_map_enable": sensed_map_switch,
        "sensed_map_enable_change_required": False,
        "sensed_map_pratio_threshold": sensed_map_threshold,
        "throttle_based_map_multiplier": tmap_coverage,
        "auto_fix_required": auto_fix_required,
        "automatic_change_allowed": bool(auto_fix_required and not blocking),
        "auto_actions": auto_actions,
        "issues": blocking_issues,
        "warnings": warnings,
        "message": (
            "Pressure-model preflight requires automatic calibration preparation before correction."
            if auto_fix_required and not blocking else
            "Pressure-model preflight passed." if not blocking else
            "Pressure-model preflight found an issue that cannot be repaired safely from the current tune/log."
        ),
    }


def prepare_airflow_strategy(hpl_path: Path, tune_path: Path, output_path: Path) -> dict:
    """Apply only a preflight-approved Pressure Ratio Max scalar correction.

    Sensed MAP (2100) and MAP sensor transfer values are never changed.
    Existing MAP routing and table coverage must already qualify.
    """
    hpl_path = Path(hpl_path)
    tune_path = Path(tune_path)
    output_path = Path(output_path)
    pf = airflow_map_preflight(hpl_path, tune_path)
    if pf.get("blocking"):
        raise ValueError("Pressure-model preflight has an unrepairable issue: " + "; ".join(pf.get("issues", [])))
    source = tune_path.read_bytes()
    blob = source
    changed = []
    if pf.get("pressure_ratio_max_change_required"):
        value = float(pf["recommended_pressure_ratio_max"])
        blob = _replace_scalar_value(blob, PRESSURE_RATIO_MAX_SCALAR, value)
        changed.append({"parameter": "Pressure Ratio Max", "key": PRESSURE_RATIO_MAX_SCALAR, "value": value})
    output_path.write_bytes(blob)

    if not changed:
        return {**pf, "output": str(output_path), "changed": False, "changes": [], "scope_verified": True}

    if pf.get("pressure_ratio_max_change_required"):
        actual = float(htt.read_scalar(output_path, PRESSURE_RATIO_MAX_SCALAR))
        if abs(actual - float(pf["recommended_pressure_ratio_max"])) > 1e-12:
            raise AssertionError("Pressure Ratio Max did not round-trip after preparation")
    # Exact scope verification: restoring the sole permitted scalar must
    # reproduce the original .htt byte-for-byte (including Sensed MAP 2100).
    restored = output_path.read_bytes()
    if pf.get("pressure_ratio_max_change_required"):
        restored = _replace_scalar_value(
            restored, PRESSURE_RATIO_MAX_SCALAR,
            float(htt.read_scalar(tune_path, PRESSURE_RATIO_MAX_SCALAR)),
        )
    if restored != source:
        raise AssertionError("Pressure-model preparation changed bytes outside the approved Pressure Ratio Max scalar")

    post = airflow_map_preflight(hpl_path, output_path)
    if post.get("blocking") or post.get("auto_fix_required"):
        raise AssertionError("Pressure-model preparation did not resolve the deterministic preflight actions")
    return {
        **pf,
        "output": str(output_path),
        "changed": True,
        "changes": changed,
        "scope_verified": True,
        "post_preflight": post,
    }


def inspect_correction_sources(hpl_path: Path, *, airflow_model: str = "neural_network",
                               closed_loop_only: bool = False) -> dict:
    """Report which correction sources are actually usable in one HPL."""
    decoded = decode_hpl(Path(hpl_path))
    adaptive = _adaptive_trim_status(decoded, airflow_model=airflow_model,
                                    closed_loop_only=closed_loop_only)
    narrowband = _narrowband_status(decoded)
    wideband = _wideband_data_status(decoded)
    maf = _maf_status(decoded)

    choices = [
        {
            "id": "adaptive",
            "label": (
                "Short Term Fuel Trims (STFT)"
                if adaptive.get("mode") == "stft_only"
                else "Adaptive Fuel Trims (LTFT + STFT)"
            ),
            "enabled": bool(adaptive["valid"]),
            "reason": adaptive.get("reason"),
        },
        {
            "id": "narrowband",
            "label": "Narrowband O2 Voltage",
            "enabled": False,
            "available": bool(narrowband["valid"]),
            "reason": (
                "Raw narrowband voltage is detected and validated, but direct VE-correction math is not frozen. "
                "Use Adaptive Fuel Trims for quantitative closed-loop correction."
                if narrowband["valid"] else narrowband.get("reason")
            ),
        },
        {
            "id": "wideband",
            "label": "Wideband O2",
            "enabled": bool(wideband["valid"]),
            "reason": wideband.get("reason"),
        },
    ]
    if closed_loop_only:
        wideband = dict(wideband, valid=False,
                        reason='Excluded by approved naturally aspirated closed-loop-only correction.')
        for choice in choices:
            if choice['id'] != 'adaptive':
                choice['enabled'] = False
                choice['reason'] = 'Excluded by approved naturally aspirated closed-loop-only correction.'
    return {
        "adaptive": adaptive,
        "narrowband": narrowband,
        "wideband": wideband,
        "maf": maf,
        "choices": choices,
        "narrowband_note": (
            "Upstream narrowband voltage is a diagnostic only; it is not a Speed Density STFT input."
            if airflow_model == "speed_density" else
            "Upstream narrowband voltage is reported as a diagnostic/health source; "
            "LTFT+STFT remain the quantitative narrowband closed-loop correction source."
        ),
        "maf_note": (
            "A populated MAF channel is an additional airflow reference only. VE Optimizer does not infer "
            "that the PCM is using MAF for fueling merely because the channel is logged."
        ),
    }


def _minimum_distortion_axis(old_axis: np.ndarray, lower: float, upper: float,
                             other_axis: np.ndarray, b1: np.ndarray, b2: np.ndarray,
                             *, direction: str) -> np.ndarray:
    """Preserve existing VE data while adding calibrated domain endpoints.

    Fixed-size 2D PCM tables cannot grow. Evaluate which internal breakpoint(s)
    can be retired with least round-trip VE interpolation error across BOTH
    banks. For an unusual severely truncated calibration, fill vacant positions
    by splitting the largest intervals. The user-defined endpoints remain exact.
    """
    old_axis = np.asarray(old_axis, dtype=float)
    if abs(float(old_axis[0]) - lower) < 1e-9 and abs(float(old_axis[-1]) - upper) < 1e-9:
        return old_axis.copy()
    proposed = np.array(sorted({float(lower), float(upper)} |
                               {float(x) for x in old_axis if lower < x < upper}), dtype=float)
    count = len(old_axis)
    if not (math.isfinite(lower) and math.isfinite(upper) and 0 <= lower < upper):
        raise ValueError("Invalid calibration-derived Speed Density axis bounds")
    # Some tunes have existing breakpoints outside their new MAP1 / Maximum
    # RPM limits. They cannot be retained in the calibrated destination domain.
    while len(proposed) < count:
        index = int(np.argmax(np.diff(proposed)))
        proposed = np.insert(proposed, index + 1, (proposed[index] + proposed[index+1]) / 2.0)

    def distortion(candidate: np.ndarray):
        if direction == "rpm":
            old_rpm, old_pr = old_axis, other_axis
            new_rpm, new_pr = candidate, other_axis
        else:
            old_rpm, old_pr = other_axis, old_axis
            new_rpm, new_pr = other_axis, candidate
        errors = []
        for z in (b1, b2):
            new_z = _regrid_speed_density_surface(old_rpm, old_pr, z, new_rpm, new_pr)
            new_z = np.rint(new_z / VE_QUANTUM) * VE_QUANTUM
            reconstructed = _regrid_speed_density_surface(new_rpm, new_pr, new_z, old_rpm, old_pr)
            errors.append(np.abs(reconstructed - z))
        arr = np.stack(errors)
        return float(np.max(arr)), float(np.mean(arr))

    surplus = len(proposed) - count
    if 0 < surplus <= 2:
        best = None
        for removed in itertools.combinations(range(1, len(proposed)-1), surplus):
            trial = np.delete(proposed, removed)
            score = distortion(trial)
            if best is None or score < best[0]:
                best = (score, trial)
        proposed = best[1]
    while len(proposed) > count:
        best = None
        for index in range(1, len(proposed) - 1):
            trial = np.delete(proposed, index)
            score = distortion(trial)
            if best is None or score < best[0]:
                best = (score, trial)
        proposed = best[1]
    if len(proposed) != count or proposed[0] != lower or proposed[-1] != upper:
        raise AssertionError("Speed Density axis scaling did not retain calibrated endpoints")
    return proposed


def speed_density_axis_preflight(tune_path: Path) -> dict:
    """Derive the complete fixed-size Speed Density grid from this .htt alone.

    Method B uses Maximum RPM (44490), from zero, and MAP1's 0..5 V
    calibrated pressure capability divided by the standard 101.325 kPa
    absolute-pressure reference. MAP2, NN training values, and logged peak
    RPM/PRatio MUST NOT redefine these endpoints. Both VE banks retain their
    original number of rows and columns. No PE calibration is modified.
    """
    tune_path = Path(tune_path)
    if detect_airflow_model(tune_path) != "speed_density":
        raise ValueError("Speed Density axis scaling requires Use Neural Network disabled")
    rpm_max = _read_optional_scalar(tune_path, MAXIMUM_RPM_SCALAR)
    if rpm_max is None or not math.isfinite(rpm_max) or rpm_max <= 0:
        raise ValueError("Maximum RPM (record 44490) is missing or invalid; Speed Density scaling is blocked")
    sensor = _sensor_transfer_status(
        tune_path, label="MAP1", linear_key=MAP1_LINEAR_SCALAR,
        offset_kpa_key=MAP1_OFFSET_KPA_SCALAR, offset_v_key=MAP1_OFFSET_V_SCALAR,
    )
    if not sensor["valid"]:
        raise ValueError("Valid MAP1 slope, pressure offset, and voltage offset are required for Speed Density scaling")
    minimum_kpa = max(0.0, sensor["offset_kpa"] - sensor["slope_kpa_per_v"] * sensor["offset_v"])
    maximum_kpa = float(sensor["full_scale_kpa"])
    if not (math.isfinite(minimum_kpa) and maximum_kpa > minimum_kpa):
        raise ValueError("MAP1 calibrated pressure range is invalid; Speed Density scaling is blocked")
    pr_min = minimum_kpa / SEA_LEVEL_BARO_KPA
    pr_max = maximum_kpa / SEA_LEVEL_BARO_KPA
    _, old_rpm, old_pr, b1 = parse_ve_table(tune_path, VE_BANK1_TABLE)
    _, other_rpm, other_pr, b2 = parse_ve_table(tune_path, VE_BANK2_TABLE)
    if not (np.array_equal(old_rpm, other_rpm) and np.array_equal(old_pr, other_pr)):
        raise ValueError("Speed Density VE Bank 1/2 axes differ; scaling is blocked")
    if b1.shape != b2.shape or min(b1.shape) < 2 or not np.all(np.isfinite(b1)) or not np.all(np.isfinite(b2)):
        raise ValueError("Speed Density VE tables have invalid dimensions or values")
    if not (np.all(np.isfinite(old_rpm)) and np.all(np.diff(old_rpm) > 0)
            and np.all(np.isfinite(old_pr)) and np.all(np.diff(old_pr) > 0)):
        raise ValueError("Speed Density VE source axes must be finite and strictly increasing")
    # Retain as many original calibrated breakpoints as possible. An even
    # 17x17 redistribution can change the stock VE surface by several VE
    # points. Reclaim the least consequential interior breakpoints instead.
    new_rpm = _minimum_distortion_axis(old_rpm, 0.0, float(rpm_max),
                                       old_pr, b1, b2, direction="rpm")
    new_pr = _minimum_distortion_axis(old_pr, float(pr_min), float(pr_max),
                                      old_rpm, b1, b2, direction="pratio")
    rpm_need = abs(float(old_rpm[0])) > 1e-9 or abs(float(old_rpm[-1]) - float(rpm_max)) > 1e-9
    pr_need = abs(float(old_pr[0]) - float(pr_min)) > 1e-9 or abs(float(old_pr[-1]) - float(pr_max)) > 1e-9
    return {
        "current_rpm_min": float(old_rpm[0]), "current_rpm_max": float(old_rpm[-1]),
        "current_pratio_min": float(old_pr[0]), "current_pratio_max": float(old_pr[-1]),
        "recommended_rpm_min": 0.0, "recommended_rpm_max": float(rpm_max),
        "recommended_pratio_min": float(pr_min), "recommended_pratio_max": float(pr_max),
        "map1_minimum_kpa": minimum_kpa, "map1_full_scale_kpa": maximum_kpa,
        "map1_sensor_class": sensor["sensor_class"], "map1_reference_kpa": SEA_LEVEL_BARO_KPA,
        "rpm_source_record": MAXIMUM_RPM_SCALAR, "pratio_source": "MAP1 calibrated 0-5V transfer",
        "proposed_rpm_axis": new_rpm, "proposed_pratio_axis": new_pr,
        "rpm_rescale_required": bool(rpm_need), "pratio_rescale_required": bool(pr_need),
        "needs_rescale": bool(rpm_need or pr_need), "requires_user_confirmation": False,
        "automatic_rescale_allowed": True,
        "message": (
            f"Speed Density VE grid requires scaling to 0..{rpm_max:g} RPM from .htt Maximum RPM "
            f"(44490) and PRatio {pr_min:.5f}..{pr_max:.5f} from MAP1 full-scale calibration. "
            "Both VE banks retain the lowest-distortion available internal breakpoints; "
            "values outside the original grid are edge-held, not measured or independently tuned."
            if rpm_need or pr_need else
            "Speed Density VE axes already match .htt Maximum RPM and MAP1 full calibrated range."
        ),
    }


def _regrid_speed_density_surface(
    old_rpm: np.ndarray, old_pr: np.ndarray, z: np.ndarray,
    new_rpm: np.ndarray, new_pr: np.ndarray,
) -> np.ndarray:
    """Interpolate in RPM then PRatio; edge-hold outside the stored surface."""
    z = np.asarray(z, dtype=float)
    along_rpm = np.vstack([
        np.interp(new_rpm, old_rpm, row, left=row[0], right=row[-1]) for row in z
    ])
    return np.column_stack([
        np.interp(new_pr, old_pr, along_rpm[:, c],
                  left=along_rpm[0, c], right=along_rpm[-1, c])
        for c in range(along_rpm.shape[1])
    ])


def _surface_grid_error(old_rpm, old_pr, old_z, new_rpm, new_pr, new_z) -> dict:
    reconstructed = _regrid_speed_density_surface(new_rpm, new_pr, new_z, old_rpm, old_pr)
    delta = reconstructed - old_z
    return {
        "maximum_absolute_ve_error": float(np.max(np.abs(delta))),
        "mean_absolute_ve_error": float(np.mean(np.abs(delta))),
    }


def speed_density_domain_preflight(analysis: dict, *, tune_path: Path | None = None,
                                   headroom_step: float = RESCALE_HEADROOM_STEP) -> dict:
    """Check calibration-derived Speed Density scaling independently of log peaks.

    The historical ``headroom_step`` argument is retained for API compatibility
    but no longer changes the calibration-defined MAP1 range.
    """
    if analysis.get("airflow_model") != "speed_density":
        raise ValueError("Speed Density domain preflight requires a Speed Density analysis")
    source = tune_path or analysis.get("tune_path")
    if not source:
        raise ValueError("The uploaded .htt is required to determine Speed Density axes")
    result = speed_density_axis_preflight(source)
    samples = list(analysis.get("accepted_samples", [])) + list(analysis.get("outside_domain_samples", []))
    result.update({
        "valid_sample_count": len(samples),
        "observed_pratio_min": min((float(s["pratio"]) for s in samples), default=None),
        "observed_pratio_max": max((float(s["pratio"]) for s in samples), default=None),
        "observed_rpm_min": min((float(s["rpm"]) for s in samples), default=None),
        "observed_rpm_max": max((float(s["rpm"]) for s in samples), default=None),
        "outside_full_sensor_domain": sum(
            not (result["recommended_rpm_min"] <= float(s["rpm"]) <= result["recommended_rpm_max"]
                 and result["recommended_pratio_min"] <= float(s["pratio"]) <= result["recommended_pratio_max"])
            for s in samples
        ),
    })
    return result


def _rebuild_ve_table_with_axes(
    original_payload: bytes, new_rpm_axis: np.ndarray, new_pratio_axis: np.ndarray,
    new_z: np.ndarray,
) -> bytes:
    sep, ends, header_b, rows_b = _split_table(original_payload)
    header = header_b.decode("utf-8").split("\t")
    if len(rows_b) != len(new_pratio_axis) or len(header) - 2 != len(new_rpm_axis):
        raise ValueError("Speed Density table axis lengths do not match its fixed size")
    if new_z.shape != (len(new_pratio_axis), len(new_rpm_axis)):
        raise ValueError("Speed Density VE surface shape does not match its new axes")
    if not np.all(np.diff(new_rpm_axis) > 0) or not np.all(np.diff(new_pratio_axis) > 0):
        raise ValueError("New Speed Density axes must be strictly increasing")
    if not np.all(np.isfinite(new_z)):
        raise ValueError("Regridded VE values must be finite")
    def axis_token(v):
        return format(float(v), ".15g")
    # Keep table's native leading '%' and trailing RPM-unit header tokens.
    new_header = "\t".join([header[0]] + [axis_token(x) for x in new_rpm_axis] + [header[-1]])
    out_rows = []
    for pr, values in zip(new_pratio_axis, new_z):
        quantized = [round(float(v) / VE_QUANTUM) * VE_QUANTUM for v in values]
        tokens = [f"{v:.8f}".rstrip("0").rstrip(".") for v in quantized]
        out_rows.append(axis_token(pr) + "\t" + "\t".join(tokens))
    result = sep.join([new_header.encode("utf-8")] + [row.encode("utf-8") for row in out_rows])
    return result + sep if ends else result


def rescale_speed_density_axes(tune_path: Path, output_path: Path) -> dict:
    """Rescale both fixed-size VE bank tables from .htt Maximum RPM and MAP1.

    This must precede adaptive or wideband VE corrections and is never applied
    to the neural-network method. No PE records or MAP sensor values are written.
    """
    import os
    import tempfile
    tune_path, output_path = Path(tune_path), Path(output_path)
    if tune_path.resolve() == output_path.resolve():
        raise ValueError("Cannot overwrite the original .htt during Speed Density scaling")
    pf = speed_density_axis_preflight(tune_path)
    old_blob = tune_path.read_bytes()
    b1_payload, old_rpm, old_pr, b1 = parse_ve_table(tune_path, VE_BANK1_TABLE)
    b2_payload, _, _, b2 = parse_ve_table(tune_path, VE_BANK2_TABLE)
    new_rpm = np.asarray(pf["proposed_rpm_axis"], dtype=float)
    new_pr = np.asarray(pf["proposed_pratio_axis"], dtype=float)
    if pf["needs_rescale"]:
        new_b1 = _regrid_speed_density_surface(old_rpm, old_pr, b1, new_rpm, new_pr)
        new_b2 = _regrid_speed_density_surface(old_rpm, old_pr, b2, new_rpm, new_pr)
        blob = old_blob
        for key, original, values in (
            (VE_BANK1_TABLE, b1_payload, new_b1), (VE_BANK2_TABLE, b2_payload, new_b2)
        ):
            payload = _rebuild_ve_table_with_axes(original, new_rpm, new_pr, values)
            blob = _replace_length_payload(blob, key, payload)
    else:
        blob = old_blob
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".sd_scaled_", suffix=".htt", dir=output_path.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        tmp.write_bytes(blob)
        _, rpm1, pr1, result_b1 = parse_ve_table(tmp, VE_BANK1_TABLE)
        _, rpm2, pr2, result_b2 = parse_ve_table(tmp, VE_BANK2_TABLE)
        if not (np.array_equal(rpm1, rpm2) and np.array_equal(pr1, pr2)):
            raise AssertionError("Scaled Speed Density VE Bank axes diverged")
        if not (np.allclose(rpm1, new_rpm, rtol=0, atol=1e-10)
                and np.allclose(pr1, new_pr, rtol=0, atol=1e-10)):
            raise AssertionError("New RPM/PRatio axis values did not round-trip")
        restored = tmp.read_bytes()
        for key, original in ((VE_BANK1_TABLE, b1_payload), (VE_BANK2_TABLE, b2_payload)):
            restored = _replace_length_payload(restored, key, original)
        if restored != old_blob:
            raise AssertionError("Speed Density scaling changed an unrelated .htt record")
        # Complete binary parser cross-check, including source type and record IDs.
        from ve_optimizer_htt_codec import parse_htt
        before, after = parse_htt(old_blob), parse_htt(tmp.read_bytes())
        for key, record in before.by_key().items():
            if key not in (VE_BANK1_TABLE, VE_BANK2_TABLE) and record.raw != after.by_key()[key].raw:
                raise AssertionError(f"Speed Density scaling modified unrelated record {key}")
        os.replace(tmp, output_path)
    finally:
        tmp.unlink(missing_ok=True)
    return {
        "output": str(output_path), "changed": bool(pf["needs_rescale"]),
        "old_rpm_axis": old_rpm, "new_rpm_axis": rpm1,
        "old_pratio_axis": old_pr, "new_pratio_axis": pr1,
        "old_rpm_min": float(old_rpm[0]), "old_rpm_max": float(old_rpm[-1]),
        "new_rpm_min": float(rpm1[0]), "new_rpm_max": float(rpm1[-1]),
        "old_pratio_min": float(old_pr[0]), "old_pratio_max": float(old_pr[-1]),
        "new_pratio_min": float(pr1[0]), "new_pratio_max": float(pr1[-1]),
        "rpm_rescaled": bool(pf["rpm_rescale_required"]),
        "pratio_rescaled": bool(pf["pratio_rescale_required"]),
        "map_source": "MAP1", "rpm_source_record": MAXIMUM_RPM_SCALAR,
        "surface_regridded": bool(pf["needs_rescale"]),
        "original_table_shape": list(b1.shape), "new_table_shape": list(result_b1.shape),
        "out_of_original_domain_behavior": "edge hold (not calibrated)",
        "regrid_error_b1": _surface_grid_error(old_rpm, old_pr, b1, rpm1, pr1, result_b1),
        "regrid_error_b2": _surface_grid_error(old_rpm, old_pr, b2, rpm2, pr2, result_b2),
        "scope_verified": True,
    }


def rescale_speed_density_pratio(tune_path: Path, output_path: Path, *, new_pratio_max: float) -> dict:
    """Compatibility entrypoint; log-based PRatio maxima are never used."""
    return rescale_speed_density_axes(tune_path, output_path)


def _pe_operating_pratio_status(
    hpl_path: Path,
    *,
    boost_threshold: float = BOOST_PRATIO_THRESHOLD,
    min_boost_samples: int = BOOST_MIN_PE_SAMPLES,
) -> dict:
    """Inspect dual-gated PE operation for meaningful boosted PRatio.

    This does not require a wideband channel.  It is therefore usable on a WOT
    log collected only to establish the correct PE operating strategy.
    """
    decoded = decode_hpl(Path(hpl_path))
    channels = decoded["channels"]
    names = {
        "rpm": (RPM_NAME,),
        "map": (),  # populated from the shared validated MAP source below
        "baro": (BARO_NAME, "Barometric Pressure - Hi Res", "Barometric Pressure (SAE)"),
        "ect": (ECT_NAME, "Engine Coolant Temp"),
        "fa": (FA_ENRICH_NAME,),
        "pe": (FA_PE_NAME,),
        "torque": (TORQUE_NAME,),
    }
    idx = {}
    for name, candidates in names.items():
        idx[name] = None
        for candidate in candidates:
            value = _resolve_optional_name(channels, candidate, decoded=decoded)
            if value is not None:
                idx[name] = value
                break
    from ve_optimizer_map_sources import select_hpl_map
    selected_map = select_hpl_map(decoded)
    idx['map'] = selected_map['source']['channel_index'] if selected_map['valid'] else None
    idx['baro'] = selected_map['baro_index'] if selected_map['valid'] else None
    missing = [name for name, value in idx.items() if value is None]
    if missing:
        return {
            "valid": False,
            "missing": missing,
            "dual_gate_samples": 0,
            "boosted_samples": 0,
            "boosted_detected": False,
            "reason": (selected_map['reason'] if not selected_map['valid'] else
                       "Missing channel(s) required for PE strategy detection: " + ", ".join(missing)),
        }

    histories = {name: _history(decoded, value) for name, value in idx.items()}
    ect_unit = str(channels[idx["ect"]].get("unit", ""))
    torque_unit = str(channels[idx["torque"]].get("unit", ""))

    def ect_f(v):
        v = float(v)
        return v * 1.8 + 32.0 if "c" in ect_unit.lower() else v

    def torque_lbft(v):
        v = float(v)
        return v / 1.35581794833 if "n" in torque_unit.lower() and "m" in torque_unit.lower() else v

    pr_values: List[float] = []
    # MAP has the highest useful update rate for the load axis.  Hold the most
    # recent values of the asynchronous PE-state channels at each MAP update.
    for t in histories["map"][0]:
        rpm = _latest(histories["rpm"], t)
        map_kpa = _latest(histories["map"], t)
        baro = _latest(histories["baro"], t)
        ect = _latest(histories["ect"], t)
        fa = _latest(histories["fa"], t)
        pe = _latest(histories["pe"], t)
        torque = _latest(histories["torque"], t)
        if any(v is None for v in (rpm, map_kpa, baro, ect, fa, pe, torque)):
            continue
        if not (
            float(rpm) > 1000
            and ect_f(ect) > 164
            and torque_lbft(torque) > 1
            and float(baro) > 0
            and float(fa) > 0
            and float(pe) > 0
        ):
            continue
        pr_values.append(float(map_kpa) / float(baro))

    boosted_values = [v for v in pr_values if v > float(boost_threshold)]
    boosted = len(boosted_values) >= int(min_boost_samples)
    return {
        "valid": bool(pr_values),
        "missing": [],
        "dual_gate_samples": len(pr_values),
        "boosted_samples": len(boosted_values),
        "boosted_detected": bool(boosted),
        "boost_threshold": float(boost_threshold),
        "minimum_boost_samples": int(min_boost_samples),
        "observed_pratio_min": float(min(pr_values)) if pr_values else None,
        "observed_pratio_max": float(max(pr_values)) if pr_values else None,
        "reason": None if pr_values else "No warm, loaded, dual-gated PE samples were found.",
    }


def pe_strategy_preflight(
    hpl_path: Path,
    tune_path: Path,
    *,
    headroom_step: float = RESCALE_HEADROOM_STEP,
) -> dict:
    """Read-only PE safety/compatibility preflight; no calibration is created.

    Boosted PE records that have an incompatible selector or insufficient
    stored PRatio axis coverage require manual calibration and relogging.
    Missing optional PE records on a naturally aspirated calibration do not
    prevent an otherwise qualified correction, and no selector is inferred.
    """
    tune_path = Path(tune_path)
    operating = _pe_operating_pratio_status(hpl_path)
    selector = _pe_table_axis_status(tune_path)
    current = selector.get("value")

    boosted = bool(operating.get("boosted_detected"))
    required = "PRatio" if boosted else "Aircharge"
    warnings: List[str] = []
    blocking_issues: List[str] = []
    if selector.get("warning"):
        warnings.append(str(selector["warning"]))

    pr_table = None
    pr_table_error = None
    try:
        pr_table = parse_numeric_2d_table(tune_path, PE_PRATIO_TABLE)
    except KeyError:
        pr_table_error = "PRatio Power Enrichment table is not stored in this calibration."
    except Exception as exc:
        pr_table_error = f"PRatio Power Enrichment table could not be decoded: {exc}"

    current_pr_max = float(pr_table["y_axis"][-1]) if pr_table is not None else None
    # PE correction/axis generation is not part of v2.4.5. Report stored
    # calibration coverage as a safety observation only; never propose values.
    switch_change = False
    rescale = False

    # Missing selector/table records are only blocking when boosted operation
    # requires those records to be reviewed manually. For ordinary NA logs,
    # they remain compatibility notes and do not disable adaptive processing.
    if boosted:
        if current not in {"Aircharge", "PRatio"}:
            blocking_issues.append(
                "Boosted PE operation requires a stored FA Power Enrich Table Select "
                "value, but this calibration does not provide a usable selector record."
            )
        elif current == "Aircharge":
            switch_change = True

        if pr_table is None:
            blocking_issues.append(
                "Boosted PE operation requires the PRatio Power Enrichment table, "
                "but that table is not available in this calibration."
            )

        observed_max = operating.get("observed_pratio_max")
        if pr_table is not None and observed_max is not None and float(observed_max) > float(current_pr_max):
            rescale = True

    # An incompatible stored PE selector/axis requires an independently
    # calibrated Tune File and a new log. Never repair it by copying or
    # interpolating stored PE FAR adders.
    if switch_change:
        blocking_issues.append(
            "Boosted calibration still selects Aircharge PE. Set and validate the "
            "appropriate PE strategy manually in VCM Editor and collect a new log."
        )
    if rescale:
        blocking_issues.append(
            "Logged boosted PRatio exceeds the stored PRatio PE table axis. "
            "Calibrate PE coverage manually and collect a new log."
        )
    manual_review_required = bool(boosted and blocking_issues)
    blocking = bool(blocking_issues)

    if not operating.get("valid"):
        message = operating.get("reason") or "PE strategy could not be determined from the log."
    elif blocking:
        message = (
            "PE calibration requires manual correction and validation in VCM Editor; "
            "VE Optimizer cannot update PE tables or selectors. Collect a new "
            "log after correcting the calibration."
        )
    elif boosted:
        message = (
            "Stored PE selector and PRatio axis cover the observed boosted range; "
            "this DOES NOT verify PE fuel delivery. PE calibration is never changed."
        )
    elif current is None:
        message = (
            "The PE selector is not stored; naturally aspirated preflight does "
            "not edit PE calibration. No PE fueling accuracy is established."
        )
    else:
        message = "No boosted PE mismatch detected. PE calibration remains unchanged and has not been validated."

    return {
        "valid": not blocking,
        "blocking": blocking,
        "issues": blocking_issues,
        "warnings": warnings,
        "selector_present": bool(selector.get("present")),
        "selector_valid": bool(selector.get("valid")),
        "selector_detection": selector.get("detection_source"),
        "operating": operating,
        "current_pe_method": current or "Not stored",
        "required_pe_method": required,
        "boosted_detected": boosted,
        "switch_change_required": bool(switch_change),
        "pratio_table_present": pr_table is not None,
        "pratio_table_error": pr_table_error,
        "pratio_rescale_required": bool(rescale),
        "current_pratio_table_max": current_pr_max,
        "recommended_pratio_table_max": None,
        "proposed_pratio_axis": np.asarray([], dtype=float),
        "preserved_low_axis_anchor_index": None,
        "table_shape": tuple(int(v) for v in pr_table["z"].shape) if pr_table is not None else None,
        "automatic_change_allowed": False,
        "manual_review_required": manual_review_required,
        "calibration_write_enabled": False,
        "message": message,
    }

def prepare_pe_strategy(
    hpl_path: Path,
    tune_path: Path,
    output_path: Path,
    *,
    headroom_step: float = RESCALE_HEADROOM_STEP,
) -> dict:
    """Disabled: v2.4.5 must never synthesize or export PE calibration.

    Retain the public function name so an old caller fails closed rather than
    silently preparing an unverified Aircharge/PRatio table.
    """
    raise RuntimeError(
        "Automatic Power Enrichment calibration has been removed from "
        "VE Optimizer v2.4.5. No PE selector/table may be changed or generated; "
        "calibrate and verify PE manually outside VE Optimizer."
    )

def build_correction_preflight(
    hpl_path: Path,
    tune_path: Path,
    *,
    delay_ms: int = 60,
    min_hits: int = MIN_HITS,
    closed_loop_only: bool = False,
    hardware_review_approved: bool = False,
) -> dict:
    """Build the data-source choice and mandatory domain check shown before processing."""
    hpl_path = Path(hpl_path)
    tune_path = Path(tune_path)
    config = detect_configuration(tune_path)
    sources = inspect_correction_sources(hpl_path, airflow_model=config["airflow_model"],
                                         closed_loop_only=closed_loop_only)
    airflow_preflight = airflow_map_preflight(hpl_path, tune_path)
    # PE calibration is no longer a correction-preflight responsibility.
    # Wideband enrichment observations remain in the VE correction data path.
    pe_preflight = {}
    # Separate read-only hardware/knock review. This does not authorize any
    # calibration edit or substitute a MAP channel without the user's approval.
    import ve_optimizer_boost_review
    engine_review = ve_optimizer_boost_review.inspect(
        tune_path, hpl_path, config['airflow_model'])
    domain = None
    wideband_analysis_error = None
    if config["airflow_model"] == "speed_density":
        try:
            domain = speed_density_axis_preflight(tune_path)
        except (KeyError, ValueError) as exc:
            domain = {"needs_rescale": False, "blocking": True,
                      "message": str(exc), "automatic_rescale_allowed": False}

    if sources["wideband"]["valid"] and not closed_loop_only:
        try:
            wb_analysis = analyze_wideband(hpl_path, tune_path, delay_ms=delay_ms, min_hits=min_hits)
            if config["airflow_model"] == "speed_density":
                domain = speed_density_domain_preflight(wb_analysis, tune_path=tune_path)
            else:
                # NN processing already rejects samples outside the active NN domain.
                outside = len(wb_analysis.get("outside_domain_samples", []))
                inside = len(wb_analysis.get("accepted_samples", []))
                domain = {
                    "valid_sample_count": inside + outside,
                    "inside_domain": inside,
                    "outside_domain": outside,
                    "needs_rescale": outside > 0,
                    "requires_user_confirmation": False,
                    "message": (
                        "Wideband samples exceed the active NN training domain; NN training-range changes require separate calibration review."
                        if outside else
                        "All valid wideband samples fit inside the active NN training domain."
                    ),
                }
        except Exception as exc:
            wideband_analysis_error = str(exc)
            sources["wideband"]["processor_ready"] = False
            sources["wideband"]["processor_error"] = str(exc)
        else:
            sources["wideband"]["processor_ready"] = True
    else:
        sources["wideband"]["processor_ready"] = False

    # Physical MAP sensor confirmation was removed by user directive.
    # Keep the independent data-driven MAP/Baro and pressure-model gates;
    # neither a source label nor a stored MAP transfer proves installed hardware.
    hardware_review_pending = False
    # Absence of logged boost is not proof of a naturally aspirated engine.
    pe_na_review_pending = False
    # PE calibration is outside VE Optimizer's scope. Its table coverage or
    # selector must not disqualify an otherwise valid VE correction source.
    pe_manual_review_required = False
    choices = []
    for item in sources["choices"]:
        item = dict(item)
        if airflow_preflight.get("blocking"):
            item["enabled"] = False
            item["reason"] = airflow_preflight.get("message")
        if config["airflow_model"] == "speed_density" and domain and domain.get("blocking"):
            item["enabled"] = False
            item["reason"] = domain.get("message")
        if item["id"] == "wideband" and not sources["wideband"].get("processor_ready", False):
            item["enabled"] = False
            item["reason"] = wideband_analysis_error or sources["wideband"].get("reason")
        choices.append(item)

    return {
        "configuration": config,
        "closed_loop_only": bool(closed_loop_only),
        "sources": {k: v for k, v in sources.items() if k != "choices"},
        "choices": choices,
        "airflow_map_preflight": airflow_preflight,
        "pe_preflight": pe_preflight,
        "engine_review": engine_review,
        "hardware_review_pending": hardware_review_pending,
        "pe_na_review_pending": pe_na_review_pending,
        "pe_calibration_pending": False,
        "pe_preparation_required": False,
        "pe_manual_review_required": pe_manual_review_required,
        "domain_preflight": domain,
        "prompt": {
            "title": "Correction Source",
            "message": "Choose which valid log data VE Optimizer should use for this correction pass.",
            "choices": choices,
        },
    }


def analyze_speed_density(
    hpl_path: Path,
    tune_path: Path,
    *,
    delay_ms: int = 60,
    min_hits: int = MIN_HITS,
    correction_fraction: float = CORRECTION_FRACTION,
) -> dict:
    """Return wideband correction data on the active SD VE-table axes."""
    tune_path = Path(tune_path)
    hpl_path = Path(hpl_path)
    if detect_airflow_model(tune_path) != "speed_density":
        raise ValueError("Speed Density wideband processing requested for an NN-enabled tune")

    b1_payload, rpm_axis, pr_axis, b1 = parse_ve_table(tune_path, VE_BANK1_TABLE)
    b2_payload, rpm2, pr2, b2 = parse_ve_table(tune_path, VE_BANK2_TABLE)
    if not np.array_equal(rpm_axis, rpm2) or not np.array_equal(pr_axis, pr2):
        raise ValueError("VE Bank 1 and Bank 2 axes differ")

    decoded = decode_hpl(hpl_path)
    indices, histories = _build_histories(decoded)
    stoich_far, stoich_points = _infer_stoich_far(histories["cmd_sae"], histories["fa"])

    stages = {
        "wideband_updates": 0,
        "endpoint_valid": 0,
        "warm_loaded": 0,
        "fa_enrichment_positive": 0,
        "fa_power_enrichment_positive": 0,
        "dual_gate_pass": 0,
        "commanded_lambda_valid": 0,
        "inside_sd_table_domain": 0,
        "outside_sd_table_domain": 0,
        "accepted": 0,
    }

    accepted: List[dict] = []
    outside: List[dict] = []
    wb_times, wb_values = histories["wb"]

    for t, measured in zip(wb_times, wb_values):
        stages["wideband_updates"] += 1
        measured = float(measured)
        if not (0.5505 < measured < 1.9995):
            continue
        stages["endpoint_valid"] += 1

        state_t = int(t) - int(delay_ms)
        if state_t < 0:
            continue
        state = {name: _latest(histories[name], state_t)
                 for name in ("rpm", "map", "baro", "ect", "fa", "pe", "torque")}
        if any(v is None for v in state.values()):
            continue

        rpm = float(state["rpm"])
        map_kpa = float(state["map"])
        baro = float(state["baro"])
        ect = float(state["ect"])
        fa = float(state["fa"])
        pe = float(state["pe"])
        torque = float(state["torque"])

        if not (rpm > 1000 and ect > 73.3333333333 and baro > 0 and torque > 1.35582):
            continue
        stages["warm_loaded"] += 1
        if fa <= 0:
            continue
        stages["fa_enrichment_positive"] += 1
        if pe <= 0:
            continue
        stages["fa_power_enrichment_positive"] += 1
        stages["dual_gate_pass"] += 1

        commanded = stoich_far / (stoich_far + fa)
        if not (0.70 < commanded < 0.995):
            continue
        stages["commanded_lambda_valid"] += 1

        pratio = map_kpa / baro
        full = (measured / commanded - 1.0) * 100.0
        row = {
            "wb_timestamp_ms": int(t),
            "state_timestamp_ms": int(state_t),
            "rpm": rpm,
            "pratio": pratio,
            "measured_lambda": measured,
            "commanded_lambda": commanded,
            "fa_enrichment": fa,
            "fa_power_enrichment": pe,
            "full_correction_pct": full,
            "applied_correction_pct": float(correction_fraction) * full,
        }

        if (rpm < rpm_axis[0] or rpm > rpm_axis[-1] or
                pratio < pr_axis[0] or pratio > pr_axis[-1]):
            stages["outside_sd_table_domain"] += 1
            outside.append(row)
            continue

        stages["inside_sd_table_domain"] += 1
        r = _nearest_index(pr_axis, pratio)
        c = _nearest_index(rpm_axis, rpm)
        row.update({"row": r, "column": c})
        accepted.append(row)

    stages["accepted"] = len(accepted)
    counts = np.zeros_like(b1, dtype=int)
    sums = np.zeros_like(b1, dtype=float)
    for row in accepted:
        r, c = row["row"], row["column"]
        counts[r, c] += 1
        sums[r, c] += row["full_correction_pct"]

    qualifying = counts >= int(min_hits)
    full_map = np.full_like(b1, np.nan, dtype=float)
    applied_map = np.full_like(b1, np.nan, dtype=float)
    full_map[qualifying] = sums[qualifying] / counts[qualifying]
    applied_map[qualifying] = float(correction_fraction) * full_map[qualifying]

    return {
        "wideband_version": VERSION,
        "airflow_model": "speed_density",
        "tune_path": str(tune_path),
        "pe_table_axis": (_pe_table_axis_status(tune_path).get("value") or "Not stored"),
        "source_sha256": decoded["source_sha256"],
        "decoder_version": decoded["decoder_version"],
        "stoich_far": stoich_far,
        "stoich_inference_points": stoich_points,
        "delay_ms": int(delay_ms),
        "minimum_hits": int(min_hits),
        "correction_fraction": float(correction_fraction),
        "banks_identical": bool(np.array_equal(b1, b2)),
        "rpm_axis": rpm_axis,
        "pratio_axis": pr_axis,
        "original_b1": b1,
        "original_b2": b2,
        "hit_counts": counts,
        "full_correction_pct": full_map,
        "applied_correction_pct": applied_map,
        "qualifying": qualifying,
        "qualifying_cell_count": int(np.count_nonzero(qualifying)),
        "accepted_samples": accepted,
        "outside_domain_samples": outside,
        "stages": stages,
    }


def export_speed_density_changed_tables(base_htt: Path, candidate_htt: Path, output_path: Path) -> dict:
    """Write a grouped, minimal HPT R v3 import from approved changed records.

    We retain the internal full-engine candidate. Only the record types and IDs
    intentionally changed by the Speed Density and pressure-model workflows are
    emitted. Every other source record must match exactly. Unknown container
    revisions or unapproved mutations block export without replacing output.

    IMPORTANT: Correct *container framing* has been verified locally against
    real VCM Editor templates; VCM Editor acceptance of our new subset output
    still requires a user-side Template Applicator test.
    """
    import os
    import tempfile
    from ve_optimizer_htt_codec import parse_htt, build_htt

    base_htt, candidate_htt, output_path = map(Path, (base_htt, candidate_htt, output_path))
    if output_path.resolve() in {base_htt.resolve(), candidate_htt.resolve()}:
        raise ValueError("Cannot overwrite baseline or candidate with the import template")

    baseline = parse_htt(base_htt.read_bytes())
    candidate = parse_htt(candidate_htt.read_bytes())
    if baseline.header != candidate.header:
        raise ValueError("Baseline and candidate use different .htt format headers")

    # Expected section/key mapping is essential: don't silently accept a key
    # if a future editor moves it to another section or changes its type.
    allowed = {
        PRESSURE_RATIO_MAX_SCALAR: "scalar",
        VE_BANK1_TABLE: "table",
        VE_BANK2_TABLE: "table",
    }
    changed_keys = []
    for kind in ("switch", "scalar", "table"):
        before_rows, after_rows = baseline.group(kind), candidate.group(kind)
        if [r.key for r in before_rows] != [r.key for r in after_rows]:
            raise ValueError(f"Candidate {kind} record identities/order differ from the original tune")
        for before, after in zip(before_rows, after_rows):
            if before.raw == after.raw:
                continue
            key = before.key
            if kind == "switch" and key == QUARANTINED_SWITCH_ID:
                raise ValueError(
                    "Unsafe switch 44433 change blocked: VCM Editor identifies this "
                    "as MDS Enable, not verified Sensed MAP Enable."
                )
            if kind == "switch" and key == SENSED_MAP_ENABLE_SWITCH:
                raise ValueError("Sensed MAP switch 2100 must remain unchanged from the uploaded tune")
            if allowed.get(key) != kind:
                raise ValueError(f"Candidate changes unrelated {kind} record {key}; selective export blocked")
            if before.raw[:4] != after.raw[:4]:
                raise ValueError(f"Unsupported framing change in {kind} record {key}")
            if kind == "scalar" and before.raw[12:] != after.raw[12:]:
                raise ValueError(f"Unsupported scalar metadata change in record {key}")
            if kind == "table" and before.raw[-2:] != after.raw[-2:]:
                raise ValueError(f"Unsupported table terminator change in record {key}")
            changed_keys.append(key)

    if not changed_keys:
        raise ValueError("No modified Speed Density or prerequisite records to export")

    changed = set(changed_keys)
    output_blob = build_htt(candidate, changed)
    verified_output = parse_htt(output_blob)
    if set(verified_output.by_key()) != changed:
        raise AssertionError("Export contains unexpected calibration records")
    candidate_by_key = candidate.by_key()
    for key, rec in verified_output.by_key().items():
        if rec.raw != candidate_by_key[key].raw:
            raise AssertionError(f"Export record {key} differs from the verified candidate")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".sd_import_", suffix=".htt", dir=output_path.parent)
    os.close(fd)
    temp = Path(name)
    try:
        temp.write_bytes(output_blob)
        if build_htt(parse_htt(temp.read_bytes())) != output_blob:
            raise AssertionError("Export lost bytes on exact container round-trip")
        os.replace(temp, output_path)
    finally:
        temp.unlink(missing_ok=True)

    return {"output": str(output_path), "changed_records": changed_keys,
            "changed_tables": [key for key in changed_keys if allowed[key] == "table"],
            "record_counts": {kind: len(verified_output.group(kind)) for kind in ("switch", "scalar", "table")},
            "format": "hpt_r3_grouped_selective_development4", "vcm_editor_import_verified": False}


def export_speed_density_candidate(
    tune_path: Path,
    analysis: dict,
    output_path: Path,
) -> dict:
    """Patch only VE Bank 1/2 using a validated SD wideband analysis."""
    if analysis.get("airflow_model") != "speed_density":
        raise ValueError("Analysis is not Speed Density wideband data")

    preflight = speed_density_domain_preflight(analysis, tune_path=tune_path)
    if preflight.get("needs_rescale"):
        raise DomainRescaleRequired(preflight)

    tune_path = Path(tune_path)
    output_path = Path(output_path)
    source_blob = tune_path.read_bytes()

    b1_payload, rpm_axis, pr_axis, b1 = parse_ve_table(tune_path, VE_BANK1_TABLE)
    b2_payload, rpm2, pr2, b2 = parse_ve_table(tune_path, VE_BANK2_TABLE)
    if not np.array_equal(rpm_axis, analysis["rpm_axis"]) or not np.array_equal(pr_axis, analysis["pratio_axis"]):
        raise ValueError("Analysis axes no longer match the input tune")
    if not np.array_equal(rpm_axis, rpm2) or not np.array_equal(pr_axis, pr2):
        raise ValueError("Bank axes differ")

    qualifying = np.asarray(analysis["qualifying"], dtype=bool)
    applied = np.asarray(analysis["applied_correction_pct"], dtype=float)

    new_b1 = b1.copy()
    new_b2 = b2.copy()
    new_b1[qualifying] = b1[qualifying] * (1.0 + applied[qualifying] / 100.0)
    new_b2[qualifying] = b2[qualifying] * (1.0 + applied[qualifying] / 100.0)

    new_payloads = {
        VE_BANK1_TABLE: _rebuild_ve_table(b1_payload, new_b1),
        VE_BANK2_TABLE: _rebuild_ve_table(b2_payload, new_b2),
    }

    patch_info = []
    for key, payload in new_payloads.items():
        _, length_pos, payload_start, payload_end = htt._find_length_payload(source_blob, key)
        patch_info.append((length_pos, payload_start, payload_end, key, payload))

    blob = source_blob
    for length_pos, payload_start, payload_end, key, payload in sorted(patch_info, reverse=True):
        blob = blob[:length_pos] + htt._encode_uleb128(len(payload)) + payload + blob[payload_end:]
    output_path.write_bytes(blob)

    # Strict verification: restore the original two payloads and require an
    # exact byte-for-byte reproduction of the input tune.
    out_blob = output_path.read_bytes()
    restored = out_blob
    restore = []
    for key, original in ((VE_BANK1_TABLE, b1_payload), (VE_BANK2_TABLE, b2_payload)):
        _, length_pos, payload_start, payload_end = htt._find_length_payload(restored, key)
        restore.append((length_pos, payload_start, payload_end, original))
    for length_pos, payload_start, payload_end, original in sorted(restore, reverse=True):
        restored = restored[:length_pos] + htt._encode_uleb128(len(original)) + original + restored[payload_end:]
    if restored != source_blob:
        raise AssertionError("Wideband export modified bytes outside the two VE table payloads")

    out_b1_payload = _read_length_payload(output_path, VE_BANK1_TABLE)
    out_b2_payload = _read_length_payload(output_path, VE_BANK2_TABLE)
    if _axis_signature(out_b1_payload) != _axis_signature(b1_payload):
        raise AssertionError("VE Bank 1 axes changed")
    if _axis_signature(out_b2_payload) != _axis_signature(b2_payload):
        raise AssertionError("VE Bank 2 axes changed")

    _, _, _, out_b1 = parse_ve_table(output_path, VE_BANK1_TABLE)
    _, _, _, out_b2 = parse_ve_table(output_path, VE_BANK2_TABLE)
    changed_b1 = int(np.count_nonzero(out_b1 != b1))
    changed_b2 = int(np.count_nonzero(out_b2 != b2))

    return {
        "output": str(output_path),
        "changed_cells_b1": changed_b1,
        "changed_cells_b2": changed_b2,
        "banks_identical_after": bool(np.array_equal(out_b1, out_b2)),
    }



def _resolve_optional_exact(channels: Dict[int, dict], name: str, *, decoded: dict = None):
    return _resolve_optional_name(channels, name, decoded=decoded)


def analyze_neural_network(
    hpl_path: Path,
    tune_path: Path,
    *,
    delay_ms: int = 60,
    min_hits: int = MIN_HITS,
    correction_fraction: float = CORRECTION_FRACTION,
) -> dict:
    """Return wideband correction targets on an active Neural Network domain.

    Qualification remains RPM/PRatio-cell based. The logged cam position is
    used only to choose which one of the five dynamic NN reference cam pairs
    receives each qualifying cell target. If Intake Cam Center Pos is absent
    but Exhaust Cam Center Pos is logged, intake is derived from the calibration
    training-range LSA relationship.
    """
    tune_path = Path(tune_path)
    hpl_path = Path(hpl_path)
    if detect_airflow_model(tune_path) != "neural_network":
        raise ValueError("Neural Network wideband processing requested for a Speed Density tune")

    net = htt.load_network(tune_path)
    domain = processing.model_domain(net)
    rpm_axis = np.asarray(domain["rpms"], dtype=float)
    pr_axis = np.asarray(domain["pratios"], dtype=float)
    pr_bins = np.asarray(domain["pr_bins"], dtype=float)
    cam_pairs = np.asarray(domain["cam_pairs"], dtype=float)

    decoded = decode_hpl(hpl_path)
    indices, histories = _build_histories(decoded)
    channels = decoded["channels"]

    exhaust_idx = _resolve_optional_exact(channels, EXHAUST_CAM_NAME, decoded=decoded)
    intake_idx = _resolve_optional_exact(channels, INTAKE_CAM_NAME, decoded=decoded)
    if exhaust_idx is None:
        raise ValueError(
            "Neural Network wideband processing requires Exhaust Cam Center Pos in the HPL"
        )
    histories["exhaust_cam"] = _history(decoded, exhaust_idx)
    if intake_idx is not None:
        histories["intake_cam"] = _history(decoded, intake_idx)

    stoich_far, stoich_points = _infer_stoich_far(
        histories["cmd_sae"], histories["fa"]
    )

    stages = {
        "wideband_updates": 0,
        "endpoint_valid": 0,
        "warm_loaded": 0,
        "fa_enrichment_positive": 0,
        "fa_power_enrichment_positive": 0,
        "dual_gate_pass": 0,
        "commanded_lambda_valid": 0,
        "cam_valid": 0,
        "inside_nn_domain": 0,
        "outside_nn_domain": 0,
        "accepted": 0,
    }

    accepted: List[dict] = []
    outside: List[dict] = []
    wb_times, wb_values = histories["wb"]

    lsa = float(domain["derived_lsa"])
    lo = np.asarray(domain["input_min"], dtype=float)
    hi = np.asarray(domain["input_max"], dtype=float)

    for t, measured in zip(wb_times, wb_values):
        stages["wideband_updates"] += 1
        measured = float(measured)
        if not (0.5505 < measured < 1.9995):
            continue
        stages["endpoint_valid"] += 1

        state_t = int(t) - int(delay_ms)
        if state_t < 0:
            continue

        state = {
            name: _latest(histories[name], state_t)
            for name in ("rpm", "map", "baro", "ect", "fa", "pe", "torque", "exhaust_cam")
        }
        if any(v is None for v in state.values()):
            continue

        rpm = float(state["rpm"])
        map_kpa = float(state["map"])
        baro = float(state["baro"])
        ect = float(state["ect"])
        fa = float(state["fa"])
        pe = float(state["pe"])
        torque = float(state["torque"])
        exhaust = float(state["exhaust_cam"])

        if not (rpm > 1000 and ect > 73.3333333333 and baro > 0 and torque > 1.35582):
            continue
        stages["warm_loaded"] += 1
        if fa <= 0:
            continue
        stages["fa_enrichment_positive"] += 1
        if pe <= 0:
            continue
        stages["fa_power_enrichment_positive"] += 1
        stages["dual_gate_pass"] += 1

        commanded = stoich_far / (stoich_far + fa)
        if not (0.70 < commanded < 0.995):
            continue
        stages["commanded_lambda_valid"] += 1

        if intake_idx is not None:
            intake_value = _latest(histories["intake_cam"], state_t)
            if intake_value is None:
                continue
            intake = float(intake_value)
            cam_source = "logged_intake_and_exhaust"
        else:
            intake = 2.0 * lsa - exhaust
            cam_source = "derived_intake_from_training_lsa"

        if not (lo[0] <= intake <= hi[0] and lo[1] <= exhaust <= hi[1]):
            continue
        stages["cam_valid"] += 1

        pratio = map_kpa / baro
        full = (measured / commanded - 1.0) * 100.0
        row = {
            "wb_timestamp_ms": int(t),
            "state_timestamp_ms": int(state_t),
            "rpm": rpm,
            "pratio": pratio,
            "intake_cam": intake,
            "exhaust_cam": exhaust,
            "measured_lambda": measured,
            "commanded_lambda": commanded,
            "fa_enrichment": fa,
            "fa_power_enrichment": pe,
            "full_correction_pct": full,
            "applied_correction_pct": float(correction_fraction) * full,
        }

        if (
            rpm < rpm_axis[0] or rpm > rpm_axis[-1] or
            pratio < pr_axis[0] or pratio > pr_axis[-1]
        ):
            stages["outside_nn_domain"] += 1
            outside.append(row)
            continue

        stages["inside_nn_domain"] += 1
        r = _nearest_index(pr_bins, pratio)
        c = _nearest_index(rpm_axis, rpm)
        row.update({"row": r, "column": c})
        accepted.append(row)

    stages["accepted"] = len(accepted)

    counts = np.zeros((20, 20), dtype=int)
    sum_full = np.zeros((20, 20), dtype=float)
    sum_intake = np.zeros((20, 20), dtype=float)
    sum_exhaust = np.zeros((20, 20), dtype=float)

    for row in accepted:
        r, c = row["row"], row["column"]
        counts[r, c] += 1
        sum_full[r, c] += row["full_correction_pct"]
        sum_intake[r, c] += row["intake_cam"]
        sum_exhaust[r, c] += row["exhaust_cam"]

    qualifying = counts >= int(min_hits)
    full_map = np.full((20, 20), np.nan, dtype=float)
    applied_map = np.full((20, 20), np.nan, dtype=float)
    pair_map = np.full((20, 20), -1, dtype=int)
    avg_intake = np.full((20, 20), np.nan, dtype=float)
    avg_exhaust = np.full((20, 20), np.nan, dtype=float)

    targets: List[dict] = []
    for r, c in zip(*np.where(qualifying)):
        full = sum_full[r, c] / counts[r, c]
        inc = sum_intake[r, c] / counts[r, c]
        exc = sum_exhaust[r, c] / counts[r, c]
        spans = hi[:2] - lo[:2]
        distances = np.sum(((cam_pairs - np.array([inc, exc])) / spans) ** 2, axis=1)
        pair = int(np.argmin(distances))

        full_map[r, c] = full
        applied_map[r, c] = float(correction_fraction) * full
        pair_map[r, c] = pair
        avg_intake[r, c] = inc
        avg_exhaust[r, c] = exc
        targets.append({
            "row": int(r),
            "column": int(c),
            "cell_index": int(r * 20 + c),
            "hits": int(counts[r, c]),
            "full_correction_pct": float(full),
            "applied_correction_pct": float(correction_fraction) * float(full),
            "average_intake_cam": float(inc),
            "average_exhaust_cam": float(exc),
            "reference_pair_index": pair,
            "reference_intake_cam": float(cam_pairs[pair, 0]),
            "reference_exhaust_cam": float(cam_pairs[pair, 1]),
            "rpm": float(rpm_axis[c]),
            "pratio": float(pr_axis[r]),
        })

    return {
        "wideband_version": VERSION,
        "airflow_model": "neural_network",
        "pe_table_axis": (_pe_table_axis_status(tune_path).get("value") or "Not stored"),
        "source_sha256": decoded["source_sha256"],
        "decoder_version": decoded["decoder_version"],
        "stoich_far": stoich_far,
        "stoich_inference_points": stoich_points,
        "delay_ms": int(delay_ms),
        "minimum_hits": int(min_hits),
        "correction_fraction": float(correction_fraction),
        "cam_source": (
            "logged_intake_and_exhaust"
            if intake_idx is not None
            else "derived_intake_from_training_lsa"
        ),
        "rpm_axis": rpm_axis,
        "pratio_axis": pr_axis,
        "cam_pairs": cam_pairs,
        "hit_counts": counts,
        "full_correction_pct": full_map,
        "applied_correction_pct": applied_map,
        "reference_pair_index": pair_map,
        "average_intake_cam": avg_intake,
        "average_exhaust_cam": avg_exhaust,
        "qualifying": qualifying,
        "qualifying_cell_count": int(np.count_nonzero(qualifying)),
        "targets": targets,
        "accepted_samples": accepted,
        "outside_domain_samples": outside,
        "stages": stages,
    }


def _build_nn_solver_rows(tune_path: Path, analysis: dict):
    if analysis.get("airflow_model") != "neural_network":
        raise ValueError("Analysis is not Neural Network wideband data")

    net = htt.load_network(tune_path)
    domain = processing.model_domain(net)
    rpm_axis = np.asarray(domain["rpms"], dtype=float)
    pr_axis = np.asarray(domain["pratios"], dtype=float)
    cam_pairs = np.asarray(domain["cam_pairs"], dtype=float)

    if not np.array_equal(rpm_axis, np.asarray(analysis["rpm_axis"], dtype=float)):
        raise ValueError("Wideband NN RPM axis no longer matches the tune")
    if not np.array_equal(pr_axis, np.asarray(analysis["pratio_axis"], dtype=float)):
        raise ValueError("Wideband NN PRatio axis no longer matches the tune")

    target_lookup = {
        (int(t["reference_pair_index"]), int(t["row"]), int(t["column"])): t
        for t in analysis.get("targets", [])
    }

    model = processing.FrozenModel(processing.config(net))
    p0 = processing.coefficients(net)
    rows: List[dict] = []

    for pair, (inc, exc) in enumerate(cam_pairs):
        for r, pr in enumerate(pr_axis):
            for c, rpm in enumerate(rpm_axis):
                target = target_lookup.get((pair, r, c))
                covered = target is not None
                full = float(target["full_correction_pct"]) if covered else None
                hits = int(target["hits"]) if covered else 0
                rows.append({
                    "pair": pair + 1,
                    "row": r,
                    "column": c,
                    "rpm": float(rpm),
                    "pratio": float(pr),
                    "intake": float(inc),
                    "exhaust": float(exc),
                    "n1": hits,
                    "n2": 0,
                    "total1": full,
                    "total2": None,
                    "eligible_bank1": covered,
                    "eligible_bank2": False,
                    "covered": covered,
                    "full_correction": full,
                    "correction": (
                        float(analysis["correction_fraction"]) * full
                        if covered else None
                    ),
                })

    x = model.normalize(np.array([
        [row["intake"], row["exhaust"], row["rpm"], row["pratio"]]
        for row in rows
    ]))
    stock = model.forward(p0, x)

    for row, value in zip(rows, stock):
        row["stock"] = float(value)
        row["target"] = (
            float(value * (1.0 + row["correction"] / 100.0))
            if row["covered"] else float(value)
        )

    return rows, model, p0, x


def fit_neural_network_candidate(
    tune_path: Path,
    analysis: dict,
    output_path: Path,
    *,
    progress=None,
) -> dict:
    """Fit/export one verified Neural Network wideband candidate.

    The standard quantized all-layer solver is reused. Wideband qualification
    is represented as one engine-level pseudo-bank solely to retain the proven
    numerical fit and exact coefficient checks. Post-fit wideband checks reject
    any target that reverses direction or moves beyond the measured 100% error.
    """
    tune_path = Path(tune_path)
    output_path = Path(output_path)
    if detect_airflow_model(tune_path) != "neural_network":
        raise ValueError("NN wideband candidate requested for a Speed Density tune")
    if not analysis.get("targets"):
        raise processing.NoQualifyingCells(
            "No wideband RPM/PRatio cells meet the minimum hit requirement inside the NN domain."
        )

    rows, model, p0, x = _build_nn_solver_rows(tune_path, analysis)
    result = processing.fit(rows, model, p0, x, progress)
    processing.require_verified_result(result)

    covered = [row for row in result["rows"] if row["covered"]]
    reverse = 0
    overshoot = 0
    no_movement = 0
    achieved_rows = []

    for row in covered:
        if row["stock"] <= 0:
            raise ValueError("Qualifying NN wideband target has non-positive stock VE")
        achieved = 100.0 * (row["fitted"] - row["stock"]) / row["stock"]
        full = float(row["full_correction"])
        if full * achieved < -1e-10:
            reverse += 1
        if full > 0 and achieved > full + 1e-10:
            overshoot += 1
        elif full < 0 and achieved < full - 1e-10:
            overshoot += 1
        if abs(achieved) <= 1e-12:
            no_movement += 1
        achieved_rows.append({
            "pair": int(row["pair"]),
            "row": int(row["row"]),
            "column": int(row["column"]),
            "rpm": float(row["rpm"]),
            "pratio": float(row["pratio"]),
            "stock_ve": float(row["stock"]),
            "target_ve": float(row["target"]),
            "fitted_ve": float(row["fitted"]),
            "full_correction_pct": full,
            "requested_correction_pct": float(row["correction"]),
            "achieved_correction_pct": float(achieved),
            "remaining_error_pct": float(full - achieved),
        })

    if reverse:
        raise ValueError(f"NN wideband candidate reversed {reverse} qualifying target(s)")
    if overshoot:
        raise ValueError(f"NN wideband candidate overshot {overshoot} qualifying full-error limit(s)")

    candidate = processing.network(np.asarray(result["candidate_coefficients"], dtype=float))
    htt.write_candidate(tune_path, output_path, candidate)

    exported = htt.load_network(output_path)
    if processing.coefficients(exported).tolist() != result["candidate_coefficients"]:
        raise ValueError("NN wideband candidate coefficient round-trip failed")
    check = model.forward(processing.coefficients(exported), x)
    if not np.array_equal(check, np.array([row["fitted"] for row in result["rows"]])):
        raise ValueError("NN wideband candidate VE round-trip failed")

    baseline = htt.load_network(tune_path)
    changes = {
        key: int(np.count_nonzero(
            np.asarray(baseline[key], dtype=float) != np.asarray(exported[key], dtype=float)
        ))
        for key in ("W1", "b1", "W2", "b2", "Wo", "bo")
    }

    result["wideband"] = {
        "method": "wideband-nn-half-step-0.1-dev",
        "airflow_model": "neural_network",
        "source_sha256": analysis.get("source_sha256"),
        "delay_ms": int(analysis.get("delay_ms", 0)),
        "minimum_hits": int(analysis.get("minimum_hits", MIN_HITS)),
        "correction_fraction": float(analysis.get("correction_fraction", CORRECTION_FRACTION)),
        "qualifying_cells": int(analysis.get("qualifying_cell_count", len(covered))),
        "qualifying_nn_targets": len(covered),
        "reverse_targets": reverse,
        "overshoot_targets": overshoot,
        "zero_movement_targets": no_movement,
        "achieved_targets": achieved_rows,
        "coefficient_changes": changes,
        "status": "development_not_frozen",
    }
    return result


def analyze_wideband(
    hpl_path: Path,
    tune_path: Path,
    *,
    delay_ms: int = 60,
    min_hits: int = MIN_HITS,
    correction_fraction: float = CORRECTION_FRACTION,
) -> dict:
    """Route wideband processing from the tune's active airflow model."""
    model = detect_airflow_model(tune_path)
    if model == "speed_density":
        return analyze_speed_density(
            hpl_path, tune_path, delay_ms=delay_ms, min_hits=min_hits,
            correction_fraction=correction_fraction,
        )
    return analyze_neural_network(
        hpl_path, tune_path, delay_ms=delay_ms, min_hits=min_hits,
        correction_fraction=correction_fraction,
    )


def export_wideband_candidate(
    tune_path: Path,
    analysis: dict,
    output_path: Path,
    *,
    progress=None,
) -> dict:
    """Route wideband export to SD tables or the NN all-layer solver."""
    model = analysis.get("airflow_model")
    if model == "speed_density":
        return export_speed_density_candidate(tune_path, analysis, output_path)
    if model == "neural_network":
        return fit_neural_network_candidate(
            tune_path, analysis, output_path, progress=progress
        )
    raise ValueError(f"Unsupported wideband airflow model: {model!r}")

def detect_configuration(tune_path: Path) -> dict:
    status = _airflow_model_switch_status(Path(tune_path))
    pe_status = _pe_table_axis_status(Path(tune_path))
    model = str(status["airflow_model"])
    return {
        "airflow_model": model,
        "use_neural_network": status.get("use_neural_network"),
        "airflow_model_detection": status.get("detection_source"),
        "airflow_model_warning": status.get("warning"),
        "pe_table_axis": pe_status.get("value") or "Not stored",
        "pe_table_axis_present": bool(pe_status.get("present")),
        "pe_table_axis_detection": pe_status.get("detection_source"),
        "pe_table_axis_warning": pe_status.get("warning"),
        "wideband_sd_supported": model == "speed_density",
        "wideband_nn_supported": model == "neural_network",
    }
