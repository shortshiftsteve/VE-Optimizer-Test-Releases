"""Read-only composite PCM-estimated performance chart from native HPL.

Use ALL valid WOT instances across a log, including short/high-RPM tip-ins,
not one chosen dyno pull. Where WOT observations are missing, use other logged
operating points as shape constraints for clearly identified illustration.
The chart is neither a measured dyno result nor a claim of available WOT torque.

No correction, qualification, coefficient, Speed Density, or .htt code imports
this module. Synthetic chart data never enter stored performance maxima.
"""
from __future__ import annotations

from collections import defaultdict
import bisect
import math
import statistics
from pathlib import Path

from ve_optimizer_logcheck import _native, convert_value
from ve_optimizer_performance import _channel_index, PAIR_MAX_AGE_MS

BIN_RPM = 100
WOT_PEDAL_PERCENT = 85.0
SUPPORT_PEDAL_PERCENT = 25.0
MIN_VALID_TORQUE_LBFT = 70.0
TIME_BUCKET_MS = 75  # avoid bias when an HPL channel repeats at high frequency
EVENT_GAP_MS = 600
MIN_PLOT_RPM = 1000
MAX_PLOT_RPM_BINS = 90
MAX_PEDAL_GAP_MS = 800
MAX_GEAR_GAP_MS = 1000


def _optional_channel(channels, names):
    for name in names:
        for idx, meta in channels.items():
            if ' '.join(str(meta.get('name', '')).lower().split()) == name:
                return idx
    return None


def _qualified_samples(decoded):
    channels = decoded['channels']
    rpm_id, rpm_meta = _channel_index(channels, 'rpm')
    torque_id, torque_meta = _channel_index(channels, 'torque')
    if rpm_id is None or torque_id is None:
        return [], '', '', False
    pedal_id = _optional_channel(channels, ('accelerator pedal effective position',
                                             'accelerator pedal position',
                                             'accelerator position d (sae)'))
    gear_id = _optional_channel(channels, ('trans current gear',))
    latest = {}
    observations = []
    for frame in decoded['frames']:
        ms = int(frame['timestamp_ms'])
        updates = frame['updates']
        for idx in (rpm_id, torque_id, pedal_id, gear_id):
            if idx is not None and idx in updates:
                latest[idx] = (ms, updates[idx])
        if rpm_id not in updates and torque_id not in updates:
            continue
        a = latest.get(rpm_id)
        b = latest.get(torque_id)
        if not a or not b or ms-a[0] > PAIR_MAX_AGE_MS or ms-b[0] > PAIR_MAX_AGE_MS:
            continue
        try:
            rpm = convert_value('rpm', rpm_meta['unit'], a[1])
            lbft = convert_value('actual_torque', torque_meta['unit'], b[1])
        except (ValueError, TypeError, OverflowError):
            continue
        if not (math.isfinite(rpm) and math.isfinite(lbft) and rpm >= 900 and lbft >= 0):
            continue
        pedal = latest.get(pedal_id)
        if pedal and ms-pedal[0] <= MAX_PEDAL_GAP_MS:
            try: pedal = float(pedal[1])
            except (TypeError, ValueError): pedal = None
            if pedal is not None and not math.isfinite(pedal): pedal = None
        else:
            pedal = None
        gear = latest.get(gear_id)
        if gear and ms-gear[0] <= MAX_GEAR_GAP_MS:
            gear = str(gear[1]).strip().upper()
            if gear in ('', 'P', 'N', 'R') or gear.startswith('UNKNOWN'):
                gear = None
        else:
            gear = None
        observations.append((ms, rpm, lbft, pedal, gear))
    return observations, rpm_meta['name'], torque_meta['name'], pedal_id is not None


def _robust_upper(samples):
    """Upper-middle time-bucket torque, not an instantaneous shift spike.

    Repeated updates of the same RPM/torque pair must not multiply the weight
    of a single observation. This is an illustration, NOT a calibrated WOT
    model, and raw logged peaks are retained independently by performance.py.
    """
    by_time = defaultdict(list)
    for ms, torque, _event in samples:
        by_time[int(ms)//TIME_BUCKET_MS].append(float(torque))
    values = sorted(statistics.median(v) for v in by_time.values())
    if not values:
        return None
    position = 0.75*(len(values)-1)
    lo = int(position)
    fraction = position-lo
    return values[lo]*(1-fraction) + values[min(lo+1,len(values)-1)]*fraction


def _bin_anchors(observations, pedal_available):
    """Pool full-log WOT events; other positive-load data are support ONLY.

    No minimum RPM sweep length: one short WOT event must remain eligible.
    Changing gear or briefly lifting the pedal starts another event, but does
    not discard its WOT measurements from the composite.
    """
    wot=defaultdict(list)
    support=defaultdict(list)
    event=0
    prior=None
    wot_times=[]
    gears=set()
    for ms,rpm,torque,pedal,gear in observations:
        if rpm < MIN_PLOT_RPM or torque < MIN_VALID_TORQUE_LBFT:
            prior=None
            continue
        x=BIN_RPM*int(math.floor(rpm/BIN_RPM+0.5))
        is_wot=bool(pedal_available and pedal is not None and pedal >= WOT_PEDAL_PERCENT)
        if is_wot:
            if (prior is None or ms-prior[0]>EVENT_GAP_MS or
                    (gear and prior[2] and gear!=prior[2]) or
                    rpm < prior[1]-max(220,prior[1]*0.05)):
                event+=1
            wot[x].append((ms,torque,event))
            wot_times.append(ms)
            if gear:gears.add(gear)
            prior=(ms,rpm,gear)
        else:
            prior=None
            # Sub-WOT events cannot be presented as measured WOT output.
            # Their time-aligned torque can constrain an illustrative estimate.
            if pedal_available:
                if pedal is not None and pedal >= SUPPORT_PEDAL_PERCENT:
                    support[x].append((ms,torque,0))
            else:
                support[x].append((ms,torque,0))
            if gear:gears.add(gear)
    wot_curve={r:_robust_upper(p) for r,p in wot.items()}
    support_curve={r:_robust_upper(p) for r,p in support.items()}
    origins={r:max(set(p[2] for p in values),key=lambda k:sum(1 for v in values if v[2]==k))
             for r,values in wot.items()}
    return wot_curve,support_curve,wot,origins,event,wot_times,gears


def _composite_curve(wot, support, wot_frames, origins):
    """Full-log WOT envelope with visually identified synthetic continuity.

    With no WOT, a partial-throttle-only plot may be shown as illustration,
    never relabeled as logged WOT. All extrapolated regions and any use of
    sub-WOT supporting observations remain synthetic and cannot enter peaks.
    """
    anchors=(dict(support) | wot) if len(wot)==1 else (wot if wot else support)
    if len(anchors)<2 or max(anchors)-min(anchors)<BIN_RPM:
        return []
    measured_rpm=sorted(wot)
    anchor_rpm=sorted(anchors)
    support_rpm=sorted(support)
    # Only extend the plotted range as far as the recorded usable engine data,
    # not to a guessed engine redline. The region before first WOT stays dashed.
    upper=max(anchor_rpm[-1],support_rpm[-1] if support_rpm else anchor_rpm[-1])
    upper=min(upper,MIN_PLOT_RPM+(MAX_PLOT_RPM_BINS-1)*BIN_RPM)
    low=MIN_PLOT_RPM
    high=max(low+BIN_RPM, min(upper, 8500))
    if anchor_rpm[0]>high:return []

    def interpolate(keys, data, rpm):
        i=bisect.bisect_left(keys,rpm)
        if i < len(keys) and keys[i]==rpm:return data[rpm]
        if 0<i<len(keys):
            l,r=keys[i-1],keys[i]
            return data[l]+(data[r]-data[l])*(rpm-l)/(r-l)
        if i==0:
            # Low-end continuation is explicitly illustrative. Do not claim
            # idle torque or full-load crankshaft capability is measured.
            ref=keys[0]
            return data[ref]*(0.65+0.35*(rpm-low)/max(1,ref-low))
        # Above last observed WOT, use restrained decay instead of projecting
        # a rising HP trend beyond the data. Any such line is dashed.
        ref=keys[-1]
        return data[ref]*max(0.65,1-0.08*(rpm-ref)/1000.0)

    curve=[]
    for rpm in range(low, high+1, BIN_RPM):
        if rpm in wot:
            torque=wot[rpm]
            kind='logged'
            event=origins[rpm]
            n=len(wot_frames[rpm])
        else:
            # Interpolation and the support floor are not logged WOT evidence.
            torque=interpolate(anchor_rpm,anchors,rpm)
            if support_rpm and wot:
                i=bisect.bisect_left(support_rpm,rpm)
                if i<len(support_rpm) and support_rpm[i]==rpm:
                    torque=max(torque,support[rpm])
            kind=('interpolated' if measured_rpm and measured_rpm[0]<rpm<measured_rpm[-1]
                  else 'illustrative')
            event=None
            n=0
        if not math.isfinite(torque) or torque<0:
            return []
        curve.append({'rpm':rpm,'torque_lbft':torque,'hp':torque*rpm/5252.0,
                      'kind':kind,'segment':event,'samples':n})
    return curve


def build_dyno_curve(path:Path)->dict:
    """Composite *display-only* all-log torque/WOT curve with provenance.

    Raw max RPM, max torque and max horsepower remain computed independently
    from native, time-matched samples in ve_optimizer_performance.
    """
    decoded=_native(Path(path))
    if decoded is None:raise ValueError('A native HP Tuners .hpl Log File is required.')
    base={'log_sha256':decoded['source_sha256'],'points':[],
          'logged_bins':0,'reconstructed_bins':0,'sweep_count':0,
          'sample_count':0,'source':'Read-only composite PCM torque × RPM / 5252'}
    samples,rpm_name,torque_name,pedal_available=_qualified_samples(decoded)
    pedal_available=bool(pedal_available and any(p[3] is not None for p in samples))
    base.update(rpm_channel=rpm_name,torque_channel=torque_name)
    if not rpm_name or not torque_name:
        return dict(base,status='unavailable',reason='Native RPM and Actual Torque channels are required.')
    if not samples:
        return dict(base,status='unavailable',reason='No fresh time-matched RPM and torque observations.')
    wot,support,wot_frames,origins,events,wot_times,gears=_bin_anchors(samples,pedal_available)
    if not wot and len(support)<2:
        return dict(base,status='unavailable',reason='Insufficient WOT/high-load RPM observations for even an illustrative curve.')
    points=_composite_curve(wot,support,wot_frames,origins)
    if not points:
        return dict(base,status='unavailable',reason='Insufficient RPM-bin coverage for a composite performance curve.')
    logged=[p for p in points if p['kind']=='logged']
    first=logged[0]['rpm'] if logged else None
    last=logged[-1]['rpm'] if logged else None
    base.update(status='ready',points=points,
                logged_bins=len(logged),reconstructed_bins=len(points)-len(logged),
                sweep_count=events,sample_count=sum(len(v) for v in wot_frames.values()),
                basis=('WOT' if logged else 'partial_load_only'),
                first_time_s=min(wot_times)/1000.0 if wot_times else None,
                last_time_s=max(wot_times)/1000.0 if wot_times else None,
                first_logged_rpm=first,last_logged_rpm=last,
                peak_logged_hp=max((p['hp'] for p in logged),default=None),
                peak_logged_torque_lbft=max((p['torque_lbft'] for p in logged),default=None),
                gears=sorted(gears))
    return base


def draw_dyno_chart(canvas, result):
    """Draw RPM/HP/lb-ft axes on native Tk Canvas; no plotting dependencies."""
    canvas.delete('all')
    w=max(580,int(canvas.winfo_width()))
    h=max(230,int(canvas.winfo_height()))
    bg='#061d32'; axes='#A9C6DC'; grid='#294761'
    hp_color='#60CDF5'; torque_color='#F2B366'; synthetic='#8C95A2'
    left,right,top,bottom=68,w-72,38,h-43
    points=result.get('points') or []
    if not points:
        canvas.create_text(w//2,h//2,text=result.get('reason','No performance curve available.'),
                           fill=axes,font=('Microsoft Sans Serif',11),width=w-45)
        return
    x_lo=min(1000, int(math.floor(points[0]['rpm']/500))*500)
    x_hi=int(math.ceil(points[-1]['rpm']/500))*500
    if x_hi<=x_lo:x_hi=x_lo+1000
    hp_max=max(p['hp'] for p in points)
    tq_max=max(p['torque_lbft'] for p in points)
    def upper(v):return max(100,100*math.ceil(v*1.07/100))
    # Both axes are HP/lb-ft and MUST have the same numeric scale so
    # HP = torque * RPM / 5252 intersects the torque curve at 5252 RPM.
    # Independent axis autoscaling makes that physically correct equality
    # appear at different heights, misleading users.
    hp_hi=tq_hi=upper(max(hp_max,tq_max))
    def xy(rpm,value,hi):return (left+(rpm-x_lo)/(x_hi-x_lo)*(right-left),
                                 bottom-value/hi*(bottom-top))
    for j in range(5):
        y=bottom-(bottom-top)*j/4
        canvas.create_line(left,y,right,y,fill=grid,width=1)
        canvas.create_text(left-10,y,text=f'{hp_hi*j/4:,.0f}',fill=hp_color,anchor='e',font=('Consolas',9))
        canvas.create_text(right+9,y,text=f'{tq_hi*j/4:,.0f}',fill=torque_color,anchor='w',font=('Consolas',9))
    for rpm in range(int(math.ceil(x_lo/1000)*1000),x_hi+1,1000):
        x=xy(rpm,0,hp_hi)[0]
        canvas.create_line(x,top,x,bottom,fill=grid)
        canvas.create_text(x,bottom+13,text=f'{rpm:,}',fill=axes,font=('Consolas',9))
    canvas.create_line(left,top,left,bottom,right,bottom,right,top,fill=axes)
    canvas.create_text(10,8,text='HP',fill=hp_color,anchor='nw',font=('Microsoft Sans Serif',9,'bold'))
    canvas.create_text(right+11,8,text='lb-ft',fill=torque_color,anchor='nw',font=('Microsoft Sans Serif',9,'bold'))
    canvas.create_text((left+right)/2,h-7,text='Engine RPM',fill=axes,
                       font=('Microsoft Sans Serif',9,'bold'))
    # A segment is solid only if BOTH endpoints are observed RPM bins.
    # All spans containing any reconstructed value are dashed and muted.
    for kind,hi,color in (('hp',hp_hi,hp_color),('torque_lbft',tq_hi,torque_color)):
        for a,b in zip(points,points[1:]):
            x1,y1=xy(a['rpm'],a[kind],hi);x2,y2=xy(b['rpm'],b[kind],hi)
            is_logged=(a['kind']=='logged' and b['kind']=='logged'
                       and a.get('segment')==b.get('segment'))
            # Keep HP blue and torque orange even over simulated RPM spans;
            # dashed strokes, rather than losing series color, signal estimates.
            canvas.create_line(x1,y1,x2,y2,fill=color,
                               width=2.6 if is_logged else 1.6,
                               dash=() if is_logged else (5,4))
    # Legend inside the chart to make reconstruction unmistakable.
    canvas.create_line(left+14,top+12,left+38,top+12,fill=hp_color,width=3)
    canvas.create_text(left+44,top+12,text='HP',anchor='w',fill=axes,font=('Microsoft Sans Serif',9))
    canvas.create_line(left+88,top+12,left+112,top+12,fill=torque_color,width=3)
    canvas.create_text(left+118,top+12,text='Torque',anchor='w',fill=axes,font=('Microsoft Sans Serif',9))
    canvas.create_line(left+205,top+12,left+231,top+12,fill=synthetic,width=2,dash=(5,4))
    canvas.create_text(left+237,top+12,text='Estimated span',anchor='w',fill=axes,font=('Microsoft Sans Serif',9))
