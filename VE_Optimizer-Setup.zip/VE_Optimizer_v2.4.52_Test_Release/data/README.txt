The application creates its local account database here. No user database is shipped.
