#!/usr/bin/env python3
from __future__ import annotations

import argparse, os, re, math, shutil, subprocess, sys, threading, json, urllib.request, urllib.parse, csv, statistics, collections, time, copy, uuid
from pathlib import Path
from typing import Dict, Optional

import ve_optimizer_processing as processing
import ve_optimizer_stage4_app as s4
import ve_optimizer_stage5_app as s5
import ve_optimizer_surface as surf
import ve_optimizer_stage3 as s3
import ve_optimizer_logcheck as logcheck
import ve_optimizer_license as licensing
import ve_optimizer_purchase as purchasing
import ve_optimizer_wideband as wideband
import ve_optimizer_wideband_integration as wideband_integration
from ve_optimizer_performance import summarize_log_performance, performance_export_stem
from ve_optimizer_dyno import build_dyno_curve, draw_dyno_chart
import ve_optimizer_channel_list as channel_list
import ve_optimizer_updates as updates
from hpl_decoder_v1_0_0 import extract_hpl_vin

APP_NAME='VE Optimizer'
APP_VERSION='2.4.52'
BUILD_ID='2.4.52-Release'
RELEASE_STAGE='Release'
EULA_VERSION='VE-EULA-1.4'
EULA_TEXT_REL=Path('legal')/'VE_EULA_1.4.txt'
EULA_PDF_REL=Path('legal')/'VE_EULA_1.4.pdf'
HELP_TEXT_REL=Path('help')/'VE_Optimizer_Help_Version_2.txt'
HELP_CONTEXT_REL=Path('help')/'VE_Optimizer_Help_Context_Map_Version_2.json'
EULA_EXPECTED_SHA='1c924f199a0d1c6f67500051dd1502e74bbbc51a23dd8ae2ae5dbc683efe1aab'
COPYRIGHT_NOTICE='Copyright © 2026 Stephen B. Schefer. All Rights Reserved.'
# Initial message is a replaceable state value, never a fixed Setup-panel label.
OPENING_EMISSIONS_WARNING=(
    'Modifying, removing, or disabling emissions-related components on vehicles driven '
    'on public roads is prohibited under federal law (Clean Air Act) and may violate '
    'local and/or state regulations. Any information shown here is intended for '
    'off-road or racing use only. Always follow all applicable laws and consult a '
    'licensed professional before performing vehicle modifications.'
)

LEGAL_CONTACT='shortshiftsteve@gmail.com'
PURCHASE_PRICE='49.99'
ENGINE_OPTIONS=('5.7L Hemi','6.2L Supercharged Hemi','6.4L Hemi')
TRANSMISSION_OPTIONS=('Auto','Manual')
MODEL_YEAR_OPTIONS=tuple(str(y) for y in range(2023,2009,-1))
MODEL_OPTIONS=('Dodge Challenger','Dodge Charger','Hellcat','Trackhawk')
DB_NAME='ve_optimizer.db'
s4.APP_NAME=s5.APP_NAME=APP_NAME
s4.APP_VERSION=s5.APP_VERSION=APP_VERSION

tk=s4.tk; ttk=s4.ttk; filedialog=s4.filedialog; messagebox=s4.messagebox

def version_closed_loop_only(version) -> bool:
    """Read the explicit closed-loop-only approval on the stored Log File."""
    if not version:return False
    try:
        stored=json.loads(str(version['log_validation_json'] or '{}'))
        report=stored.get('standard_report') or stored
        return bool(report.get('na_closed_loop_only'))
    except (ValueError,TypeError,KeyError):
        return False


CANDIDATE_HTT='Candidate1_FullEngine_Internal.htt' 
CANDIDATE_EXPORT_HTT='Candidate1_ChangesOnly.htt'
SUMMARY_FILE='Review_Summary.txt'
TECH_FILE='Technical_Details.txt'
DIAG_DIR='_Diagnostics'

# Keep enough margin below the classic Windows MAX_PATH boundary for generated
# diagnostics and temporary files. Revision 9 review does not require long-path
# support to be enabled on the review PC.
WINDOWS_PATH_BUDGET=235
OUTPUT_PATH_PROBES=(
    CANDIDATE_HTT, CANDIDATE_EXPORT_HTT, SUMMARY_FILE,
    f'{DIAG_DIR}/Baseline Conditioned Training Data.csv',
    f'{DIAG_DIR}/Baseline Accepted NN Training Data.csv',
    f'{DIAG_DIR}/VE Surfaces/Combined_Original.csv',
    'V999/' + ('P'*80) + '_V999_Result.htt',
    f'VE_Optimizer_{APP_VERSION}_Technical_Project.zip',
)

def output_path_check(folder:Path):
    base=Path(folder)
    lengths=[(str(Path(base)/rel),len(str(Path(base)/rel))) for rel in OUTPUT_PATH_PROBES]
    worst=max(lengths,key=lambda x:x[1])
    return worst[1] < WINDOWS_PATH_BUDGET, worst

def default_build_output_dir():
    # User-owned Build It exports belong with HP Tuners files, never in the
    # protected VE Optimizer project store.
    p=Path.home()/'Documents'/'HP Tuners'/'Logs and Tunes'
    p.mkdir(parents=True,exist_ok=True)
    return p

REQUIRED=('stock_nn.htt','frozen_model.json','reference_axes.json')

C={'bg':'#F3F6FA','surface':'#FFFFFF','sidebar':'#162033','side_active':'#2B3E60','accent':'#2563EB','accent2':'#1D4ED8',
   'text':'#172033','muted':'#667085','border':'#DCE3EC','success':'#15803D','success_bg':'#EAF7EE','warning':'#B45309',
   'warning_bg':'#FFF5E6','danger':'#B42318','info_bg':'#EAF2FF','soft':'#F8FAFC'}

SETUP_NAVY='#072A4A'
SETUP_NAVY_DARK='#061C31'
SETUP_BORDER='#3F80B2'
SETUP_SKY='#A7DDFC'

RUN_TRIM_RPM_AXIS=tuple(processing.RPM)  # legacy stored-version fallback only
RUN_TRIM_PR_AXIS=tuple(processing.PR_BINS)  # legacy stored-version fallback only
RUN_TRIM_COLOR_SPAN=40.0  # Display scale only; never a processing gate.

def _nearest_axis_index(value,axis):
    return min(range(len(axis)),key=lambda i:abs(float(value)-float(axis[i])))

def run_trim_chart_snapshot(conditioned_csv:Path,baseline_htt=None,domain=None):
    path=Path(conditioned_csv)
    if domain is None and baseline_htt:
        try:domain=processing.domain_from_htt(Path(baseline_htt))
        except Exception:domain=None
    if domain is None:domain={'rpms':list(RUN_TRIM_RPM_AXIS),'pr_bins':list(RUN_TRIM_PR_AXIS),'source':'legacy_reference_axes'}
    empty={'cells':{},'sample_count':0,'rpms':list(domain['rpms']),'pratios':list(domain['pr_bins']),'domain_source':domain.get('source','')}
    if not path.is_file():return empty
    samples=processing.read_samples(path);counts,totals=processing.aggregate(samples);cells={}
    for k in range(400):
        values=[totals[b][k] for b in (0,1) if counts[b,k]>=processing.MIN_HITS]
        if values:cells[(k//20,k%20)]=max(values)
    empty.update(cells=cells,sample_count=len(samples));return empty


def stored_run_trim_chart_snapshot(version):
    """Return the Run Review grid for exactly one stored project version.

    The grid must never be inherited from another project/version.  Completed
    versions use their committed Accepted CSV.  Pending review previews use the
    Accepted CSV referenced by that version's Candidate_Preview.json.
    """
    empty={'cells':{},'sample_count':0,'rpms':list(RUN_TRIM_RPM_AXIS),'pratios':list(RUN_TRIM_PR_AXIS),'domain_source':'legacy_reference_axes'}
    if not version:return empty
    try:
        try:baseline=Path(str(version['baseline_htt_path'] or ''))
        except (KeyError,IndexError,TypeError):baseline=None
        if int(version['run_completed'] or 0):
            accepted=Path(str(version['accepted_csv_path'] or ''))
            if accepted.is_file():return run_trim_chart_snapshot(accepted,baseline)
        preview=Path(str(version['preview_json_path'] or ''))
        if preview.is_file():
            payload=json.loads(preview.read_text(encoding='utf-8'))
            if payload.get('method_id')!=processing.METHOD_ID:return empty
            accepted=Path(str(payload.get('accepted_csv') or ''))
            expected=str(payload.get('accepted_sha256') or '')
            if accepted.is_file() and (not expected or s5.sha256_file(accepted)==expected):
                return run_trim_chart_snapshot(accepted,baseline)
    except (OSError,ValueError,TypeError,KeyError,json.JSONDecodeError):
        return empty
    return empty



def verify_assets(asset_dir:Path):
    missing=[n for n in REQUIRED if not (asset_dir/n).is_file()]
    if missing:raise FileNotFoundError('Package is incomplete. Missing: '+', '.join(missing))
    manifest=Path(asset_dir).parent/'RUNTIME_ASSETS.json'
    if not manifest.is_file():raise FileNotFoundError('Runtime asset manifest is missing')
    for name,digest in json.loads(manifest.read_text()).items():
        if s5.sha256_file(Path(asset_dir)/name)!=digest:raise ValueError(f'Runtime asset integrity check failed: {name}')


def verify_legal(app_dir:Path):
    app_dir=Path(app_dir)
    txt=app_dir/EULA_TEXT_REL; pdf=app_dir/EULA_PDF_REL
    missing=[str(x.relative_to(app_dir)) for x in (txt,pdf) if not x.is_file()]
    if missing:raise FileNotFoundError('Package is incomplete. Missing legal file(s): '+', '.join(missing))
    actual=s5.sha256_file(txt)
    if actual!=EULA_EXPECTED_SHA:raise ValueError('EULA text integrity check failed.')
    if pdf.read_bytes()[:5]!=b'%PDF-':raise ValueError('EULA PDF integrity check failed.')
    return actual

def verify_help(app_dir:Path):
    app_dir=Path(app_dir)
    txt=app_dir/HELP_TEXT_REL; ctx=app_dir/HELP_CONTEXT_REL
    missing=[str(x.relative_to(app_dir)) for x in (txt,ctx) if not x.is_file()]
    if missing:raise FileNotFoundError('Package is incomplete. Missing help file(s): '+', '.join(missing))
    data=json.loads(ctx.read_text(encoding='utf-8'))
    if not isinstance(data.get('contexts'),dict) or not data['contexts']:
        raise ValueError('Help context map is invalid or empty.')
    body=txt.read_text(encoding='utf-8',errors='replace')
    for item in data['contexts'].values():
        section=str(item.get('section') or '').strip()
        if section and f'[HELP:{section}]' not in body:
            raise ValueError(f'Help section is missing: {section}')
    return data

def verify_purchase_assets(app_dir:Path):
    app_dir=Path(app_dir);info=app_dir/'purchase'/'PURCHASE_INFO.txt'
    if not info.is_file():raise FileNotFoundError('Package is incomplete. Missing purchase information.')
    return info








def validate_hp_tuners_log(path:Path):
    path=Path(path)
    if not path.is_file():return False,'Selected Log File does not exist.'
    try:
        meta=logcheck.read_metadata(path)
        if not meta.names:return False,'Log channel metadata is missing.'
    except Exception as exc:return False,f'Unable to read HP Tuners Log File: {exc}'
    return True,''


def engine_from_displacement(value):
    try:
        disp=float(str(value).strip())
    except (TypeError,ValueError):
        return ''
    candidates=((5.7,'5.7L Hemi'),(6.2,'6.2L Supercharged Hemi'),(6.4,'6.4L Hemi'))
    nearest=min(candidates,key=lambda x:abs(x[0]-disp))
    return nearest[1] if abs(nearest[0]-disp)<=0.15 else ''


def decode_vin_optional(vin:str):
    vin=re.sub(r'[^A-Za-z0-9]','',vin or '').upper()
    if len(vin)!=17:
        raise ValueError('VIN must contain 17 characters.')
    if any(ch in vin for ch in 'IOQ'):
        raise ValueError('VIN cannot contain I, O, or Q.')
    url='https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValuesExtended/'+urllib.parse.quote(vin)+'?format=json'
    req=urllib.request.Request(url,headers={'User-Agent':'VE-Optimizer/0.0.1'})
    with urllib.request.urlopen(req,timeout=8) as r:
        payload=json.loads(r.read().decode('utf-8','replace'))
    rows=payload.get('Results') or []
    if not rows:
        raise ValueError('VIN lookup returned no vehicle data.')
    row=rows[0]
    year=str(row.get('ModelYear') or '').strip()
    make=str(row.get('Make') or '').strip()
    model=str(row.get('Model') or '').strip()
    trim=str(row.get('Trim') or '').strip()
    raw_name=' '.join(x for x in (make,model,trim) if x).strip()
    model_l=model.lower()
    # The VIN service returns the full Jeep model/trim, whereas Setup uses
    # 'Trackhawk' as its selectable Vehicle Type.  Preserve that canonical
    # Setup value so VIN autofill and manual selection share the Verify gate.
    if make.lower()=='jeep' and 'trackhawk' in f'{model} {trim}'.lower():
        name='Trackhawk'
    elif model_l=='challenger': name='Dodge Challenger'
    elif model_l=='charger': name='Dodge Charger'
    else: name=raw_name
    engine=engine_from_displacement(row.get('DisplacementL'))
    if not engine:
        # Preserve the actual decoded displacement even when it is not one
        # of the three suggested Hemi engine labels. This is display-only.
        try:
            displacement=float(row.get('DisplacementL'))
            if math.isfinite(displacement) and 0.5 <= displacement <= 15.0:
                engine=f'{displacement:g}L Engine'
        except (ValueError,TypeError):pass
    transmission_text=str(row.get('TransmissionStyle') or row.get('TransmissionType') or '').lower()
    transmission=('Manual' if 'manual' in transmission_text else
                  'Auto' if 'automatic' in transmission_text or 'auto' in transmission_text else '')
    return {'vin':vin,'model_year':year,'model_name':name,
            'engine':engine,'transmission':transmission}


class ReviewDatabase(s5.Database):
    """Project-scoped Review persistence."""
    def _init_schema(self):
        super()._init_schema()
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS project_setup (
                project_id INTEGER PRIMARY KEY,
                vin TEXT NOT NULL DEFAULT '',
                transmission TEXT NOT NULL DEFAULT 'Auto',
                log_source_path TEXT NOT NULL DEFAULT '',
                log_local_path TEXT NOT NULL DEFAULT '',
                mod_cai INTEGER NOT NULL DEFAULT 0,
                mod_headers INTEGER NOT NULL DEFAULT 0,
                mod_throttle INTEGER NOT NULL DEFAULT 0,
                mod_intake INTEGER NOT NULL DEFAULT 0,
                mod_camshaft INTEGER NOT NULL DEFAULT 0,
                lsa REAL,
                cam_ack INTEGER NOT NULL DEFAULT 0,
                throttle_ack INTEGER NOT NULL DEFAULT 0,
                intake_ack INTEGER NOT NULL DEFAULT 0,
                nn_eligible INTEGER NOT NULL DEFAULT 1,
                log_sha256 TEXT NOT NULL DEFAULT '',
                log_density_pass INTEGER NOT NULL DEFAULT 0,
                log_validation_json TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(project_id) REFERENCES projects(id)
            )
        ''')
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS user_eula_acceptance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                eula_version TEXT NOT NULL,
                username_snapshot TEXT NOT NULL DEFAULT '',
                terms_sha256 TEXT NOT NULL,
                app_version TEXT NOT NULL,
                acceptance_status TEXT NOT NULL DEFAULT 'ACCEPTED',
                previous_eula_version TEXT NOT NULL DEFAULT '',
                accepted_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id),
                UNIQUE(user_id,eula_version,terms_sha256)
            )
        ''')
        self.conn.execute('CREATE INDEX IF NOT EXISTS idx_user_eula_acceptance_user ON user_eula_acceptance(user_id,accepted_at)')
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.conn.execute("INSERT OR IGNORE INTO app_settings(key,value) VALUES('multi_user_enabled','0')")
        # A project under correction is a draft, not a permanently named project.
        # Only Apply Changes promotes it into the user's project list.
        self.conn.execute('''CREATE TABLE IF NOT EXISTS staged_projects (
            project_id INTEGER PRIMARY KEY,
            created_by INTEGER NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )''')
        self.conn.execute('''CREATE TABLE IF NOT EXISTS project_version_performance (
            project_id INTEGER NOT NULL,
            version_no INTEGER NOT NULL,
            log_sha256 TEXT NOT NULL,
            max_rpm REAL,
            max_torque_lbft REAL,
            max_hp REAL,
            rpm_samples INTEGER NOT NULL DEFAULT 0,
            torque_samples INTEGER NOT NULL DEFAULT 0,
            paired_samples INTEGER NOT NULL DEFAULT 0,
            recorded_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(project_id,version_no),
            FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
        )''')
        eula_cols={str(r[1]) for r in self.conn.execute('PRAGMA table_info(user_eula_acceptance)').fetchall()}
        if 'username_snapshot' not in eula_cols:self.conn.execute("ALTER TABLE user_eula_acceptance ADD COLUMN username_snapshot TEXT NOT NULL DEFAULT ''")
        self.conn.commit()
        self._ensure_project_setup_ack_columns()
        self._migrate_legacy_user_setup()

    def _ensure_project_setup_ack_columns(self):
        cols={str(r[1]) for r in self.conn.execute('PRAGMA table_info(project_setup)').fetchall()}
        for name in ('throttle_ack','intake_ack'):
            if name not in cols:
                self.conn.execute(f'ALTER TABLE project_setup ADD COLUMN {name} INTEGER NOT NULL DEFAULT 0')
        if 'transmission' not in cols:
            self.conn.execute("ALTER TABLE project_setup ADD COLUMN transmission TEXT NOT NULL DEFAULT 'Auto'")
        self.conn.commit()

    def _migrate_legacy_user_setup(self):
        tables={r[0] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if 'vehicle_setup' not in tables:return
        try: rows=self.conn.execute('SELECT * FROM vehicle_setup').fetchall()
        except Exception:return
        for old in rows:
            uid=old['user_id'] if 'user_id' in old.keys() else None
            if not uid:continue
            pr=self.conn.execute('SELECT id FROM projects WHERE created_by=? ORDER BY updated_at DESC,id DESC LIMIT 1',(uid,)).fetchone()
            if not pr:continue
            pid=int(pr['id'])
            if self.conn.execute('SELECT 1 FROM project_setup WHERE project_id=?',(pid,)).fetchone():continue
            keys=set(old.keys())
            def g(k,d=''):return old[k] if k in keys and old[k] is not None else d
            self.conn.execute('''INSERT OR IGNORE INTO project_setup
                (project_id,vin,transmission,log_source_path,log_local_path,mod_cai,mod_headers,mod_throttle,mod_intake,mod_camshaft,lsa,cam_ack,throttle_ack,intake_ack,nn_eligible,log_sha256,log_density_pass,log_validation_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (pid,g('vin'),'Auto',g('log_source_path'),g('log_local_path'),int(bool(g('mod_cai',0))),int(bool(g('mod_headers',0))),int(bool(g('mod_throttle',0))),int(bool(g('mod_intake',0))),int(bool(g('mod_camshaft',0))),g('lsa',None),int(bool(g('cam_ack',0))),int(bool(g('throttle_ack',0))),int(bool(g('intake_ack',0))),int(bool(g('nn_eligible',1))),g('log_sha256'),int(bool(g('log_density_pass',0))),g('log_validation_json')))
        self.conn.commit()

    def get_app_setting(self,key:str,default=''):
        row=self.conn.execute('SELECT value FROM app_settings WHERE key=?',(str(key),)).fetchone()
        return str(row['value']) if row is not None else str(default)

    def set_app_setting(self,key:str,value):
        self.conn.execute('''INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP''',(str(key),str(value)))
        self.conn.commit()

    def multi_user_enabled(self):
        return self.get_app_setting('multi_user_enabled','0').strip().lower() in ('1','true','yes','on')

    def set_multi_user_enabled(self,enabled:bool):
        self.set_app_setting('multi_user_enabled','1' if enabled else '0')

    def single_user_identity(self):
        row=self.conn.execute("SELECT * FROM users WHERE username_norm='admin' AND active=1 LIMIT 1").fetchone()
        if row is None:
            row=self.conn.execute("SELECT * FROM users WHERE active=1 ORDER BY CASE WHEN role='admin' THEN 0 ELSE 1 END,id LIMIT 1").fetchone()
        if row is None:
            raise ValueError('No active local user is available for Single User mode.')
        return s4.User(int(row['id']),str(row['username_display']),str(row['role']),str(row['first_name']),str(row['last_name']))

    def get_eula_acceptance(self,user_id:int,eula_version:str,terms_sha256:str):
        return self.conn.execute('''SELECT * FROM user_eula_acceptance
            WHERE user_id=? AND eula_version=? AND terms_sha256=? AND acceptance_status='ACCEPTED'
            ORDER BY accepted_at DESC,id DESC LIMIT 1''',(int(user_id),str(eula_version),str(terms_sha256))).fetchone()

    def has_eula_acceptance(self,user_id:int,eula_version:str,terms_sha256:str):
        return self.get_eula_acceptance(user_id,eula_version,terms_sha256) is not None

    def latest_eula_acceptance(self,user_id:int):
        return self.conn.execute('''SELECT * FROM user_eula_acceptance WHERE user_id=? AND acceptance_status='ACCEPTED'
            ORDER BY accepted_at DESC,id DESC LIMIT 1''',(int(user_id),)).fetchone()

    def record_eula_acceptance(self,user_id:int,eula_version:str,terms_sha256:str,app_version:str):
        user_row=self.get_user(int(user_id))
        if not user_row:raise ValueError('User not found.')
        existing=self.get_eula_acceptance(user_id,eula_version,terms_sha256)
        if existing:return existing
        prev=self.latest_eula_acceptance(user_id)
        previous=str(prev['eula_version']) if prev else ''
        self.conn.execute('''INSERT INTO user_eula_acceptance
            (user_id,eula_version,username_snapshot,terms_sha256,app_version,acceptance_status,previous_eula_version,accepted_at)
            VALUES(?,?,?,?,?,?,?,?)''',(int(user_id),str(eula_version),str(user_row['username_display']),str(terms_sha256),str(app_version),'ACCEPTED',previous,s5.utc_now()))
        self.conn.commit()
        return self.get_eula_acceptance(user_id,eula_version,terms_sha256)

    def list_user_projects(self,uid:int):
        return self.conn.execute('''SELECT p.*,COALESCE(s.vin,'') AS vin,COALESCE(s.log_source_path,'') AS log_source_path,COALESCE(s.log_sha256,'') AS log_sha256,COALESCE(s.log_density_pass,0) AS log_density_pass
            FROM projects p LEFT JOIN project_setup s ON s.project_id=p.id WHERE p.created_by=? AND NOT EXISTS (SELECT 1 FROM staged_projects d WHERE d.project_id=p.id) ORDER BY p.updated_at DESC,p.id DESC''',(uid,)).fetchall()

    def is_staged_project(self,pid:int)->bool:
        return self.conn.execute('SELECT 1 FROM staged_projects WHERE project_id=?',(int(pid),)).fetchone() is not None

    def create_staged_initial_project(self,uid:int,year:int,model:str,vin:str,engine:str,transmission:str,
                                      initial_htt:Path,log_source:Path,**mods):
        internal_name=f'VE_Temporary_{int(uid)}_{uuid.uuid4().hex}'
        project=self.create_initial_project(uid,internal_name,year,model,vin,engine,transmission,
                                            initial_htt,log_source,**mods)
        self.conn.execute('INSERT INTO staged_projects(project_id,created_by) VALUES(?,?)',
                          (int(project.id),int(uid)))
        self.conn.commit()
        return project

    def finalize_staged_project(self,pid:int,uid:int,project_name:str):
        """Promote a draft only at Apply Changes, preserving every stored file path.

        Existing named projects are never altered by this operation. The staged
        workspace has a temporary internal name while validation and tuning run.
        """
        self._assert_owner(pid,uid)
        if not self.is_staged_project(pid):return self.get_project(pid)
        name=self._unique_name_for_user(uid,project_name)
        if not name.strip() or name in ('.','..') or name[-1] in '. ':
            raise ValueError('Select a valid Project Name.')
        old_root=self.project_root(pid,create=False)
        if not old_root.is_dir():raise ValueError('The temporary project folder is missing.')
        original_name=self.get_project(pid).name
        original_display=str(self.get_project_setup(pid)['project_name'] or '')
        moved=False;destination=None;rewritten=[]
        try:
            # Update uncommitted metadata first to derive the accepted folder name.
            self.conn.execute('UPDATE project_setup SET project_name=? WHERE project_id=?',(name,int(pid)))
            internal_name=name
            collision=self.conn.execute('SELECT 1 FROM projects WHERE name=? AND id<>?',(name,int(pid))).fetchone()
            if collision:internal_name=f'{name} [u{int(uid)} p{int(pid)}]'
            self.conn.execute('UPDATE projects SET name=? WHERE id=?',(internal_name,int(pid)))
            destination=self.get_project_base()/self._folder_name(pid)
            if destination!=old_root:
                if destination.exists():raise ValueError(f'Project folder already exists: {destination}')
                shutil.move(str(old_root),str(destination));moved=True
            old_prefix=str(old_root);new_prefix=str(destination)
            if moved:
                # Rewrite only project-local paths (never user-selected Tune / Log paths).
                for table,columns in (
                    ('projects',('output_dir',)),
                    ('project_setup',('initial_htt_local_path','log_local_path','export_htt_path')),
                    ('project_versions',('baseline_htt_path','log_local_path','metrics_json',
                        'accepted_csv_path','result_htt_path','export_htt_path','result_txt_path',
                        'summary_path','technical_path','preview_json_path')),
                    ('project_runs',('source_path','conditioned_path','accepted_path','report_path')),
                    ('project_artifacts',('path',)),
                ):
                    for col in columns:
                        has_col=any(str(r[1])==col for r in self.conn.execute(f'PRAGMA table_info({table})'))
                        if not has_col:continue
                        rows=self.conn.execute(f'SELECT rowid AS rid,{col} AS val FROM {table} WHERE '+('id=?' if table=='projects' else 'project_id=?'),(int(pid),)).fetchall()
                        for row in rows:
                            value=str(row['val'] or '')
                            if value==old_prefix or value.startswith(old_prefix+os.sep):
                                self.conn.execute(f'UPDATE {table} SET {col}=? WHERE rowid=?',
                                                  (new_prefix+value[len(old_prefix):],int(row['rid'])))
                # Preview/metrics JSON can contain paths to the same project files.
                # Updating only JSON values leaves all verified .htt/.hpl/.csv bytes intact.
                def shift(obj):
                    if isinstance(obj,str) and (obj==old_prefix or obj.startswith(old_prefix+os.sep)):
                        return new_prefix+obj[len(old_prefix):]
                    if isinstance(obj,list):return [shift(x) for x in obj]
                    if isinstance(obj,dict):return {k:shift(v) for k,v in obj.items()}
                    return obj
                for filename in destination.rglob('*.json'):
                    try:
                        original=filename.read_text(encoding='utf-8')
                        doc=json.loads(original)
                    except (OSError,ValueError,UnicodeError):continue
                    shifted=shift(doc)
                    if shifted!=doc:
                        rewritten.append((filename,original))
                        filename.write_text(json.dumps(shifted,indent=2,ensure_ascii=False),encoding='utf-8')
            self.conn.execute('UPDATE projects SET output_dir=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                              (str(destination),int(pid)))
            self.conn.execute('DELETE FROM staged_projects WHERE project_id=?',(int(pid),))
            self.conn.commit()
            self.record_event(pid,'PROJECT_NAMED',f'Temporary project finalized as {name}.',uid)
            return self.get_project(pid)
        except Exception:
            self.conn.rollback()
            for filename,original in reversed(rewritten):
                try:filename.write_text(original,encoding='utf-8')
                except OSError:pass
            if moved and destination is not None and destination.exists() and not old_root.exists():
                try:shutil.move(str(destination),str(old_root))
                except OSError:pass
            raise

    def record_version_performance(self,pid:int,version_no:int,uid:int):
        """Record measured log peaks separately; never alter calibration or result.

        A V1 successor reads this from its own new HPL. The V0 record is retained
        for comparison. Replaced logs invalidate the cached result by SHA-256.
        """
        self._assert_owner(pid,uid)
        v=self.get_version(pid,version_no)
        if not v:raise ValueError('Project version not found.')
        source=Path(str(v['log_local_path'] or ''))
        if not source.is_file():return None
        expected=str(v['log_sha256'] or '').lower()
        existing=self.get_version_performance(pid,version_no)
        if existing:return existing
        measured=summarize_log_performance(source)
        if expected and measured['log_sha256'].lower()!=expected:
            raise ValueError('Log identity mismatch while reading performance information.')
        self.conn.execute('''INSERT INTO project_version_performance
            (project_id,version_no,log_sha256,max_rpm,max_torque_lbft,max_hp,
             rpm_samples,torque_samples,paired_samples)
            VALUES(?,?,?,?,?,?,?,?,?)
            ON CONFLICT(project_id,version_no) DO UPDATE SET
                log_sha256=excluded.log_sha256,max_rpm=excluded.max_rpm,
                max_torque_lbft=excluded.max_torque_lbft,max_hp=excluded.max_hp,
                rpm_samples=excluded.rpm_samples,torque_samples=excluded.torque_samples,
                paired_samples=excluded.paired_samples,recorded_at=CURRENT_TIMESTAMP''',
            (int(pid),int(version_no),measured['log_sha256'],measured['max_rpm'],
             measured['max_torque_lbft'],measured['max_hp'],measured['rpm_samples'],
             measured['torque_samples'],measured['paired_samples']))
        self.conn.commit()
        return self.get_version_performance(pid,version_no)

    def delete_version_suffix(self,pid,uid,start_version):
        result=super().delete_version_suffix(pid,uid,start_version)
        self.conn.execute('DELETE FROM project_version_performance WHERE project_id=? AND version_no>=?',
                          (int(pid),int(start_version)))
        self.conn.commit()
        return result

    def get_version_performance(self,pid:int,version_no:int):
        version=self.get_version(pid,version_no)
        if version is None:return None
        row=self.conn.execute('SELECT * FROM project_version_performance WHERE project_id=? AND version_no=?',
                              (int(pid),int(version_no))).fetchone()
        if row is None:return None
        actual=str(version['log_sha256'] or '').lower()
        if not actual or actual!=str(row['log_sha256'] or '').lower():return None
        return dict(row)

    def get_project_setup(self,pid:int):
        return self.conn.execute('SELECT * FROM project_setup WHERE project_id=?',(pid,)).fetchone()

    def _assert_owner(self,pid:int,uid:int):
        r=self.conn.execute('SELECT created_by FROM projects WHERE id=?',(pid,)).fetchone()
        if not r or int(r['created_by'] or 0)!=int(uid):raise ValueError('Project is not assigned to the logged-in user.')

    def _unique_project_name(self,uid:int,year:int,model:str,vin:str,pid=None):
        u=self.get_user(uid);username=(u['username_display'] if u else f'user{uid}')
        base=f"{username} | {int(year)} {model.strip()}"+(f" | {vin.strip().upper()}" if vin.strip() else '')
        name=base;n=2
        while True:
            row=self.conn.execute('SELECT id FROM projects WHERE name=?',(name,)).fetchone()
            if not row or (pid is not None and int(row['id'])==int(pid)):return name
            name=f'{base} #{n}';n+=1

    def create_project_draft(self,uid:int,year:int,model:str,vin:str='',engine:str='5.7L Hemi'):
        model=model.strip();engine=str(engine).strip()
        if not model:raise ValueError('Model Name is required.')
        if not engine:engine='Not Specified'
        name=self._unique_project_name(uid,year,model,vin)
        cur=self.conn.execute('INSERT INTO projects(name,model_year,model,engine,output_dir,created_by) VALUES(?,?,?,?,?,?)',(name,int(year),model,engine,'',int(uid)))
        self.conn.commit();return self.get_project(int(cur.lastrowid))

    def save_project_setup(self,pid:int,uid:int,vin:str,model_year:int,model_name:str,engine:str,transmission:str,log_source:Path,mod_cai=False,mod_headers=False,mod_throttle=False,mod_intake=False,mod_camshaft=False,lsa=None,cam_ack=False,throttle_ack=False,intake_ack=False,tune_path=None,na_closed_loop_only=False):
        self._assert_owner(pid,uid)
        ok,msg=validate_hp_tuners_log(log_source)
        if not ok:raise ValueError(msg)
        candidate_tune=Path(tune_path) if tune_path else None
        if candidate_tune is None and self.get_version(pid,0):
            raw=str(self.get_version(pid,0)['baseline_htt_path'] or '')
            candidate_tune=Path(raw) if raw else None
        airflow_model=(wideband.detect_airflow_model(candidate_tune)
                       if candidate_tune is not None and candidate_tune.is_file() else 'neural_network')
        standard_validation=logcheck.analyze_log(Path(log_source),airflow_model=airflow_model)
        if na_closed_loop_only:
            if candidate_tune is None or not candidate_tune.is_file():
                raise ValueError('Tune File is required for naturally aspirated closed-loop-only correction.')
            standard_validation=logcheck.approved_na_closed_loop_report(
                standard_validation,candidate_tune,Path(log_source))
        validation=standard_validation
        # Speed Density generic requirements deliberately treat Fuel Flow as
        # advisory.  Before saving the project, the actual adaptive/wideband
        # processor MUST still qualify: advisory cannot bypass a source gate.
        if airflow_model=='speed_density' or not standard_validation['passed']:
            if candidate_tune is None or not candidate_tune.is_file():
                details='\n'.join('• '+x for x in standard_validation.get('recommendations',[])[:8])
                raise ValueError('A Full Engine .htt is required to qualify the selected correction source.'+((('\n\n'+details) if details else '')))
            qualification=wideband_integration.qualify_log_for_tune(
                Path(log_source),candidate_tune,standard_validation,
                closed_loop_only=bool(na_closed_loop_only))
            if not qualification.get('passed'):
                details='\n'.join('• '+x for x in standard_validation.get('recommendations',[])[:8])
                raise ValueError('Log File failed source-specific adaptive and wideband qualification.'+((('\n\n'+details) if details else '')))
            validation=qualification
        if na_closed_loop_only and airflow_model=='neural_network':
            check=wideband_integration.qualify_log_for_tune(
                Path(log_source),candidate_tune,standard_validation,closed_loop_only=True)
            if not check.get('adaptive_ready'):
                raise ValueError('No qualifying zero-enrichment fuel-trim observations remain for closed-loop-only correction.')
        model_name=str(model_name).strip();year=int(model_year);vin=vin.strip().upper();engine=str(engine).strip();transmission=str(transmission).strip()
        if not model_name:raise ValueError('Model Name is required.')
        if year<1981 or year>2100:raise ValueError('Enter a valid four-digit vehicle Model Year.')
        if not engine:engine='Not Specified'
        if transmission not in TRANSMISSION_OPTIONS:raise ValueError('Select Transmission: Auto or Manual.')
        cam=bool(mod_camshaft);ack=bool(cam_ack);thr=bool(mod_throttle);inta=bool(mod_intake);thr_ack=bool(throttle_ack);intake_ack=bool(intake_ack);lsa_value=None;eligible=True
        if thr and not thr_ack:
            raise ValueError('Throttle Body airflow-only scope acknowledgement is required.')
        if inta and not intake_ack:
            raise ValueError('Intake Manifold airflow-only scope acknowledgement is required.')
        if cam:
            if lsa not in (None,''):
                try:lsa_value=float(lsa)
                except (TypeError,ValueError):raise ValueError('Camshaft LSA must be numeric when entered.')
            # LSA is optional project metadata. It is not an NN eligibility gate;
            # live Intake/Exhaust Cam Center Position values are continuous NN inputs.
            eligible=True
            if not ack:raise ValueError('Camshaft airflow-only scope acknowledgement is required.')
        prev=self.get_project_setup(pid);prev_hash=str(prev['log_sha256'] or '') if prev else ''
        prev_signature=None
        if prev:
            p0=self.get_project(pid);prev_signature=(p0.model_year,p0.model,p0.engine,str(prev['transmission'] or 'Auto'),str(prev['vin'] or ''),int(prev['mod_cai']),int(prev['mod_headers']),int(prev['mod_throttle']),int(prev['mod_intake']),int(prev['mod_camshaft']),prev['lsa'],int(prev['cam_ack']),int(prev['throttle_ack']),int(prev['intake_ack']))
        log_hash=s5.sha256_file(Path(log_source));validation_json=json.dumps(validation,separators=(',',':'))
        store=self.path.parent/'current_logs';store.mkdir(parents=True,exist_ok=True);local=store/f'project_{pid}_current_log.hpl'
        replacing_log=bool(prev_hash and prev_hash!=log_hash)
        if replacing_log and local.is_file():
            local.unlink()
        shutil.copy2(log_source,local)
        self.conn.execute('''INSERT INTO project_setup(project_id,vin,transmission,log_source_path,log_local_path,mod_cai,mod_headers,mod_throttle,mod_intake,mod_camshaft,lsa,cam_ack,throttle_ack,intake_ack,nn_eligible,log_sha256,log_density_pass,log_validation_json,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
            ON CONFLICT(project_id) DO UPDATE SET vin=excluded.vin,transmission=excluded.transmission,log_source_path=excluded.log_source_path,log_local_path=excluded.log_local_path,mod_cai=excluded.mod_cai,mod_headers=excluded.mod_headers,mod_throttle=excluded.mod_throttle,mod_intake=excluded.mod_intake,mod_camshaft=excluded.mod_camshaft,lsa=excluded.lsa,cam_ack=excluded.cam_ack,throttle_ack=excluded.throttle_ack,intake_ack=excluded.intake_ack,nn_eligible=excluded.nn_eligible,log_sha256=excluded.log_sha256,log_density_pass=excluded.log_density_pass,log_validation_json=excluded.log_validation_json,updated_at=CURRENT_TIMESTAMP''',(pid,vin,transmission,str(log_source),str(local),int(bool(mod_cai)),int(bool(mod_headers)),int(bool(mod_throttle)),int(bool(mod_intake)),int(cam),lsa_value,int(ack),int(thr_ack),int(intake_ack),int(eligible),log_hash,1,validation_json))
        name=self._unique_project_name(uid,year,model_name,vin,pid);self.conn.execute('UPDATE projects SET name=?,model_year=?,model=?,engine=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(name,year,model_name,engine,pid));self.conn.commit()
        new_signature=(year,model_name,engine,transmission,vin,int(bool(mod_cai)),int(bool(mod_headers)),int(bool(mod_throttle)),int(bool(mod_intake)),int(cam),lsa_value,int(ack),int(thr_ack),int(intake_ack))
        if replacing_log or (prev_signature is not None and prev_signature!=new_signature):self.invalidate_project_results(pid,'Project Setup or current Log File changed.')
        if replacing_log:
            try:self.record_event(pid,'PROJECT_LOG_REPLACED',f'Current project Log File replaced with {Path(log_source).name}; SHA-256 {log_hash}',uid)
            except Exception:pass
        return self.get_project_setup(pid)

    def project_setup_complete(self,pid:int):
        p=self.get_project(pid);r=self.get_project_setup(pid)
        if not p or not r:return False
        if not p.model_year or not str(p.model).strip():return False
        if str(r['transmission'] or '') not in TRANSMISSION_OPTIONS:return False
        if not Path(r['log_local_path']).is_file() or not r['log_density_pass']:return False
        if r['mod_throttle'] and not r['throttle_ack']:return False
        if r['mod_intake'] and not r['intake_ack']:return False
        if r['mod_camshaft'] and not r['cam_ack']:return False
        return True

    def invalidate_project_results(self,pid:int,reason='Project input changed.'):
        p=self.get_project(pid);self.conn.execute('UPDATE projects SET baseline_trim_mae=NULL,baseline_trim_median=NULL,stage3_candidate_applied=0,updated_at=CURRENT_TIMESTAMP WHERE id=?',(pid,));self.conn.commit()
        if p and p.output_dir:
            out=Path(p.output_dir)
            for rel in (CANDIDATE_HTT,CANDIDATE_EXPORT_HTT,SUMMARY_FILE,f'{DIAG_DIR}/Current_Log_Metrics.json',f'{DIAG_DIR}/Baseline Conditioned Training Data.csv',f'{DIAG_DIR}/Baseline Accepted NN Training Data.csv'):
                q=out/rel
                try:
                    if q.is_file():q.unlink()
                except Exception:pass
        try:self.record_event(pid,'PROJECT_RESULTS_INVALIDATED',reason,None)
        except Exception:pass

    def set_output(self,pid:int,uid:int,path:Path):
        self._assert_owner(pid,uid);norm=os.path.normcase(os.path.abspath(str(path)))
        rows=self.conn.execute("SELECT id,output_dir FROM projects WHERE id<>? AND output_dir<>''",(pid,)).fetchall()
        for r in rows:
            if os.path.normcase(os.path.abspath(str(r['output_dir'])))==norm:raise ValueError('That output folder is already assigned to another VE Optimizer project. Choose a separate folder to keep projects isolated.')
        self.conn.execute('UPDATE projects SET output_dir=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(str(path),pid));self.conn.commit()

    def project_state(self,pid:int):
        return {'state':'SETUP_REQUIRED','next':'Complete project setup.'}

def write_summary(project,result,metrics,out:Path,transmission=''):
    p=out/SUMMARY_FILE
    p.write_text('\n'.join([
        f'VE Optimizer {APP_VERSION}',f'Vehicle: {project.model_year} {project.model} {project.engine} / {transmission}',
        '', 'Method: accepted v0.1.5',
        'Bank LTFT + STFT arithmetic means; MAX of qualifying bank totals; Results applies the selected displayed correction.',
        'At least 5 hits per bank and cell. Weights and biases fit the full VE surface.',
        '', f"Qualifying cells: {metrics['qualifying_cells']}",
        f"Qualifying bank entries: {metrics['qualifying_bank_entries']}",
        f"Target VE mean absolute error: {metrics['target_mae']:.6f} points",
        f"Qualifying-bank trim MAE estimate: {metrics['bank_mae_before']:.4f}% -> {metrics['bank_mae_after']:.4f}%",
        f"Qualifying banks with adverse estimated movement: {metrics['qualifying_bank_issues']}",
        f"Existing positive bank entries improved / unchanged: {metrics['positive_bank_improved']} / {metrics['positive_bank_unchanged']}",
        '', 'Positive residuals may remain after the selected correction. The next measured log determines the next correction.',
        'Closed-loop assessment only. The VE table also remains active in open loop and WOT; those fueling modes have not been assessed.',
        'After-values are estimates. Vehicle validation is pending.'
    ])+'\n',encoding='utf-8')
    return p


def write_technical(project,result,metrics,out:Path,asset_dir:Path,source_log:Path,transmission=''):
    d=out/DIAG_DIR;d.mkdir(exist_ok=True);p=d/TECH_FILE
    details={'app_version':APP_VERSION,'method_id':processing.METHOD_ID,'source_log_sha256':s5.sha256_file(source_log),'metrics':metrics,'preparation':result.get('preparation',{}),'input_and_project_workflow':'retained','vehicle_validation':'pending'}
    p.write_text(json.dumps(details,indent=2)+'\n',encoding='utf-8');return p


def _package_preview_level(project,result,model,x,level_out,pct,baseline,assets,source,transmission):
    processing.require_verified_result(result)
    level_out=Path(level_out);level_out.mkdir(parents=True,exist_ok=True)
    m=result['metrics'];m['nn_architecture']=s3.architecture_summary(baseline);m['application_percent']=float(pct)
    try:result['settings']['correction_fraction']=float(pct)/100.0
    except Exception:pass
    cand=level_out/CANDIDATE_HTT
    s3.write_candidate(baseline,cand,processing.network(processing.np.array(result['candidate_coefficients'])))
    if processing.coefficients(s3.load_network(cand)).tolist()!=result['candidate_coefficients']:raise ValueError('Candidate coefficients failed export verification')
    check=model.forward(processing.coefficients(s3.load_network(cand)),x)
    if check.tolist()!=[r['fitted'] for r in result['rows']]:raise ValueError('Exported candidate VE failed exact verification')
    bn=s3.load_network(baseline);cn=s3.load_network(cand)
    m['changes']={k:int(processing.np.count_nonzero(processing.np.array(bn[k])!=processing.np.array(cn[k]))) for k in ('W1','b1','W2','b2','Wo','bo')}
    export=level_out/CANDIDATE_EXPORT_HTT
    s3.write_changed_nn_template(baseline,cand,export,carrier_htt=assets/'stock_nn.htt')
    summary=write_summary(project,result,m,level_out,transmission)
    technical=write_technical(project,result,m,level_out,assets,source)
    detail=level_out/'Processing_Result.json';detail.write_text(json.dumps(result,indent=2,allow_nan=False))
    mp=level_out/'Metrics.json';mp.write_text(json.dumps(m,indent=2))
    level={'percent':pct,'candidate_htt':str(cand),'export_htt':str(export),'summary':str(summary),'technical':str(technical),'metrics_json':str(mp),'processing_result':str(detail)}
    level['hashes']={k:s5.sha256_file(Path(level[k])) for k in ('candidate_htt','export_htt','summary','technical','metrics_json','processing_result')}
    return level,m


def generate_reduced_preview(db,pid,uid,version_no,assets,progress=None):
    """Build the optional Results-level half reduction only when the user asks for it."""
    db._assert_owner(pid,uid);project=db.get_project(pid);v=db.get_version(pid,version_no)
    if not v or int(v['run_completed'] or 0):raise ValueError('This version cannot prepare another preview.')
    preview_path=Path(str(v['preview_json_path'] or ''))
    payload=json.loads(preview_path.read_text())
    method=payload.get('method_id')
    if wideband_integration.is_wideband_method(method):
        level=wideband_integration.generate_reduced_extended_preview(payload,preview_path.parent,progress=progress)
        tmp=preview_path.with_suffix(preview_path.suffix+'.tmp');tmp.write_text(json.dumps(payload,indent=2));tmp.replace(preview_path)
        db.record_event(pid,'REDUCED_PREVIEW_READY',f'V{int(version_no)}; {method}; Results reduction prepared',uid)
        return level
    if method!=processing.METHOD_ID:raise ValueError('Rerun with the accepted processing method.')
    if '25' in payload.get('levels',{}):return payload['levels']['25']
    baseline=Path(payload['baseline_htt']);accepted=Path(payload['accepted_csv']);source=Path(v['log_local_path'])
    if s5.sha256_file(baseline)!=payload['baseline_sha256']:raise ValueError('Stored baseline failed integrity validation.')
    if s5.sha256_file(source)!=payload['log_sha256']:raise ValueError('Stored log changed; rerun the review.')
    if s5.sha256_file(accepted)!=payload['accepted_sha256']:raise ValueError('Stored bank-event inputs changed; rerun the review.')
    primary=payload.get('levels',{}).get('50')
    if not primary:raise ValueError('Primary Results preview is unavailable.')
    samples=processing.read_samples(accepted);baseline_net=s3.load_network(baseline)
    rows,model,p0,x=processing.make_targets(samples,baseline_net)
    primary_result=json.loads(Path(primary['processing_result']).read_text())
    primary_rows=primary_result['rows']
    if len(primary_rows)!=len(rows):raise ValueError('Primary Results surface is incomplete.')
    # Reduce the currently visible candidate movement by half at every displayed
    # VE cell, including incidental NN movement outside correction cells. Raw
    # 100% correction targets are never used as a Results display option.
    for row,primary_row in zip(rows,primary_rows):
        visible_target=float(row['stock']+0.5*(float(primary_row['fitted'])-float(row['stock'])))
        row['target']=visible_target
        if row['covered'] and row['stock']>0:
            row['correction']=100.0*(visible_target-row['stock'])/row['stock']
    result=processing.fit_reduced(rows,model,p0,x,primary_result['candidate_coefficients'],progress)
    result['preparation']=primary_result.get('preparation',{})
    m=result['metrics'];m['accepted']=len(samples)
    if m['qualifying_bank_issues']:raise ValueError('Reduced candidate failed qualifying-bank verification')
    level,m=_package_preview_level(project,result,model,x,preview_path.parent/'Reduced_By_Half',25,baseline,assets,source,str(db.get_project_setup(pid)['transmission'] or ''))
    payload.setdefault('levels',{})['25']=level
    tmp=preview_path.with_suffix(preview_path.suffix+'.tmp');tmp.write_text(json.dumps(payload,indent=2));tmp.replace(preview_path)
    db.record_event(pid,'REDUCED_PREVIEW_READY',f'V{int(version_no)}; {processing.METHOD_ID}; Results reduction prepared',uid)
    return level



APPLICATION_LEVELS=(50,25)

def build_it_application_gate(version, selected_percent):
    if not version or not int(version['run_completed'] or 0):return False,'Apply the reviewed candidate before using Build It.'
    mp=Path(str(version['metrics_json'] or ''))
    try:m=json.loads(mp.read_text())
    except (OSError,ValueError):return False,'Stored candidate metrics are unavailable.'
    method=m.get('method_id')
    if method==processing.METHOD_ID:
        check=m.get('fit_verification',{})
        if not (check.get('passed') and check.get('initial_success') and check.get('constrained_success') and check.get('solver_revision')==processing.SOLVER_REVISION):
            return False,'Stored candidate lacks successful numerical-solve verification. Rerun review.'
    elif wideband_integration.is_wideband_method(method):
        if not m.get('verification_passed') or not m.get('scope_verified'):
            return False,'Stored wideband candidate lacks successful verification. Rerun review.'
    else:
        return False,'This historical result uses a superseded processing method.'
    stored=int(round(float(version['application_percent'] or 0)))
    allowed=APPLICATION_LEVELS
    if stored not in allowed:return False,'Stored correction selection is unavailable.'
    if selected_percent is not None and int(selected_percent)!=stored:return False,'The displayed correction selection does not match the applied result.'
    return True,''



def apply_candidate_result(db,pid,uid,version_no,assets,selected_percent=50):
    db._assert_owner(pid,uid);v=db.get_version(pid,version_no)
    if not v or int(v['run_completed'] or 0):raise ValueError('This version already has a stored result.')
    payload=json.loads(Path(v['preview_json_path']).read_text())
    method=payload.get('method_id')
    if wideband_integration.is_wideband_method(method):
        if s5.sha256_file(Path(payload['baseline_htt']))!=payload['baseline_sha256']:raise ValueError('Stored baseline failed integrity validation.')
        if s5.sha256_file(Path(v['log_local_path']))!=payload['log_sha256']:raise ValueError('Stored log changed; rerun the review.')
        pct=int(selected_percent)
        if pct not in APPLICATION_LEVELS or str(pct) not in payload.get('levels',{}):raise ValueError('The selected correction level is unavailable.')
        metrics=wideband_integration.verify_wideband_preview_payload(payload,pct)
        level=payload['levels'][str(pct)];accepted=Path(payload['accepted_csv'])
        db.conn.execute('UPDATE project_versions SET application_percent=? WHERE project_id=? AND version_no=?',(pct,pid,version_no));db.conn.commit()
        db.commit_version_result(pid,version_no,uid,Path(level['candidate_htt']),Path(level['export_htt']),Path(level['summary']),Path(level['technical']),accepted,metrics,0.,0.)
        db.mark_candidate_applied(pid,True);db.record_event(pid,'EXTENDED_CANDIDATE_COMMITTED',f'V{version_no}; {method}; Results selection={pct}',uid)
        return {'version_no':int(version_no),'percent':pct,'metrics':metrics,'state':db.project_state(pid,version_no)}
    if method!=processing.METHOD_ID:raise ValueError('Rerun with the accepted processing method.')
    if s5.sha256_file(Path(payload['baseline_htt']))!=payload['baseline_sha256']:raise ValueError('Stored baseline failed integrity validation.')
    if s5.sha256_file(Path(v['log_local_path']))!=payload['log_sha256']:raise ValueError('Stored log changed; rerun the review.')
    pct=int(selected_percent)
    if pct not in APPLICATION_LEVELS or str(pct) not in payload.get('levels',{}):raise ValueError('The selected correction level is unavailable.')
    level=payload['levels'][str(pct)];accepted=Path(payload['accepted_csv'])
    if s5.sha256_file(accepted)!=payload['accepted_sha256']:raise ValueError('Stored bank-event inputs changed; rerun the review.')
    for key,digest in level['hashes'].items():
        if s5.sha256_file(Path(level[key]))!=digest:raise ValueError(f'Candidate artifact failed integrity validation: {key}')
    processing.require_verified_result(json.loads(Path(level['processing_result']).read_text()))
    m=json.loads(Path(level['metrics_json']).read_text())
    if m.get('method_id')!=processing.METHOD_ID or m['qualifying_bank_issues']:raise ValueError('Candidate processing verification failed')
    db.conn.execute('UPDATE project_versions SET application_percent=? WHERE project_id=? AND version_no=?',(pct,pid,version_no));db.conn.commit()
    db.commit_version_result(pid,version_no,uid,Path(level['candidate_htt']),Path(level['export_htt']),Path(level['summary']),Path(level['technical']),accepted,m,m['bank_mae_before'],0.)
    db.mark_candidate_applied(pid,True);db.record_event(pid,'ACCEPTED_CANDIDATE_COMMITTED',f'V{version_no}; {processing.METHOD_ID}; Results selection={pct}',uid)
    return {'version_no':int(version_no),'percent':pct,'metrics':m,'state':db.project_state(pid,version_no)}



def execute_review(db:ReviewDatabase,pid:int,uid:int,assets:Path,progress=None,version_no=None,chart_progress=None,conditioning_done=None,abort_check=None):
    db._assert_owner(pid,uid);p=db.get_project(pid)
    v=db.latest_version(pid) if version_no is None else db.get_version(pid,version_no)
    if not v:raise ValueError('Project version not found.')
    vn=int(v['version_no'])
    if int(v['run_completed']):raise ValueError(f'V{vn} is read-only because its results are already stored.')
    if not db.version_setup_complete(pid,vn):raise ValueError(f'Complete Setup and select a qualified Log File for V{vn}.')
    source=Path(v['log_local_path']);baseline=Path(v['baseline_htt_path'])
    if s5.sha256_file(source)!=v['log_sha256']:raise ValueError('Selected log changed after qualification.')
    if s5.sha256_file(baseline)!=v['baseline_htt_sha256']:raise ValueError('Stored tune baseline failed integrity validation.')
    db.validate_initial_htt(baseline);verify_assets(assets)
    def upd(pct,title,msg):
        if progress:progress(pct,title,msg)
    db.conn.execute('UPDATE project_versions SET preview_ready=0,preview_json_path=? WHERE project_id=? AND version_no=?',('',pid,vn));db.conn.commit()
    out=db.version_dir(pid,vn)/'_Accepted_Method_Preview';out.mkdir(parents=True,exist_ok=True)
    upd(0,'Condition selected Log File','Preparing native bank events using the accepted method.')
    baseline_net=s3.load_network(baseline);domain=processing.model_domain(baseline_net)
    samples,prep=processing.prepare_samples(source,domain,
        closed_loop_only=version_closed_loop_only(v));accepted=out/'Accepted_Bank_Events.csv';processing.write_samples(accepted,samples)
    if chart_progress:chart_progress(run_trim_chart_snapshot(accepted,baseline,domain))
    if conditioning_done:conditioning_done(accepted)
    upd(4,'Condition selected Log File',f"Prepared {len(samples):,} bank events.")

    # The primary Results view is the accepted half-step candidate. Raw 100%
    # correction targets are never exposed to the Results surface.
    rows50,model50,p050,x50=processing.make_targets(samples,baseline_net,domain)
    failure_path=out/'Fit_Failure.json';failure_path.unlink(missing_ok=True)
    try:
        result50=processing.fit(rows50,model50,p050,x50,lambda pct,msg:upd(4+pct*.76,'Fit Neural Network',msg))
    except processing.FitConvergenceError as exc:
        failure_path.write_text(json.dumps({'approved':False,'stage':exc.stage,
            'details':exc.details,'source_log_sha256':s5.sha256_file(source),
            'baseline_htt_sha256':s5.sha256_file(baseline)},indent=2))
        raise
    result50['preparation']=prep;result50['metrics']['accepted']=len(samples)
    level50,m50=_package_preview_level(p,result50,model50,x50,out,50,baseline,assets,source,str(db.get_project_setup(pid)['transmission'] or ''))
    if m50['qualifying_bank_issues']:raise ValueError('Primary candidate failed qualifying-bank verification')

    # The optional Results-level half reduction is generated lazily only if selected.

    payload={'method_id':processing.METHOD_ID,'version_no':vn,'levels':{'50':level50},'accepted_csv':str(accepted),'accepted_sha256':s5.sha256_file(accepted),'baseline_htt':str(baseline),'baseline_sha256':s5.sha256_file(baseline),'log_sha256':s5.sha256_file(source)}
    pj=out/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2))
    db.update_baseline(pid,m50['bank_mae_before'],0.)
    db.conn.execute('UPDATE project_versions SET preview_ready=1,preview_json_path=?,application_percent=0 WHERE project_id=? AND version_no=?',(str(pj),pid,vn));db.conn.commit()
    db.record_event(pid,'ACCEPTED_CANDIDATE_READY',f'V{vn}; {processing.METHOD_ID}; qualifying cells={m50["qualifying_cells"]}',uid)
    upd(100,'Write & store results','Candidate ready. Review Results, then Apply Changes and Build It.')
    return {'metrics':m50,'preview_json':pj,'preview_levels':payload['levels'],'state':db.project_state(pid,vn),'source_log':source,'version_no':vn}



def execute_adaptive_sd_review(db:ReviewDatabase,pid:int,uid:int,assets:Path,progress=None,version_no=None):
    db._assert_owner(pid,uid)
    v=db.latest_version(pid) if version_no is None else db.get_version(pid,version_no)
    if not v:raise ValueError('Project version not found.')
    vn=int(v['version_no'])
    if int(v['run_completed']):raise ValueError(f'V{vn} is read-only because its results are already stored.')
    if not db.version_setup_complete(pid,vn):raise ValueError(f'Complete Setup and select a qualified Log File for V{vn}.')
    source=Path(v['log_local_path']);baseline=Path(v['baseline_htt_path'])
    if s5.sha256_file(source)!=v['log_sha256']:raise ValueError('Selected log changed after qualification.')
    if s5.sha256_file(baseline)!=v['baseline_htt_sha256']:raise ValueError('Stored tune baseline failed integrity validation.')
    def upd(pct,title,msg):
        if progress:progress(pct,title,msg)
    out=db.version_dir(pid,vn)/'_Adaptive_SD_Preview'
    if out.exists():shutil.rmtree(out,ignore_errors=True)
    out.mkdir(parents=True,exist_ok=True)
    built=wideband_integration.build_adaptive_speed_density_preview(
        baseline,source,out,progress=upd,closed_loop_only=version_closed_loop_only(v))
    payload=dict(built['payload']);payload['version_no']=vn;pj=out/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    metrics=built['metrics'];db.conn.execute('UPDATE project_versions SET preview_ready=1,preview_json_path=?,application_percent=0 WHERE project_id=? AND version_no=?',(str(pj),pid,vn));db.conn.commit();db.record_event(pid,'ADAPTIVE_SD_CANDIDATE_READY',f"V{vn}; qualifying cells={metrics['qualifying_cells']}; trim mode={metrics.get('trim_mode')}",uid)
    upd(100,'Write & store results','Speed Density trim candidate ready. Review Results, then Apply Changes and Build It.')
    return {'metrics':metrics,'preview_json':pj,'preview_levels':payload['levels'],'state':db.project_state(pid,vn),'source_log':source,'version_no':vn}


def execute_wideband_review(db:ReviewDatabase,pid:int,uid:int,assets:Path,progress=None,version_no=None,rescale_approved=False,delay_ms=60):
    db._assert_owner(pid,uid)
    v=db.latest_version(pid) if version_no is None else db.get_version(pid,version_no)
    if not v:raise ValueError('Project version not found.')
    vn=int(v['version_no'])
    if version_closed_loop_only(v):
        raise ValueError('Wideband and PE correction cannot run under the approved closed-loop-only exception.')
    if int(v['run_completed']):raise ValueError(f'V{vn} is read-only because its results are already stored.')
    if not db.version_setup_complete(pid,vn):raise ValueError(f'Complete Setup and select a qualified Log File for V{vn}.')
    source=Path(v['log_local_path']);baseline=Path(v['baseline_htt_path'])
    if s5.sha256_file(source)!=v['log_sha256']:raise ValueError('Selected log changed after qualification.')
    if s5.sha256_file(baseline)!=v['baseline_htt_sha256']:raise ValueError('Stored tune baseline failed integrity validation.')
    db.validate_initial_htt(baseline);verify_assets(assets)
    def upd(pct,title,msg):
        if progress:progress(pct,title,msg)
    db.conn.execute('UPDATE project_versions SET preview_ready=0,preview_json_path=? WHERE project_id=? AND version_no=?',('',pid,vn));db.conn.commit()
    out=db.version_dir(pid,vn)/'_Wideband_Preview'
    if out.exists():shutil.rmtree(out,ignore_errors=True)
    out.mkdir(parents=True,exist_ok=True)
    built=wideband_integration.build_wideband_preview(
        baseline,source,out,rescale_approved=bool(rescale_approved),delay_ms=int(delay_ms),progress=upd)
    payload=dict(built['payload']);payload['version_no']=vn
    pj=out/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    metrics=built['metrics']
    db.conn.execute('UPDATE project_versions SET preview_ready=1,preview_json_path=?,application_percent=0 WHERE project_id=? AND version_no=?',(str(pj),pid,vn));db.conn.commit()
    db.record_event(pid,'WIDEBAND_CANDIDATE_READY',f"V{vn}; {metrics['method_id']}; qualifying cells={metrics['qualifying_cells']}; rescaled={int(bool(metrics.get('rescaled')))}",uid)
    upd(100,'Write & store results','Wideband candidate ready. Review Results, then Apply Changes and Build It.')
    return {'metrics':metrics,'preview_json':pj,'preview_levels':payload['levels'],'state':db.project_state(pid,vn),'source_log':source,'version_no':vn}


def execute_combined_review(db:ReviewDatabase,pid:int,uid:int,assets:Path,progress=None,version_no=None,rescale_approved=False,delay_ms=60):
    db._assert_owner(pid,uid)
    v=db.latest_version(pid) if version_no is None else db.get_version(pid,version_no)
    if not v:raise ValueError('Project version not found.')
    vn=int(v['version_no'])
    if version_closed_loop_only(v):
        raise ValueError('Wideband and PE correction cannot run under the approved closed-loop-only exception.')
    if int(v['run_completed']):raise ValueError(f'V{vn} is read-only because its results are already stored.')
    if not db.version_setup_complete(pid,vn):raise ValueError(f'Complete Setup and select a qualified Log File for V{vn}.')
    source=Path(v['log_local_path']);baseline=Path(v['baseline_htt_path'])
    if s5.sha256_file(source)!=v['log_sha256']:raise ValueError('Selected log changed after qualification.')
    if s5.sha256_file(baseline)!=v['baseline_htt_sha256']:raise ValueError('Stored tune baseline failed integrity validation.')
    def upd(pct,title,msg):
        if progress:progress(pct,title,msg)
    db.conn.execute('UPDATE project_versions SET preview_ready=0,preview_json_path=? WHERE project_id=? AND version_no=?',('',pid,vn));db.conn.commit()
    out=db.version_dir(pid,vn)/'_Combined_Preview'
    if out.exists():shutil.rmtree(out,ignore_errors=True)
    out.mkdir(parents=True,exist_ok=True)
    built=wideband_integration.build_combined_preview(baseline,source,out,rescale_approved=bool(rescale_approved),delay_ms=int(delay_ms),progress=upd)
    payload=dict(built['payload']);payload['version_no']=vn
    pj=out/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2),encoding='utf-8')
    metrics=built['metrics']
    db.conn.execute('UPDATE project_versions SET preview_ready=1,preview_json_path=?,application_percent=0 WHERE project_id=? AND version_no=?',(str(pj),pid,vn));db.conn.commit()
    db.record_event(pid,'COMBINED_CANDIDATE_READY',f"V{vn}; {metrics['method_id']}; qualifying={metrics['qualifying_cells']}",uid)
    upd(100,'Write & store results','Combined candidate ready. Review Results, then Apply Changes and Build It.')
    return {'metrics':metrics,'preview_json':pj,'preview_levels':payload['levels'],'state':db.project_state(pid,vn),'source_log':source,'version_no':vn}

def open_path(path:Path):
    if os.name=='nt': os.startfile(str(path))
    elif sys.platform=='darwin':subprocess.Popen(['open',str(path)])
    else:subprocess.Popen(['xdg-open',str(path)])




def _hex_rgb(value):
    value=value.lstrip('#')
    return tuple(int(value[i:i+2],16) for i in (0,2,4))


def _rgb_hex(rgb):
    return '#%02X%02X%02X' % tuple(max(0,min(255,int(round(v)))) for v in rgb)


def _blend(c1,c2,t):
    a=_hex_rgb(c1); b=_hex_rgb(c2); t=max(0.0,min(1.0,float(t)))
    return _rgb_hex(tuple(a[i]+(b[i]-a[i])*t for i in range(3)))


def _piecewise_color(x,colors):
    # Reviewer-facing pastel palette. Keep every band light enough that exact
    # cell values can remain readable with dark text.
    x=max(0.0,min(1.0,float(x)))
    if len(colors)==1:return colors[0]
    pos=x*(len(colors)-1)
    idx=min(len(colors)-2,int(pos)); local=pos-idx
    return _blend(colors[idx],colors[idx+1],local)


def _sequential_color(value,vmin,vmax):
    if vmax<=vmin:return '#CFE8FF'
    x=(value-vmin)/(vmax-vmin)
    return _piecewise_color(x,[
        '#DCEEFF',  # light blue
        '#B7DBF7',
        '#BDE6DF',  # light aqua/green
        '#FFF0AF',  # pale yellow
        '#FFD39A',
        '#FFB487',  # light orange
    ])


def _delta_color(value,limit):
    if limit<=0:return '#F8FAFC'
    x=max(-1.0,min(1.0,value/limit))
    if x<0:return _blend('#FFFFFF','#A9C9FF',abs(x))
    return _blend('#FFFFFF','#FFB8B8',x)


def _text_for_fill(fill):
    # Current review palettes are intentionally light. A consistent dark label
    # is easier to scan than per-cell white/black switching.
    return '#172033'

class ReviewApp:
    # UI Updates Version 1 overrides the older sidebar ordering while preserving
    # Dashboard and Diagnostics as internal pages. Users remains admin-only.
    NAV=(('projects','Projects'),('setup','New Project'),('preflight','Preflight'),('review','Run/Review'),('results','Results'),('settings','Settings'),('legal','About'))
    def __init__(self,root,db_path:Path,asset_dir:Path):
        verify_assets(asset_dir); self.root=root; self.asset_dir=asset_dir; self.app_dir=Path(asset_dir).parent; channel_list.bundled_channel_list(self.app_dir); verify_purchase_assets(self.app_dir); self.license=licensing.LicenseManager(); self.eula_sha=verify_legal(self.app_dir); self.eula_text_path=self.app_dir/EULA_TEXT_REL; self.eula_pdf_path=self.app_dir/EULA_PDF_REL; self.help_text_path=self.app_dir/HELP_TEXT_REL; self.help_context_path=self.app_dir/HELP_CONTEXT_REL; self.help_context_map=verify_help(self.app_dir); self.db=ReviewDatabase(db_path); self.metrics={}
        self.fixed_metrics=dict(self.metrics); self.user=None; self.project=None; self.active_version_no=None; self.content=None; self.page_title=None; self.nav={}; self.running=False; self.surface_cache={}; self.surface_display_cache=None
        self.page_canvas=None; self.page_scrollbar=None; self.back_button=None; self.page_history=[]; self.current_page=None; self.help_context='login'; self.help_window=None; self.purchase_window=None; self.purchase_qr_image=None
        self.progress=tk.DoubleVar(value=0); self.run_title=tk.StringVar(value='Ready'); self.run_detail=tk.StringVar(value=''); self.run_pct=tk.StringVar(value=''); self.run_elapsed=tk.StringVar(value='')
        self.application_selected_percent=None; self.application_selection_context=None; self.application_preview_candidate=None; self.application_preview_accepted=None; self.application_preview_metrics=None; self.application_checks={}; self.application_buttons={}; self.application_preview_host=None; self.build_it_btn=None
        self._application_preview_updating=False; self._application_surface_after_id=None; self._surface_resize_after_id=None; self._surface_refresh_error=''
        self._watermark_login_photo=None; self._watermark_eula_photo=None; self._watermark_page_photo=None; self._watermark_splash_photo=None; self._working_overlay=None; self._working_after_id=None; self._working_visible=True; self._setup_blink_after_id=None; self._setup_blink_visible=True
        self._setup_verify_button=None;self._setup_verify_blink_after_id=None;self._setup_verify_blink_on=False
        self._setup_verified_signature=None
        self._setup_verification_displayed_signature=None
        self._vin_lookup_generation=0
        self._vin_lookup_pending=False
        self.run_progressbar=None; self._progress_mode='determinate'; self._review_started_at=None; self._elapsed_after_id=None; self._run_blink_after_id=None; self._run_blink_on=False
        self.run_trim_chart_data={'cells':{},'sample_count':0,'max_abs_sample':0.0}; self.run_trim_canvas=None
        self.run_quality_vars={}; self.run_quality_activity_widget=None; self.run_quality_activity_lines=[]; self._run_quality_last_activity=None; self._run_quality_active_stage=None; self._progress_activity_times={}
        self._progress_context=None  # (project_id, version_no) for pinned progress
        self.correction_source_selection=None; self.correction_preflight_cache=None; self.correction_preflight_context=None; self.correction_rescale_approved=False; self.correction_preflight_running=False
        self.setup_panel_message=None  # {heading, text, align}; replaced atomically as events arrive
        self.setup_message_host=None
        self.setup_action_view=None;self.setup_progress_view=None;self.setup_header_label=None
        self._setup_header_blink_after_id=None;self._setup_header_blink_on=False
        self._setup_header_mode=None;self.setup_workflow_button=None;self._setup_action_command=None
        self.setup_choice_var=None;self.setup_choice_actions={}
        self.setup_processing_host=None
        # Dyno-style graph is strictly read-only and is loaded off the Tk thread.
        self._dyno_curve_cache={};self._dyno_pending=set();self._dyno_selected=None
        self._dyno_display_key=None;self.dyno_canvas=None;self.dyno_caption=None
        self.setup_processing_viewport=None;self.setup_processing_scroll=None
        self.setup_activity_host=None;self.setup_activity_bar=None;self.setup_activity_state=None
        self._setup_lower_mode='status';self._staged_project_name=None
        self._setup_build_in_progress=False;self._correction_launch_pending=False
        # Submit starts one unattended workflow. Safety decisions pause it;
        # changing the staged inputs, errors or leaving Setup cancels it.
        self._auto_submit_active=False;self._auto_submit_signature=None
        self._auto_submit_generation=0
        self._failed_log_detail=None;self._failed_log_report=None
        self.vs_na_closed_loop_only=False
        self._run_trim_watch_stop=None; self._run_trim_watch_thread=None; self._run_trim_abort_event=None
        root.option_add('*Font',('Microsoft Sans Serif',9))
        root.title(self.license.display_version()); self._position_initial_window(); root.configure(bg=C['bg']); root.protocol('WM_DELETE_WINDOW',self.clean_exit)
        root.bind('<Destroy>',self._on_root_destroy,add='+')
        root.bind_all('<F1>',lambda _e:self.show_help())
        self._install_mousewheel_support()
        self._load_watermark(); self.styles(); self.splash() if os.environ.get('VE_OPTIMIZER_SKIP_SPLASH')!='1' else self.startup()

    def _position_initial_window(self):
        """Place the normal review window high on the primary display and keep it fully visible."""
        try:
            sw=max(1100,int(self.root.winfo_screenwidth()))
            sh=max(720,int(self.root.winfo_screenheight()))
            # Keep the approved 1360 x 850 review size whenever the display can
            # accommodate it. On smaller work areas, shrink only enough to avoid
            # opening below the usable desktop.
            w=min(1360,max(1000,sw-24))
            h=min(850,max(680,sh-120))
            x=max(0,(sw-w)//2)
            # The review window previously relied on the window manager's cascade
            # position and could open too low. Aim just below a typical browser
            # toolbar while always leaving the bottom edge visible.
            y=max(8,min(70,sh-h-12))
            self.root.geometry(f'{w}x{h}+{x}+{y}')
            self.root.minsize(min(1100,w),min(720,h))
        except Exception:
            self.root.geometry('1360x850+20+20'); self.root.minsize(1100,720)

    def _position_build_output_window(self,top):
        """Open Build It beside the Results controls instead of screen corner."""
        try:
            top.update_idletasks()
            ww=max(250,int(top.winfo_reqwidth())); wh=max(180,int(top.winfo_reqheight()))
            anchor=getattr(self,'application_buttons',{}).get(100)
            if anchor is not None and anchor.winfo_exists():
                anchor.update_idletasks()
                x=int(anchor.winfo_rootx()+anchor.winfo_width()-ww)
                y=int(anchor.winfo_rooty()+anchor.winfo_height()+8)
            else:
                x=int(self.root.winfo_rootx()+self.root.winfo_width()-ww-24)
                y=int(self.root.winfo_rooty()+90)
            sw=max(ww+16,int(top.winfo_screenwidth())); sh=max(wh+16,int(top.winfo_screenheight()))
            x=max(8,min(x,sw-ww-8)); y=max(8,min(y,sh-wh-8))
            top.geometry(f'{ww}x{wh}+{x}+{y}')
        except Exception:
            pass

    def _load_watermark(self):
        # VE Optimizer 2.4.0 Release: project/page watermarking remains disabled.
        self._watermark_login_photo=None
        self._watermark_eula_photo=None
        self._watermark_page_photo=None
        self._watermark_splash_photo=None

    def _watermark_frame(self,parent,padx=0,pady=0):
        f=tk.Frame(parent,bg=C['bg']); f.pack(fill='both',expand=True,padx=padx,pady=pady)
        return f

    def _refresh_progress_activity(self):
        widget=getattr(self,'setup_progress_log',None)
        if widget is None:return
        try:
            if not widget.winfo_exists():return
            lines=list(self.run_quality_activity_lines[-24:])
            activity=getattr(self,'setup_activity_state',None)
            if activity and not lines:
                lines=[f"{activity.get('title','Ready')} — {activity.get('detail','')}"]
            prior=getattr(self,'_progress_activity_times',{})
            stamped={line:prior.get(line,time.strftime('%H:%M:%S')) for line in lines}
            self._progress_activity_times=stamped
            widget.configure(state='normal')
            widget.delete('1.0','end')
            widget.insert('end','RECENT ACTIVITY\n','activity_heading')
            for line in lines:
                # Internal stage bookkeeping stays unchanged. Present readable
                # activity instead of raw DATA / WORKING / COMPLETE records.
                if line.startswith('DATA    '):
                    description=line[len('DATA    '):].replace(': ', '  —  ', 1)
                    style='activity_fact'
                elif line.startswith('WORKING  '):
                    description='In progress  —  '+line[len('WORKING  '):]
                    style='activity_active'
                elif line.startswith('COMPLETE 100%  '):
                    description='Completed  —  '+line[len('COMPLETE 100%  '):]
                    style='activity_done'
                elif line.startswith('OVERALL 100%  '):
                    description=line[len('OVERALL 100%  '):]
                    style='activity_done'
                else:
                    description=line
                    style='activity_fact'
                widget.insert('end',stamped[line]+'   ','activity_time')
                widget.insert('end',description+'\n',style)
            widget.see('end')
            widget.configure(state='disabled')
        except (tk.TclError,AttributeError):pass

    def _record_processing_fact(self,subject,detail):
        # Append a factual, deduplicated observation on the UI thread.
        item=f'DATA    {str(subject)}: {str(detail)}'
        if item not in self.run_quality_activity_lines[-20:]:
            self.run_quality_activity_lines.append(item)
            self.run_quality_activity_lines=self.run_quality_activity_lines[-32:]
            self._refresh_progress_activity()

    def _sync_progress_version(self,project_id,version_no):
        """Discard an earlier version's display state, never its stored results.

        V1+ uses fresh Log File and correction progress. The same-version page
        refresh preserves the active progress stream; only a context switch
        clears old V0 completion messages, timestamps and a 100% bar.
        """
        context=(int(project_id),int(version_no))
        if getattr(self,'_progress_context',None)==context:
            return False
        self._progress_context=context
        self.run_quality_activity_lines=[]
        self._run_quality_last_activity=None
        self._run_quality_active_stage=None
        self._progress_activity_times={}
        self.progress.set(0)
        self.run_title.set('Ready')
        self.run_detail.set('')
        self.run_pct.set('')
        self.run_elapsed.set('')
        self._set_setup_activity(f'V{version_no} ready',
            f'Progress for active V{version_no}; awaiting its Log File and processing.',
            percent=0,busy=False)
        return True

    def _set_setup_activity(self,title,detail='',percent=None,step=None,total=None,busy=False,error=False):
        """Upper-right stage progress, preserved while action messages are displayed.

        Only the review solver reports a real percent; all other asynchronous
        steps use an indeterminate bar. Nothing flashes or claims an invented
        degree of completion. A finished stage remains visible until replaced.
        """
        state=dict(title=str(title),detail=str(detail),percent=percent,
                   step=step,total=total,busy=bool(busy),error=bool(error))
        self.setup_activity_state=state
        self._render_setup_activity()
        self._update_setup_workflow_action()

    def _render_setup_activity(self):
        host=getattr(self,'setup_activity_host',None)
        if host is None:return
        try:
            if not host.winfo_exists():return
        except (tk.TclError,AttributeError):return
        state=getattr(self,'setup_activity_state',None)
        if not state:
            self.setup_activity_heading_var.set('Ready')
            self.setup_activity_status_var.set('')
            self.setup_activity_detail_var.set('')
            self._refresh_progress_activity()
            self._refresh_setup_information_view()
            return
        # Progress is permanently anchored in the upper-right information panel.
        title=state['title']
        marker='FAILED' if state['error'] else ('IN PROGRESS' if state['busy'] else 'FINISHED')
        if state['step'] is not None and state['total'] is not None:
            marker+=f"  •  STEP {state['step']} OF {state['total']}"
        if state['percent'] is not None:
            marker+=f"  •  {int(round(state['percent']))}%"
        self.setup_activity_heading_var.set(title)
        self.setup_activity_status_var.set(marker)
        self.setup_activity_detail_var.set(state['detail'])
        self._refresh_progress_activity()
        self._refresh_setup_information_view()
        bar=self.setup_activity_bar
        if bar is not None:
            try:bar.stop()
            except Exception:pass
            if state['percent'] is None:
                bar.configure(mode='indeterminate',value=0)
                if state['busy']:bar.start(15)
            else:
                bar.configure(mode='determinate',value=max(0,min(100,float(state['percent']))))

    def _show_working_overlay(self,title='Processing',detail='Please wait while this step completes.'):
        """No full-window blinking overlay on the three-panel Setup screen."""
        self._hide_working_overlay()
        if getattr(self,'current_page',None)=='setup' and getattr(self,'setup_activity_host',None) is not None:
            self._set_setup_activity(title,detail,busy=True)
            return
        host=self.page_canvas if self.page_canvas is not None else self.root
        ov=tk.Frame(host,bg='white');ov.place(x=0,y=0,relwidth=1,relheight=1);ov.lift();self._working_overlay=ov
        self._working_label=tk.Label(ov,text='Processing',bg='white',fg=C['accent'],
                 font=('Microsoft Sans Serif',20,'bold'))
        self._working_label.place(relx=.5,rely=.5,anchor='center')

    def _hide_working_overlay(self):
        if self._working_after_id:
            try:self.root.after_cancel(self._working_after_id)
            except Exception:pass
            self._working_after_id=None
        if self._working_overlay is not None:
            try:self._working_overlay.destroy()
            except Exception:pass
            self._working_overlay=None
        state=getattr(self,'setup_activity_state',None)
        if state and state['busy'] and state['percent'] is None:
            self._set_setup_activity(state['title'],'Check the upper-right panel for the result.',busy=False)

    def _start_setup_button_blink(self,button):
        # Retain the compatibility call, but never blink the label.
        self._stop_setup_button_blink(button,reset=False)
        try:button.config(text='Processing',style='WorkingPrimary.TButton');button.state(['disabled'])
        except Exception:pass

    def _stop_setup_button_blink(self,button,reset=True):
        if self._setup_blink_after_id:
            try:self.root.after_cancel(self._setup_blink_after_id)
            except Exception:pass
            self._setup_blink_after_id=None
        if reset:
            try:button.config(text='Build',style='Primary.TButton');button.state(['!disabled'])
            except Exception:pass

    def _run_background_task(self,task,done):
        box={}
        def runner():
            try:box['result']=task()
            except Exception as e:box['result']=('error',str(e),None)
        threading.Thread(target=runner,daemon=True).start()
        def poll():
            if 'result' in box: done(box['result']); return
            self.root.after(50,poll)
        self.root.after(50,poll)

    def _install_mousewheel_support(self):
        # Candidate 12: make the mouse wheel follow the scrollable region under
        # the pointer instead of requiring the user to drag a scrollbar. Normal
        # Tk scrollable controls keep their native wheel behavior; other child
        # widgets route the wheel to the nearest scrollable ancestor (normally
        # the page canvas). Comboboxes are intercepted so wheel input scrolls
        # the page and never changes the selected value.
        for sequence in ('<MouseWheel>','<Button-4>','<Button-5>'):
            self.root.bind_all(sequence,self._global_mousewheel,add='+')
        try:
            self.root.bind_class('TCombobox','<MouseWheel>',self._combobox_mousewheel)
            self.root.bind_class('TCombobox','<Button-4>',self._combobox_mousewheel)
            self.root.bind_class('TCombobox','<Button-5>',self._combobox_mousewheel)
        except Exception:
            pass

    @staticmethod
    def _mousewheel_units(event):
        num=getattr(event,'num',None)
        if num==4:return -3
        if num==5:return 3
        delta=int(getattr(event,'delta',0) or 0)
        if not delta:return 0
        notches=max(1,abs(delta)//120)
        return (-3 if delta>0 else 3)*notches

    @staticmethod
    def _native_wheel_widget(widget):
        return isinstance(widget,(tk.Text,tk.Listbox,ttk.Treeview))

    def _scrollable_ancestor(self,widget,units):
        cur=widget
        while cur is not None:
            # A Combobox is deliberately not a scroll target. Its class binding
            # calls this routine starting at the parent.
            if not isinstance(cur,ttk.Combobox) and hasattr(cur,'yview'):
                try:
                    first,last=cur.yview()
                    first=float(first);last=float(last)
                    if (units<0 and first>1e-6) or (units>0 and last<1.0-1e-6):
                        return cur
                except Exception:
                    pass
            try:
                parent_name=cur.winfo_parent()
                if not parent_name:break
                cur=cur._nametowidget(parent_name)
            except Exception:
                break
        return None

    def _route_mousewheel(self,event,start_widget=None):
        units=self._mousewheel_units(event)
        if not units:return None
        widget=start_widget or getattr(event,'widget',None)
        if widget is None:return None
        target=self._scrollable_ancestor(widget,units)
        if target is None:return None
        try:
            target.yview_scroll(units,'units')
            return 'break'
        except Exception:
            return None

    def _combobox_mousewheel(self,event):
        # Route to the surrounding page/panel and consume the event before the
        # ttk Combobox class can alter its selection.
        try:
            parent_name=event.widget.winfo_parent()
            start=event.widget._nametowidget(parent_name) if parent_name else None
        except Exception:
            start=None
        self._route_mousewheel(event,start_widget=start)
        return 'break'

    def _global_mousewheel(self,event):
        widget=getattr(event,'widget',None)
        if widget is None:return None
        # Text/Listbox/Treeview already have correct native wheel bindings.
        # Avoid applying a second scroll from the global binding.
        if self._native_wheel_widget(widget):return None
        if isinstance(widget,ttk.Combobox):return 'break'
        return self._route_mousewheel(event)

    def license_status(self):
        return self.license.status()

    def _operation_allowed(self, show_purchase=True):
        # Compatibility name retained. DEMO mode has no expiration and may run the workflow.
        return True

    def _refresh_license_branding(self):
        try:self.root.title(self.license.display_version())
        except Exception:pass

    def splash(self):
        self.clear();self.help_context='overview';self._refresh_license_branding();st=self.license_status()
        shell=tk.Frame(self.root,bg=C['bg']);shell.pack(fill='both',expand=True)
        if self._watermark_splash_photo is not None:
            try:
                tk.Label(shell,image=self._watermark_splash_photo,bd=0,highlightthickness=0).place(x=0,y=0,relwidth=1,relheight=1)
            except Exception:pass
        card=tk.Frame(shell,bg=C['sidebar']);card.place(relx=.5,rely=.48,anchor='center')
        logo=tk.Canvas(card,width=106,height=106,bg=C['sidebar'],highlightthickness=0);logo.create_oval(5,5,101,101,fill=C['accent'],outline='');logo.create_text(53,53,text='VE',fill='white',font=('Microsoft Sans Serif',28,'bold'));logo.pack(pady=(0,18))
        tk.Label(card,text='VE Optimizer',bg=C['sidebar'],fg='white',font=('Microsoft Sans Serif',30,'bold')).pack()
        version=st['label']
        tk.Label(card,text=version,bg=C['sidebar'],fg='#D7E0ED',font=('Microsoft Sans Serif',15,'bold')).pack(pady=(6,4))
        if st['mode']!='licensed':
            tk.Label(card,text='TRIAL/DEMO licensing controls Build It output',bg=C['sidebar'],fg='#AFC0D8',font=('Microsoft Sans Serif',11)).pack()
        else:
            tk.Label(card,text='Licensed',bg=C['sidebar'],fg='#AFC0D8',font=('Microsoft Sans Serif',11)).pack()
        tk.Label(card,text=COPYRIGHT_NOTICE,bg=C['sidebar'],fg='#8FA5C2',font=('Microsoft Sans Serif',8)).pack(pady=(24,0))
        self.root.after(1200,self.startup)

    def show_purchase(self,parent=None):
        if self.purchase_window is not None:
            try:
                if self.purchase_window.winfo_exists():self.purchase_window.destroy()
            except Exception:pass
        st=self.license_status();top=tk.Toplevel(parent or self.root);self.purchase_window=top;top.title('VE Optimizer Purchase / License');top.configure(bg=C['bg']);top.transient(parent or self.root)
        top.update_idletasks();sw=max(800,top.winfo_screenwidth());sh=max(600,top.winfo_screenheight());dw=min(900,max(760,sw-80));dh=min(700,max(560,sh-100));top.geometry(f'{dw}x{dh}');top.minsize(min(760,dw),min(560,dh))
        head=tk.Frame(top,bg='white',height=70,highlightbackground=C['border'],highlightthickness=1);head.pack(fill='x');head.pack_propagate(False)
        hh=tk.Frame(head,bg='white');hh.pack(fill='both',expand=True,padx=20,pady=13);tk.Label(hh,text='Purchase / License',bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(side='left');ttk.Button(hh,text='Close',style='Secondary.TButton',command=top.destroy).pack(side='right')
        purchase_host=tk.Frame(top,bg=C['bg']);purchase_host.pack(fill='both',expand=True)
        purchase_scroll=tk.Scrollbar(purchase_host,orient='vertical');purchase_scroll.pack(side='right',fill='y')
        purchase_canvas=tk.Canvas(purchase_host,bg=C['bg'],highlightthickness=0,yscrollcommand=purchase_scroll.set);purchase_canvas.pack(side='left',fill='both',expand=True);purchase_scroll.config(command=purchase_canvas.yview)
        purchase_body=tk.Frame(purchase_canvas,bg=C['bg']);purchase_window_id=purchase_canvas.create_window((0,0),window=purchase_body,anchor='nw')
        def _purchase_body_configure(_event=None):purchase_canvas.configure(scrollregion=purchase_canvas.bbox('all'))
        def _purchase_canvas_configure(event):purchase_canvas.itemconfigure(purchase_window_id,width=event.width)
        purchase_body.bind('<Configure>',_purchase_body_configure);purchase_canvas.bind('<Configure>',_purchase_canvas_configure)
        body=tk.Frame(purchase_body,bg=C['bg']);body.pack(fill='x',expand=True,padx=18,pady=18)
        if st['mode']=='licensed':
            o,i=self.card(body,22,18);o.pack(fill='x');self.pill(i,'LICENSED','ok').pack(anchor='w');tk.Label(i,text=f'VE Optimizer Version {APP_VERSION}',bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(anchor='w',pady=(12,4));tk.Label(i,text=f"Licensed to: {st.get('licensed_to') or st.get('email') or 'Licensed User'}",bg='white',fg=C['text'],font=('Microsoft Sans Serif',10)).pack(anchor='w');tk.Label(i,text=f"License ID: {st.get('license_id','')}",bg='white',fg=C['muted'],font=('Consolas',9)).pack(anchor='w',pady=(3,0));tk.Label(i,text='Licensed Build It output contains the processed VE changes.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=760,justify='left').pack(anchor='w',pady=(10,0));return top
        # Purchase information / Purchase Order workflow
        o,i=self.card(body,18,16);o.pack(fill='x')
        tk.Label(i,text=f'VE Optimizer - ${PURCHASE_PRICE} USD',bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(anchor='w')
        state_text=self.license.mode_summary()
        tk.Label(i,text=state_text,bg='white',fg=C['warning'],font=('Microsoft Sans Serif',10,'bold')).pack(anchor='w',pady=(5,8))
        tk.Label(i,text='Create and securely submit a Purchase Order. After successful submission, payment instructions are emailed automatically to the confirmed buyer email address and the seller receives a copy. A signed license is issued only after payment is independently verified.',bg='white',fg=C['text'],font=('Microsoft Sans Serif',10),wraplength=810,justify='left').pack(anchor='w')

        po,pi=self.card(body,18,14);po.pack(fill='x',pady=(14,0))
        tk.Label(pi,text='Create Purchase Order',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w')
        tk.Label(pi,text=f'Purchase Orders are submitted securely for review by {LEGAL_CONTACT}. Required buyer information is marked with *.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=810,justify='left').pack(anchor='w',pady=(3,10))
        form=tk.Frame(pi,bg='white');form.pack(fill='x');form.grid_columnconfigure(1,weight=1);form.grid_columnconfigure(3,weight=1)
        po_vars={k:tk.StringVar() for k in ('first_name','last_name','postal_code','address','city','state','country','phone','email','confirm_email','company')}
        po_vars['country'].set('United States')
        # Creation order intentionally defines keyboard traversal order:
        # First Name -> Last Name -> ZIP -> Address -> City -> State ->
        # Country -> Phone -> Email -> Confirm Email -> Company.
        fields=[
            ('first_name','First Name *',0,0),('last_name','Last Name *',0,2),
            ('postal_code','ZIP / Postal Code *',1,0),('address','Address *',1,2),
            ('city','City *',2,0),('state','State / Region *',2,2),
            ('country','Country',3,0),('phone','Phone',3,2),
            ('email','Email *',4,0),('confirm_email','Confirm Email *',4,2),
            ('company','Company',5,0),
        ]
        po_entries={}
        for key,label,row,col in fields:
            tk.Label(form,text=label,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).grid(row=row,column=col,sticky='w',padx=(0 if col==0 else 14,6),pady=(4,2))
            entry=tk.Entry(form,textvariable=po_vars[key],font=('Microsoft Sans Serif',10),relief='solid',bd=1)
            entry.grid(row=row,column=col+1,sticky='ew',ipady=5,pady=(4,2))
            po_entries[key]=entry
        zip_status=tk.StringVar(value='')
        zip_row=tk.Frame(pi,bg='white');zip_row.pack(fill='x',pady=(6,0))
        zip_status_label=tk.Label(zip_row,textvariable=zip_status,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),justify='left',anchor='w')
        zip_status_label.pack(side='left',fill='x',expand=True)
        zip_lookup_state={'busy':False,'last':''}
        def lookup_zip(show_errors=True):
            country=po_vars['country'].get().strip().lower()
            if country not in ('united states','united states of america','usa','us','u.s.','u.s.a.'):
                if show_errors:
                    zip_status.set('ZIP lookup is available for United States addresses only.')
                return
            entered=po_vars['postal_code'].get().strip()
            if not entered:
                return
            if zip_lookup_state['busy']:
                return
            if entered==zip_lookup_state['last'] and po_vars['city'].get().strip() and po_vars['state'].get().strip():
                return
            zip_lookup_state['busy']=True;zip_status.set('Looking up ZIP code...')
            def worker():
                try:
                    result=purchasing.lookup_us_zip(entered)
                    def ok():
                        zip_lookup_state['busy']=False;zip_lookup_state['last']=entered
                        po_vars['postal_code'].set(result['postal_code']);po_vars['city'].set(result['city']);po_vars['state'].set(result['state'])
                        zip_status.set(f"ZIP {result['postal_code']}: {result['city']}, {result['state']}")
                        zip_status_label.config(fg=C['success'])
                    top.after(0,ok)
                except Exception as e:
                    def fail(msg=str(e)):
                        zip_lookup_state['busy']=False;zip_status.set(msg);zip_status_label.config(fg=C['warning'])
                    top.after(0,fail)
            threading.Thread(target=worker,daemon=True).start()
        po_entries['postal_code'].bind('<FocusOut>',lambda _e:lookup_zip(False))
        po_entries['postal_code'].bind('<Return>',lambda _e:(lookup_zip(True),'break')[1])
        ttk.Button(zip_row,text='Lookup ZIP',style='Secondary.TButton',command=lambda:lookup_zip(True)).pack(side='right',padx=(8,0))
        po_ack=tk.BooleanVar(value=False)
        po_ack_text='I understand this Purchase Order is not an invoice. Payment instructions will be emailed automatically after successful submission, and a license is issued only after payment is independently verified.'
        ack_row=tk.Frame(pi,bg='white');ack_row.pack(fill='x',expand=True,pady=(12,4))
        ack_check=ttk.Checkbutton(ack_row,variable=po_ack);ack_check.pack(side='left',anchor='n',padx=(0,5))
        ack_label=tk.Label(ack_row,text=po_ack_text,bg='white',fg=C['text'],font=('Microsoft Sans Serif',9),justify='left',anchor='nw',wraplength=730)
        ack_label.pack(side='left',fill='x',expand=True)
        ack_label.bind('<Button-1>',lambda _e:po_ack.set(not po_ack.get()))
        def _resize_po_ack(event):
            ack_label.configure(wraplength=max(260,event.width-34))
        ack_row.bind('<Configure>',_resize_po_ack)
        po_status=tk.StringVar(value='No Purchase Order has been submitted.')
        tk.Label(pi,textvariable=po_status,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=810,justify='left').pack(anchor='w',pady=(3,7))
        po_last={'order':None,'txt':None,'json':None,'submitted':False}

        def copy_licensing_email():
            try:
                top.clipboard_clear();top.clipboard_append(LEGAL_CONTACT);top.update()
                messagebox.showinfo('Licensing Email',f'Copied to clipboard:\n{LEGAL_CONTACT}',parent=top)
            except Exception as e:messagebox.showerror('Licensing Email',str(e),parent=top)

        def open_po_folder():
            try:
                folder=purchasing.purchase_order_dir(self.license.dir/'PurchaseOrders')
                open_path(folder)
            except Exception as e:messagebox.showerror('Purchase Orders',str(e),parent=top)

        def copy_po_text():
            if not po_last['order']:
                messagebox.showinfo('Purchase Order','Create a Purchase Order first.',parent=top);return
            try:
                top.clipboard_clear();top.clipboard_append(purchasing.render_purchase_order(po_last['order']));top.update()
                messagebox.showinfo('Purchase Order',f"Purchase Order {po_last['order']['po_number']} copied to the clipboard.",parent=top)
            except Exception as e:messagebox.showerror('Purchase Order',str(e),parent=top)

        def create_purchase_order():
            if po_last.get('submitted'):
                return
            try:
                if po_last.get('order') is None:
                    if not po_ack.get():
                        messagebox.showwarning('Purchase Order','Confirm the Purchase Order acknowledgement before continuing.',parent=top);return
                    country=po_vars['country'].get().strip().lower()
                    if country in ('united states','united states of america','usa','us','u.s.','u.s.a.') and po_vars['postal_code'].get().strip() and (not po_vars['city'].get().strip() or not po_vars['state'].get().strip()):
                        try:
                            result=purchasing.lookup_us_zip(po_vars['postal_code'].get())
                            po_vars['postal_code'].set(result['postal_code']);po_vars['city'].set(result['city']);po_vars['state'].set(result['state'])
                            zip_status.set(f"ZIP {result['postal_code']}: {result['city']}, {result['state']}");zip_status_label.config(fg=C['success'])
                        except Exception as lookup_error:
                            messagebox.showwarning('ZIP Lookup',f'{lookup_error}\n\nEnter City and State manually before submitting the Purchase Order.',parent=top);return
                    email=po_vars['email'].get().strip()
                    confirm_email=po_vars['confirm_email'].get().strip()
                    if not confirm_email:
                        messagebox.showwarning('Email Confirmation','Enter the buyer email address again in Confirm Email.',parent=top);return
                    if email.casefold()!=confirm_email.casefold():
                        messagebox.showwarning('Email Confirmation','Email and Confirm Email do not match.',parent=top);return
                    buyer={k:v.get() for k,v in po_vars.items() if k!='confirm_email'}
                    order=purchasing.create_purchase_order(buyer)
                    txt_path,json_path=purchasing.save_purchase_order(order,self.license.dir/'PurchaseOrders')
                    po_last.update(order=order,txt=txt_path,json=json_path,submitted=False)
                    folder_btn.config(state='normal');copy_po_btn.config(state='normal')
                order=po_last['order']
                po_status.set(f"Submitting Purchase Order {order['po_number']} securely...")
                top.update_idletasks()
                result=purchasing.submit_purchase_order(order)
                po_last['submitted']=True
                payment_email_status=str(result.get('payment_email_status') or '').strip().lower()
                submit_po_btn.config(text='Purchase Order Submitted',state='disabled')
                if payment_email_status=='sent':
                    po_status.set(f"Purchase Order {order['po_number']} submitted successfully. Payment instructions were emailed to {order['buyer']['email']}.")
                    messagebox.showinfo('Purchase Order Submitted',f"Purchase Order {order['po_number']} was submitted successfully.\n\nPayment instructions were emailed to {order['buyer']['email']} and the seller was CC'd.\n\nKeep the local Purchase Order copy for your records.",parent=top)
                elif payment_email_status=='failed':
                    po_status.set(f"Purchase Order {order['po_number']} was submitted, but the payment-instructions email could not be confirmed.")
                    messagebox.showwarning('Purchase Order Submitted',f"Purchase Order {order['po_number']} was submitted successfully, but the payment-instructions email could not be delivered.\n\nContact {LEGAL_CONTACT} and reference the Purchase Order number.\n\nDo not submit a duplicate Purchase Order.",parent=top)
                else:
                    po_status.set(f"Purchase Order {order['po_number']} submitted successfully. Watch the confirmed buyer email for payment instructions.")
                    messagebox.showinfo('Purchase Order Submitted',f"Purchase Order {order['po_number']} was submitted successfully.\n\nWatch {order['buyer']['email']} for payment instructions.\n\nKeep the local Purchase Order copy for your records.",parent=top)
            except Exception as e:
                if po_last.get('order') is not None:
                    order=po_last['order']
                    po_status.set(f"Purchase Order {order['po_number']} was saved locally but was not submitted. Check the internet connection and retry.")
                    submit_po_btn.config(text='Retry Submission',state='normal')
                    messagebox.showwarning('Purchase Order Not Submitted',f"Purchase Order {order['po_number']} was saved locally, but VE Optimizer could not confirm delivery to the Purchase Order service.\n\n{e}\n\nPayment instructions are sent only after the Purchase Order service confirms submission. Check the internet connection and click Retry Submission.",parent=top)
                else:
                    messagebox.showerror('Purchase Order',str(e),parent=top)

        purchase_actions=tk.Frame(pi,bg='white');purchase_actions.pack(fill='x',pady=(7,0))
        submit_po_btn=ttk.Button(purchase_actions,text='Create & Submit PO',style='Primary.TButton',command=create_purchase_order);submit_po_btn.pack(side='left')
        ttk.Button(purchase_actions,text='Copy Licensing Email',style='Secondary.TButton',command=copy_licensing_email).pack(side='left',padx=(8,0))
        copy_po_btn=ttk.Button(purchase_actions,text='Copy PO Text',style='Secondary.TButton',command=copy_po_text,state='disabled');copy_po_btn.pack(side='left',padx=(8,0))
        folder_btn=ttk.Button(purchase_actions,text='Open PO Folder',style='Secondary.TButton',command=open_po_folder,state='disabled');folder_btn.pack(side='left',padx=(8,0))

        pol,pri=self.card(body,18,14);pol.pack(fill='x',pady=(14,0));tk.Label(pri,text='What happens next?',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w')
        next_steps=('1. Submit the Purchase Order securely from this screen.\n'
                    '2. Payment instructions are emailed automatically to the confirmed buyer email address; the seller is copied.\n'
                    '3. Send the PayPal payment using the Purchase Order number in the payment notes.\n'
                    '4. After the seller independently verifies payment, a signed .velicense file is issued.\n'
                    '5. Return here and activate that license file.')
        tk.Label(pri,text=next_steps,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=810,justify='left').pack(anchor='w',pady=(5,0))

        pol2,pi2=self.card(body,18,14);pol2.pack(fill='x',pady=(14,0));tk.Label(pi2,text='Refund Policy',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w');refund=('A 72-hour Trial enables processed Build It output. After the Trial expires, DEMO Build It output is an exact copy of the input .htt; a purchased license removes all restrictions. Refund requests must be made within 7 calendar days by contacting shortshiftsteve@gmail.com. See the full Refund Policy for exclusions and complete terms.')
        tk.Label(pi2,text=refund,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=810,justify='left').pack(anchor='w',pady=(5,5));ttk.Button(pi2,text='Open Full Refund Policy in Help',style='Secondary.TButton',command=lambda:self.show_help('refund_policy',top)).pack(anchor='w')
        act,ai=self.card(body,18,14);act.pack(fill='x',pady=(14,0));tk.Label(ai,text='Already purchased?',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w');tk.Label(ai,text='Select the signed .velicense file supplied after payment verification.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(3,9))
        ack=tk.BooleanVar(value=False);ttk.Checkbutton(ai,text='I have reviewed the Refund Policy and understand the $49.99 license terms.',variable=ack).pack(anchor='w')
        activate=ttk.Button(ai,text='Activate License...',style='Primary.TButton',state='disabled');activate.pack(anchor='e',pady=(8,0))
        ack.trace_add('write',lambda *_:activate.config(state='normal' if ack.get() else 'disabled'))
        def do_activate():
            f=filedialog.askopenfilename(parent=top,title='Select VE Optimizer License',filetypes=[('VE Optimizer License','*.velicense'),('JSON files','*.json'),('All files','*.*')])
            if not f:return
            try:
                payload=self.license.activate_file(Path(f));self._refresh_license_branding();messagebox.showinfo('License Activated',f"VE Optimizer Version {APP_VERSION} is licensed to {payload.get('licensed_to') or payload.get('email') or 'Licensed User'}.\n\nLicensed Build It output is now enabled.",parent=top);top.destroy()
                if self.user:
                    self.shell();self.goto('projects')
                else:self.login()
            except Exception as e:messagebox.showerror('License Activation',str(e),parent=top)
        activate.config(command=do_activate)
        return top

    def styles(self):
        st=ttk.Style(self.root)
        try:st.theme_use('clam')
        except:pass
        st.configure('TFrame',background=C['bg'])
        st.configure('Primary.TButton',font=('Microsoft Sans Serif',10,'bold'),padding=(16,10),background=C['accent'],foreground='white',borderwidth=2,relief='raised')
        st.map('Primary.TButton',background=[('active',C['accent2']),('disabled','#AFC6F5')],relief=[('pressed','sunken'),('active','raised')])
        # Setup build work indicator: keep the disabled/blinking text high-contrast.
        st.configure('WorkingPrimary.TButton',font=('Microsoft Sans Serif',10,'bold'),padding=(16,10),background=C['accent'],foreground='white',borderwidth=2,relief='raised')
        st.map('WorkingPrimary.TButton',background=[('disabled',C['accent']),('active',C['accent2'])],foreground=[('disabled','white'),('!disabled','white')],relief=[('pressed','sunken'),('active','raised')])
        st.configure('ReviewPending.TButton',font=('Microsoft Sans Serif',10,'bold'),padding=(16,10),
                     background='#FFD541',foreground='#111111',borderwidth=2,relief='raised')
        st.map('ReviewPending.TButton',background=[('active','#EBC12F')],foreground=[('active','#111111')])
        # Setup Verify is the only flashing action. Alternating yellow shades
        # keep its identity visible while drawing attention to required input.
        for name,background in (('VerifyBright.TButton','#FFD541'),('VerifySoft.TButton','#FFF1A3')):
            st.configure(name,font=('Microsoft Sans Serif',10,'bold'),padding=(16,10),
                         background=background,foreground='#111111',borderwidth=2,relief='raised')
            st.map(name,background=[('active','#EBC12F')],foreground=[('active','#111111')])
        st.configure('ReviewComplete.TButton',font=('Microsoft Sans Serif',10,'bold'),padding=(16,10),
                     background='#208046',foreground='white',borderwidth=2,relief='raised')
        st.map('ReviewComplete.TButton',background=[('active','#176638')],foreground=[('active','white')])
        st.configure('Secondary.TButton',font=('Microsoft Sans Serif',10,'bold'),padding=(14,9),background='white',foreground=C['text'],borderwidth=2,relief='raised')
        st.map('Secondary.TButton',relief=[('pressed','sunken'),('active','raised')])
        st.configure('Horizontal.TProgressbar',troughcolor='#E7ECF3',background=C['accent'],borderwidth=0); st.configure('Treeview',font=('Microsoft Sans Serif',9),rowheight=28,background='white',fieldbackground='white'); st.configure('Treeview.Heading',font=('Microsoft Sans Serif',9,'bold'),background='#EEF2F7',padding=7)
    def _help_sections(self):
        text=self.help_text_path.read_text(encoding='utf-8',errors='replace')
        matches=list(re.finditer(r'^\[HELP:([A-Z0-9_]+)\]\s*(.*?)\s*$',text,re.M))
        sections={}
        for idx,m in enumerate(matches):
            end=matches[idx+1].start() if idx+1<len(matches) else len(text)
            body=text[m.end():end]
            lines=body.splitlines()
            while lines and (not lines[0].strip() or (set(lines[0].strip())=={'='} and len(lines[0].strip())>10)):lines.pop(0)
            while lines and (not lines[-1].strip() or (set(lines[-1].strip())=={'='} and len(lines[-1].strip())>10)):lines.pop()
            sections[m.group(1)]={'title':m.group(2).strip(),'body':'\n'.join(lines).strip()}
        return sections

    def show_help(self,context=None,parent=None):
        context=context or self.help_context or 'overview'
        contexts=self.help_context_map.get('contexts',{})
        if context not in contexts:context=self.help_context_map.get('default_context','OVERVIEW').lower()
        sections=self._help_sections()
        if self.help_window is not None:
            try:
                if self.help_window.winfo_exists():self.help_window.destroy()
            except Exception:pass
        top=tk.Toplevel(parent or self.root);self.help_window=top;top.title('VE Optimizer Help');top.geometry('1000x720');top.minsize(780,540);top.configure(bg=C['bg']);top.transient(parent or self.root)
        head=tk.Frame(top,bg='white',height=70,highlightbackground=C['border'],highlightthickness=1);head.pack(fill='x');head.pack_propagate(False)
        hh=tk.Frame(head,bg='white');hh.pack(fill='both',expand=True,padx=20,pady=13)
        tk.Label(hh,text='VE Optimizer Help',bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(side='left')
        tk.Label(hh,text='F1 opens help for the current page',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(side='left',padx=(14,0))
        ttk.Button(hh,text='Close',style='Secondary.TButton',command=top.destroy).pack(side='right')
        body=tk.Frame(top,bg=C['bg']);body.pack(fill='both',expand=True,padx=16,pady=16)
        left=tk.Frame(body,bg='white',highlightbackground=C['border'],highlightthickness=1,width=245);left.pack(side='left',fill='y');left.pack_propagate(False)
        tk.Label(left,text='HELP TOPICS',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w',padx=12,pady=(12,6))
        topic_list=tk.Listbox(left,exportselection=False,activestyle='none',relief='flat',bd=0,highlightthickness=0,bg='white',fg=C['text'],selectbackground=C['info_bg'],selectforeground=C['accent'],font=('Microsoft Sans Serif',9))
        topic_list.pack(fill='both',expand=True,padx=7,pady=(0,8))
        right=tk.Frame(body,bg='white',highlightbackground=C['border'],highlightthickness=1);right.pack(side='left',fill='both',expand=True,padx=(12,0))
        sy=tk.Scrollbar(right,orient='vertical');sy.pack(side='right',fill='y')
        text=tk.Text(right,wrap='word',yscrollcommand=sy.set,bg='white',fg=C['text'],relief='flat',bd=0,font=('Microsoft Sans Serif',10),padx=20,pady=18,spacing1=1,spacing3=5);text.pack(side='left',fill='both',expand=True);sy.config(command=text.yview)
        ordered=[]
        for key,item in contexts.items():
            section=str(item.get('section') or '').upper();title=str(item.get('title') or sections.get(section,{}).get('title') or key.replace('_',' ').title())
            if section in sections:
                ordered.append((key,section,title));topic_list.insert('end',title)
        def render(index):
            if index<0 or index>=len(ordered):return
            key,section,title=ordered[index];entry=sections[section]
            text.config(state='normal');text.delete('1.0','end');text.insert('end',entry['title']+'\n','help_title');text.insert('end','\n')
            # Recommended Channels / Polling uses a true two-column tab stop so
            # the user-provided Channel Name and Polling Interval values remain
            # aligned even though the normal Help body uses a proportional font.
            for line in entry['body'].splitlines():
                if '\t' in line:
                    tag='help_table_header' if line.startswith('Channel Name\t') else 'help_table_row'
                    text.insert('end',line+'\n',tag)
                else:
                    text.insert('end',line+'\n')
            text.tag_configure('help_title',font=('Microsoft Sans Serif',17,'bold'),foreground=C['text'])
            text.tag_configure('help_table_header',font=('Consolas',9,'bold'),foreground=C['text'],tabs=('360',))
            text.tag_configure('help_table_row',font=('Consolas',9),foreground=C['text'],tabs=('360',))
            text.config(state='disabled');text.yview_moveto(0.0)
        def on_select(_e=None):
            sel=topic_list.curselection()
            if sel:render(int(sel[0]))
        topic_list.bind('<<ListboxSelect>>',on_select)
        initial=0
        for idx,(key,_section,_title) in enumerate(ordered):
            if key==context:initial=idx;break
        topic_list.selection_set(initial);topic_list.see(initial);render(initial)
        top.protocol('WM_DELETE_WINDOW',top.destroy)
        return top

    def clear(self):
        # Tear down the preceding page's menu when switching to EULA/login/splash.
        try:self.root.configure(menu='')
        except tk.TclError:pass
        for w in self.root.winfo_children():w.destroy()
    def clean_exit(self):
        if self.running:
            if not messagebox.askyesno('Review in progress','A review is currently running. Exit now? The current review will stop and may need to be run again.'):
                return
        s4.RESOURCES.close_all(); self.root.destroy()
    def startup(self):
        if self.db.multi_user_enabled():
            self.login()
        else:
            self._enter_single_user_mode()

    def _enter_single_user_mode(self):
        self.clear();self.project=None;self.active_version_no=None;self.page_history=[];self.current_page=None;self.help_context='projects'
        try:self.user=self.db.single_user_identity()
        except Exception as exc:
            messagebox.showerror('Single User Mode',str(exc));self.clean_exit();return
        if self.db.has_eula_acceptance(self.user.id,EULA_VERSION,self.eula_sha):
            self.shell();self.goto('setup')
        else:
            self.show_eula_acceptance()

    def login(self):
        self.clear(); self.user=None; self.project=None; self.active_version_no=None; self.page_history=[]; self.current_page=None; self.help_context='login'
        shell=tk.Frame(self.root,bg=C['bg']); shell.pack(fill='both',expand=True)
        left=tk.Frame(shell,bg=C['sidebar'],width=300); left.pack(side='left',fill='y'); left.pack_propagate(False)
        b=tk.Frame(left,bg=C['sidebar']); b.pack(fill='both',expand=True,padx=32,pady=60)
        logo=tk.Canvas(b,width=72,height=72,bg=C['sidebar'],highlightthickness=0); logo.create_oval(3,3,69,69,fill=C['accent'],outline=''); logo.create_text(36,36,text='VE',fill='white',font=('Microsoft Sans Serif',19,'bold')); logo.pack(anchor='w',pady=(30,28))
        st=self.license_status(); login_license_text=self.license.trial_expiration_label() if st['mode']=='trial' else self.license.mode_summary()
        tk.Label(b,text='VE Optimizer',bg=C['sidebar'],fg='white',font=('Microsoft Sans Serif',28,'bold')).pack(anchor='w'); tk.Label(b,text=st['label'],bg=C['sidebar'],fg='#AFC0D8',font=('Microsoft Sans Serif',12)).pack(anchor='w',pady=(4,4)); tk.Label(b,text=login_license_text,bg=C['sidebar'],fg='#8FA5C2',font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(0,24))
        tk.Label(b,text='A guided review experience for supported Dodge Challenger neural-network calibration projects.',bg=C['sidebar'],fg='#D7E0ED',font=('Microsoft Sans Serif',11),justify='left',wraplength=225).pack(anchor='w')
        tk.Label(b,text='Select the current Log File in Vehicle Setup. Bundled reference assets are automatic.',bg=C['sidebar'],fg='#8FA5C2',font=('Microsoft Sans Serif',10),justify='left',wraplength=225).pack(anchor='w',pady=(18,0))
        right=tk.Frame(shell,bg=C['bg']); right.pack(side='left',fill='both',expand=True)
        if self._watermark_login_photo is not None:
            try:
                tk.Label(right,image=self._watermark_login_photo,bd=0,highlightthickness=0,bg=C['bg']).place(relx=.5,rely=.5,anchor='center')
            except Exception:pass
        card=tk.Frame(right,bg='white',highlightbackground=C['border'],highlightthickness=1); card.place(relx=.5,rely=.5,anchor='center',width=455,height=485)
        tk.Label(card,text='Sign in',bg='white',fg=C['text'],font=('Microsoft Sans Serif',23,'bold')).pack(anchor='w',padx=42,pady=(42,5)); tk.Label(card,text='Open the VE Optimizer review workspace.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',10)).pack(anchor='w',padx=42,pady=(0,26))
        f=tk.Frame(card,bg='white'); f.pack(fill='x',padx=42); uv=tk.StringVar(value='admin'); pv=tk.StringVar(value='admin'); err=tk.StringVar()
        for label,var,show in [('USER NAME',uv,''),('PASSWORD',pv,'•')]:
            tk.Label(f,text=label,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w'); e=tk.Entry(f,textvariable=var,show=show,font=('Microsoft Sans Serif',11),relief='solid',bd=1); e.pack(fill='x',ipady=8,pady=(5,16));
            if label=='PASSWORD':pe=e
        tk.Label(f,textvariable=err,bg='white',fg=C['danger'],font=('Microsoft Sans Serif',9)).pack(anchor='w')
        def go(*_):
            u=self.db.authenticate(uv.get(),pv.get())
            if not u:err.set('User name or password is incorrect.');return
            self.user=u; self.project=None
            if self.db.has_eula_acceptance(self.user.id,EULA_VERSION,self.eula_sha):
                self.shell(); self.goto('projects')
            else:self.show_eula_acceptance()
        ttk.Button(f,text='Sign In',style='Primary.TButton',command=go).pack(fill='x',pady=(10,8)); ttk.Button(f,text='Purchase / License',style='Secondary.TButton',command=self.show_purchase).pack(fill='x',pady=(0,8)); ttk.Button(f,text='Help',style='Secondary.TButton',command=lambda:self.show_help('login')).pack(fill='x',pady=(0,12)); tk.Label(f,text='Default review account: admin / admin',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w'); tk.Label(f,text=COPYRIGHT_NOTICE,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=340,justify='left').pack(anchor='w',pady=(12,0)); pe.bind('<Return>',go)
    def show_eula_acceptance(self):
        if not self.user:return self.login()
        self.clear(); shell=tk.Frame(self.root,bg=C['bg']);shell.pack(fill='both',expand=True)
        if self._watermark_eula_photo is not None:
            try:
                tk.Label(shell,image=self._watermark_eula_photo,bd=0,highlightthickness=0).place(x=0,y=0,relwidth=1,relheight=1)
            except Exception:pass
        top=tk.Frame(shell,bg='white',height=86,highlightbackground=C['border'],highlightthickness=1);top.pack(fill='x');top.pack_propagate(False)
        h=tk.Frame(top,bg='white');h.pack(fill='both',expand=True,padx=30,pady=16)
        tk.Label(h,text='VE Optimizer Software License and Terms of Use',bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(anchor='w')
        tk.Label(h,text=f'{EULA_VERSION}  •  {COPYRIGHT_NOTICE}',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(4,0))
        body=tk.Frame(shell,bg=C['bg']);body.pack(fill='both',expand=True,padx=30,pady=(20,12))
        card=tk.Frame(body,bg='white',highlightbackground=C['border'],highlightthickness=1);card.pack(fill='both',expand=True)
        scroll=tk.Scrollbar(card,orient='vertical');scroll.pack(side='right',fill='y')
        terms=tk.Text(card,wrap='word',yscrollcommand=scroll.set,bg='white',fg=C['text'],relief='flat',bd=0,font=('Microsoft Sans Serif',10),padx=20,pady=18,spacing1=1,spacing3=5);terms.pack(side='left',fill='both',expand=True);scroll.config(command=terms.yview)
        terms.insert('1.0',self.eula_text_path.read_text(encoding='utf-8'));terms.config(state='disabled')
        controls=tk.Frame(shell,bg='white',highlightbackground=C['border'],highlightthickness=1);controls.pack(fill='x')
        inner=tk.Frame(controls,bg='white');inner.pack(fill='x',padx=30,pady=14)
        accepted=tk.BooleanVar(value=False)
        cb=ttk.Checkbutton(inner,text='I have read, understand, and agree to the VE Optimizer Software License and Terms of Use.',variable=accepted);cb.pack(anchor='w')
        lower=tk.Frame(inner,bg='white');lower.pack(fill='x',pady=(10,0))
        tk.Label(lower,text=f'Acceptance will be recorded to User ID {self.user.id} ({self.user.username}) for {EULA_VERSION}.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8)).pack(side='left')
        actions=tk.Frame(lower,bg='white');actions.pack(side='right')
        accept=ttk.Button(actions,text='Accept and Continue',style='Primary.TButton',state='disabled');accept.pack(side='right')
        def toggle(*_):accept.config(state='normal' if accepted.get() else 'disabled')
        accepted.trace_add('write',toggle)
        def decline():
            self.user=None;self.project=None
            if self.db.multi_user_enabled():self.login()
            else:self.clean_exit()
        def agree():
            if not accepted.get():return
            try:
                self.db.record_eula_acceptance(self.user.id,EULA_VERSION,self.eula_sha,APP_VERSION)
                self.shell();self.goto('projects')
            except Exception as e:messagebox.showerror('License Acceptance',str(e))
        accept.config(command=agree);ttk.Button(actions,text='Decline',style='Secondary.TButton',command=decline).pack(side='right',padx=(0,10));ttk.Button(actions,text='Help',style='Secondary.TButton',command=lambda:self.show_help('about')).pack(side='right',padx=(0,10))
    def _download_channel_list(self):
        """Export the bundled VCM Scanner channel list to this user's Downloads."""
        try:
            channel_list.bundled_channel_list(self.app_dir)
            destination = channel_list.channel_list_destination()
            replace = False
            if destination.exists() and destination.is_file():
                if channel_list.sha256_file(destination) != channel_list.CHANNEL_LIST_SHA256:
                    replace = messagebox.askyesno(
                        'Channel List',
                        f'A file with this name already exists in Downloads:\n{destination.name}\n\n'
                        'Replace it with the VE Optimizer Channel List?',
                        parent=self.root,
                    )
                    if not replace:
                        return
            target, status = channel_list.export_channel_list(
                self.app_dir, overwrite=replace,
            )
            confirmation = ('The current Channel List is already in Downloads:'
                            if status == 'already_current' else 'Channel List saved to:')
            messagebox.showinfo('Channel List', f'{confirmation}\n{target}', parent=self.root)
        except Exception as exc:
            messagebox.showerror('Channel List', str(exc), parent=self.root)

    def check_for_updates(self):
        """Check public GitHub Releases only on explicit Help-menu activation."""
        if getattr(self, 'running', False):
            messagebox.showinfo('Check for Updates',
                                'Finish the current processing run before checking for updates.',
                                parent=self.root)
            return
        if getattr(self, '_update_busy', False):
            return
        self._update_busy = True

        def deliver(release=None, error=None):
            try:
                if not self.root.winfo_exists():
                    return
                self._update_busy = False
                if error:
                    messagebox.showerror('Check for Updates', str(error), parent=self.root)
                    return
                if not updates.newer_than(release.version, APP_VERSION):
                    messagebox.showinfo('Check for Updates',
                                        f'VE Optimizer v{APP_VERSION} is up to date.', parent=self.root)
                    return
                if messagebox.askyesno('VE Optimizer Update Available',
                                       f'Installed version: {APP_VERSION}\n'
                                       f'Available Release: {release.version}\n\n'
                                       'Download and install this update?', parent=self.root):
                    self._download_and_install_update(release)
            except Exception as exc:
                self._update_busy = False
                if self.root.winfo_exists():
                    messagebox.showerror('Check for Updates', str(exc), parent=self.root)

        def work():
            try:
                release = updates.fetch_latest_release()
                self.root.after(0, lambda: deliver(release=release))
            except Exception as exc:
                self.root.after(0, lambda err=str(exc): deliver(error=err))

        threading.Thread(target=work, daemon=True, name='VE-Update-Check').start()

    def _download_and_install_update(self, release):
        """Fetch a signed installer, then hand off shutdown to a separate process."""
        if getattr(self, '_update_busy', False):
            return
        if getattr(self, 'running', False):
            messagebox.showinfo('VE Optimizer Update',
                                'Finish processing before installing an update.', parent=self.root)
            return
        self._update_busy = True
        progress = tk.Toplevel(self.root)
        progress.title('VE Optimizer Update')
        progress.transient(self.root)
        progress.resizable(False, False)
        frame = ttk.Frame(progress, padding=24)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text=f'Downloading and verifying VE Optimizer v{release.version}...').pack(pady=(0,12))
        bar = ttk.Progressbar(frame, mode='indeterminate', length=340)
        bar.pack(fill='x')
        bar.start(12)
        progress.protocol('WM_DELETE_WINDOW', lambda: None)

        def finish(installer=None, error=None):
            self._update_busy = False
            try:
                bar.stop()
                progress.destroy()
            except tk.TclError:
                pass
            if not self.root.winfo_exists():
                return
            if error:
                messagebox.showerror('VE Optimizer Update', str(error), parent=self.root)
                return
            try:
                updates.start_update_handoff(installer, release.version)
            except Exception as exc:
                messagebox.showerror('VE Optimizer Update', str(exc), parent=self.root)
                return
            # Update launcher waits for this process to terminate. The normal
            # interactive installer, not this app, launches the replacement.
            self.clean_exit()

        def work():
            try:
                stage = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'VEOptimizer' / 'updates' / uuid.uuid4().hex
                installer = updates.download_installer(release, stage)
                updates.verify_windows_installer(installer, release.version)
                self.root.after(0, lambda: finish(installer=installer))
            except Exception as exc:
                self.root.after(0, lambda err=str(exc): finish(error=err))

        threading.Thread(target=work, daemon=True, name='VE-Update-Download').start()

    def shell(self):
        """Traditional Windows shell. All existing pages remain accessible via menus."""
        self.clear()
        self.nav={}
        main=tk.Frame(self.root,bg=C['bg'])
        main.pack(fill='both',expand=True)
        bar=tk.Menu(self.root,tearoff=False,font=('Microsoft Sans Serif',10))
        file_menu=tk.Menu(bar,tearoff=False,font=('Microsoft Sans Serif',10))
        file_menu.add_command(label='New Project',command=self._new_project_setup)
        file_menu.add_command(label='Projects...',command=lambda:self.goto('projects'))
        file_menu.add_separator()
        file_menu.add_command(label='Exit',command=self.clean_exit)
        bar.add_cascade(label='File',menu=file_menu)
        edit_menu=tk.Menu(bar,tearoff=False,font=('Microsoft Sans Serif',10))
        edit_menu.add_command(label='Settings',command=lambda:self.goto('settings'))
        bar.add_cascade(label='Edit',menu=edit_menu)
        tools_menu=tk.Menu(bar,tearoff=False,font=('Microsoft Sans Serif',10))
        downloads_menu=tk.Menu(tools_menu,tearoff=False,font=('Microsoft Sans Serif',10))
        downloads_menu.add_command(label='Channel List',command=self._download_channel_list)
        tools_menu.add_cascade(label='Downloads',menu=downloads_menu)
        tools_menu.add_command(label='Preflight',command=lambda:self.goto('preflight'))
        tools_menu.add_command(label='Run/Review',command=lambda:self.goto('review'))
        tools_menu.add_command(label='Results',command=lambda:self.goto('results'))
        if self.db.multi_user_enabled() and self.user and self.user.role=='admin':
            tools_menu.add_command(label='User Management',command=lambda:self.goto('users'))
        bar.add_cascade(label='Tools',menu=tools_menu)
        help_menu=tk.Menu(bar,tearoff=False,font=('Microsoft Sans Serif',10))
        help_menu.add_command(label='Help',command=self.show_help)
        help_menu.add_command(label='Check for Updates',command=self.check_for_updates)
        help_menu.add_command(label='About',command=lambda:self.goto('legal'))
        help_menu.add_command(label='License',command=self.show_purchase)
        if self.db.multi_user_enabled():
            help_menu.add_command(label='Logout',command=self.login)
        bar.add_cascade(label='Help',menu=help_menu)
        self.root.configure(menu=bar)
        self.menu_bar=bar

        # Other existing pages retain their normal in-page navigation/action header.
        # The accepted Setup workspace deliberately hides this entire header.
        top=tk.Frame(main,bg='white',height=55,highlightbackground=C['border'],highlightthickness=1)
        self.shell_header=top
        top.pack_propagate(False)
        self.back_button=ttk.Button(top,text='← Back',style='Secondary.TButton',command=self.go_back,state='disabled')
        self.back_button.pack(side='left',padx=(14,6),pady=7)
        self.page_title=tk.Label(top,text='Projects',bg='white',fg=C['text'],font=('Microsoft Sans Serif',14,'bold'))
        self.page_title.pack(side='left',padx=(8,12))
        self.header_project_title=tk.Label(top,text='',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',10,'bold'))
        self.header_project_title.pack(side='left',padx=(0,16))
        self.header_action=tk.Frame(top,bg='white')
        self.header_action.pack(side='right',pady=7,padx=(0,14))
        self._set_header_action()
        page_host=tk.Frame(main,bg=C['bg'])
        page_host.pack(fill='both',expand=True)
        self.page_host=page_host
        self.page_scrollbar=tk.Scrollbar(page_host,orient='vertical')
        self.page_scrollbar.pack(side='right',fill='y')
        self.page_canvas=tk.Canvas(page_host,bg=C['bg'],highlightthickness=0,yscrollcommand=self.page_scrollbar.set)
        self.page_canvas.pack(side='left',fill='both',expand=True)
        self.page_scrollbar.config(command=self.page_canvas.yview)
        self.content=tk.Frame(self.page_canvas,bg=C['bg'])
        self._page_window=self.page_canvas.create_window((0,0),window=self.content,anchor='nw')
        self.content.bind('<Configure>',lambda _e:self.page_canvas.configure(scrollregion=self.page_canvas.bbox('all')))
        self.page_canvas.bind('<Configure>',self._on_page_canvas_resize)

    def _on_page_canvas_resize(self,event):
        if not self.page_canvas:return
        # Fill the initial 3-panel workspace vertically, but retain legacy
        # natural content height and scrolling for every other page.
        height=max(700,int(event.height)) if self.current_page=='setup' else 0
        self.page_canvas.itemconfigure(self._page_window,width=int(event.width),height=height)

    def _set_header_action(self,text=None,command=None):
        host=getattr(self,'header_action',None)
        if host is None:return
        for child in host.winfo_children():child.destroy()
        if text and command:
            self.header_page_action=ttk.Button(host,text=text,style='Primary.TButton',command=command)
        else:
            self.header_page_action=ttk.Button(host,text='Help',style='Secondary.TButton',command=self.show_help)
        self.header_page_action.pack(side='right')

    def _update_back_button(self):
        if self.back_button:
            # Results always returns to the completed dyno workspace even when
            # the page was opened via Tools and the history stack is empty.
            can_return=bool(self.page_history or
                            (self.current_page=='results' and self.project))
            try:self.back_button.config(state='normal' if can_return else 'disabled')
            except Exception:pass

    def go_back(self):
        if self.current_page=='results' and self.project:
            if self.page_history and self.page_history[-1]=='setup':
                self.page_history.pop()
            self.goto('setup',record_history=False)
            return
        if not self.page_history:return
        page=self.page_history.pop()
        self.goto(page,record_history=False)

    def goto(self,page,record_history=True):
        requested=page
        if self.running and requested not in ('review','setup'):return
        if requested in ('preflight','review') and self.project:
            self._setup_lower_mode=requested
            page='setup'
        elif requested=='setup' and not self.project:
            self._setup_lower_mode='status' 
        titles={'dashboard':'Dashboard','preflight':'Correction Preflight','review':'Run/Review','results':'Results','surfaces':'VE Surface Viewer','setup':'New Project','projects':'Projects','settings':'Settings','diagnostics':'Diagnostics','legal':'About','users':'User Management'}
        if page in ('preflight','review','results','surfaces') and not self.project:
            messagebox.showinfo('Project','Select a prior project or create a new project from Projects first.'); page='projects'
        if record_history and self.current_page and page!=self.current_page:
            self.page_history.append(self.current_page)
            if len(self.page_history)>50:self.page_history=self.page_history[-50:]
        self.current_page=page
        self.help_context={'setup':'setup','projects':'setup','preflight':'run_review','review':'run_review','results':'results','surfaces':'ve_surfaces','settings':'settings','legal':'about','users':'users','diagnostics':'troubleshooting','dashboard':'overview'}.get(page,'overview')
        self._set_header_action()
        if hasattr(self,'header_project_title'):
            project_title=''
            if page in ('preflight','review') and self.project:
                project_title=str(self.db.project_display_name(self.project.id) or self.project.name or '').strip()
            self.header_project_title.config(text=project_title)
        if page=='setup':
            self.shell_header.pack_forget()
        elif not self.shell_header.winfo_ismapped():
            self.shell_header.pack(before=self.page_host,fill='x')
        self.page_title.config(text=titles[page])
        if self.page_canvas:
            self.page_canvas.itemconfigure(self._page_window,height=(max(700,self.page_canvas.winfo_height()) if page=='setup' else 0))
        for k,b in self.nav.items():b.config(bg=C['side_active'] if k==page else C['sidebar'],fg='white' if k==page else '#C8D3E2')
        if self.current_page!='setup':self._stop_setup_header_blink()
        for w in self.content.winfo_children():w.destroy()
        getattr(self,'page_'+page)()
        if self.page_canvas:
            self.page_canvas.update_idletasks();self.page_canvas.yview_moveto(0.0)
        self._update_back_button()
    def header(self,p,title,sub):
        tk.Label(p,text=title,bg=C['bg'],fg=C['text'],font=('Microsoft Sans Serif',23,'bold')).pack(anchor='w');tk.Label(p,text=sub,bg=C['bg'],fg=C['muted'],font=('Microsoft Sans Serif',10)).pack(anchor='w',pady=(3,18))
    def card(self,p,padx=20,pady=18):
        o=tk.Frame(p,bg='white',highlightbackground=C['border'],highlightthickness=1);i=tk.Frame(o,bg='white');i.pack(fill='both',expand=True,padx=padx,pady=pady);return o,i
    def pill(self,p,text,kind='ok'):
        bg,fg=(C['success_bg'],C['success']) if kind=='ok' else ((C['warning_bg'],C['warning']) if kind=='warn' else (C['info_bg'],C['accent']));return tk.Label(p,text=text,bg=bg,fg=fg,font=('Microsoft Sans Serif',9,'bold'),padx=12,pady=6)
    def metric(self,p,title,value,detail,ok=False):
        o,i=self.card(p,18,16);tk.Label(i,text=title.upper(),bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w');tk.Label(i,text=value,bg='white',fg=C['text'],font=('Microsoft Sans Serif',19,'bold')).pack(anchor='w',pady=(6,1));tk.Label(i,text=detail,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=210,justify='left').pack(anchor='w');
        if ok:tk.Label(i,text='PASS',bg='white',fg=C['success'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w',pady=(8,0))
        return o
    def state(self):
        if not self.user or not self.project:return {'state':'SETUP_REQUIRED'}
        self.project=self.db.get_project(self.project.id)
        vn=self.active_version_no
        if vn is None:
            v=self.db.latest_version(self.project.id);vn=int(v['version_no']) if v else None
        return self.db.project_state(self.project.id,vn) if vn is not None else self.db.project_state(self.project.id)
    def _active_version(self):
        if not self.project:return None
        if self.active_version_no is None:
            return self.db.latest_version(self.project.id)
        return self.db.get_version(self.project.id,self.active_version_no)
    def choose_output(self):
        # Project storage is fixed and protected.  This compatibility method no
        # longer offers a user-selectable internal project location.
        if not self.project:messagebox.showinfo('Setup','Create or open a project first.');return False
        if self.user.role=='guest':messagebox.showinfo('Read-only','Guest users cannot change review setup.');return False
        try:
            root=self.db.project_root(self.project.id)
            self.db.set_output(self.project.id,self.user.id,root)
            self.project=self.db.get_project(self.project.id);self.surface_cache={};self.surface_display_cache=None
            return True
        except Exception as e:messagebox.showerror('Setup',str(e));return False

    def _active_metrics(self):
        v=self._active_version()
        if v and str(v['metrics_json'] or '').strip():
            p=Path(v['metrics_json'])
            if p.is_file():
                try:
                    m=json.loads(p.read_text(encoding='utf-8'))
                    if isinstance(m,dict) and m.get('method_id')==processing.METHOD_ID:return m
                except Exception:pass
        if self.project:
            p=Path(self.project.output_dir)/DIAG_DIR/'Current_Log_Metrics.json'
            if p.is_file():
                try:
                    m=json.loads(p.read_text(encoding='utf-8'))
                    if isinstance(m,dict) and m.get('method_id')==processing.METHOD_ID:return m
                except Exception:pass
        return dict(self.fixed_metrics)

    def page_dashboard(self):
        b=self._watermark_frame(self.content,28,24);st=self.state();self.header(b,'Review dashboard','Everything needed for review is summarized here. Raw engineering data stays out of the way.')
        o,i=self.card(b,24,21);o.pack(fill='x');l=tk.Frame(i,bg='white');l.pack(side='left',fill='x',expand=True);a=tk.Frame(i,bg='white');a.pack(side='right',padx=(24,0))
        if st['state']=='READY_FOR_REVIEW':kind,label,head,desc='ok','READY FOR REVIEW','The current version passed the packaged review checks.','Use Results for the concise engineering summary or open the output folder for the processed .htt file.';tt=('View Results',lambda:self.goto('results'))
        elif st['state']=='READY_TO_RUN':kind,label,head,desc='info','READY TO RUN','One guided run produces the complete review package.','The selected version Log File is conditioned, the Neural Network result is generated from the stored tune baseline, and a concise summary is written automatically.';tt=('Run Complete Review',lambda:self.goto('review'))
        else:
            vehicle_ok=self.project is not None and self.db.project_setup_complete(self.project.id)
            if not vehicle_ok:kind,label,head,desc='warn','SETUP REQUIRED','Complete Vehicle Setup before processing.','Enter vehicle information, select the current HP Tuners Log File, and declare modifications.';tt=('Vehicle Setup',lambda:self.goto('setup'))
            else:kind,label,head,desc='warn','SETUP REQUIRED','Complete project setup.','Vehicle Setup or current Log File still needs attention.';tt=('Open Setup',lambda:self.goto('setup'))
        self.pill(l,label,kind).pack(anchor='w');tk.Label(l,text=head,bg='white',fg=C['text'],font=('Microsoft Sans Serif',17,'bold')).pack(anchor='w',pady=(13,5));tk.Label(l,text=desc,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',10),wraplength=650,justify='left').pack(anchor='w');ttk.Button(a,text=tt[0],style='Primary.TButton',command=tt[1]).pack(fill='x')
        if st['state']=='READY_FOR_REVIEW':ttk.Button(a,text='Open Output Folder',style='Secondary.TButton',command=self.open_output).pack(fill='x',pady=(8,0))
        steps=tk.Frame(b,bg=C['bg']);steps.pack(fill='x',pady=(16,0));defs=[('1','Project folder',bool(self.project),'Automatic' if self.project else 'Created with project'),('2','Baseline analysis',bool(self.project and self.project.baseline_trim_mae is not None),(f"{self._active_metrics().get('accepted',0):,} accepted samples" if self.project and self.project.baseline_trim_mae is not None else 'Not run')),('3','Candidate outputs',st['state']=='READY_FOR_REVIEW','.htt verified')]
        for z,(n,name,done,detail) in enumerate(defs):
            x,y=self.card(steps,16,14);x.pack(side='left',fill='x',expand=True,padx=(0 if z==0 else 6,0));tk.Label(y,text='✓' if done else n,bg=C['success_bg'] if done else C['info_bg'],fg=C['success'] if done else C['accent'],width=3,font=('Microsoft Sans Serif',10,'bold'),pady=5).pack(side='left');q=tk.Frame(y,bg='white');q.pack(side='left',padx=(10,0));tk.Label(q,text=name,bg='white',fg=C['text'],font=('Microsoft Sans Serif',10,'bold')).pack(anchor='w');tk.Label(q,text=detail,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8)).pack(anchor='w')
        if st['state']=='READY_FOR_REVIEW':
            cards=tk.Frame(b,bg=C['bg']);cards.pack(fill='x',pady=(16,0));m=self._active_metrics();vals=[('Baseline samples',f"{m['accepted']:,}",'Accepted bank-event samples',False),('Estimated trim improvement',f"{m['bank_improvement_pct']:.1f}%",f"Qualifying-bank MAE {m['bank_mae_before']:.3f}% → {m['bank_mae_after']:.3f}%",False),('Correction','50%', 'Applied once to the full shared correction',True),('Output integrity','PASS','Stored tune baseline hash, NN coefficients, and .htt verified',True)]
            for z,args in enumerate(vals):self.metric(cards,*args).pack(side='left',fill='both',expand=True,padx=(0 if z==0 else 6,0))
            note=tk.Frame(b,bg=C['info_bg']);note.pack(fill='x',pady=(16,0));tk.Label(note,text='Reviewer note',bg=C['info_bg'],fg=C['accent'],font=('Microsoft Sans Serif',9,'bold')).pack(side='left',padx=(16,8),pady=11);tk.Label(note,text='You do not need to review the raw conditioning CSV files. They are isolated in _Diagnostics and are optional.',bg=C['info_bg'],fg=C['text'],font=('Microsoft Sans Serif',9)).pack(side='left',pady=11)
    def _dash_setup(self):
        if self.choose_output():self.goto('dashboard')

    def _application_payload(self):
        v=self._active_version()
        if not v:return None
        if not int(v['preview_ready'] or 0) and not (int(v['run_completed'] or 0) and str(v['preview_json_path'] or '').strip()):return None
        p=Path(str(v['preview_json_path'] or ''))
        if not p.is_file():return None
        try:
            data=json.loads(p.read_text(encoding='utf-8'));method=data.get('method_id') if isinstance(data,dict) else None
            return data if method==processing.METHOD_ID or wideband_integration.is_wideband_method(method) else None
        except Exception:return None




    def _schedule_application_surface_refresh(self):
        """Refresh candidate preview data after the Results surface is actually mapped.

        Results is now a separate page. On slower Windows systems the new page
        can take longer than one Tk idle cycle to receive its final canvas size.
        Refresh after layout and also let the canvas <Configure> handler perform
        a geometry-driven redraw.
        """
        host=self.application_preview_host
        if host is None or not host.winfo_exists():return
        if not host.winfo_children():
            self._build_surface_viewer(host,include_header=False)
        if self._application_surface_after_id is not None:
            try:self.root.after_cancel(self._application_surface_after_id)
            except Exception:pass
            self._application_surface_after_id=None
        def refresh():
            self._application_surface_after_id=None
            if self.current_page!='results' or host is None or not host.winfo_exists():return
            self._refresh_surface_widgets()
        self._application_surface_after_id=self.root.after(120,refresh)

    def _surface_canvas_configured(self,_event=None):
        """Redraw after the surface canvas receives its real page dimensions."""
        if self.current_page not in ('results','surfaces'):return
        canvas=getattr(self,'surface_main_canvas',None)
        if canvas is None or not canvas.winfo_exists():return
        try:
            if canvas.winfo_width()<100 or canvas.winfo_height()<100:return
        except Exception:return
        if self._surface_resize_after_id is not None:
            try:self.root.after_cancel(self._surface_resize_after_id)
            except Exception:pass
            self._surface_resize_after_id=None
        def redraw():
            self._surface_resize_after_id=None
            try:
                if canvas.winfo_exists() and self.current_page in ('results','surfaces'):
                    self._refresh_surface_widgets()
            except Exception:pass
        self._surface_resize_after_id=self.root.after(75,redraw)

    def _prepare_reduced_application_preview(self):
        if not self.project or not self.user:return
        if getattr(self,'_reduced_preview_running',False):return
        v=self._active_version()
        if not v:return
        self._reduced_preview_running=True
        for widget in getattr(self,'application_check_widgets',{}).values():widget.state(['disabled'])
        if hasattr(self,'application_apply_btn'):self.application_apply_btn.state(['disabled'])
        self._show_working_overlay()
        pid=self.project.id;uid=self.user.id;vn=int(v['version_no']);dbp=self.db.path
        def worker():
            db=None
            try:
                db=ReviewDatabase(dbp);generate_reduced_preview(db,pid,uid,vn,self.asset_dir)
                self.root.after(0,done)
            except Exception as exc:self.root.after(0,lambda e=exc:failed(e))
            finally:
                if db:db.close()
        def done():
            self._reduced_preview_running=False;self._hide_working_overlay()
            for widget in getattr(self,'application_check_widgets',{}).values():widget.state(['!disabled'])
            if hasattr(self,'application_apply_btn'):self.application_apply_btn.state(['!disabled'])
            self._set_application_preview(25)
        def failed(exc):
            self._reduced_preview_running=False;self._hide_working_overlay()
            self.application_checks.get(25,tk.BooleanVar()).set(False);self.application_checks.get(50,tk.BooleanVar()).set(True)
            for widget in getattr(self,'application_check_widgets',{}).values():widget.state(['!disabled'])
            if hasattr(self,'application_apply_btn'):self.application_apply_btn.state(['!disabled'])
            messagebox.showerror('Reduce by half',str(exc))
        threading.Thread(target=worker,daemon=True).start()

    def _set_application_preview(self,pct):
        if self._application_preview_updating:return
        self._application_preview_updating=True
        try:
            pct=int(pct);payload=self._application_payload()
            if not payload or str(pct) not in payload.get('levels',{}):
                messagebox.showerror('Application Preview','The selected preview is unavailable.');return
            level=payload['levels'][str(pct)]
            cand=Path(level['candidate_htt']);accepted=Path(payload['accepted_csv']);mp=Path(level['metrics_json'])
            if not cand.is_file() or not accepted.is_file() or not mp.is_file():
                messagebox.showerror('Application Preview','Stored preview files are unavailable.');return
            self.application_selected_percent=pct;self.application_selection_context=(int(self.project.id),int(self._active_version()['version_no'])) if self.project and self._active_version() else None;self.application_preview_candidate=cand;self.application_preview_accepted=accepted
            try:self.application_preview_metrics=json.loads(mp.read_text(encoding='utf-8'))
            except Exception:self.application_preview_metrics={}
            for n,var in self.application_checks.items():var.set(int(n)==pct)
            pass
            self._update_build_it_gate()
            self.surface_cache={};self.surface_display_cache=None
            self._schedule_application_surface_refresh()
        finally:
            self._application_preview_updating=False


    def _update_build_it_gate(self):
        btn=getattr(self,'build_it_btn',None)
        if btn is None:return
        try:
            if not btn.winfo_exists():return
        except Exception:return
        ready,_=build_it_application_gate(self._active_version(),self.application_selected_percent)
        if self.user and self.user.role=='guest':ready=False
        btn.state(['!disabled'] if ready else ['disabled'])



    def _request_staged_project_name(self):
        if not self.project or not self.db.is_staged_project(self.project.id):return None
        from tkinter import simpledialog
        name=simpledialog.askstring('Save Project','Project Name:',parent=self.root)
        if name is None:return False
        try:
            name=self.db._unique_name_for_user(self.user.id,name)
            if name[-1] in '. ' or name in ('.','..'):
                raise ValueError('Select a valid Project Name.')
        except Exception as exc:
            messagebox.showerror('Project Name',str(exc),parent=self.root)
            return False
        return name

    def _apply_selected_changes(self):
        if not self.project or not self.user:return
        if self.user.role=='guest':return
        pid=self.project.id;uid=self.user.id;vn=int(self._active_version()['version_no']);dbp=self.db.path;pct=int(self.application_selected_percent or 50)
        proposed_name=self._request_staged_project_name()
        if proposed_name is False:return
        self.application_apply_btn.state(['disabled'])
        def worker():
            db=None
            try:
                db=ReviewDatabase(dbp)
                result=apply_candidate_result(db,pid,uid,vn,self.asset_dir,pct)
                if proposed_name is not None:
                    db.finalize_staged_project(pid,uid,proposed_name)
                self.root.after(0,lambda:self._application_apply_ok(result))
            except Exception as exc:self.root.after(0,lambda e=exc:self._application_apply_fail(e))
            finally:
                if db:db.close()
        threading.Thread(target=worker,daemon=True).start()

    def _finalize_committed_staged_project(self):
        """Recovery if saving the project name failed after Apply committed."""
        name=self._request_staged_project_name()
        if name is False or name is None:return
        try:
            self.db.finalize_staged_project(self.project.id,self.user.id,name)
            self.project=self.db.get_project(self.project.id)
            self.goto('results')
        except Exception as exc:messagebox.showerror('Project Name',str(exc),parent=self.root)

    def _application_apply_ok(self,result):
        self.project=self.db.get_project(self.project.id);self.active_version_no=int(result['version_no']);self.metrics=result['metrics'];self.application_selected_percent=int(result['percent']);self.application_selection_context=(int(self.project.id),int(result['version_no']));self.application_preview_candidate=None;self.application_preview_accepted=None;self.application_preview_metrics=None;self.surface_cache={};self.surface_display_cache=None
        messagebox.showinfo('Apply Changes','Accepted candidate committed. Use Build It to export it.')
        self.goto('results')

    def _application_apply_fail(self,e):
        if hasattr(self,'application_apply_btn'):self.application_apply_btn.state(['!disabled'])
        messagebox.showerror('Apply Changes',str(e))

    def _build_application_section(self,b):
        payload=self._application_payload()
        if not payload:return
        v=self._active_version();self.application_buttons={};self.application_checks={}
        stored=int(round(float(v['application_percent'] or 0))) if v else 0
        default_pct=stored if int(v['run_completed'] or 0) and str(stored) in payload.get('levels',{}) else 50
        if str(default_pct) not in payload.get('levels',{}):default_pct=50
        self.application_selected_percent=default_pct
        outer,inner=self.card(b,20,13);outer.pack(fill='x',pady=(10,0))
        controls=tk.Frame(inner,bg='white');controls.pack(fill='x')
        full_var=tk.BooleanVar(value=default_pct==50);half_var=tk.BooleanVar(value=default_pct==25)
        self.application_checks={50:full_var,25:half_var}
        def choose(pct):
            var=self.application_checks[pct]
            if not var.get():
                var.set(True);return
            other=25 if pct==50 else 50
            self.application_checks[other].set(False)
            payload_now=self._application_payload() or {}
            if pct==25 and '25' not in payload_now.get('levels',{}):
                self._prepare_reduced_application_preview();return
            self._set_application_preview(pct)
        full_cb=ttk.Checkbutton(controls,text='  Apply full correction?',variable=full_var,command=lambda:choose(50));full_cb.pack(side='left',padx=(0,24))
        half_cb=ttk.Checkbutton(controls,text='  Reduce by half (%)',variable=half_var,command=lambda:choose(25));half_cb.pack(side='left',padx=(0,24))
        self.application_apply_btn=ttk.Button(controls,text='Apply Changes',style='Primary.TButton',command=self._apply_selected_changes);self.application_apply_btn.pack(side='left')
        self.build_it_btn=ttk.Button(controls,text='Build It',style='Primary.TButton',command=self.show_build_outputs)
        self.build_it_btn.pack(side='left',padx=(12,0))
        self._update_build_it_gate()
        self.application_check_widgets={50:full_cb,25:half_cb}
        if int(v['run_completed'] or 0) or (self.user and self.user.role=='guest'):
            self.application_apply_btn.state(['disabled']);full_cb.state(['disabled']);half_cb.state(['disabled'])
            if int(v['run_completed'] or 0) and self.db.is_staged_project(self.project.id):
                ttk.Button(controls,text='Name Project',style='Primary.TButton',
                           command=self._finalize_committed_staged_project).pack(side='left',padx=(10,0))
        self.application_preview_host=tk.Frame(b,bg=C['bg']);self.application_preview_host.pack(fill='both',expand=True,pady=(10,0));self._set_application_preview(default_pct)

    def _run_quality_source_model(self):
        payload=self._application_payload() or {}
        metrics={}
        level=(payload.get('levels') or {}).get('50') or {}
        mp=level.get('metrics_json')
        if mp:
            try:metrics=json.loads(Path(mp).read_text(encoding='utf-8'))
            except Exception:metrics={}
        source=(metrics.get('correction_source') or payload.get('correction_source') or self.correction_source_selection)
        method=str(metrics.get('method_id') or payload.get('method_id') or '')
        if not source and method==processing.METHOD_ID:source='adaptive'
        source_label={'adaptive':'LTFT+STFT','wideband':'Wideband O2','combined':'Combined Adaptive + Wideband'}.get(source,'Not selected')
        pf=self.correction_preflight_cache or payload.get('preflight') or {}
        cfg=pf.get('configuration') or {}
        model=metrics.get('airflow_model') or payload.get('airflow_model') or cfg.get('airflow_model')
        if not model and method==processing.METHOD_ID:model='neural_network'
        model_label={'neural_network':'Neural Network','speed_density':'Speed Density VE Tables'}.get(model,'Unknown')
        # Method B keeps the same internal `adaptive` source ID, but the
        # selected mode is stored independently from Method A. Prefer the
        # actual completed result over preflight; an unknown mode must NEVER
        # be advertised as LTFT+STFT without evidence.
        if source=='adaptive' and model=='speed_density':
            mode=(metrics.get('trim_mode') or
                  ((pf.get('sources') or {}).get('adaptive') or {}).get('mode'))
            source_label='LTFT+STFT' if mode=='ltft_plus_stft' else 'STFT'
        return source,source_label,model,model_label,pf,metrics

    def _run_quality_preflight_text(self,source,pf):
        sources=(pf or {}).get('sources') or {}
        ad=sources.get('adaptive') or {};wbq=sources.get('wideband') or {}
        if source=='adaptive':
            b1=int(ad.get('accepted_events_bank1',0) or 0);b2=int(ad.get('accepted_events_bank2',0) or 0)
            return f'B1 {b1:,} / B2 {b2:,}' if (b1 or b2) else 'Validated'
        if source=='wideband':
            n=int(wbq.get('dual_gate_updates',0) or 0)
            return f'{n:,} PE-gated' if n else 'Validated'
        if source=='combined':
            b1=int(ad.get('accepted_events_bank1',0) or 0);b2=int(ad.get('accepted_events_bank2',0) or 0);w=int(wbq.get('dual_gate_updates',0) or 0)
            return f'B1 {b1:,} / B2 {b2:,} / WB {w:,}' if (b1 or b2 or w) else 'Validated'
        return 'Pending'

    def _run_quality_set(self,key,value):
        var=self.run_quality_vars.get(key)
        if var is not None:var.set(str(value))

    def _append_run_quality_activity(self,pct,title,detail):
        """Report each stage independently; only the header tracks overall percent.

        A stage is marked 100% only on transition to the next stage, or
        after successful completion. Partial solver iterations must not be
        presented as partially completed processes after the run finishes.
        """
        title=str(title)
        done=(title=='Processing complete')
        prior=getattr(self,'_run_quality_active_stage',None)
        if prior and (done or prior!=title):
            for index in range(len(self.run_quality_activity_lines)-1,-1,-1):
                if self.run_quality_activity_lines[index].startswith('WORKING  ' + prior):
                    self.run_quality_activity_lines[index]='COMPLETE 100%  '+prior
                    break
            self._run_quality_active_stage=None
        if done:
            self.run_quality_activity_lines.append('OVERALL 100%  Processing complete — '+str(detail))
        else:
            if title!=self._run_quality_active_stage:
                self._run_quality_active_stage=title
                self.run_quality_activity_lines.append('WORKING  '+title)
            # Intermediate percentages belong to the overall bar, not the
            # completed-stage summary. Detail is displayed in the header.
        self.run_quality_activity_lines=self.run_quality_activity_lines[-32:]
        self._refresh_progress_activity()

    def _update_run_quality_from_metrics(self,metrics,status='COMPLETE'):
        metrics=metrics or {}
        self._run_quality_set('accepted',f"{int(metrics.get('accepted',0) or 0):,}")
        self._run_quality_set('qualified',f"{int(metrics.get('qualifying_cells',0) or 0):,}")
        self._run_quality_set('minimum_hits',f"≥{int(metrics.get('minimum_hits',processing.MIN_HITS) or processing.MIN_HITS)}")
        passed=metrics.get('verification_passed')
        if passed is None:passed=(int(metrics.get('qualifying_bank_issues',0) or 0)==0 and bool(metrics))
        self._run_quality_set('verification','PASS' if passed else ('FAIL' if metrics else 'Pending'))
        self._run_quality_set('status',status)

    def _build_run_quality_panel(self,parent,results_ready=False):
        source,source_label,model,model_label,pf,metrics=self._run_quality_source_model()
        outer=tk.Frame(parent,bg=SETUP_NAVY_DARK,highlightbackground=SETUP_BORDER,highlightthickness=1)
        outer.pack(fill='both',expand=True,pady=(6,0))
        hdr=tk.Frame(outer,bg=SETUP_NAVY);hdr.pack(fill='x',padx=0,pady=(0,5))
        tk.Label(hdr,text='Processing Quality',bg=SETUP_NAVY,fg='white',font=('Microsoft Sans Serif',11,'bold')).pack(side='left',padx=12,pady=5)
        tk.Label(hdr,text='Live processing status and data-quality results',bg=SETUP_NAVY,fg=SETUP_SKY,font=('Microsoft Sans Serif',8)).pack(side='right',padx=10)
        self.run_quality_vars={k:tk.StringVar(value='') for k in ('source','model','preflight','minimum_hits','accepted','qualified','verification','status')}
        values={
            'source':source_label,'model':model_label,'preflight':self._run_quality_preflight_text(source,pf),
            'minimum_hits':f'≥{processing.MIN_HITS}','accepted':'Pending','qualified':'Pending','verification':'Pending',
            'status':'WORKING' if self.running else ('COMPLETE' if results_ready else 'READY')}
        for k,v in values.items():self.run_quality_vars[k].set(v)
        grid=tk.Frame(outer,bg=SETUP_NAVY_DARK);grid.pack(fill='x',padx=8,pady=(0,5))
        cards=[('Correction source','source','Selected quantitative correction source'),('Airflow model','model','Active VE representation'),('Preflight data','preflight','Usable source events detected before processing'),('Minimum hits','minimum_hits','Qualification threshold per modeled cell'),('Accepted samples','accepted','Events retained by the active processing method'),('Qualified cells','qualified','Modeled cells/targets meeting qualification'),('Verification','verification','Candidate integrity and scope verification'),('Run status','status','Current processing state')]
        for idx,(title,key,desc) in enumerate(cards):
            r,c=divmod(idx,8)
            cell=tk.Frame(grid,bg=SETUP_NAVY_DARK,highlightbackground=SETUP_BORDER,highlightthickness=1)
            cell.grid(row=r,column=c,sticky='nsew',padx=(0 if c==0 else 3,0))
            grid.grid_columnconfigure(c,weight=1,uniform='quality')
            tk.Label(cell,text=title,bg=SETUP_NAVY_DARK,fg=SETUP_SKY,
                font=('Microsoft Sans Serif',8)).pack(anchor='w',padx=6,pady=(5,2))
            tk.Label(cell,textvariable=self.run_quality_vars[key],bg=SETUP_NAVY_DARK,fg='white',
                font=('Microsoft Sans Serif',9,'bold'),wraplength=130,justify='left').pack(anchor='w',padx=6)
            tk.Label(cell,text=desc,bg=SETUP_NAVY_DARK,fg=SETUP_SKY,
                font=('Microsoft Sans Serif',7),wraplength=130,justify='left').pack(anchor='w',padx=6,pady=(1,4))
        # Progress and its event log live in upper-right panel. Never duplicate.
        self.run_quality_activity_widget=getattr(self,'setup_progress_log',None)
        if results_ready and metrics:
            self._update_run_quality_from_metrics(metrics,'COMPLETE')
            if not self.run_quality_activity_lines or not self.run_quality_activity_lines[-1].startswith('OVERALL 100%'):
                self.run_quality_activity_lines.append('OVERALL 100%  Processing complete — Stored result loaded and verified.')
                self.run_quality_activity_lines=self.run_quality_activity_lines[-12:]
        elif not self.running and not self.run_quality_activity_lines:
            self.run_quality_activity_lines=['OVERALL   0%  Ready — Processing continues automatically; respond to prompts when required.']
        self._refresh_progress_activity()


    def _run_trim_fill(self,value):
        v=max(-RUN_TRIM_COLOR_SPAN,min(RUN_TRIM_COLOR_SPAN,float(value)))
        if abs(v)<1e-12:return '#FFFFFF'
        if v>0:return _blend('#FFFFFF','#F04438',v/RUN_TRIM_COLOR_SPAN)
        return _blend('#FFFFFF','#12A150',abs(v)/RUN_TRIM_COLOR_SPAN)

    def _build_run_trim_chart(self,parent):
        outer=tk.Frame(parent,bg='white',highlightbackground=C['border'],highlightthickness=1)
        outer.pack(fill='both',expand=True,pady=(14,0))
        hdr=tk.Frame(outer,bg='white');hdr.pack(fill='x',padx=14,pady=(10,4))
        tk.Label(hdr,text='Current corrected fuel trims',bg='white',fg=C['text'],font=('Microsoft Sans Serif',11,'bold')).pack(side='left')
        tk.Label(hdr,text='Red = positive  •  Green = negative  •  Scale ±40',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8)).pack(side='right')
        self.run_trim_canvas=tk.Canvas(outer,bg='white',highlightthickness=0,height=485)
        self.run_trim_canvas.pack(fill='both',expand=True,padx=8,pady=(0,8))
        self.run_trim_canvas.bind('<Configure>',lambda _e:self._draw_run_trim_chart())
        self.root.after_idle(self._draw_run_trim_chart)

    def _update_run_trim_chart(self,snapshot):
        if snapshot is None:return
        self.run_trim_chart_data=snapshot
        self._draw_run_trim_chart()

    def _draw_run_trim_chart(self):
        c=self.run_trim_canvas
        if c is None:return
        try:
            if not c.winfo_exists():return
        except Exception:return
        c.delete('all')
        w=max(760,int(c.winfo_width() or 0));h=max(420,int(c.winfo_height() or 0))
        left,top,right,bottom=62,50,10,10
        snap=self.run_trim_chart_data or {}
        rpm_axis=tuple(snap.get('rpms') or RUN_TRIM_RPM_AXIS);pr_axis=tuple(snap.get('pratios') or RUN_TRIM_PR_AXIS)
        cols=len(rpm_axis);rows=len(pr_axis)
        gw=max(1.0,w-left-right);gh=max(1.0,h-top-bottom);cw=gw/cols;ch=gh/rows
        c.create_text(left+gw/2,12,text='Engine RPM (rpm)',fill=C['text'],font=('Microsoft Sans Serif',10,'bold'),anchor='n')
        c.create_text(14,top+gh/2,text='Pressure Ratio',fill=C['text'],font=('Microsoft Sans Serif',9,'bold'),angle=90)
        for j,rpm in enumerate(rpm_axis):
            x=left+(j+.5)*cw
            c.create_text(x,34,text=f'{float(rpm):.0f}',fill=C['text'],font=('Microsoft Sans Serif',7),anchor='center')
        for i,pr in enumerate(pr_axis):
            y=top+(i+.5)*ch
            label=f'{float(pr):.2f}'
            c.create_text(left-5,y,text=label,fill=C['text'],font=('Microsoft Sans Serif',7),anchor='e')
        cells=(self.run_trim_chart_data or {}).get('cells',{})
        font_size=7 if cw<48 or ch<22 else 8
        for i in range(rows):
            y0=top+i*ch;y1=y0+ch
            for j in range(cols):
                x0=left+j*cw;x1=x0+cw;value=cells.get((i,j))
                fill=self._run_trim_fill(value) if value is not None else '#FFFFFF'
                c.create_rectangle(x0,y0,x1,y1,fill=fill,outline='#AEB6C2',width=1)
                if value is not None:
                    c.create_text((x0+x1)/2,(y0+y1)/2,text=f'{float(value):.3f}',fill=C['text'],font=('Microsoft Sans Serif',font_size))

    def _stop_run_trim_watch(self):
        if self._run_trim_watch_stop is not None:self._run_trim_watch_stop.set()
        self._run_trim_watch_stop=None;self._run_trim_watch_thread=None

    def _start_run_trim_watch(self,conditioned_path:Path):
        # The completed bank-event snapshot is delivered by execute_review. Partial
        # file reads must not change eligibility counts or trigger processing gates.
        self._stop_run_trim_watch()

    def _correction_context(self):
        if not self.project:return None
        av=self._active_version()
        if not av:return None
        return (int(self.project.id),int(av['version_no']),str(av['baseline_htt_sha256'] or ''),str(av['log_sha256'] or ''))

    def _run_correction_preflight(self,force=False):
        if self.correction_preflight_running:return
        if not self.project:return
        av=self._active_version()
        if not av or not self.db.version_setup_complete(self.project.id,int(av['version_no'])):
            messagebox.showinfo('Correction Preflight','Complete Setup and select a qualified Log File first.');self.goto('setup');return
        context=self._correction_context()
        if not force and self.correction_preflight_cache is not None and self.correction_preflight_context==context:return
        self.correction_preflight_running=True
        self._set_setup_panel_message('Correction Preflight',
                                      'Checking the selected Tune File and Log File for correction requirements.',requires_action=False)
        self._show_working_overlay('Correction preflight', 'Checking Tune File and Log File correction requirements.')
        baseline=Path(av['baseline_htt_path']);log_path=Path(av['log_local_path'])
        def task():
            try:
                return ('ok',wideband.build_correction_preflight(
                    log_path,baseline,delay_ms=60,closed_loop_only=version_closed_loop_only(av),
                    hardware_review_approved=False))
            except KeyError as e:
                detail=str(e).strip("'\"")
                return ('error',
                    'Correction Preflight found a calibration record that is required for this specific check but is not stored in the selected Full Engine .htt. '
                    'This is a calibration compatibility issue, not a Log File failure. '+detail)
            except Exception as e:
                return ('error',str(e))
        def done(result):
            self.correction_preflight_running=False;self._hide_working_overlay()
            if result[0]!='ok':
                self._cancel_auto_submit()
                self.correction_preflight_cache=None
                self._set_setup_panel_message('Correction Preflight Error',result[1])
                return
            previous_context=self.correction_preflight_context
            self.correction_preflight_cache=result[1];self.correction_preflight_context=context;self.correction_rescale_approved=False
            choices={x['id']:x for x in result[1].get('choices',[])}
            config=result[1].get('configuration') or {}
            model=config.get('airflow_model')
            if model:self._record_processing_fact('Airflow model',
                'Speed Density VE Tables' if model=='speed_density' else 'Neural Network' if model=='neural_network' else model)
            adaptive=(result[1].get('sources') or {}).get('adaptive') or {}
            b1,b2=adaptive.get('accepted_events_bank1'),adaptive.get('accepted_events_bank2')
            if b1 is not None and b2 is not None:
                self._record_processing_fact('Trim events',f'Bank 1: {int(b1):,}; Bank 2: {int(b2):,}')
            enabled=[k for k in ('adaptive','wideband') if choices.get(k,{}).get('enabled')]
            if len(enabled)==1:
                self.correction_source_selection=enabled[0]
            elif previous_context!=context or self.correction_source_selection not in enabled:
                # Two qualified sources require an explicit choice for each
                # new Tune File/Log File; refreshing the same context preserves it.
                self.correction_source_selection=None
            self._show_preflight_prompt()
            if self.current_page=='setup' and self._setup_lower_mode=='preflight':
                self._render_setup_lower_view()
            if self._auto_submit_active:
                self.root.after_idle(self._auto_advance_preflight)
        self._run_background_task(task,done)

    def _show_preflight_prompt(self):
        """Present the qualified correction source without MAP hardware prompts."""
        self._show_correction_source_message()

    def _show_correction_source_message(self):
        """Offer a source choice only when BOTH correction paths qualify.

        One available source is selected automatically and processing resumes.
        Do not display an unavailable Wideband option or its failure message
        when qualified adaptive trims are the only correction source.
        """
        pf=self.correction_preflight_cache or {}
        items={row['id']:row for row in pf.get('choices',[])
               if row.get('id') in ('adaptive','wideband')}
        valid=[sid for sid in ('adaptive','wideband') if items.get(sid,{}).get('enabled')]
        if self.correction_source_selection not in valid:
            self.correction_source_selection=(valid[0] if len(valid)==1 else None)

        def build(parent):
            if len(valid)==2:
                choices=tk.StringVar(value=self.correction_source_selection or '')
                self.correction_source_var=choices
                for sid in valid:
                    row=tk.Frame(parent,bg='white');row.pack(fill='x',pady=(5,2))
                    radio=ttk.Radiobutton(row,text=items[sid].get('label',sid),value=sid,
                        variable=choices,command=lambda key=sid:self._select_correction_source(key))
                    radio.pack(anchor='w')
            elif not valid:
                details=(pf.get('airflow_map_preflight') or {}).get('issues') or []
                failure=('MAP/Pressure Model: '+'; '.join(str(v) for v in details)
                         if details else 'No correction source qualifies; review Processing Quality below.')
                tk.Label(parent,text=failure,
                    bg='white',fg=C['danger'],font=('Microsoft Sans Serif',10),
                    wraplength=460,justify='left').pack(anchor='w',pady=(5,8))
            # The Continue action uses the fixed Vehicle Info button.
            self.correction_continue_button=self.setup_workflow_button

        map_issues=(pf.get('airflow_map_preflight') or {}).get('issues') or []
        if len(valid)==2:
            message='Both correction sources are qualified. Select the source for this correction pass.'
        elif len(valid)==1:
            selected_label = items[valid[0]].get('label', valid[0])
            primary = (pf.get('sources', {}).get('wideband') or {}).get('channel_name')
            source_detail = f' ({primary})' if valid[0] == 'wideband' and primary else ''
            message = (f'{selected_label}{source_detail} qualified and selected automatically. '
                       'Processing will continue without another button click.')
        elif map_issues:
            message='MAP/Pressure Model preflight requires review. Processing cannot continue.'
        else:
            message='No correction source qualifies for this Log File.'
        self._set_setup_panel_message('CORRECTION SOURCE',message,builder=build,
                                      requires_action=(len(valid)!=1))

    def _run_selected_correction(self):
        """The final qualified correction-source action starts the review directly.

        A second click must not schedule another solver. Keep the existing
        readiness, MAP/PE and correction-source gates in start_review().
        """
        if (getattr(self,'running',False) or getattr(self,'correction_preflight_running',False) or
                getattr(self,'_correction_launch_pending',False) or
                getattr(self,'_setup_build_in_progress',False)):
            return
        # A queued second Run event can arrive after the background worker has
        # committed the V1 candidate. A completed run is not a missing Setup.
        if self._review_result_ready():
            self.goto('review',record_history=False)
            return
        reason=self._review_source_block_reason()
        if reason:
            self._set_setup_panel_message('CORRECTION SOURCE',reason)
            return
        self._correction_launch_pending=True
        try:
            # Rendering the review panel is necessary to establish its progress
            # and Results widgets before the already accepted worker is started.
            self.goto('review')
            if self.current_page=='setup' and self._setup_lower_mode=='review':
                self.start_review()
        finally:
            self._correction_launch_pending=False

    def _select_correction_source(self,source_id):
        if source_id not in ('adaptive','wideband'):
            return
        self.correction_source_selection=str(source_id)
        if source_id != 'wideband':self.correction_rescale_approved=False
        if self.current_page=='setup' and self._setup_lower_mode=='preflight':self._render_setup_lower_view()
        self._show_correction_source_message()
        self._update_setup_workflow_action()

    def _approve_correction_rescale(self):
        """Method B calibration-derived axes do not require a separate prompt."""
        self.correction_rescale_approved = True

    def page_preflight(self,host=None):
        inline=host is not None
        b=tk.Frame(host,bg=C['bg']) if inline else self._watermark_frame(self.content,24,16)
        if inline:
            b.pack(fill='both',expand=True,padx=4,pady=6)
            header=tk.Frame(b,bg=C['bg']);header.pack(fill='x',pady=(0,10))
            tk.Label(header,text='Correction Preflight',bg=C['bg'],fg=C['text'],font=('Microsoft Sans Serif',13,'bold')).pack(side='left')
            # Refresh/Run share the fixed Vehicle Info workflow button.
        else:
            self.header(b,'Correction Preflight','Validate correction inputs and calibration-domain coverage before processing.')
            self._set_header_action('Refresh Preflight',lambda:self._run_correction_preflight(force=True))
        av=self._active_version()
        if not self.project or not av or not self.db.version_setup_complete(self.project.id,int(av['version_no'])):
            o,i=self.card(b,20,18);o.pack(fill='x');self.pill(i,'SETUP REQUIRED','warn').pack(anchor='w');tk.Label(i,text='Complete Setup and select a qualified Log File before Correction Preflight.',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w',pady=(10,8));ttk.Button(i,text='Go to Setup',style='Primary.TButton',command=lambda:self.goto('setup')).pack(anchor='w');return
        context=self._correction_context()
        if self.correction_preflight_context!=context:self.correction_preflight_cache=None;self.correction_source_selection=None;self.correction_rescale_approved=False
        if self.correction_preflight_cache is None:
            o,i=self.card(b,20,18);o.pack(fill='x');tk.Label(i,text='Analyzing current tune and Log File...',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w');tk.Label(i,text='This checks the selected airflow model, recorded correction inputs and RPM/PRatio coverage.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=820,justify='left').pack(anchor='w',pady=(6,0))
            if not self.correction_preflight_running:self.root.after(40,self._run_correction_preflight)
            return
        pf=self.correction_preflight_cache;cfg=pf.get('configuration',{});src=pf.get('sources',{});domain=pf.get('domain_preflight') or {};airmap=pf.get('airflow_map_preflight') or {}
        # Keep the primary navigation action visible at the top of a long NN preflight.
        # If exactly one correction source is valid, select it defensively even when
        # the cached preflight was restored without passing through the async done() path.
        choices={x['id']:x for x in pf.get('choices',[])}
        enabled_sources=[k for k in ('adaptive','wideband') if choices.get(k,{}).get('enabled')]
        if self.correction_source_selection not in enabled_sources:
            self.correction_source_selection=(enabled_sources[0] if len(enabled_sources)==1 else None)
        selected=self.correction_source_selection
        can_continue=bool(selected and choices.get(selected,{}).get('enabled'))
        o,i=self.card(b,20,14);o.pack(fill='x',pady=(0,10));tk.Label(i,text='CALIBRATION / AIRFLOW MODEL',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w')
        nn_enabled=(cfg.get('airflow_model')=='neural_network')
        model_label='Neural Network airflow model active' if nn_enabled else 'Speed Density VE tables active'
        status_row=tk.Frame(i,bg='white');status_row.pack(fill='x',pady=(5,2))
        tk.Label(status_row,text=('Neural Network: ENABLED' if nn_enabled else 'Neural Network: DISABLED'),bg='white',fg=C['text'],font=('Microsoft Sans Serif',13,'bold')).pack(side='left')
        self.pill(status_row,('NN ACTIVE' if nn_enabled else 'SPEED DENSITY'),'ok' if nn_enabled else 'info').pack(side='right')
        tk.Label(i,text=model_label,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(0,2))
        if cfg.get('airflow_model_warning'):
            tk.Label(i,text=str(cfg.get('airflow_model_warning')),bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=860,justify='left').pack(anchor='w',pady=(2,2))
        if cfg.get('airflow_model')=='speed_density':tk.Label(i,text='Wideband corrections map directly to the active fixed-size VE tables. Table scaling is checked before any correction.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=820,justify='left').pack(anchor='w')
        else:tk.Label(i,text='Wideband corrections use the active NN training domain and the quantized all-layer solver.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=820,justify='left').pack(anchor='w')
        # User decisions/controls are displayed only in the upper-right
        # message pane; the lower preflight shows calibration evidence.

        def source_row(title,status,detail,kind='ok'):
            o2,i2=self.card(b,18,11);o2.pack(fill='x',pady=(0,7));row=tk.Frame(i2,bg='white');row.pack(fill='x');tk.Label(row,text=title,bg='white',fg=C['text'],font=('Microsoft Sans Serif',10,'bold')).pack(side='left');self.pill(row,status,kind).pack(side='right');tk.Label(i2,text=detail,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=880,justify='left').pack(anchor='w',pady=(5,0))

        def fmt_optional(value,decimals):
            """Preflight display: unknown/missing hardware data is not zero."""
            try:
                v=float(value)
                return f'{v:.{decimals}f}' if math.isfinite(v) else 'No Data'
            except (TypeError,ValueError,OverflowError):
                return 'No Data'

        if airmap:
            m1=airmap.get('map1') or {};m2=airmap.get('map2') or {};tm=airmap.get('throttle_based_map_multiplier') or {}
            auto_fix=bool(airmap.get('auto_fix_required'));blocked=bool(airmap.get('blocking'))
            if blocked:air_status,air_kind='REVIEW REQUIRED','warn'
            elif auto_fix:air_status,air_kind='AUTO PREP','warn'
            else:air_status,air_kind='PASS','ok'
            map_detail=(f"Observed MAP max {fmt_optional(airmap.get('observed_map_max_kpa'),2)} kPa  •  "
                        f"Operating PRatio max {fmt_optional(airmap.get('observed_pratio_max'),3)}  •  "
                        f"logged Baro {fmt_optional(airmap.get('logged_baro_median_kpa'),2)} kPa (PRatio only)  •  "
                        f"sea-level MAP baseline {fmt_optional(airmap.get('sea_level_reference_kpa',101.325),3)} kPa")
            source_row('MAP / Pressure Model Preflight',air_status,map_detail,air_kind)
            sensor_detail=(f"MAP1 {m1.get('sensor_class') or 'No Data'} / "
                           f"{fmt_optional(m1.get('full_scale_kpa'),1)} kPa full scale / "
                           f"{fmt_optional(m1.get('sea_level_boost_capacity_psi'),1)} psi sea-level boost capacity  •  "
                           f"MAP2 {m2.get('sensor_class') or 'No Data'} / "
                           f"{fmt_optional(m2.get('full_scale_kpa'),1)} kPa full scale / "
                           f"{fmt_optional(m2.get('sea_level_boost_capacity_psi'),1)} psi sea-level boost capacity")
            source_row('MAP Sensor Scaling','PASS' if airmap.get('map_sensors_covering_observed_range') else 'REVIEW',sensor_detail,'ok' if airmap.get('map_sensors_covering_observed_range') else 'warn')
            route_detail=(f"Pressure Ratio Max {airmap.get('pressure_ratio_max')}"
                          f"{' → '+str(airmap.get('recommended_pressure_ratio_max')) if airmap.get('pressure_ratio_max_change_required') else ''}  •  "
                          f"Sensed MAP {airmap.get('sensed_map_enable') or 'Unknown'} (unchanged)  •  "
                          f"Stored threshold {airmap.get('sensed_map_pratio_threshold')}")
            source_row('Pressure Model Routing','AUTO PREP' if auto_fix else ('REVIEW' if blocked else 'PASS'),route_detail,'warn' if auto_fix or blocked else 'ok')
            if tm:
                tm_detail=(f"TMAP Multiplier: RPM axis to {fmt_optional(tm.get('rpm_axis_max'),0)}, "
                           f"applicable observed {fmt_optional(tm.get('observed_rpm_max'),0)}; "
                           f"airflow axis to {fmt_optional(tm.get('airflow_axis_max_gps'),1)} g/s, "
                           f"applicable observed {fmt_optional(tm.get('observed_airflow_max_gps'),1)} g/s  •  {tm.get('coverage_basis','')}")
                tm_status,tm_kind=(
                    ('REVIEW REQUIRED','warn') if not tm.get('airflow_covered',True) else
                    ('RPM AXIS NOTICE','info') if tm.get('rpm_endpoint_advisory') else
                    ('PASS','ok')
                )
                source_row('Throttle Based MAP Multiplier',tm_status,tm_detail,tm_kind)
            for item in airmap.get('auto_actions',[]):
                source_row('Automatic Airflow Preparation','PASS' if airmap.get('automatic_change_allowed') else 'FAIL',str(item),'ok' if airmap.get('automatic_change_allowed') else 'warn')
            for item in airmap.get('issues',[]):
                source_row('Airflow Calibration Issue','REVIEW REQUIRED',str(item),'warn')
            for item in airmap.get('warnings',[]):
                source_row('Airflow Calibration Warning','REVIEW',str(item),'warn')

        engine_review=pf.get('engine_review') or {}
        if engine_review:
            mr=engine_review.get('map_source') or {}
            knock=engine_review.get('knock_retard') or {}
            st=knock.get('short_term') or {}
            description=(f"MAP > Barometric Pressure observations: {mr.get('exceeds_baro',0):,}. "
                         f"PRatio > {engine_review.get('boost_review_pratio_threshold',1.06):.2f} samples: {mr.get('boost_pratio_hits',0):,}. "
                         f"Sensed MAP switch: {(engine_review.get('tune') or {}).get('sensed_map_switch') or 'Not available'}. "
                         f"Short Term Knock Retard: {'No Data' if not st.get('present') else str(st.get('max'))+' '+str(st.get('unit',''))}; goal 0°.")
            # Logged boost is evidence, not an installation or hardware identity
            # verification.  Pressure-transfer validity is checked separately.
            review_status='OBSERVED' if engine_review.get('boost_review_required') else 'AVAILABLE'
            source_row('Boost / MAP / WOT Review',review_status,description,'ok')
            # The Review button and its pending/completed state are displayed
            # at the top of Correction Preflight, not buried below other checks.

        ad=src.get('adaptive',{});ad_label=('Short Term Fuel Trims (STFT)' if ad.get('mode')=='stft_only' else 'Adaptive Fuel Trims (LTFT + STFT)')
        ad_detail=(f"Accepted events: Bank 1 {ad.get('accepted_events_bank1',0):,}  •  Bank 2 {ad.get('accepted_events_bank2',0):,}" if ad.get('valid') else str(ad.get('reason') or 'Not available.'))
        if not ad.get('valid') and ad.get('missing'):
            display_names={'fuel_flow':'Fuel Flow Rate','stft_b1':'STFT Bank 1','stft_b2':'STFT Bank 2',
                           'ltft_b1':'LTFT Bank 1','ltft_b2':'LTFT Bank 2','ect':'Engine Coolant Temp',
                           'map':'MAP','baro':'Barometric Pressure','rpm':'Engine RPM',
                           'torque':'Actual Torque','fa':'FA Enrichment','pe':'FA Power Enrichment'}
            ad_detail='Required input missing: '+', '.join(display_names.get(k,k) for k in ad['missing'])
        trim_ch=ad.get('stft_channels') or {}
        stft_updates=ad.get('stft_updates') or {}
        stft_available=bool(ad.get('stft_data_available'))
        if stft_available:
            mode_note=('LTFT + STFT' if ad.get('mode')=='ltft_plus_stft' else 'STFT only')
            ad_detail=(f"{mode_note} selected; STFT Bank 1 {stft_updates.get('bank1',0):,} updates; "
                       f"Bank 2 {stft_updates.get('bank2',0):,} updates.  •  "+ad_detail)
        if trim_ch.get('bank1') and trim_ch.get('bank2'):
            ad_detail+=f"  •  Selected STFT: Bank 1 {trim_ch['bank1']}; Bank 2 {trim_ch['bank2']}"
        ad_status='PASS' if ad.get('valid') else ('AVAILABLE' if stft_available else 'FAIL')
        source_row(ad_label,ad_status,ad_detail,'ok' if ad_status!='FAIL' else 'warn')
        nb=src.get('narrowband',{})
        if nn_enabled:
            source_row('Upstream Narrowband O2','VALID / DIAGNOSTIC' if nb.get('valid') else ('PRESENT / INVALID' if nb.get('present') else 'NOT LOGGED'),(f'Raw narrowband voltage is used as a health/diagnostic signal. Quantitative closed-loop correction uses LTFT + STFT for this airflow model.' if nb.get('valid') else str(nb.get('reason') or 'Not available.')), 'ok' if nb.get('valid') else 'warn')
        wbs=src.get('wideband',{})
        if nn_enabled or wbs.get('present'):
            wb_detail=(f"{wbs.get('channel_name') or 'Wideband O2'}  •  {wbs.get('wideband_updates',0):,} recorded updates  •  Valid PE samples: {wbs.get('dual_gate_updates',0):,}"
                       if wbs.get('processor_ready') else str(wbs.get('processor_error') or wbs.get('reason') or 'Not available.'))
            if wbs.get('secondary_channel_name'):
                wb_detail += (f"  •  {wbs['secondary_channel_name']} also logged, but not used "
                              "by the existing single-stream correction method.")
            source_row('Wideband O2','VALID' if wbs.get('processor_ready') else ('PRESENT / INVALID' if wbs.get('present') else 'NOT LOGGED'),wb_detail, 'ok' if wbs.get('processor_ready') else 'warn')
        maf=src.get('maf',{});mp=maf.get('primary') or {};maf_detail=(f"{mp.get('name','MAF')}  •  {mp.get('updates',0):,} updates  •  range {mp.get('minimum')} to {mp.get('maximum')} {mp.get('unit','')}" if maf.get('present') else 'No MAF channel was logged.')
        if maf.get('reason'):maf_detail+='  '+str(maf['reason'])
        if nn_enabled:
            source_row('Mass Airflow Reference','VALID' if maf.get('valid') else ('PRESENT / INVALID' if maf.get('present') else 'NOT LOGGED'),maf_detail,'ok' if maf.get('valid') else 'warn')

        if cfg.get('airflow_model')=='speed_density' and domain:
            needs=bool(domain.get('needs_rescale'))
            blocking=bool(domain.get('blocking'))
            detail=str(domain.get('message') or '')
            source_row('Speed Density VE Axis Scaling',
                       'FAIL' if blocking else ('AUTO RESCALE' if needs else 'PASS'),
                       detail,'warn' if blocking or needs else 'ok')
        elif wbs.get('processor_ready') and domain:
            source_row('Wideband NN Training Domain',
                       'PARTIAL COVERAGE' if domain.get('needs_rescale') else 'PASS',
                       str(domain.get('message') or ''),
                       'warn' if domain.get('needs_rescale') else 'ok')

        # The correction-source radio buttons and Run action are hosted
        # in the dynamic right panel. Do not duplicate them in this scroll pane.

    def _scroll_preflight_to_options(self):
        if self.correction_preflight_cache is None:return
        if self.current_page=='setup' and self._setup_lower_mode=='preflight':
            canvas=getattr(self,'setup_processing_scroll',None)
        elif self.current_page=='preflight':canvas=self.page_canvas
        else:return
        if canvas is None:
            return
        try:
            if not canvas.winfo_exists():
                return
            canvas.update_idletasks()
            canvas.yview_moveto(1.0)
        except tk.TclError:
            pass

    def _review_source_block_reason(self):
        """Reject a selected correction source when its latest preflight is unresolved."""
        pf=self.correction_preflight_cache or {}
        selected=self.correction_source_selection
        if selected == 'combined':
            return 'Wideband and fuel trims must be processed separately. Select STFT or Wideband O2.'
        choices={item.get('id'):item for item in pf.get('choices',[])}
        choice=choices.get(selected) if selected else None
        if not choice:
            return 'Complete Correction Preflight and select a qualified correction source.'
        if not choice.get('enabled'):
            return str(choice.get('reason') or 'The selected correction source is not qualified.')
        return None

    def page_review(self,host=None):
        inline=host is not None
        b=tk.Frame(host,bg=C['bg']) if inline else self._watermark_frame(self.content,24,14)
        if inline:b.pack(fill='both',expand=True,padx=4,pady=6)
        st=self.state()
        if self.correction_preflight_context!=self._correction_context():
            self.correction_preflight_cache=None;self.correction_source_selection=None;self.correction_rescale_approved=False
        results_ready=(st['state'] in ('READY_TO_APPLY','READY_FOR_REVIEW') and self._application_payload() is not None)
        if not results_ready and not self.running and self.correction_preflight_cache is not None and self.correction_source_selection:
            reason=self._review_source_block_reason()
            if reason:
                messagebox.showwarning('Correction Preflight',reason)
                self.goto('preflight',record_history=False)
                return
        if self.running:
            run_text='Working';run_command=self.start_review
        elif results_ready:
            run_text='Results';run_command=lambda:self.goto('results')
        elif self.project and (self.correction_preflight_cache is None or not self.correction_source_selection):
            run_text='Correction Preflight';run_command=lambda:self.goto('preflight')
        elif self.project:
            run_text='Run';run_command=self.start_review
        else:
            run_text='Create or Open Project First';run_command=lambda:self.goto('setup')
        if inline:
            # Review Run/Results is the same physical button as Submit/Build.
            # The right pane shows live progress unless a real decision interrupts it.
            self.run_btn=self.setup_workflow_button
            if results_ready:
                heading='REVIEW COMPLETE'
                body='Processing and verification completed. Select Results to review the candidate.'
            elif self.running:
                heading='RUN / REVIEW'
                body='Processing the selected correction workflow.'
            else:
                heading='RUN / REVIEW'
                body='Review the correction source and select Continue if a decision is required.'
            self._set_setup_panel_message(heading,body,requires_action=False)
            self._update_setup_workflow_action()
        else:
            self._set_header_action(run_text,run_command)
            self.run_btn=self.header_page_action
        if self.running:self.run_btn.state(['disabled'])
        # The upper-right activity strip replaces the old inline review
        # progress card completely, including its empty border.
        if host is None:
            o,i=self.card(b,18,10);o.pack(fill='x')
        if results_ready:
            self.progress.set(100);self.run_title.set('Ready');self.run_detail.set('Review complete. Select Results to continue.');self.run_pct.set('COMPLETE • 100%');self.run_elapsed.set('')
        elif self.correction_source_selection:
            label={'adaptive':('Short Term Fuel Trims (STFT)' if ((self.correction_preflight_cache or {}).get('sources',{}).get('adaptive',{}).get('mode')=='stft_only') else 'Adaptive Fuel Trims (LTFT + STFT)'),'wideband':'Wideband O2','combined':'Combined Closed Loop + Wideband'}.get(self.correction_source_selection,self.correction_source_selection)
            self.run_title.set('Ready');self.run_detail.set(f'Correction source: {label}.');self.run_pct.set('');self.run_elapsed.set('')
        # The main three-panel Setup has one persistent progress strip in the
        # upper-right panel. Do not duplicate the same stage,
        # percent and progress bar inside the scrolling Run / Review details.
        # Standalone review screens retain their own progress widgets.
        if host is None:
            top=tk.Frame(i,bg='white');top.pack(fill='x')
            tk.Label(top,textvariable=self.run_title,bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(side='left')
            tk.Label(top,textvariable=self.run_pct,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(side='right')
            self.run_progressbar=ttk.Progressbar(i,variable=self.progress,maximum=100,mode='determinate',style='Horizontal.TProgressbar')
            self.run_progressbar.pack(fill='x',pady=(8,5))
            detail_row=tk.Frame(i,bg='white');detail_row.pack(fill='x')
            tk.Label(detail_row,textvariable=self.run_detail,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=760,justify='left').pack(side='left',fill='x',expand=True,anchor='w')
            tk.Label(detail_row,textvariable=self.run_elapsed,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(side='right',anchor='n',padx=(12,0))
        else:
            self.run_progressbar=None
        self._build_run_quality_panel(b,results_ready=results_ready)
        if not results_ready and self.user.role=='guest':self.run_btn.state(['disabled']);self.run_detail.set('Guest role is view-only.')
    def _review_setup(self):
        if self.choose_output():self.goto('review')

    def _review_result_ready(self):
        """A stored candidate/completed V0+ review must never be run a second time.

        Run callbacks can remain queued while the worker commits and moves the
        version from READY_TO_RUN to READY_TO_APPLY / READY_FOR_REVIEW.  Those
        are successful states, not missing or unqualified Log File states.
        Confirm that a usable stored payload actually exists before treating
        either state as complete; incomplete records must still fail closed.
        """
        if not getattr(self,'project',None):
            return False
        return (self.state().get('state') in ('READY_TO_APPLY','READY_FOR_REVIEW')
                and self._application_payload() is not None)

    def start_review(self):
        # Check single-flight before touching the database: a late button event
        # may arrive while a V1 worker is committing its candidate/result.
        if self.running or getattr(self,'_setup_build_in_progress',False):return
        if not self._operation_allowed():return
        if self._review_result_ready():
            # Preserve REVIEW COMPLETE / Results if it is already on screen.
            # Otherwise refresh that panel, never show the false Setup dialog.
            if not (self.current_page=='setup' and self._setup_lower_mode=='review'
                    and (self.setup_panel_message or {}).get('heading')=='REVIEW COMPLETE'):
                self.goto('review',record_history=False)
            return
        av=self._active_version()
        if not self.project or not av or self.state().get('state')!='READY_TO_RUN' or not self.db.version_setup_complete(self.project.id,int(av['version_no'])):
            # Real setup failures still block the review; use the established
            # right-panel messages instead of a modal unrelated to the result.
            self._setup_lower_mode='status'
            self.goto('setup',record_history=False)
            self._set_setup_panel_message('SETUP REQUIRED',
                'Select the current project version and a qualified Log File before running the review.')
            return
        if self.correction_preflight_context!=self._correction_context() or self.correction_preflight_cache is None or not self.correction_source_selection:
            messagebox.showinfo('Correction Preflight','Complete Correction Preflight and select a correction source before running.');self.goto('preflight');return
        if self.running or not self.project or self.user.role=='guest':return
        reason=self._review_source_block_reason()
        if reason:
            messagebox.showwarning('Correction Preflight',reason)
            self.goto('preflight')
            return
        source_id=self.correction_source_selection
        if source_id == 'wideband':
            cfg=self.correction_preflight_cache.get('configuration',{});domain=self.correction_preflight_cache.get('domain_preflight') or {}
        self.run_quality_activity_lines=[];self._run_quality_last_activity=None;self._run_quality_active_stage=None;self._progress_activity_times={}
        self._refresh_progress_activity()
        self._record_processing_fact('Optimization method',
            'Method B — Speed Density' if ((self.correction_preflight_cache or {}).get('configuration') or {}).get('airflow_model')=='speed_density' else 'Method A — Neural Network')
        source=self.correction_source_selection
        if source=='adaptive':
            trim=((self.correction_preflight_cache or {}).get('sources') or {}).get('adaptive') or {}
            method=((self.correction_preflight_cache or {}).get('configuration') or {}).get('airflow_model')
            title='STFT' if method=='speed_density' and trim.get('mode')!='ltft_plus_stft' else 'LTFT+STFT'
        else:title='Wideband O2' if source=='wideband' else str(source or 'Unselected')
        self._record_processing_fact('Correction source',title)
        self.running=True;self._review_started_at=time.monotonic();self.progress.set(0);self.run_title.set('Prepare review');self.run_detail.set('Preparing the selected correction workflow.');self.run_pct.set('STEP 1 OF 5 • 0%');self.run_elapsed.set('Elapsed: 00:00');self._set_progress_mode('determinate');self._schedule_elapsed_update();self.run_btn.state(['disabled']);self._start_working_blink();self._set_setup_activity('Prepare review','Preparing the selected correction workflow.',percent=0,step=1,total=5,busy=True);self._run_quality_set('status','WORKING');self._run_quality_set('accepted','Pending');self._run_quality_set('qualified','Pending');self._run_quality_set('verification','Pending');self._append_run_quality_activity(0,'Prepare review','Preparing the selected correction workflow.');pid=self.project.id;uid=self.user.id;dbp=self.db.path;vn=int(av['version_no'])
        def cb(v,t,d):self.root.after(0,lambda:self._set_progress(v,t,d))
        def abort_check():return bool(self._run_trim_abort_event and self._run_trim_abort_event.is_set())
        def worker():
            db=None
            try:
                db=ReviewDatabase(dbp)
                if source_id=='adaptive':
                    airflow_model=((self.correction_preflight_cache or {}).get('configuration') or {}).get('airflow_model')
                    if airflow_model=='speed_density':result=execute_adaptive_sd_review(db,pid,uid,self.asset_dir,cb,version_no=vn)
                    else:result=execute_review(db,pid,uid,self.asset_dir,cb,version_no=vn,abort_check=abort_check)
                elif source_id=='wideband':result=execute_wideband_review(db,pid,uid,self.asset_dir,cb,version_no=vn,rescale_approved=self.correction_rescale_approved,delay_ms=60)

                else:raise ValueError('Select a correction source in Correction Preflight.')
                try:db.record_version_performance(pid,vn,uid)
                except (OSError,ValueError,KeyError,AttributeError):pass  # Auxiliary metrics do not gate tuning.
                self.root.after(0,lambda:self._review_ok(result))
            except Exception as e:self.root.after(0,lambda x=e:self._review_fail(x))
            finally:
                if self._run_trim_watch_stop is not None:self._run_trim_watch_stop.set()
                if db:db.close()
        threading.Thread(target=worker,daemon=True).start()
    def _set_progress_mode(self,mode):
        bar=self.run_progressbar
        if not bar:
            self._progress_mode=mode;return
        try:
            if not bar.winfo_exists():self._progress_mode=mode;return
            if self._progress_mode=='indeterminate':bar.stop()
            bar.configure(mode=mode,maximum=100)
            self._progress_mode=mode
            if mode=='indeterminate':bar.start(12)
        except Exception:
            self._progress_mode=mode
    def _start_working_blink(self):
        """Keep processing action visibly disabled without blinking."""
        self._stop_working_blink(reset=False)
        try:
            if self.run_btn and self.run_btn.winfo_exists():
                self.run_btn.config(text='Processing')
                self.run_btn.state(['disabled'])
        except Exception:pass

    def _stop_working_blink(self,reset=True):
        if self._run_blink_after_id is not None:
            try:self.root.after_cancel(self._run_blink_after_id)
            except Exception:pass
            self._run_blink_after_id=None
        self._run_blink_on=False
        if reset:
            try:
                if self.run_btn and self.run_btn.winfo_exists():self.run_btn.config(text='Run')
            except Exception:pass

    def _schedule_elapsed_update(self):
        if not self.running or self._review_started_at is None:return
        elapsed=max(0,int(time.monotonic()-self._review_started_at));mins,secs=divmod(elapsed,60);hours,mins=divmod(mins,60)
        self.run_elapsed.set((f'Elapsed: {hours:d}:{mins:02d}:{secs:02d}' if hours else f'Elapsed: {mins:02d}:{secs:02d}'))
        self._elapsed_after_id=self.root.after(1000,self._schedule_elapsed_update)
    def _set_progress(self,v,t,d):
        # Ignore a late worker notification after the completion state is set.
        if not self.running and self.run_pct.get().startswith('COMPLETE'):return
        self.run_title.set(t);self.run_detail.set(d);self._set_progress_mode('determinate')
        pct=max(0,min(100,int(round(float(v)))))
        self.progress.set(pct)
        step_map={'Prepare review':1,'Wideband preflight':1,'Prepare pressure model':2,'Rescale VE tables':2,'Condition selected Log File':2,'Process wideband':3,'Process combined sources':3,'Build candidate':4,'Fit Neural Network':4,'Validate candidate':4,'Write & store results':5}
        step=step_map.get(t,1)
        self.run_pct.set(f'OVERALL {pct}% • STEP {step} OF 5')
        self._set_setup_activity(t,d,percent=pct,step=step,total=5,busy=True)
        self._run_quality_set('status','WORKING')
        self._append_run_quality_activity(pct,t,d)
    def _review_ok(self,result):
        # Submit runs automatically, but a verified candidate STOPS at the dyno
        # workspace. The user decides when to open Results using the fixed button.
        self._stop_run_trim_watch()
        self.running=False
        self._stop_working_blink(reset=False)
        self._set_progress_mode('determinate')
        self.project=self.db.get_project(self.project.id)
        self.active_version_no=int(result.get('version_no',self.active_version_no or 0))
        self.metrics=result['metrics']
        self.fixed_metrics={}
        self.application_selected_percent=None
        self.application_preview_candidate=None
        self.application_preview_accepted=None
        self.application_preview_metrics=None
        self.surface_cache={}
        self.surface_display_cache=None
        self.progress.set(100)
        self.run_title.set('Ready')
        self.run_detail.set('Review complete. Examine the dyno graph, then select Results.')
        self.run_pct.set('COMPLETE • 100%')
        self._update_run_quality_from_metrics(result.get('metrics') or {},'COMPLETE')
        result_metrics=result.get('metrics') or {}
        quality=[]
        for key,label in (('accepted','accepted events'),('qualifying_cells','qualifying cells')):
            if key in result_metrics and result_metrics[key] is not None:
                quality.append(f'{int(result_metrics[key]):,} {label}')
        if quality:self._record_processing_fact('Candidate quality','; '.join(quality))
        self._append_run_quality_activity(100,'Processing complete',
                                          'Candidate verified. Examine the dyno graph, then select Results.')
        self._refresh_performance_summary()
        self._set_setup_activity('Processing complete','All five stages completed. Candidate verified.',
                                 percent=100,step=5,total=5,busy=False)
        self._cancel_auto_submit()
        self.root.after(150,self._show_completed_dyno_after_run)

    def _show_completed_dyno_after_run(self):
        if self._review_result_ready():
            self.goto('review',record_history=False)
        else:
            self._set_setup_panel_message('PROCESSING ERROR',
                'Processing completed without a verified candidate. Review the result before continuing.')
    def _review_fail(self,e):
        self._cancel_auto_submit()
        self._stop_run_trim_watch();self.running=False;self._stop_working_blink();self._set_progress_mode('determinate');self.run_title.set('Review stopped');self.run_detail.set(str(e));self.run_pct.set('ERROR');self._run_quality_set('verification','FAIL');self._run_quality_set('status','FAILED');self._append_run_quality_activity(self.progress.get(),'Processing stopped',str(e));self._set_setup_activity('Processing stopped',str(e),percent=self.progress.get(),busy=False,error=True)
        self._set_setup_panel_message('PROCESSING ERROR',str(e))
        self._update_setup_workflow_action()
    def _build_wideband_results(self,b,payload):
        v=self._active_version();method=payload.get('method_id');level=payload.get('levels',{}).get('50',{})
        try:m=json.loads(Path(level['metrics_json']).read_text(encoding='utf-8'))
        except Exception:m={}
        self.application_selected_percent=50;self.application_selection_context=(int(self.project.id),int(v['version_no'])) if self.project and v else None
        source=m.get('correction_source') or payload.get('correction_source') or 'wideband';model=m.get('airflow_model') or payload.get('airflow_model') or 'unknown'
        title='Combined Adaptive + Wideband' if source=='combined' else 'Wideband O2'
        o,i=self.card(b,22,16);o.pack(fill='x');row=tk.Frame(i,bg='white');row.pack(fill='x');self.pill(row,'VERIFIED','ok').pack(side='left');tk.Label(row,text=f'  {title}',bg='white',fg=C['text'],font=('Microsoft Sans Serif',13,'bold')).pack(side='left')
        tk.Label(i,text=('Neural Network' if model=='neural_network' else 'Speed Density VE Tables'),bg='white',fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(anchor='w',pady=(12,3));tk.Label(i,text="Power Enrichment tables unchanged  •  VE correction step: 50%",bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w')
        cards=tk.Frame(b,bg=C['bg']);cards.pack(fill='x',pady=(12,0))
        vals=[('Accepted samples',f"{int(m.get('accepted',0)):,}",'Events used by the selected correction source',False),('Qualified cells',f"{int(m.get('qualifying_cells',0)):,}",'Cells/NN targets meeting ≥5-hit qualification',True),('Airflow model','NN' if model=='neural_network' else '17×17 SD',('Quantized NN fit' if model=='neural_network' else 'Fixed PCM VE-table dimensions retained'),True),('Verification','PASS','Candidate integrity and scope checks passed',True)]
        for z,args in enumerate(vals):self.metric(cards,*args).pack(side='left',fill='both',expand=True,padx=(0 if z==0 else 6,0))
        if m.get('rescaled'):
            res=payload.get('rescale') or {};o2,i2=self.card(b,18,12);o2.pack(fill='x',pady=(12,0));self.pill(i2,'VE TABLE RESCALED','warn').pack(anchor='w');tk.Label(i2,text=f"RPM {float(res.get('old_rpm_min',0)):.0f}–{float(res.get('old_rpm_max',0)):.0f} → {float(res.get('new_rpm_min',0)):.0f}–{float(res.get('new_rpm_max',0)):.0f}; PRatio {float(res.get('old_pratio_min',0)):.4f}–{float(res.get('old_pratio_max',0)):.4f} → {float(res.get('new_pratio_min',0)):.4f}–{float(res.get('new_pratio_max',0)):.4f}. MAP1 / Maximum RPM from .htt; fixed table size, interpolated VE surface.",bg='white',fg=C['text'],font=('Microsoft Sans Serif',9),wraplength=860,justify='left').pack(anchor='w',pady=(8,0))
        pf=payload.get('preflight') or {};maf=pf.get('sources',{}).get('maf',{});mp=maf.get('primary') or {}
        o3,i3=self.card(b,18,12);o3.pack(fill='x',pady=(12,0));tk.Label(i3,text='PREFLIGHT NOTES',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w');maf_text=('Valid airflow reference' if maf.get('valid') else ('Present but unusable' if maf.get('present') else 'Not logged'));tk.Label(i3,text=f"MAF: {maf_text}"+(f" — {mp.get('name')} range {mp.get('minimum')} to {mp.get('maximum')} {mp.get('unit','')}" if mp else ''),bg='white',fg=C['text'],font=('Microsoft Sans Serif',9),wraplength=860,justify='left').pack(anchor='w',pady=(6,0));tk.Label(i3,text='Narrowband O2 voltage remains diagnostic; LTFT+STFT are the quantitative closed-loop source. PE wideband data use both FA Enrichment and FA Power Enrichment gates.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=860,justify='left').pack(anchor='w',pady=(4,0))
        actions=tk.Frame(b,bg=C['bg']);actions.pack(fill='x',pady=(14,4));self.application_apply_btn=ttk.Button(actions,text='Apply Changes',style='Primary.TButton',command=self._apply_selected_changes);self.application_apply_btn.pack(side='left');self.build_it_btn=ttk.Button(actions,text='Build It',style='Primary.TButton',command=self.show_build_outputs);self.build_it_btn.pack(side='left',padx=(8,0))
        if int(v['run_completed'] or 0) or (self.user and self.user.role=='guest'):self.application_apply_btn.state(['disabled'])
        self._update_build_it_gate()

    def page_results(self):
        b=self._watermark_frame(self.content,28,24);st=self.state();payload=self._application_payload()
        if st['state']=='HISTORICAL_RESULT':
            o,i=self.card(b,24,24);o.pack(fill='x');tk.Label(i,text='Historical result from a superseded processing method.',bg='white',fg=C['text']).pack(anchor='w');return
        if st['state'] not in ('READY_TO_APPLY','READY_FOR_REVIEW') or payload is None:
            o,i=self.card(b,24,24);o.pack(fill='x');self.pill(i,'NOT RUN YET','warn').pack(anchor='w');tk.Label(i,text='Run the selected correction workflow to generate the reviewer summary and candidate output.',bg='white',fg=C['text'],font=('Microsoft Sans Serif',13,'bold')).pack(anchor='w',pady=(13,6));ttk.Button(i,text='Go to Correction Preflight',style='Primary.TButton',command=lambda:self.goto('preflight')).pack(anchor='w',pady=(8,0));return
        # Wideband/combined results intentionally use the same Results surface
        # and controls as the accepted NN workflow.  The active airflow model
        # determines whether the familiar viewer opens on NN or the actual
        # Speed Density VE tables.
        self._build_application_section(b)

    def _build_output_sources(self):
        if not self.project:
            raise ValueError('Select or create a project first.')
        v=self._active_version()
        if not v:
            raise ValueError('Stored results are unavailable for this version.')
        ready,reason=build_it_application_gate(v,self.application_selected_percent)
        if not ready:raise ValueError(reason)

        mode=self.license_status().get('mode')
        processed=mode in ('licensed','trial')
        if processed:
            htt=Path(str(v['export_htt_path'] or ''))
            expected=str(v['export_htt_sha256'] or '').strip().upper()
            missing='Stored HP Tuners-compatible .htt result is unavailable.'
        else:
            htt=Path(str(v['baseline_htt_path'] or ''))
            expected=str(v['baseline_htt_sha256'] or '').strip().upper()
            missing='Stored input .htt is unavailable for DEMO output.'
        if not htt.is_file():raise FileNotFoundError(missing)
        if expected and s5.sha256_file(htt).upper()!=expected:
            raise ValueError('Stored .htt source failed its integrity check.')

        display=str(self.db.project_display_name(self.project.id) or self.project.name or 'VE_Optimizer').strip()
        base=performance_export_stem(display,int(v['version_no']))
        return base,htt,mode

    def _build_output_files(self,destination_or_file):
        base,htt,mode=self._build_output_sources()
        target=Path(destination_or_file).expanduser()
        # Retain directory-call compatibility for automated tests and internal callers.
        if target.suffix.lower()!='.htt':
            target.mkdir(parents=True,exist_ok=True)
            target=target/f'{base}.htt'
        else:
            target.parent.mkdir(parents=True,exist_ok=True)
        if os.path.abspath(str(htt))!=os.path.abspath(str(target)):
            shutil.copy2(htt,target)
        if s5.sha256_file(target)!=s5.sha256_file(htt):
            raise ValueError('Built .htt failed byte-for-byte integrity verification.')
        return [target],mode,htt

    def _complete_build_lineage(self,demo_baseline=None):
        """Finalize the current result and guarantee its blank successor after Build It."""
        if not self.project or not self.user:raise ValueError('Select or create a project first.')
        v=self._active_version()
        if not v:raise ValueError('Project version not found.')
        pid=int(self.project.id);uid=int(self.user.id);vn=int(v['version_no']);next_no=vn+1
        ready,reason=build_it_application_gate(v,self.application_selected_percent)
        if not ready:raise ValueError(reason)
        promote_db=None
        try:
            promote_db=ReviewDatabase(Path(self.db.path))
            fresh=promote_db.get_version(pid,vn)
            ready,reason=build_it_application_gate(fresh,self.application_selected_percent)
            if not ready:raise ValueError(reason)
            next_v=promote_db.create_successor_after_build(pid,vn,uid,baseline_source=demo_baseline)
            verified=promote_db.get_version(pid,next_no)
            if not verified or int(verified['version_no'])!=next_no:
                raise RuntimeError(f'Build It completed the output copy but V{next_no} was not created. Project lineage was not advanced.')
            if int(next_v['version_no'])!=next_no:raise RuntimeError(f'Build It returned an unexpected successor version. Expected V{next_no}.')
        finally:
            if promote_db is not None:
                try:promote_db.close()
                except Exception:pass
        self.db.conn.commit();check=self.db.get_version(pid,next_no)
        if not check:raise RuntimeError(f'V{next_no} was created but could not be reloaded by the application. Reopen Projects before continuing.')
        self.project=self.db.get_project(pid)
        return {'built_version_no':vn,'next_version_no':next_no,'committed_now':False}

    def show_build_outputs(self):
        if self.user and self.user.role=='guest':
            messagebox.showinfo('Read-only','Guest users cannot build output files.');return
        try:
            base,_,mode=self._build_output_sources()
        except Exception as e:
            messagebox.showerror('Build It',str(e));return
        w=tk.Toplevel(self.root);w.title('Build It');w.configure(bg=C['bg']);w.transient(self.root);w.grab_set();w.resizable(False,False)
        card=tk.Frame(w,bg='white',highlightbackground=C['border'],highlightthickness=1);card.pack(padx=18,pady=18,fill='both',expand=True)
        tk.Label(card,text='Build Output File',bg='white',fg=C['text'],font=('Microsoft Sans Serif',15,'bold')).pack(anchor='w',padx=22,pady=(20,5))
        if mode=='licensed':status='Licensed: the processed VE changes will be written to the .htt output.'
        elif mode=='trial':status='3-Day Trial: the processed VE changes will be written to the .htt output.'
        else:status='DEMO: the .htt output will be an exact byte-for-byte copy of the input .htt.'
        tk.Label(card,text=status,bg='white',fg=C['text'],font=('Microsoft Sans Serif',9),wraplength=520,justify='left').pack(anchor='w',padx=22,pady=(0,10))
        tk.Label(card,text=f'{base}.htt',bg='white',fg=C['muted'],font=('Consolas',9)).pack(anchor='w',padx=24,pady=5)
        actions=tk.Frame(card,bg='white');actions.pack(fill='x',padx=22,pady=(16,20))
        ttk.Button(actions,text='Cancel',style='Secondary.TButton',command=w.destroy).pack(side='right')
        def go():
            initial=default_build_output_dir()
            target=filedialog.asksaveasfilename(parent=w,title='Save Build Output File',initialdir=str(initial),initialfile=f'{base}.htt',defaultextension='.htt',filetypes=[('HP Tuners Template File','*.htt'),('All files','*.*')],confirmoverwrite=True)
            if not target:return
            try:
                built,built_mode,source=self._build_output_files(Path(target))
                lineage=self._complete_build_lineage(source if built_mode=='demo' else None)
            except Exception as e:
                messagebox.showerror('Build It',str(e),parent=w);return
            w.destroy();next_no=int(lineage['next_version_no'])
            note='' if built_mode!='demo' else '\n\nDEMO verification: output is unchanged from the input .htt.'
            messagebox.showinfo('Build It','Built:\n'+ '\n'.join(str(p) for p in built)+note+f'\n\nV{next_no} is ready. Open V{next_no} and select a new Log File to continue.')
        ttk.Button(actions,text='Go',style='Primary.TButton',command=go).pack(side='right',padx=(0,8))
        self._position_build_output_window(w);w.lift()


    def _surface_baseline_path(self):
        v=self._active_version()
        if not v:raise FileNotFoundError('Stored results are unavailable for this version.')
        payload=self._application_payload() if self.current_page=='results' else None
        if payload and wideband_integration.is_wideband_method(payload.get('method_id')):
            raw=str(payload.get('effective_baseline_htt') or payload.get('baseline_htt') or '')
            p=Path(raw)
            if p.is_file():return p
        return Path(v['baseline_htt_path'])

    def _results_airflow_model(self):
        payload=self._application_payload() if self.current_page=='results' else None
        if payload and wideband_integration.is_wideband_method(payload.get('method_id')):
            return str(payload.get('airflow_model') or ((payload.get('preflight') or {}).get('configuration') or {}).get('airflow_model') or '')
        return 'neural_network'

    def _surface_dataset(self, pair):
        key=(float(pair[0]),float(pair[1]))
        if key not in self.surface_cache:
            if not self.project:raise ValueError('Review project is not configured.')
            v=self._active_version()
            preview_mode=(self.current_page=='results' and self.state()['state'] in ('READY_TO_APPLY','READY_FOR_REVIEW') and self.application_preview_candidate is not None)
            if not v or (not int(v['run_completed']) and not preview_mode):raise FileNotFoundError('Stored results are unavailable for this version.')
            baseline=self._surface_baseline_path()
            candidate=(Path(self.application_preview_candidate) if self.current_page=='results' and self.application_preview_candidate else Path(v['result_htt_path']))
            if not candidate.is_file() or not baseline.is_file():raise FileNotFoundError('Stored version .htt files are unavailable.')
            self.surface_cache[key]=surf.build_surfaces(baseline,candidate,None,key)
        return self.surface_cache[key]

    def _surface_display_maps(self):
        if self.surface_display_cache is None:
            if not self.project:raise ValueError('Review project is not configured.')
            v=self._active_version()
            preview_mode=(self.current_page=='results' and self.state()['state'] in ('READY_TO_APPLY','READY_FOR_REVIEW') and self.application_preview_candidate is not None)
            if not v or (not int(v['run_completed']) and not preview_mode):raise FileNotFoundError('Stored results are unavailable for this version.')
            baseline=self._surface_baseline_path()
            if self.current_page=='results' and self.application_preview_candidate and self.application_preview_accepted:
                candidate=Path(self.application_preview_candidate);accepted=Path(self.application_preview_accepted)
            else:
                candidate=Path(v['result_htt_path']);accepted=Path(v['accepted_csv_path'])
            if not candidate.is_file() or not baseline.is_file():raise FileNotFoundError('Stored version .htt files are unavailable.')
            if not accepted.is_file():raise FileNotFoundError('Stored accepted training data is unavailable for this version.')
            self.surface_display_cache=surf.build_display_maps(baseline,candidate,None,accepted)
        return self.surface_display_cache

    def _surface_speed_density_maps(self):
        if not isinstance(self.surface_display_cache,dict):self.surface_display_cache={}
        maps=self.surface_display_cache
        if '_speed_density' not in maps:
            if not self.project:raise ValueError('Review project is not configured.')
            v=self._active_version()
            preview_mode=(self.current_page=='results' and self.state()['state'] in ('READY_TO_APPLY','READY_FOR_REVIEW') and self.application_preview_candidate is not None)
            if not v or (not int(v['run_completed']) and not preview_mode):raise FileNotFoundError('Stored results are unavailable for this version.')
            baseline=self._surface_baseline_path()
            candidate=(Path(self.application_preview_candidate) if self.current_page=='results' and self.application_preview_candidate else Path(v['result_htt_path']))
            if not candidate.is_file() or not baseline.is_file():raise FileNotFoundError('Stored version .htt files are unavailable.')
            maps['_speed_density']=surf.build_speed_density_maps(baseline,candidate)
        return maps['_speed_density']

    def _current_surface_dataset(self):
        mode=self.surface_map.get() if hasattr(self,'surface_map') else 'combined'
        if mode not in surf.DISPLAY_MAPS:mode='combined'
        fmt=self.surface_format.get() if hasattr(self,'surface_format') else 'neural_network'
        maps=self._surface_speed_density_maps() if fmt=='speed_density' else self._surface_display_maps()
        return maps[mode]

    def _set_surface_format(self,mode):
        active_model=self._results_airflow_model()
        if active_model=='speed_density':mode='speed_density'
        elif mode not in ('neural_network','speed_density'):mode='neural_network'
        self.surface_format.set(mode);self.surface_selected_cell=None;self.surface_selection=None;self.surface_selection_anchor=None
        self._refresh_surface_widgets()

    def _set_surface_map(self,mode):
        if mode not in surf.DISPLAY_MAPS:mode='combined'
        self.surface_map.set(mode);self.surface_selected_cell=None;self.surface_selection=None;self.surface_selection_anchor=None;self._refresh_surface_widgets()

    def _surface_selection_bounds(self,data):
        rows=len(data['pratios']); cols=len(data['rpms'])
        sel=getattr(self,'surface_selection',None)
        if sel is None:
            cell=getattr(self,'surface_selected_cell',None)
            if cell is None:return None
            sel=(cell[0],cell[1],cell[0],cell[1])
        r0,c0,r1,c1=sel
        r0=max(0,min(rows-1,int(r0)));r1=max(0,min(rows-1,int(r1)))
        c0=max(0,min(cols-1,int(c0)));c1=max(0,min(cols-1,int(c1)))
        return min(r0,r1),min(c0,c1),max(r0,r1),max(c0,c1)

    def _update_surface_selection_status(self,data):
        if not hasattr(self,'surface_selection_status'):return
        b=self._surface_selection_bounds(data)
        if b is None:
            self.surface_selection_status.set('No cells selected')
            return
        r0,c0,r1,c1=b; nr=r1-r0+1; nc=c1-c0+1
        self.surface_selection_status.set(f'{nr} x {nc} selected  ({nr*nc} cells)')

    def _surface_select_all(self):
        try:
            data=self._current_surface_dataset()
            self.surface_selection=(0,0,len(data['pratios'])-1,len(data['rpms'])-1)
            self.surface_selection_anchor=(0,0)
            self.surface_selected_cell=(0,0)
            self._update_surface_cell_detail(data);self._update_surface_selection_status(data)
            self._render_surface_selection_overlay(data)
            self.surface_hover.set(f"Selected all {len(data['pratios'])*len(data['rpms'])} cells.")
        except Exception as e:self.surface_hover.set(str(e))

    def _surface_clear_selection(self):
        self.surface_selection=None;self.surface_selection_anchor=None;self.surface_selected_cell=None
        try:
            data=self._current_surface_dataset();self._update_surface_cell_detail(data);self._update_surface_selection_status(data)
            self._render_surface_selection_overlay(data)
            self.surface_hover.set('Selection cleared.')
        except Exception as e:self.surface_hover.set(str(e))

    def _surface_selection_tsv(self,data,view,include_axes):
        b=self._surface_selection_bounds(data)
        if b is None:raise ValueError('Select one or more surface cells first.')
        r0,c0,r1,c1=b; matrix=data[view]; rpms=data['rpms']; pratios=data['pratios']
        pe=(data.get('surface_format')=='pe')
        def fmt(v):
            return f'{float(v):.6f}' if pe else f'{float(v):.3f}'
        lines=[]
        if include_axes:
            y_axis=data.get('y_axis_label','PRatio');x_axis=data.get('x_axis_label','RPM')
            lines.append('\t'.join([f'{y_axis}/{x_axis}']+[f'{rpms[c]:.0f}' for c in range(c0,c1+1)]))
        speed_density=(data.get('surface_format')=='speed_density')
        for r in range(r0,r1+1):
            vals=[fmt(matrix[r][c]) for c in range(c0,c1+1)]
            if include_axes:
                pr_label=(f'{pratios[r]:.0f}' if pe and data.get('pe_table')=='aircharge' else (f'{pratios[r]:.6f}' if pe else (str(pratios[r]) if speed_density else f'{pratios[r]:.2f}')))
                vals=[pr_label]+vals
            lines.append('\t'.join(vals))
        return '\r\n'.join(lines)

    def _surface_copy_selection(self,include_axes):
        try:
            data=self._current_surface_dataset();view=self.surface_view.get()
            text=self._surface_selection_tsv(data,view,include_axes)
            self.root.clipboard_clear();self.root.clipboard_append(text);self.root.update_idletasks()
            b=self._surface_selection_bounds(data);r0,c0,r1,c1=b;cells=(r1-r0+1)*(c1-c0+1)
            kind=(f"with {data.get('x_axis_label','RPM')}/{data.get('y_axis_label','PRatio')} axes" if include_axes else 'values only')
            self.surface_hover.set(f'Copied {cells} {view.title()} cells to clipboard ({kind}).')
        except Exception as e:
            self.surface_hover.set(str(e));messagebox.showwarning('Copy VE Surface',str(e))

    def _update_surface_cell_detail(self,data):
        if not hasattr(self,'surface_cell_vars'):
            return
        selected=getattr(self,'surface_selected_cell',None)
        if selected is None:
            vals={'rpm':'—','pratio':'—','original':'—','new':'—','delta':'—','percent':'—','zone':'Click any cell in the detailed surface.'}
        else:
            r,c=selected
            if not (0<=r<len(data['pratios']) and 0<=c<len(data['rpms'])):
                self.surface_selected_cell=None; return self._update_surface_cell_detail(data)
            rpm=data['rpms'][c]; pr=data['pratios'][r]; o=data['original'][r][c]; n=data['new'][r][c]; d=data['delta'][r][c]
            pct=(d/o*100.0) if o else 0.0
            pe=data.get('surface_format')=='pe'
            pr_text=(f'{pr:.0f}' if data.get('pe_table')=='aircharge' else f'{pr:.6f}') if pe else (str(pr) if data.get('surface_format')=='speed_density' else f'{pr:.2f}')
            zone=(data.get('display_name','PE table') if pe else ('Speed Density 17x17 fit' if data.get('surface_format')=='speed_density' else 'Neural Network 20x20 surface'))
            vals={'rpm':f'{rpm:.0f}','pratio':pr_text,
                'original':(f'{o:.6f} FAR' if pe else f'{o:.3f} VE'),
                'new':(f'{n:.6f} FAR' if pe else f'{n:.3f} VE'),
                'delta':(f'{d:+.6f} FAR' if pe else f'{d:+.3f} VE pt'),
                'percent':f'{pct:+.3f}%', 'zone':zone}
        for k,v in vals.items():
            self.surface_cell_vars[k].set(v)

    def _render_surface_selection_overlay(self,data=None):
        """Redraw only the lightweight selection overlay.

        This intentionally avoids repainting the full active VE surface while
        the mouse is being dragged. Full-surface repaint during <B1-Motion>
        caused visible flashing and made rectangular selection difficult to
        follow.
        """
        if not hasattr(self,'surface_main_canvas'):
            return
        canvas=self.surface_main_canvas
        geom=getattr(self,'surface_grid_geometry',None)
        if geom is None:
            return
        if data is None:
            data=getattr(self,'surface_grid_data',None)
        if data is None:
            return
        left,top,cw,ch=geom
        canvas.delete('selection_overlay')
        bounds=self._surface_selection_bounds(data)
        if bounds is None:
            return
        r0,c0,r1,c1=bounds
        x0=left+c0*cw; y0=top+r0*ch; x1=left+(c1+1)*cw; y1=top+(r1+1)*ch
        canvas.create_rectangle(x0+1,y0+1,x1-1,y1-1,outline='#111827',width=3,tags=('selection_overlay',))
        selected=getattr(self,'surface_selected_cell',None)
        if selected is not None:
            r,c=selected
            if r0<=r<=r1 and c0<=c<=c1:
                sx0=left+c*cw; sy0=top+r*ch; sx1=left+(c+1)*cw; sy1=top+(r+1)*ch
                canvas.create_rectangle(sx0+3,sy0+3,sx1-3,sy1-3,outline=C['accent'],width=2,tags=('selection_overlay',))

    def _draw_surface_3d(self,canvas,data,view):
        """Render the interactive NNT-style VE surface on the existing Tk canvas.

        This is presentation-only. It uses the same active RPM/PRatio data as
        the 2D display.  The surface is raised above a light reference floor and
        the RPM, PRatio, and VE scales follow the visible perimeter of the
        rotated table.  Right-button drag pivots the view without changing any
        VE or neural-network calculation.
        """
        canvas.delete('all'); canvas.update_idletasks()
        width=max(520,int(canvas.winfo_width() or 760))
        height=max(320,int(canvas.winfo_height() or 455))
        rows=[float(v) for v in data['pratios']]
        cols=[float(v) for v in data['rpms']]
        matrix=data[view]
        nr=len(rows); nc=len(cols)
        if not nr or not nc:
            return

        common_min=min(data['stats']['original_min'],data['stats']['new_min'])
        common_max=max(data['stats']['original_max'],data['stats']['new_max'])
        dlim=max(abs(data['stats']['min_delta']),abs(data['stats']['max_delta']),0.001)
        lo,hi=surf.display_range(data,view)
        zspan=max(hi-lo,1e-9)

        # Retain the user's current viewing angle while the viewer is active.
        # Defaults intentionally use a high three-quarter calibration-table view.
        azim=float(getattr(self,'surface_3d_azim',-52.0))
        elev=float(getattr(self,'surface_3d_elev',28.0))
        azim=((azim+180.0)%360.0)-180.0
        elev=max(8.0,min(78.0,elev))
        self.surface_3d_azim=azim
        self.surface_3d_elev=elev

        import math as _m
        ca=_m.cos(_m.radians(azim)); sa=_m.sin(_m.radians(azim))
        pitch=_m.radians(90.0-elev)
        cp=_m.cos(pitch); sp=_m.sin(pitch)

        # Equal sample spacing intentionally matches the 2D NNT-compatible grid.
        xhalf=1.20
        yhalf=0.92
        zheight=1.24

        def logical_xyz(r,c,val=None,zfrac=None):
            x=-xhalf + (2.0*xhalf)*(float(c)/max(nc-1,1))
            y=-yhalf + (2.0*yhalf)*(float(r)/max(nr-1,1))
            if zfrac is None:
                zfrac=(float(val)-lo)/zspan
            z=max(0.0,min(1.0,float(zfrac)))*zheight
            return x,y,z

        def raw_project(x,y,z):
            # Orthographic projection keeps the calibration axes dimensionally
            # stable while the user pivots the table.
            xr=ca*x-sa*y
            yr=sa*x+ca*y
            screen_x=xr
            screen_y=yr*cp-z*sp
            depth=yr*sp+z*cp
            return screen_x,screen_y,depth

        # Reserve extra perimeter space for scale labels instead of forcing the
        # labels inside the mesh as the previous implementation did.
        box_xyz=[]
        for x in (-xhalf,xhalf):
            for y in (-yhalf,yhalf):
                for z in (0.0,zheight):box_xyz.append((x,y,z))
        raw_box=[raw_project(*q) for q in box_xyz]
        minx=min(q[0] for q in raw_box);maxx=max(q[0] for q in raw_box)
        miny=min(q[1] for q in raw_box);maxy=max(q[1] for q in raw_box)
        left=92.0;right=74.0;top=38.0;bottom=88.0
        avail_w=max(180.0,width-left-right);avail_h=max(160.0,height-top-bottom)
        sx_scale=avail_w/max(maxx-minx,1e-9);sy_scale=avail_h/max(maxy-miny,1e-9)
        scale=min(sx_scale,sy_scale)
        used_w=(maxx-minx)*scale;used_h=(maxy-miny)*scale
        ox=left+(avail_w-used_w)/2.0-minx*scale
        oy=top+(avail_h-used_h)/2.0-miny*scale

        def project_xyz(x,y,z):
            rx,ry,dep=raw_project(x,y,z)
            return ox+rx*scale,oy+ry*scale,dep
        def project(r,c,val):
            return project_xyz(*logical_xyz(r,c,val=val))

        def edge_outward(p0,p1):
            """Unit screen-space normal pointing away from the table center."""
            x0,y0=p0; x1,y1=p1
            dx=x1-x0;dy=y1-y0;ln=max(_m.hypot(dx,dy),1e-9)
            nx=-dy/ln;ny=dx/ln
            mx=(x0+x1)/2.0;my=(y0+y1)/2.0
            cx=width/2.0;cy=height/2.0
            if ((mx+nx*20-cx)**2+(my+ny*20-cy)**2) < ((mx-nx*20-cx)**2+(my-ny*20-cy)**2):
                nx=-nx;ny=-ny
            return nx,ny

        def text_anchor(nx,ny):
            if abs(nx)>=abs(ny):return 'w' if nx>0 else 'e'
            return 'n' if ny>0 else 's'

        def readable_angle(p0,p1):
            angle=_m.degrees(_m.atan2(-(p1[1]-p0[1]),p1[0]-p0[0]))
            while angle>90.0:angle-=180.0
            while angle<-90.0:angle+=180.0
            return angle

        # Use the visually lowest floor corner as the near/front corner.  This
        # keeps both horizontal scales on the outside perimeter at every normal
        # viewing angle instead of allowing an axis to cut through the surface.
        floor_corners=[]
        for xi,x in enumerate((-xhalf,xhalf)):
            for yi,y in enumerate((-yhalf,yhalf)):
                px,py,dep=project_xyz(x,y,0.0)
                floor_corners.append((py,dep,xi,yi,x,y,px,py))
        _screen_y,_dep,fxi,fyi,front_x,front_y,_px,_py=max(floor_corners,key=lambda q:(q[0],-q[1]))

        # Light reference floor and grid create the familiar raised-table look
        # without surrounding the surface with a dominant wireframe cube.
        floor_order=[(-xhalf,-yhalf),(xhalf,-yhalf),(xhalf,yhalf),(-xhalf,yhalf)]
        floor_pts=[]
        for x,y in floor_order:
            px,py,_=project_xyz(x,y,0.0);floor_pts.extend((px,py))
        canvas.create_polygon(*floor_pts,fill='#F8FAFC',outline='#CBD5E1',width=1)
        floor_grid='#E2E8F0'
        for c in range(nc):
            x=-xhalf+(2.0*xhalf)*(float(c)/max(nc-1,1))
            p0=project_xyz(x,-yhalf,0.0);p1=project_xyz(x,yhalf,0.0)
            canvas.create_line(p0[0],p0[1],p1[0],p1[1],fill=floor_grid,width=1)
        for r in range(nr):
            y=-yhalf+(2.0*yhalf)*(float(r)/max(nr-1,1))
            p0=project_xyz(-xhalf,y,0.0);p1=project_xyz(xhalf,y,0.0)
            canvas.create_line(p0[0],p0[1],p1[0],p1[1],fill=floor_grid,width=1)

        # Filled surface; paint farther faces first, then restore the dark mesh.
        faces=[]
        for r in range(nr-1):
            for c in range(nc-1):
                verts=((r,c),(r,c+1),(r+1,c+1),(r+1,c))
                vals=[float(matrix[rr][cc]) for rr,cc in verts]
                pts=[];depths=[]
                for (rr,cc),v in zip(verts,vals):
                    px,py,dep=project(rr,cc,v);pts.extend((px,py));depths.append(dep)
                avg=sum(vals)/4.0
                fill=_delta_color(avg,dlim) if view=='delta' else _sequential_color(avg,common_min,common_max)
                faces.append((sum(depths)/4.0,pts,fill))
        for _depth,pts,fill in sorted(faces,key=lambda q:q[0],reverse=True):
            canvas.create_polygon(*pts,fill=fill,outline='',width=0)

        mesh_color='#334155'
        for r in range(nr):
            pts=[]
            for c in range(nc):
                px,py,_=project(r,c,matrix[r][c]);pts.extend((px,py))
            canvas.create_line(*pts,fill=mesh_color,width=1)
        for c in range(nc):
            pts=[]
            for r in range(nr):
                px,py,_=project(r,c,matrix[r][c]);pts.extend((px,py))
            canvas.create_line(*pts,fill=mesh_color,width=1)

        # Corner drop-lines make the VE surface read as raised from the floor.
        post_color='#94A3B8'
        for r,c,x,y in ((0,0,-xhalf,-yhalf),(0,nc-1,xhalf,-yhalf),(nr-1,0,-xhalf,yhalf),(nr-1,nc-1,xhalf,yhalf)):
            bx,by,_=project_xyz(x,y,0.0);tx,ty,_=project(r,c,matrix[r][c])
            canvas.create_line(bx,by,tx,ty,fill=post_color,width=1)

        # Perimeter scales. Tick marks and axis titles project outward from the
        # table, so rotation keeps the numbers around the perimeter rather than
        # over the VE mesh.
        axis_color='#0F172A';tick_color='#475569'

        rpm_p0=project_xyz(-xhalf,front_y,0.0)[:2];rpm_p1=project_xyz(xhalf,front_y,0.0)[:2]
        rnx,rny=edge_outward(rpm_p0,rpm_p1);ranchor=text_anchor(rnx,rny)
        canvas.create_line(*rpm_p0,*rpm_p1,fill=axis_color,width=2)
        for c,rpm in enumerate(cols):
            x=-xhalf+(2.0*xhalf)*(float(c)/max(nc-1,1));px,py,_=project_xyz(x,front_y,0.0)
            canvas.create_line(px,py,px+rnx*5,py+rny*5,fill=axis_color,width=1)
            canvas.create_text(px+rnx*9,py+rny*9,text=f'{rpm:,.0f}',anchor=ranchor,fill=tick_color,font=('Microsoft Sans Serif',6))
        mx=(rpm_p0[0]+rpm_p1[0])/2.0;my=(rpm_p0[1]+rpm_p1[1])/2.0
        canvas.create_text(mx+rnx*31,my+rny*31,text=data.get('x_axis_label','Engine Speed (rpm)'),fill=C['text'],font=('Microsoft Sans Serif',9,'bold'),angle=readable_angle(rpm_p0,rpm_p1))

        pr_p0=project_xyz(front_x,-yhalf,0.0)[:2];pr_p1=project_xyz(front_x,yhalf,0.0)[:2]
        pnx,pny=edge_outward(pr_p0,pr_p1);panchor=text_anchor(pnx,pny)
        canvas.create_line(*pr_p0,*pr_p1,fill=axis_color,width=2)
        for r,pr in enumerate(rows):
            y=-yhalf+(2.0*yhalf)*(float(r)/max(nr-1,1));px,py,_=project_xyz(front_x,y,0.0)
            canvas.create_line(px,py,px+pnx*5,py+pny*5,fill=axis_color,width=1)
            pr_label=(f'{pr:.0f}' if data.get('pe_table')=='aircharge' else f'{pr:.4f}') if data.get('surface_format')=='pe' else (f'{pr:.4f}' if data.get('surface_format')=='speed_density' else f'{pr:.2f}')
            canvas.create_text(px+pnx*9,py+pny*9,text=pr_label,anchor=panchor,fill=tick_color,font=('Microsoft Sans Serif',6))
        mx=(pr_p0[0]+pr_p1[0])/2.0;my=(pr_p0[1]+pr_p1[1])/2.0
        canvas.create_text(mx+pnx*31,my+pny*31,text=data.get('y_axis_label','PRatio'),fill=C['text'],font=('Microsoft Sans Serif',9,'bold'),angle=readable_angle(pr_p0,pr_p1))

        # Keep the VE scale on the left perimeter corner rather than at the
        # meeting point of the RPM/PRatio scales.  This mirrors a calibration
        # table perimeter and prevents the vertical numbers from obscuring the
        # center of the VE mesh.
        z_corner=min(floor_corners,key=lambda q:q[6])
        _zsy,_zdep,_zxi,_zyi,zx,zy,_zpx,_zpy=z_corner
        zbase=project_xyz(zx,zy,0.0)[:2];ztop=project_xyz(zx,zy,zheight)[:2]
        znx,zny=edge_outward(zbase,ztop);zanchor=text_anchor(znx,zny)
        canvas.create_line(*zbase,*ztop,fill=axis_color,width=2)
        zticks=8
        for i in range(zticks+1):
            frac=float(i)/zticks;val=lo+frac*zspan;px,py,_=project_xyz(zx,zy,frac*zheight)
            canvas.create_line(px,py,px+znx*5,py+zny*5,fill=axis_color,width=1)
            canvas.create_text(px+znx*9,py+zny*9,text=f'{val:.3f}',anchor=zanchor,fill=tick_color,font=('Microsoft Sans Serif',6))
        pe=data.get('surface_format')=='pe'
        canvas.create_text(ztop[0]+znx*32,ztop[1]+zny*32-12,
            text=('PE FAR' if view!='delta' else 'Delta PE FAR') if pe else ('VE' if view!='delta' else 'Delta VE'),
            fill=C['text'],font=('Microsoft Sans Serif',9,'bold'))

        nodes=[]
        for r in range(nr):
            for c in range(nc):
                px,py,_=project(r,c,matrix[r][c]);nodes.append((px,py,r,c))
        self.surface_3d_nodes=nodes
        self.surface_3d_axis_bins={'rpms':tuple(cols),'pratios':tuple(rows)}
        self.surface_grid_geometry=None
        self.surface_grid_data=data

        def nearest(ev,limit=15):
            best=None;bestd=limit*limit
            for px,py,r,c in nodes:
                d=(px-ev.x)*(px-ev.x)+(py-ev.y)*(py-ev.y)
                if d<bestd:bestd=d;best=(px,py,r,c)
            return best
        def motion(ev):
            hit=nearest(ev)
            if hit:
                _px,_py,r,c=hit;o=data['original'][r][c];n=data['new'][r][c];d=data['delta'][r][c]
                if pe:
                    self.surface_hover.set(f"RPM {cols[c]:.0f} • {data['y_axis_label']} {rows[r]:.5g} • Old {o:.6f} FAR • New {n:.6f} FAR • Delta {d:+.6f} FAR • Right-drag to pivot")
                else:
                    self.surface_hover.set(f"RPM {cols[c]:.0f}  •  PRatio {(str(rows[r]) if data.get('surface_format')=='speed_density' else f'{rows[r]:.2f}')}  •  Original {o:.3f} VE  •  New {n:.3f} VE  •  Delta {d:+.3f} VE point  •  Right-drag to pivot")
            else:
                self.surface_hover.set('3D VE surface — right-drag anywhere on the table or perimeter scales to pivot; left-click a grid point to select.')
        def press(ev):
            hit=nearest(ev,20)
            if not hit:return
            px,py,r,c=hit
            self.surface_selected_cell=(r,c);self.surface_selection=(r,c,r,c);self.surface_selection_anchor=(r,c)
            self._update_surface_cell_detail(data);self._update_surface_selection_status(data)
            canvas.delete('surface3d_selection')
            canvas.create_oval(px-5,py-5,px+5,py+5,outline=C['accent'],fill='white',width=3,tags=('surface3d_selection',))
        def rotate_start(ev):
            self.surface_3d_drag_anchor=(ev.x,ev.y,float(self.surface_3d_azim),float(self.surface_3d_elev))
            try:canvas.configure(cursor='fleur')
            except Exception:pass
            return 'break'
        def rotate_drag(ev):
            anchor=getattr(self,'surface_3d_drag_anchor',None)
            if not anchor:return 'break'
            ax,ay,a0,e0=anchor
            self.surface_3d_azim=a0+(ev.x-ax)*0.45
            self.surface_3d_elev=max(8.0,min(78.0,e0-(ev.y-ay)*0.35))
            self._draw_surface_3d(canvas,data,view)
            return 'break'
        def rotate_end(_ev):
            self.surface_3d_drag_anchor=None
            try:canvas.configure(cursor='')
            except Exception:pass
            return 'break'

        canvas.bind('<Motion>',motion)
        canvas.bind('<ButtonPress-1>',press)
        canvas.bind('<ButtonPress-3>',rotate_start)
        canvas.bind('<B3-Motion>',rotate_drag)
        canvas.bind('<ButtonRelease-3>',rotate_end)

        selected=getattr(self,'surface_selected_cell',None)
        if selected is not None:
            r,c=selected
            if 0<=r<nr and 0<=c<nc:
                px,py,_=project(r,c,matrix[r][c])
                canvas.create_oval(px-5,py-5,px+5,py+5,outline=C['accent'],fill='white',width=3,tags=('surface3d_selection',))
    def _draw_surface(self,canvas,data,view,preview=False):
        canvas.delete('all'); canvas.update_idletasks()
        width=max(180,int(canvas.winfo_width() or (270 if preview else 760)))
        height=max(110,int(canvas.winfo_height() or (145 if preview else 455)))
        rows=data['pratios']; cols=data['rpms']; matrix=data[view]
        mode='heatmap' if preview else (self.surface_render.get() if hasattr(self,'surface_render') else 'heatmap')
        if preview:
            left,top,right,bottom=8,8,8,8
        else:
            left,top,right,bottom=68,56,14,42
        gw=max(10,width-left-right); gh=max(10,height-top-bottom); cw=gw/len(cols); ch=gh/len(rows)
        common_min=min(data['stats']['original_min'],data['stats']['new_min']); common_max=max(data['stats']['original_max'],data['stats']['new_max'])
        dlim=max(abs(data['stats']['min_delta']),abs(data['stats']['max_delta']),0.001)
        lo,hi=surf.display_range(data,view); band_step=(hi-lo)/8.0 if hi>lo else 1.0
        cell_text=[]
        for r,row in enumerate(matrix):
            for c,val in enumerate(row):
                x0=left+c*cw; y0=top+r*ch; x1=left+(c+1)*cw; y1=top+(r+1)*ch
                shown=val
                if mode=='contour' and not preview:
                    shown=lo+round((val-lo)/band_step)*band_step
                    shown=max(lo,min(hi,shown))
                fill=_delta_color(shown,dlim) if view=='delta' else _sequential_color(shown,common_min,common_max)
                canvas.create_rectangle(x0,y0,x1,y1,fill=fill,outline='#FFFFFF' if preview else '#E7ECF3',width=0 if preview else 1)
                if not preview:
                    # Always show the exact grid value on the detailed surface.
                    # Draw labels after contour isolines so contour geometry never
                    # obscures the underlying numeric map value.
                    pe=data.get('surface_format')=='pe'
                    text=(f'{val:+.6f}' if view=='delta' else f'{val:.6f}') if pe else (f'{val:+.3f}' if view=='delta' else f'{val:.3f}')
                    font_size=6 if pe else (7 if (cw>=34 and ch>=15) else 6)
                    cell_text.append(((x0+x1)/2,(y0+y1)/2,text,_text_for_fill(fill),font_size))

        # In contour mode, overlay interpolated marching-squares isolines.
        if not preview and mode=='contour':
            levels=surf.contour_levels(data,view,9)
            for level in levels:
                zero=(view=='delta' and abs(level)<1e-10)
                color='#FFFFFF' if zero else '#526274'
                width_line=2 if zero else 1
                for (x0g,y0g),(x1g,y1g) in surf.contour_segments(matrix,level):
                    x0=left+(x0g+.5)*cw; y0=top+(y0g+.5)*ch
                    x1=left+(x1g+.5)*cw; y1=top+(y1g+.5)*ch
                    canvas.create_line(x0,y0,x1,y1,fill=color,width=width_line,smooth=True)

        # Exact values stay on top of both heatmap bands and contour lines.
        if not preview:
            for x,y,text,color,font_size in cell_text:
                canvas.create_text(x,y,text=text,fill=color,font=('Microsoft Sans Serif',font_size,'bold'))

        # Selection is tied to the exact NN grid. Store geometry so drag
        # updates can repaint only the selection outline rather than the entire
        # surface. This prevents flicker while the left mouse button is held.
        if not preview:
            self.surface_grid_geometry=(left,top,cw,ch)
            self.surface_grid_data=data
            self._render_surface_selection_overlay(data)

        if not preview:
            for c,rpm in enumerate(cols):
                canvas.create_text(left+(c+.5)*cw,top-8,text=f'{rpm:,.0f}',anchor='s',fill=C['muted'],font=('Microsoft Sans Serif',7))
            for r,pr in enumerate(rows):
                pr_label=(f'{pr:.0f}' if data.get('pe_table')=='aircharge' else f'{pr:.4f}') if data.get('surface_format')=='pe' else (f'{pr:.4f}' if data.get('surface_format')=='speed_density' else f'{pr:.2f}')
                canvas.create_text(left-7,top+(r+.5)*ch,text=pr_label,anchor='e',fill=C['muted'],font=('Microsoft Sans Serif',7))
            canvas.create_text(left+gw/2,height-10,text=f"{data.get('x_axis_label','RPM')}  (columns)",fill=C['text'],font=('Microsoft Sans Serif',9,'bold'))
            canvas.create_text(13,top+gh/2,text=f"{data.get('y_axis_label','PRatio')}  (rows)",angle=90,fill=C['text'],font=('Microsoft Sans Serif',9,'bold'))

            # Spreadsheet-style corner selector at the row/column-header
            # intersection. Clicking it selects the complete active surface.
            corner_size=18
            corner_x0=left-corner_size-8; corner_y0=top-corner_size-7
            corner_x1=left-8; corner_y1=top-7
            canvas.create_rectangle(corner_x0,corner_y0,corner_x1,corner_y1,fill='#F4F7FB',outline=C['border'],width=1,tags=('select_all_corner',))
            canvas.create_polygon(corner_x0+4,corner_y1-4,corner_x1-4,corner_y1-4,corner_x1-4,corner_y0+4,fill='#93A4B8',outline='',tags=('select_all_corner',))

            def in_select_all_corner(ev):
                return corner_x0<=ev.x<=corner_x1 and corner_y0<=ev.y<=corner_y1
            def cell_at(ev):
                c=int((ev.x-left)//cw); r=int((ev.y-top)//ch)
                return (r,c) if 0<=c<len(cols) and 0<=r<len(rows) else None
            def motion(ev):
                if in_select_all_corner(ev):
                    self.surface_hover.set('Select all surface cells.')
                    return
                rc=cell_at(ev)
                if rc:
                    # Avoid repeatedly rewriting the same status text while the
                    # pointer remains inside one cell.
                    if rc==getattr(self,'surface_hover_cell',None):
                        return
                    self.surface_hover_cell=rc
                    r,c=rc; o=data['original'][r][c]; n=data['new'][r][c]; d=data['delta'][r][c]
                    if data.get('surface_format')=='pe':
                        self.surface_hover.set(f"RPM {cols[c]:.0f} • {data['y_axis_label']} {rows[r]:.5g} • Old {o:.6f} FAR • New {n:.6f} FAR • Delta {d:+.6f} FAR")
                    else:
                        self.surface_hover.set(f"RPM {cols[c]:.0f}  •  PRatio {(str(rows[r]) if data.get('surface_format')=='speed_density' else f'{rows[r]:.2f}')}  •  Original {o:.3f} VE  •  New {n:.3f} VE  •  Delta {d:+.3f} VE point")
                else:
                    self.surface_hover_cell=None
            def set_range(anchor,rc):
                ar,ac=anchor;r,c=rc
                self.surface_selection=(min(ar,r),min(ac,c),max(ar,r),max(ac,c))
                self.surface_selected_cell=rc
                self._update_surface_cell_detail(data);self._update_surface_selection_status(data)
                # Lightweight outline-only update: do not repaint the heatmap.
                self._render_surface_selection_overlay(data)
            def press(ev):
                canvas.focus_set()
                if in_select_all_corner(ev):
                    self.surface_drag_anchor=None
                    self.surface_drag_last_cell=None
                    self._surface_select_all()
                    return
                rc=cell_at(ev)
                if rc:
                    shift=bool(ev.state & 0x0001)
                    anchor=getattr(self,'surface_selection_anchor',None) if shift else None
                    if anchor is None:
                        anchor=rc;self.surface_selection_anchor=rc
                    self.surface_drag_anchor=anchor
                    self.surface_drag_last_cell=rc
                    set_range(anchor,rc)
            def drag(ev):
                anchor=getattr(self,'surface_drag_anchor',None);rc=cell_at(ev)
                if anchor is None or rc is None:
                    return
                if rc==getattr(self,'surface_drag_last_cell',None):
                    return
                self.surface_drag_last_cell=rc
                set_range(anchor,rc)
            def release(ev):
                self.surface_drag_anchor=None
                self.surface_drag_last_cell=None
            def select_all_event(ev):
                self._surface_select_all();return 'break'
            def copy_event(ev):
                self._surface_copy_selection(True);return 'break'
            def copy_values_event(ev):
                self._surface_copy_selection(False);return 'break'
            canvas.bind('<Motion>',motion);canvas.bind('<ButtonPress-1>',press);canvas.bind('<B1-Motion>',drag);canvas.bind('<ButtonRelease-1>',release)
            canvas.bind('<Control-a>',select_all_event);canvas.bind('<Control-A>',select_all_event);canvas.bind('<Control-c>',copy_event);canvas.bind('<Control-C>',copy_event);canvas.bind('<Control-Shift-c>',copy_values_event);canvas.bind('<Control-Shift-C>',copy_values_event)

    def _refresh_surface_widgets(self):
        try:
            data=self._current_surface_dataset()
            view=self.surface_view.get()
            dimension=self.surface_dimension.get() if hasattr(self,'surface_dimension') else '2d'
            if dimension=='3d':
                self._draw_surface_3d(self.surface_main_canvas,data,view)
            else:
                self._draw_surface(self.surface_main_canvas,data,view,False)
            for key,can in self.surface_previews.items():self._draw_surface(can,data,key,True)
            s=data['stats'];pe=False;digits=3
            self.surface_stat_vars['min'].set(f"{s['min_delta']:+.{digits}f}"); self.surface_stat_vars['max'].set(f"{s['max_delta']:+.{digits}f}");self.surface_stat_vars['mean'].set(f"{s['mean_delta']:+.{digits}f}");self.surface_stat_vars['protect'].set(f"{s['protected_max_abs']:.{digits}f}")
            for unit in getattr(self,'surface_stat_unit_vars',{}).values():unit.set('FAR adder' if pe else 'VE point')
            picker=getattr(self,'surface_pe_picker',None)
            if picker is not None and picker.winfo_exists():
                if pe and not picker.winfo_manager():picker.pack(side='left',padx=(8,0))
                elif not pe and picker.winfo_manager():picker.pack_forget()
            for key,btn in self.surface_view_buttons.items():btn.config(bg=C['accent'] if key==view else 'white',fg='white' if key==view else C['text'],relief='sunken' if key==view else 'raised')
            if hasattr(self,'surface_dimension_buttons'):
                for key,btn in self.surface_dimension_buttons.items():btn.config(bg=C['accent'] if key==dimension else 'white',fg='white' if key==dimension else C['text'],relief='sunken' if key==dimension else 'raised')
            if hasattr(self,'surface_format_buttons'):
                fmt=self.surface_format.get()
                for key,btn in self.surface_format_buttons.items():btn.config(bg=C['accent'] if key==fmt else 'white',fg='white' if key==fmt else C['text'],relief='sunken' if key==fmt else 'raised')
            if hasattr(self,'surface_basis_note'):
                if data.get('surface_source')=='pcm_speed_density_tables':
                    self.surface_basis_note.set(str(data.get('display_note') or 'Active PCM Speed Density VE table representation.'))
                else:
                    self.surface_basis_note.set(('Speed Density uses exact NN evaluation at the 17x17 workbook breakpoints; no 20x20 interpolation.' if data.get('surface_format')=='speed_density' else 'NN surface sampled across calibration-derived cam references.'))
            if hasattr(self,'surface_cell_label_vars'):
                self.surface_cell_label_vars['rpm'].set(data.get('x_axis_label','RPM'))
                self.surface_cell_label_vars['pratio'].set(data.get('y_axis_label','PRatio'))
            self._update_surface_cell_detail(data);self._update_surface_selection_status(data)
            if dimension=='3d':
                self.surface_hover.set('3D VE surface — right-drag to pivot; left-click a grid point to select.')
            else:
                self.surface_hover.set('Drag to select cells; Shift-click extends. Use the upper-left corner or Ctrl+A to select all; Ctrl+C copies with axes; Ctrl+Shift+C copies values only.')
            self._surface_refresh_error=''
            return True
        except Exception as e:
            self._surface_refresh_error=str(e)
            try:self.surface_hover.set(str(e))
            except Exception:pass
            try:
                can=self.surface_main_canvas;can.delete('all')
                can.create_text(max(20,can.winfo_width()/2),max(20,can.winfo_height()/2),text='VE surface could not be displayed.\n'+str(e),fill=C['danger'],font=('Microsoft Sans Serif',10,'bold'),justify='center',width=max(240,can.winfo_width()-80))
            except Exception:pass
            return False

    def _set_surface_view(self,view):
        self.surface_view.set(view); self._refresh_surface_widgets()

    def _set_surface_dimension(self,dimension):
        self.surface_dimension.set(dimension); self._refresh_surface_widgets()

    def _set_surface_render(self,mode):
        # Retained only for compatibility with older UI state; 2D uses heatmap.
        if hasattr(self,'surface_render'):self.surface_render.set(mode)
        self._refresh_surface_widgets()

    def export_surface_data(self):
        try:
            data=self._current_surface_dataset()
            folder=Path(self.project.output_dir)/DIAG_DIR/'VE Surfaces'
            paths=surf.export_surface_csvs(data,folder)
            self.db.record_event(self.project.id,'VE_SURFACE_EXPORTED',f"Display={data.get('display_name','VE')}; folder={folder}",self.user.id)
            messagebox.showinfo('VE Surface Export',f"{data.get('display_name','VE')} Original, New, and Delta CSV files were written to:\n{folder}")
        except Exception as e:messagebox.showerror('VE Surface Export',str(e))

    def _build_surface_viewer(self,b,include_header=True):
        st=self.state()
        if include_header:self.header(b,'VE Surface Viewer','Calibration-derived average VE surface. RPM, PRatio, and cam references come from the input .htt training domain.')
        if st['state']!='READY_FOR_REVIEW' and not (st['state']=='READY_TO_APPLY' and self.current_page=='results' and self.application_preview_candidate):
            o,i=self.card(b,24,24);o.pack(fill='x');self.pill(i,'RUN/REVIEW FIRST','warn').pack(anchor='w');tk.Label(i,text='Run the selected version before viewing the Original / New / Delta surfaces.',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w',pady=(12,8));ttk.Button(i,text='Go to Run/Review',style='Primary.TButton',command=lambda:self.goto('review')).pack(anchor='w');return

        self.surface_map=tk.StringVar(value=getattr(self,'surface_map',tk.StringVar(value='combined')).get() if hasattr(self,'surface_map') else 'combined')
        if self.surface_map.get() not in surf.DISPLAY_MAPS:self.surface_map.set('combined')
        active_model=self._results_airflow_model()
        # Keep the familiar Results viewer, but open on the airflow model that
        # is actually active in this tune.
        self.surface_format=tk.StringVar(value=('speed_density' if active_model=='speed_density' else 'neural_network'))

        # Compact summary metrics: preserve all four values while reclaiming vertical surface space.
        stats=tk.Frame(b,bg=C['bg']);stats.pack(fill='x',pady=(0,6));self.surface_stat_vars={k:tk.StringVar(value='—') for k in ('min','max','mean','protect')}
        self.surface_stat_unit_vars={k:tk.StringVar(value='VE point') for k in ('min','max','mean','protect')}
        for idx,(key,title,detail) in enumerate([('min','Min Delta','VE point'),('max','Max Delta','VE point'),('mean','Mean Delta','VE point'),('protect','Max |Delta|','VE point')]):
            o,i=self.card(stats,10,4);o.pack(side='left',fill='x',expand=True,padx=(0 if idx==0 else 5,0))
            tk.Label(i,text=title.upper(),bg='white',fg=C['muted'],font=('Microsoft Sans Serif',7,'bold')).pack(anchor='w')
            value_row=tk.Frame(i,bg='white');value_row.pack(fill='x',pady=(0,0))
            tk.Label(value_row,textvariable=self.surface_stat_vars[key],bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(side='left')
            tk.Label(value_row,textvariable=self.surface_stat_unit_vars[key],bg='white',fg=C['muted'],font=('Microsoft Sans Serif',7)).pack(side='left',padx=(6,0),pady=(3,0))

        body=tk.Frame(b,bg=C['bg']);body.pack(fill='both',expand=True)
        lo,li=self.card(body,12,10);lo.pack(side='left',fill='both',expand=True,padx=(0,7))
        head=tk.Frame(li,bg='white');head.pack(fill='x')
        self.surface_chart_title=None
        controls=tk.Frame(head,bg='white');controls.pack(side='left')
        self.surface_dimension=tk.StringVar(value=getattr(self,'surface_dimension',tk.StringVar(value='2d')).get() if hasattr(self,'surface_dimension') else '2d');self.surface_dimension_buttons={}
        if self.surface_dimension.get() not in ('2d','3d'):self.surface_dimension.set('2d')
        for key,label in [('2d','2D'),('3d','3D')]:
            btn=tk.Button(controls,text=label,relief='raised',bd=2,highlightthickness=0,cursor='hand2',font=('Microsoft Sans Serif',8,'bold'),padx=10,pady=5,command=lambda k=key:self._set_surface_dimension(k));btn.pack(side='left',padx=2);self.surface_dimension_buttons[key]=btn
        tk.Frame(controls,bg=C['border'],width=1,height=22).pack(side='left',padx=6)
        self.surface_view=tk.StringVar(value=getattr(self,'surface_view',tk.StringVar(value='new')).get() if hasattr(self,'surface_view') else 'new');self.surface_view_buttons={}
        if self.surface_view.get() not in ('original','new','delta'):self.surface_view.set('new')
        for key,label in [('new','New'),('original','Old'),('delta','Delta')]:
            btn=tk.Button(controls,text=label,relief='raised',bd=2,highlightthickness=0,cursor='hand2',font=('Microsoft Sans Serif',8,'bold'),padx=10,pady=5,command=lambda k=key:self._set_surface_view(k));btn.pack(side='left',padx=2);self.surface_view_buttons[key]=btn
        self.surface_map=tk.StringVar(value='combined');self.surface_map_buttons={}
        if self.current_page=='results':
            format_controls=tk.Frame(head,bg='white');format_controls.pack(side='right')
            self.surface_format_buttons={}
            active_model=self._results_airflow_model()
            for key,label in [('neural_network','Neural Network'),('speed_density','Speed Density')]:
                btn=tk.Button(format_controls,text=label,relief='raised',bd=2,highlightthickness=0,cursor='hand2',font=('Microsoft Sans Serif',8,'bold'),padx=10,pady=5,command=lambda k=key:self._set_surface_format(k));btn.pack(side='left',padx=2);self.surface_format_buttons[key]=btn
                if active_model=='speed_density' and key=='neural_network':btn.config(state='disabled',cursor='arrow')
        else:
            self.surface_format_buttons={}
        self.surface_pe_picker=None

        # 2D remains a heatmap internally; its redundant scale/mode row is hidden.
        self.surface_render=tk.StringVar(value='heatmap')

        selectbar=tk.Frame(li,bg=C['soft']);selectbar.pack(fill='x',pady=(5,1));self.surface_selection_status=tk.StringVar(value='No cells selected')
        tk.Label(selectbar,textvariable=self.surface_selection_status,bg=C['soft'],fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(side='left',padx=(8,10),pady=5)
        for label,cmd in [('Copy + Axes',lambda:self._surface_copy_selection(True)),('Copy Values',lambda:self._surface_copy_selection(False)),('Clear',self._surface_clear_selection),('Select All',self._surface_select_all)]:
            tk.Button(selectbar,text=label,relief='raised',bd=2,highlightthickness=0,cursor='hand2',font=('Microsoft Sans Serif',8,'bold'),padx=8,pady=3,bg='white',fg=C['text'],command=cmd).pack(side='left',padx=2,pady=3)
        self.surface_main_canvas=tk.Canvas(li,bg='white',highlightthickness=0,height=420,takefocus=1);self.surface_main_canvas.pack(fill='both',expand=True,pady=(2,0));self.surface_main_canvas.bind('<Configure>',self._surface_canvas_configured,add='+');self.surface_hover=tk.StringVar(value='');tk.Label(li,textvariable=self.surface_hover,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),anchor='w').pack(fill='x',pady=(4,0))

        ro,ri=self.card(body,12,10);ro.pack(side='left',fill='y',padx=(7,0));tk.Label(ri,text='COMPARISON',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w');tk.Label(ri,text='Click a preview to inspect it.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8)).pack(anchor='w',pady=(1,6));self.surface_previews={}
        for key,title in [('original','Original'),('new','New'),('delta','Delta')]:
            f=tk.Frame(ri,bg='white');f.pack(fill='x',pady=(2,3));tk.Label(f,text=title,bg='white',fg=C['text'],font=('Microsoft Sans Serif',9,'bold')).pack(anchor='w');can=tk.Canvas(f,width=185,height=52,bg='white',highlightthickness=1,highlightbackground=C['border']);can.pack();can.bind('<Button-1>',lambda e,k=key:self._set_surface_view(k));self.surface_previews[key]=can
        sep=tk.Frame(ri,bg=C['border'],height=1);sep.pack(fill='x',pady=(2,6))
        tk.Label(ri,text='SELECTED CELL',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w')
        self.surface_cell_vars={k:tk.StringVar(value='—') for k in ('rpm','pratio','original','new','delta','percent','zone')}
        grid=tk.Frame(ri,bg='white');grid.pack(fill='x',pady=(4,2))
        rowspec=[('RPM','rpm'),('PRatio','pratio'),('Original','original'),('New','new'),('Delta','delta'),('Change','percent')]
        self.surface_cell_label_vars={}
        for label,key in rowspec:
            rr=tk.Frame(grid,bg='white');rr.pack(fill='x',pady=0)
            self.surface_cell_label_vars[key]=tk.StringVar(value=label)
            tk.Label(rr,textvariable=self.surface_cell_label_vars[key],bg='white',fg=C['muted'],font=('Microsoft Sans Serif',7)).pack(side='left')
            tk.Label(rr,textvariable=self.surface_cell_vars[key],bg='white',fg=C['text'],font=('Microsoft Sans Serif',8,'bold'),width=12,anchor='e').pack(side='right')
        tk.Label(ri,textvariable=self.surface_cell_vars['zone'],bg=C['soft'],fg=C['accent'],font=('Microsoft Sans Serif',7,'bold'),wraplength=180,justify='left',padx=7,pady=5).pack(fill='x',pady=(4,4))
        self.surface_basis_note=tk.StringVar(value='NN surface sampled across calibration-derived cam references. Open-loop and WOT fueling remain unassessed.')
        tk.Label(ri,textvariable=self.surface_basis_note,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',7),justify='left',wraplength=185).pack(anchor='w',pady=(1,0))
        self.root.after(120,self._refresh_surface_widgets)

    def page_surfaces(self):
        b=self._watermark_frame(self.content,22,18)
        self._build_surface_viewer(b,include_header=True)

    def _performance_version_columns(self):
        """Keep V0 visible, including while later versions are being processed.

        The first four headings mirror the approved layout. As a project gains
        further versions, columns are appended and can scroll horizontally.
        """
        version_no=0
        if getattr(self,'project',None) is not None:
            av=self._active_version()
            if av is not None:
                version_no=max(0,int(av['version_no']))
            elif self.active_version_no is not None:
                version_no=max(0,int(self.active_version_no))
        return list(range(max(4,version_no+1)))

    @staticmethod
    def _performance_cell_text(key,value):
        if value is None:return '—'
        if key=='rpm':return f'{float(value):,.0f}'
        if key=='torque':return f'{float(value):,.0f} lb-ft'
        return f'{float(value):,.0f} hp'

    def _refresh_performance_summary(self):
        """Show measured HPL peaks in V0/V1/... columns, without deltas.

        Each version retains its own hash-validated HPL measurement. A new
        version remains blank until its correction review finishes, while
        all previously completed versions remain visible during that run.
        Missing or stale measurements are never replaced with guesses.
        """
        cells=getattr(self,'performance_cells',None)
        if not cells:return
        active_no=0
        pid=None
        if getattr(self,'project',None) is not None:
            pid=int(self.project.id)
            av=self._active_version()
            if av is not None:active_no=int(av['version_no'])
            elif self.active_version_no is not None:active_no=int(self.active_version_no)
        values={}
        for vn in self.performance_version_numbers:
            stored=None
            if pid is not None and vn<=active_no:
                version=self.db.get_version(pid,vn)
                # After Run the verified candidate is preview_ready; Apply Changes
                # sets run_completed later. Either is a processed version, but a
                # log staged merely by Build must remain blank in this table.
                if version is not None:
                    try: processed=bool(version['run_completed'] or version['preview_ready'])
                    except (KeyError,IndexError,TypeError):
                        processed=bool(version['run_completed'])
                    if processed:stored=self.db.get_version_performance(pid,vn)
            values[vn]=stored
            for key,column in (('rpm','max_rpm'),('torque','max_torque_lbft'),('hp','max_hp')):
                value=stored.get(column) if stored else None
                cells[vn][key].set(self._performance_cell_text(key,value))
        # Preserve the old read-only aliases used by existing GUI tests and
        # nonvisual inspection, but do not show an additional summary or deltas.
        for key in ('rpm','torque','hp'):
            value=values.get(active_no)
            column={'rpm':'max_rpm','torque':'max_torque_lbft','hp':'max_hp'}[key]
            self.performance_vars[key].set(self._performance_cell_text(key,value.get(column) if value else None))

    def _build_performance_summary(self,parent):
        """Compact V0...Vn matrix. No title or percentage/delta comparison."""
        outer=tk.Frame(parent,bg=SETUP_NAVY_DARK)
        outer.pack(fill='both',expand=True,padx=2,pady=2)
        self.performance_vars={key:tk.StringVar(value='—') for key in ('rpm','torque','hp')}
        self.performance_cells={}
        self.performance_version_numbers=self._performance_version_columns()
        row_bg=SETUP_NAVY_DARK
        head_bg=SETUP_NAVY
        pane=tk.Canvas(outer,bg=row_bg,highlightthickness=0,borderwidth=0)
        pane.pack(side='top',fill='both',expand=True)
        self.performance_table_canvas=pane
        interior=tk.Frame(pane,bg=row_bg)
        self.performance_table_interior=interior
        window=pane.create_window((0,0),window=interior,anchor='nw')
        interior.grid_columnconfigure(0,weight=1,minsize=126)
        for column_no in range(1,len(self.performance_version_numbers)+1):
            interior.grid_columnconfigure(column_no,weight=1,minsize=111)
        headings=[('',0)]+[(f'V{vn}' + (' (Baseline)' if vn==0 else ''),i+1)
                         for i,vn in enumerate(self.performance_version_numbers)]
        for text,col in headings:
            tk.Label(interior,text=text,bg=head_bg,fg='white',font=('Microsoft Sans Serif',9,'bold'),
                borderwidth=1,relief='solid',height=1,anchor='center').grid(
                row=0,column=col,sticky='nsew',padx=1,pady=1)
        for row_no,(key,title) in enumerate((('rpm','Max RPM:'),('torque','Max Torque:'),('hp','Max HP:')),start=1):
            tk.Label(interior,text=title,bg=row_bg,fg='white',
                font=('Microsoft Sans Serif',10,'bold'),anchor='w',height=1,
                borderwidth=1,relief='solid',padx=5).grid(
                row=row_no,column=0,sticky='nsew',padx=1,pady=1)
            for i,vn in enumerate(self.performance_version_numbers,start=1):
                self.performance_cells.setdefault(vn,{})[key]=tk.StringVar(value='—')
                tk.Label(interior,textvariable=self.performance_cells[vn][key],
                    bg=row_bg,fg='white',font=('Microsoft Sans Serif',10,'bold'),
                    borderwidth=1,relief='solid',anchor='center',height=1).grid(
                    row=row_no,column=i,sticky='nsew',padx=1,pady=1)
        min_width=126+111*len(self.performance_version_numbers)
        bar=tk.Scrollbar(outer,orient='horizontal',command=pane.xview)
        self.performance_table_scrollbar=bar
        pane.configure(xscrollcommand=bar.set)
        interior.bind('<Configure>',lambda _e:pane.configure(scrollregion=pane.bbox('all')))
        def resize(e):
            if not pane.winfo_exists():return
            pane.itemconfigure(window,width=max(min_width,int(e.width)))
            if int(e.width)<min_width:
                if not bar.winfo_manager():bar.pack(side='bottom',fill='x')
            elif bar.winfo_manager():
                bar.pack_forget()
                pane.xview_moveto(0)
        pane.bind('<Configure>',resize)
        self._refresh_performance_summary()

    def _set_setup_panel_message(self,heading,body,align='left',actions=(),builder=None,requires_action=True):
        """Show a real user decision above Progress without losing Progress state.

        Informational notices set requires_action=False and update the progress
        narrative rather than replacing it with another message-only view.
        Existing safety prompts remain visible until the user resolves them.
        """
        self.setup_panel_message={
            'heading':str(heading), 'body':str(body),
            'align':('center' if align=='center' else 'left'),
            'actions':tuple(actions), 'requires_action':bool(requires_action),
        }
        if builder is not None:self.setup_panel_message['builder']=builder
        if not requires_action:
            activity=getattr(self,'setup_activity_state',None)
            if not activity or not activity.get('busy'):
                # Preserve real solver stage/percentage after a completed review.
                if not (activity and activity.get('percent') is not None):
                    self._set_setup_activity(heading,body,busy=False)
        self._render_setup_panel_message()
        self._update_setup_workflow_action()

    def _stop_setup_header_blink(self):
        pending=getattr(self,'_setup_header_blink_after_id',None)
        if pending is not None:
            try:self.root.after_cancel(pending)
            except (AttributeError,tk.TclError):pass
        self._setup_header_blink_after_id=None
        self._setup_header_blink_on=False

    def _on_root_destroy(self,event):
        """Cancel Setup flash timers before Tcl tears down the root widget."""
        if event.widget is self.root:
            self._stop_setup_header_blink()
            self._stop_setup_verify_blink()

    def _refresh_setup_information_view(self):
        """One right-side host: actionable MESSAGE or live PROCESSING/PROGRESS.

        Swapping the two content frames leaves stage history, Progressbar and
        button state intact, including while asynchronous workers are active.
        """
        progress=getattr(self,'setup_progress_view',None)
        action=getattr(self,'setup_action_view',None)
        title=getattr(self,'setup_header_label',None)
        if progress is None or action is None or title is None:return
        try:
            if not title.winfo_exists():return
        except tk.TclError:return
        state=getattr(self,'setup_panel_message',None) or {}
        activity=getattr(self,'setup_activity_state',None) or {}
        opening_warning=(state.get('heading')=='WARNING' and
                         state.get('body')==OPENING_EMISSIONS_WARNING)
        # The opening disclaimer is the initial screen, not a decision that can
        # obscure real processing. Once progress exists, it replaces that notice.
        message=bool(state.get('requires_action')) and not (opening_warning and activity)
        warning=opening_warning and message
        mode='WARNING' if warning else ('MESSAGE' if message else
               ('PROCESSING' if activity.get('busy') else 'PROGRESS'))
        if message:
            if progress.winfo_manager():progress.pack_forget()
            if not action.winfo_manager():action.pack(fill='both',expand=True)
        else:
            if action.winfo_manager():action.pack_forget()
            if not progress.winfo_manager():progress.pack(fill='both',expand=True)
        if mode!=getattr(self,'_setup_header_mode',None):
            self._stop_setup_header_blink()
            self._setup_header_mode=mode
            title.configure(text=mode,fg='white')
            if mode in ('MESSAGE','PROCESSING'):
                self._blink_setup_header()

    def _blink_setup_header(self):
        """Flash only the header label; never hide an active user decision."""
        self._setup_header_blink_after_id=None
        label=getattr(self,'setup_header_label',None)
        mode=getattr(self,'_setup_header_mode',None)
        try:
            if (self.current_page!='setup' or mode not in ('MESSAGE','PROCESSING') or
                    label is None or not label.winfo_exists()):
                return
            self._setup_header_blink_on=not self._setup_header_blink_on
            label.configure(fg=('#FFE082' if self._setup_header_blink_on else 'white'))
            self._setup_header_blink_after_id=self.root.after(450,self._blink_setup_header)
        except tk.TclError:
            self._stop_setup_header_blink()

    def _render_setup_panel_message(self):
        """Render action messages without rebuilding the fixed header or Progress.

        Body wrapping and scrolling use the available right-panel width. Source
        radio choices, VIN confirmation and safety decisions stay in this pane;
        their execution uses the single workflow button in Vehicle Info.
        """
        host=getattr(self,'setup_action_view',None)
        if host is None:return
        try:
            if not host.winfo_exists():return
        except (tk.TclError,AttributeError):return
        for child in host.winfo_children():child.destroy()
        state=getattr(self,'setup_panel_message',None)
        if not state:
            self._refresh_setup_information_view()
            return
        title=state['heading']
        if title!='VEHICLE VERIFICATION':self._setup_verification_displayed_signature=None
        self.setup_choice_var=None;self.setup_choice_actions={}
        body=state['body']
        initial_warning=(title=='WARNING' and body==OPENING_EMISSIONS_WARNING)
        if body:
            body_area=tk.Frame(host,bg='white')
            body_area.pack(fill='x',padx=7,pady=(11,5))
            root_width=(self.root.winfo_width() if getattr(self,'root',None) is not None else 1100)
            available=max(225,host.winfo_width()-25 if host.winfo_width()>50 else root_width//2-72)
            text_align=('center' if initial_warning and state.get('align')=='center' else 'left')
            message=tk.Label(body_area,text=body,bg='white',fg=C['text'],
                font=('Microsoft Sans Serif',11,'bold' if initial_warning else 'normal'),
                justify=text_align,anchor=('n' if text_align=='center' else 'nw'),wraplength=available)
            message.pack(fill='x',expand=True)
            def reflow(_event=None):
                if message.winfo_exists() and message.winfo_width()>50:
                    message.configure(wraplength=max(195,message.winfo_width()-8))
            message.bind('<Configure>',reflow)
        builder=state.get('builder')
        if builder is not None:
            wrap=tk.Frame(host,bg='white');wrap.pack(fill='both',expand=True)
            sb=tk.Scrollbar(wrap,orient='vertical');sb.pack(side='right',fill='y')
            canvas=tk.Canvas(wrap,bg='white',highlightthickness=0,yscrollcommand=sb.set)
            canvas.pack(side='left',fill='both',expand=True)
            sb.configure(command=canvas.yview)
            content=tk.Frame(canvas,bg='white')
            item=canvas.create_window((0,0),window=content,anchor='nw')
            content.bind('<Configure>',lambda _e:canvas.configure(scrollregion=canvas.bbox('all')))
            canvas.bind('<Configure>',lambda e:canvas.itemconfigure(item,width=e.width))
            builder(content)
        if state['actions']:
            self.setup_choice_actions={name:callback for name,callback in state['actions']}
            self.setup_choice_var=tk.StringVar(value='')
            choices=tk.Frame(host,bg='white');choices.pack(anchor='w',padx=14,pady=(4,6))
            for name,_handler in state['actions']:
                ttk.Radiobutton(choices,text=name,variable=self.setup_choice_var,value=name,
                    command=self._update_setup_workflow_action).pack(side='left',padx=(0,24))
        self._refresh_setup_information_view()

    def _invoke_setup_action(self):
        """Invoke only the current fixed-button action; never reuse stale stages."""
        button=getattr(self,'setup_workflow_button',None)
        command=getattr(self,'_setup_action_command',None)
        if button is None or command is None:return
        try:
            if button.instate(['disabled']):return
        except tk.TclError:return
        command()

    def _invoke_setup_choice(self):
        var=getattr(self,'setup_choice_var',None)
        selected=var.get() if var is not None else ''
        callback=getattr(self,'setup_choice_actions',{}).get(selected)
        if callback is not None:callback()

    def _update_setup_workflow_action(self):
        """Keep one fixed-size Verify/Submit/Continue/VIEW/Results button.

        File browsing is not a workflow action and stays next to its input.
        No new action bypasses verification, preflight, or correction gates.
        """
        button=getattr(self,'setup_workflow_button',None)
        if button is None or self.current_page!='setup':return
        try:
            if not button.winfo_exists():return
        except tk.TclError:return
        label='Submit';callback=None;enabled=False;verify=False
        state=getattr(self,'setup_panel_message',None) or {}
        mode=getattr(self,'_setup_lower_mode','status')
        activity=getattr(self,'setup_activity_state',None) or {}
        if state.get('requires_action') and state.get('actions') and not getattr(self,'running',False):
            label='Continue';callback=self._invoke_setup_choice
            enabled=bool(getattr(self,'setup_choice_var',None) and self.setup_choice_var.get() in self.setup_choice_actions)
        elif (getattr(self,'_vin_lookup_pending',False) or getattr(self,'running',False) or
                getattr(self,'_setup_build_in_progress',False) or
                getattr(self,'correction_preflight_running',False) or activity.get('busy')):
            label='Processing'
        elif state.get('requires_action') and state.get('heading') in (
                'Log File Error','Log File Validation Error','LOG FILE INCOMPLETE'):
            label='VIEW';callback=self._view_failed_log_diagnostics;enabled=True
        elif state.get('requires_action') and state.get('heading') in (
                'Log File Required','SELECT ANOTHER LOG FILE'):
            label='Select Log File';callback=self._select_current_log
            av=self._active_version() if self.project else None
            enabled=bool(self.user and self.user.role!='guest' and not (av and int(av['run_completed'])))
        elif state.get('requires_action') and state.get('heading') in ('Tune File Error','Tune File Required'):
            label='Select .htt';callback=self._select_initial_htt
            enabled=bool(self.user and self.user.role!='guest')
        elif state.get('requires_action') and state.get('heading')=='Correction Preflight Error':
            label='Retry Preflight';callback=lambda:self._run_correction_preflight(force=True)
            enabled=bool(self.project)
        elif state.get('requires_action') and state.get('heading')=='PROCESSING ERROR':
            label='Review Error'  # Requires user review/correction, not an automatic rerun.
        elif mode=='review' and self.project:
            if self._review_result_ready():
                label='Results';callback=lambda:self.goto('results');enabled=True
            else:
                label='Continue';callback=self.start_review
                enabled=not bool(self._review_source_block_reason())
        elif mode=='preflight' and self.project:
            choices={row.get('id'):row for row in (self.correction_preflight_cache or {}).get('choices',[])}
            selected=self.correction_source_selection
            if selected and choices.get(selected,{}).get('enabled'):
                label='Continue';callback=self._run_selected_correction;enabled=True
            elif any(row.get('enabled') for row in choices.values()):
                label='Continue'  # Both sources need an explicit radio selection.
            else:
                label='Refresh Preflight' if self.correction_preflight_cache is not None else 'Processing'
                callback=lambda:self._run_correction_preflight(force=True)
                enabled=bool(self.correction_preflight_cache is not None)
        else:
            values=self._setup_vehicle_signature()
            av=self._active_version() if self.project else None
            completed=bool(av and int(av['run_completed']))
            latest_ok=True
            if self.project and av:
                latest=self.db.latest_version(self.project.id)
                latest_ok=bool(latest and int(av['version_no'])==int(latest['version_no']))
            authorized=bool(self.user and self.user.role!='guest' and
                            self.license_status().get('active') and not completed and latest_ok)
            complete=bool(values and len(values)==7 and values[3] and values[4]
                          and self._valid_vehicle_year(values[0]) and values[1]
                          and values[2] and values[5] in TRANSMISSION_OPTIONS)
            if complete and not self._setup_vehicle_is_verified():
                label='Verify';callback=self._confirm_setup_vehicle
                enabled=authorized and bool(getattr(self,'_setup_verification_displayed_signature',None)==values)
                verify=enabled
            elif getattr(self,'vs_log_staged',False):
                label='Submit';callback=self._submit_selected_log;enabled=authorized and self._setup_vehicle_is_verified()
            else:
                label='Build';callback=self._save_vehicle_setup
                enabled=bool(authorized and self._setup_vehicle_is_verified()
                             and getattr(self,'vs_log_valid',False) and getattr(self,'vs_log_report',None))
        prior=(str(button.cget('text')),button.instate(['disabled']))
        self._setup_action_command=callback if enabled else None
        button.configure(text=label,style=('VerifyBright.TButton' if verify else 'Primary.TButton'))
        button.state(['!disabled'] if enabled else ['disabled'])
        if verify:
            if getattr(self,'_setup_verify_button',None) is not button or self._setup_verify_blink_after_id is None:
                self._start_setup_verify_blink(button)
        elif getattr(self,'_setup_verify_button',None) is not None:
            self._stop_setup_verify_blink()
        if enabled and label!=prior[0]:
            try:button.focus_set()
            except tk.TclError:pass

    @staticmethod
    def _valid_vehicle_year(value):
        try:return 1981 <= int(str(value).strip()) <= 2100
        except (ValueError,TypeError):return False

    def _setup_vehicle_signature(self):
        """Snapshot exactly the displayed vehicle identity and selected files."""
        values=getattr(self,'vs_vars',{})
        try:return tuple(str(values[key].get()).strip() for key in ('year','engine','model','htt','log','transmission','vin'))
        except (AttributeError,KeyError):return ()

    def _setup_vehicle_is_verified(self):
        signature=self._setup_vehicle_signature()
        return bool(signature and signature==getattr(self,'_setup_verified_signature',None))

    def _stop_setup_verify_blink(self):
        after_id=getattr(self,'_setup_verify_blink_after_id',None)
        if after_id is not None:
            try:self.root.after_cancel(after_id)
            except (AttributeError,tk.TclError):pass
        self._setup_verify_blink_after_id=None
        self._setup_verify_button=None
        self._setup_verify_blink_on=False

    def _start_setup_verify_blink(self,button):
        """Blink only the yellow Verify button, never the Setup panel or Submit."""
        self._setup_verify_button=button
        self._setup_verify_blink_on=False
        def flash():
            self._setup_verify_blink_after_id=None
            try:
                if (self.current_page!='setup' or self._setup_verify_button is not button
                        or not button.winfo_exists() or self._setup_vehicle_is_verified()):
                    self._stop_setup_verify_blink();return
                self._setup_verify_blink_on=not self._setup_verify_blink_on
                button.configure(style=('VerifySoft.TButton' if self._setup_verify_blink_on
                                        else 'VerifyBright.TButton'))
                self._setup_verify_blink_after_id=self.root.after(450,flash)
            except tk.TclError:self._stop_setup_verify_blink()
        self._setup_verify_blink_after_id=self.root.after(450,flash)

    def _show_setup_vehicle_verification(self):
        """Present log-derived vehicle identity; Verify is the fixed button."""
        values=self._setup_vehicle_signature()
        if not values or not values[4]:return
        self._setup_verified_signature=None
        self._setup_verification_displayed_signature=values
        year,engine,vehicle_type,_tune,_log,transmission,vin=values
        def build(parent):
            tk.Label(parent,text='Please verify the selected vehicle:',bg='white',fg=C['text'],
                     font=('Microsoft Sans Serif',10),justify='left').pack(anchor='w',padx=12,pady=(8,7))
            tk.Label(parent,text=(f'Model Year: {year}\nEngine: {engine}\nVehicle Type: {vehicle_type}'
                                  f'\nTransmission: {transmission}\nVIN: {vin or "Not available (optional)"}'),
                     bg='white',fg=C['text'],font=('Microsoft Sans Serif',10,'bold'),
                     justify='left',anchor='w',wraplength=450).pack(anchor='w',padx=12)
        self._set_setup_panel_message('VEHICLE VERIFICATION','',builder=build)
        self._update_setup_workflow_action()
        def focus_verify():
            button=getattr(self,'setup_workflow_button',None)
            try:
                if (self.current_page=='setup' and button is not None and button.winfo_exists()
                        and button.cget('text')=='Verify'):
                    button.focus_set()
            except tk.TclError:pass
        self.root.after_idle(focus_verify)

    def _confirm_setup_vehicle(self):
        """Accept the displayed selection; Submit then becomes available."""
        if not getattr(self,'vs_log_staged',False) and not getattr(self,'vs_log_valid',False):return
        signature=self._setup_vehicle_signature()
        if not signature or not signature[3] or not signature[4]:return
        if signature!=getattr(self,'_setup_verification_displayed_signature',None):
            self._show_setup_vehicle_verification();return
        if (not self._valid_vehicle_year(signature[0]) or not signature[1] or not signature[2]
                or signature[5] not in TRANSMISSION_OPTIONS):return
        self._setup_verified_signature=signature
        self._set_setup_panel_message('VEHICLE VERIFIED',
            f'Model Year: {signature[0]}\nEngine: {signature[1]}\n'
            f'Vehicle Type: {signature[2]}\n\nVerified. Select Submit to continue.'
            if getattr(self,'vs_log_staged',False) else
            f'Model Year: {signature[0]}\nEngine: {signature[1]}\n'
            f'Vehicle Type: {signature[2]}\n\nVerified. Select Build to continue.',requires_action=False)
        self._vehicle_form_update()
        button=self.setup_workflow_button
        try:
            if button.winfo_manager():button.focus_set()
        except tk.TclError:pass

    def _setup_vehicle_identity_changed(self,*_):
        """A changed year, engine or vehicle type always requires a fresh Verify."""
        if (getattr(self,'_setup_verified_signature',None) is not None
                and not self._setup_vehicle_is_verified()):
            self._setup_verified_signature=None
            self._cancel_auto_submit()
        if (getattr(self,'vs_vars',None) and self.current_page=='setup'
                and self.vs_vars['log'].get().strip()
                and (getattr(self,'vs_log_staged',False) or getattr(self,'vs_log_valid',False))
                and not self._setup_vehicle_is_verified()):
            self._show_setup_vehicle_verification()
        self._vehicle_form_update()

    def _setup_processing_changed(self,*_):
        """Status and warnings live only in the upper-right message panel.

        The lower panel is reserved for active processing, validation View,
        correction preflight, and Run/Review details—not duplicate status text.
        """
        return

    def _dyno_processed_versions(self):
        """Only processed, SHA-verified native logs may appear in this panel."""
        project=getattr(self,'project',None)
        if project is None:return []
        result=[]
        try:
            pid=int(project.id)
            for vn in self._performance_version_columns():
                version=self.db.get_version(pid,vn)
                if version is None:continue
                if not (version['run_completed'] or version['preview_ready']):continue
                metrics=self.db.get_version_performance(pid,vn)
                if metrics is None:continue
                location=Path(str(version['log_local_path'] or ''))
                if not location.is_file():continue
                digest=str(version['log_sha256'] or '').lower()
                if digest and str(metrics.get('log_sha256') or '').lower()==digest:
                    result.append((vn,location,digest))
        except (AttributeError,KeyError,TypeError,ValueError,IndexError):
            return []
        return result

    def _draw_current_dyno(self):
        canvas=getattr(self,'dyno_canvas',None)
        if canvas is None:return
        try:
            if not canvas.winfo_exists():return
        except tk.TclError:return
        key=getattr(self,'_dyno_display_key',None)
        result=getattr(self,'_dyno_curve_cache',{}).get(key)
        if result is None:
            canvas.delete('all')
            canvas.create_text(max(240,canvas.winfo_width()//2),max(110,canvas.winfo_height()//2),
                               text='Reading native HPL performance data…',
                               fill=SETUP_SKY,font=('Microsoft Sans Serif',11))
            return
        draw_dyno_chart(canvas,result)
        caption=getattr(self,'dyno_caption',None)
        if caption is None:return
        if result.get('status')!='ready':
            caption.set('Curve unavailable: '+result.get('reason','Unknown log analysis error.'))
            return
        total=result['reconstructed_bins']
        if result.get('basis')=='WOT':
            description=(f"Composite from {result['sweep_count']} WOT instances"
                         f"  •  {result['logged_bins']} WOT RPM bins"
                         f"  •  {total} estimated bins")
        else:
            description=f"Partial-load illustration only  •  {total} estimated bins; no WOT evidence"
        caption.set(description+'  •  PCM estimate, not measured dyno power.')

    def _select_dyno_version(self, versions, selected):
        if selected not in versions:return
        vn,path,digest=versions[selected]
        key=(str(path),digest)
        self._dyno_selected=(int(self.project.id),vn)
        self._dyno_display_key=key
        caption=getattr(self,'dyno_caption',None)
        if caption is not None:caption.set('Log-derived PCM estimates (not a chassis dyno). Loading…')
        if key in self._dyno_curve_cache:
            self._draw_current_dyno()
            return
        self._draw_current_dyno()
        if key in self._dyno_pending:return
        self._dyno_pending.add(key)
        def work():
            try:
                curve=build_dyno_curve(path)
                if curve['log_sha256'].lower()!=digest:
                    raise ValueError('Source HPL checksum differs from this project version.')
            except (OSError,ValueError,KeyError,TypeError,OverflowError) as exc:
                curve={'status':'unavailable','reason':str(exc),'points':[]}
            def complete():
                self._dyno_pending.discard(key)
                self._dyno_curve_cache[key]=curve
                if getattr(self,'_dyno_display_key',None)==key:
                    self._draw_current_dyno()
            try:self.root.after(0,complete)
            except (RuntimeError,tk.TclError):pass
        threading.Thread(target=work,daemon=True,name='VE-Dyno-ReadOnly').start()

    def _build_dyno_history(self, host):
        """Plot below the upper panels, above the existing Processing Quality."""
        versions=self._dyno_processed_versions()
        if not versions:return
        version_map={f'V{vn}' + (' (Baseline)' if vn==0 else ''):(vn,path,digest)
                     for vn,path,digest in versions}
        by_number={vn:name for name,(vn,_,__) in version_map.items()}
        selected=self._dyno_selected
        if not selected or selected[0]!=int(self.project.id) or selected[1] not in by_number:
            selected=(int(self.project.id),versions[-1][0])
        default=by_number[selected[1]]
        outer=tk.Frame(host,bg=SETUP_NAVY_DARK,highlightbackground=SETUP_BORDER,highlightthickness=1)
        outer.pack(fill='x',pady=(2,7))
        header=tk.Frame(outer,bg=SETUP_NAVY)
        header.pack(fill='x')
        tk.Label(header,text='Dyno-Style Performance — PCM Estimate',bg=SETUP_NAVY,
                 fg='white',font=('Microsoft Sans Serif',11,'bold')).pack(side='left',padx=12,pady=5)
        choice=tk.StringVar(value=default)
        picker=ttk.Combobox(header,textvariable=choice,values=list(version_map),state='readonly',width=16)
        picker.pack(side='right',padx=10,pady=4)
        self.dyno_version_picker=picker
        self.dyno_canvas=tk.Canvas(outer,bg='#061d32',height=280,highlightthickness=0)
        self.dyno_canvas.pack(fill='x',expand=False,padx=6,pady=(6,2))
        self.dyno_caption=tk.StringVar(value='')
        tk.Label(outer,textvariable=self.dyno_caption,bg=SETUP_NAVY_DARK,fg=SETUP_SKY,
                 font=('Microsoft Sans Serif',8),anchor='w',justify='left',
                 wraplength=1300).pack(fill='x',padx=10,pady=(4,7))
        picker.bind('<<ComboboxSelected>>',lambda _e:self._select_dyno_version(version_map,choice.get()))
        self.dyno_canvas.bind('<Configure>',lambda _e:self._draw_current_dyno())
        self._select_dyno_version(version_map,default)

    def _render_setup_lower_view(self):
        host=getattr(self,'setup_processing_host',None)
        if host is None or not host.winfo_exists():return
        for child in host.winfo_children():child.destroy()
        # Legacy handle for validation logic/tests; never pack a second View.
        # On failure, the ONE fixed primary button becomes VIEW.
        self.setup_actions=tk.Frame(host,bg='white')
        self.vs_log_details_btn=ttk.Button(self.setup_actions,text='View',style='Secondary.TButton',
            command=self._view_failed_log_diagnostics)
        mode=getattr(self,'_setup_lower_mode','status')
        # Lower panel contains only the read-only dyno and Processing Quality.
        # Active preflight status and user decisions belong in the upper-right
        # PROCESSING/MESSAGE panel; never draw the old white preflight card here.
        self._build_dyno_history(host)
        if mode=='preflight' and self.project:
            # Preserve the previous preflight page's version-context invalidation:
            # V1+ must not reuse a V0 correction-source choice or stale checks.
            if self.correction_preflight_context!=self._correction_context():
                self.correction_preflight_cache=None
                self.correction_source_selection=None
                self.correction_rescale_approved=False
            self._build_run_quality_panel(host)
            if (self.correction_preflight_cache is None and
                    not self.correction_preflight_running):
                av=self._active_version()
                if av and self.db.version_setup_complete(self.project.id,int(av['version_no'])):
                    self.root.after(40,self._run_correction_preflight)
        elif mode=='review' and self.project:
            self.page_review(host)
        self.setup_processing_scroll.configure(scrollregion=self.setup_processing_scroll.bbox('all'))

    def page_setup(self):
        # Discard asynchronous VIN callbacks from a previous Setup frame.
        self._vin_lookup_generation+=1
        self._vin_lookup_pending=False
        # Show three permanent layout panels. None has a permanent message or
        # processing heading. Existing submit/build/validation workflow remains.
        b=tk.Frame(self.content,bg=SETUP_NAVY_DARK)
        b.pack(fill='both',expand=True,padx=7,pady=6)
        b.grid_columnconfigure(0,weight=1,uniform='upper')
        b.grid_columnconfigure(1,weight=1,uniform='upper')
        b.grid_rowconfigure(0,minsize=350)
        b.grid_rowconfigure(1,weight=1,minsize=280)
        lpanel=tk.Frame(b,bg='white',highlightbackground=SETUP_BORDER,highlightthickness=2)
        lpanel.grid(row=0,column=0,sticky='nsew',padx=(0,5),pady=(0,8))
        rpanel=tk.Frame(b,bg=SETUP_NAVY_DARK,highlightbackground=SETUP_BORDER,highlightthickness=2)
        rpanel.grid(row=0,column=1,sticky='nsew',padx=(5,0),pady=(0,8))
        lower=tk.Frame(b,bg=SETUP_NAVY_DARK,highlightbackground=SETUP_BORDER,highlightthickness=2)
        lower.grid(row=1,column=0,columnspan=2,sticky='nsew')
        left=tk.Frame(lpanel,bg='white');left.pack(fill='both',expand=True,padx=15,pady=10)
        # The upper-right pane owns BOTH transient action messages and Progress.
        # Its header alone flashes; the lower pane contains quality/details only.
        self._stop_setup_header_blink()
        self._setup_header_mode=None
        message_box=tk.Frame(rpanel,bg='white',height=198)
        message_box.pack(fill='both',expand=True,padx=2,pady=(2,2))
        message_box.pack_propagate(False)
        self.setup_message_host=tk.Frame(message_box,bg='white')
        self.setup_message_host.pack(fill='both',expand=True,padx=14,pady=6)
        heading_bar=tk.Frame(self.setup_message_host,bg=SETUP_NAVY,height=31)
        heading_bar.pack(fill='x',pady=(0,4));heading_bar.pack_propagate(False)
        self.setup_header_label=tk.Label(heading_bar,text='PROGRESS',bg=SETUP_NAVY,fg='white',
            font=('Microsoft Sans Serif',11,'bold'),anchor='center',justify='center')
        self.setup_header_label.pack(fill='both',expand=True,padx=10)
        self.setup_action_view=tk.Frame(self.setup_message_host,bg='white')
        self.setup_progress_view=tk.Frame(self.setup_message_host,bg='white')
        self.setup_activity_host=self.setup_progress_view
        self.setup_activity_heading_var=tk.StringVar(value='Ready')
        self.setup_activity_status_var=tk.StringVar(value='')
        self.setup_activity_detail_var=tk.StringVar(value='')
        state_row=tk.Frame(self.setup_progress_view,bg='white')
        state_row.pack(fill='x',padx=7,pady=(4,1))
        tk.Label(state_row,textvariable=self.setup_activity_heading_var,bg='white',fg=C['text'],
            font=('Microsoft Sans Serif',10,'bold'),anchor='w').pack(side='left')
        tk.Label(state_row,textvariable=self.setup_activity_status_var,bg='white',fg=C['muted'],
            font=('Microsoft Sans Serif',8),anchor='e').pack(side='right')
        self.setup_activity_bar=ttk.Progressbar(self.setup_progress_view,maximum=100,
            mode='determinate',style='Horizontal.TProgressbar')
        self.setup_activity_bar.pack(fill='x',padx=7,pady=(1,4))
        tk.Label(self.setup_progress_view,textvariable=self.setup_activity_detail_var,bg='white',fg=C['muted'],
            font=('Microsoft Sans Serif',8),justify='left',anchor='w',wraplength=540).pack(fill='x',padx=7)
        event_frame=tk.Frame(self.setup_progress_view,bg='white')
        event_frame.pack(fill='both',expand=True,padx=7,pady=(6,2))
        self.setup_progress_log=tk.Text(event_frame,height=5,bg='white',fg=C['text'],
            insertbackground=C['text'],font=('Microsoft Sans Serif',9),
            relief='flat',borderwidth=0,wrap='word',spacing3=5)
        self.setup_progress_log.tag_configure('activity_heading',foreground=C['muted'],font=('Microsoft Sans Serif',8,'bold'),spacing3=7)
        self.setup_progress_log.tag_configure('activity_time',foreground=C['muted'],font=('Microsoft Sans Serif',8))
        self.setup_progress_log.tag_configure('activity_fact',foreground=C['text'])
        self.setup_progress_log.tag_configure('activity_active',foreground=C['accent'],font=('Microsoft Sans Serif',9,'bold'))
        self.setup_progress_log.tag_configure('activity_done',foreground=C['text'])
        self.setup_progress_log.pack(side='left',fill='both',expand=True)
        scrollbar_events=tk.Scrollbar(event_frame,orient='vertical',command=self.setup_progress_log.yview)
        scrollbar_events.pack(side='right',fill='y')
        self.setup_progress_log.configure(yscrollcommand=scrollbar_events.set,state='disabled')
        # Keep the baseline performance table and its data unchanged.
        perf=tk.Frame(rpanel,bg=SETUP_NAVY_DARK,height=110)
        self.setup_performance_panel=perf
        perf.pack(fill='x',side='bottom',padx=2,pady=(0,2))
        perf.pack_propagate(False)
        self._build_performance_summary(perf)
        self.setup_processing_viewport=tk.Frame(lower,bg=SETUP_NAVY_DARK)
        self.setup_processing_viewport.pack(fill='both',expand=True,padx=5,pady=5)
        scrollbar=tk.Scrollbar(self.setup_processing_viewport,orient='vertical')
        scrollbar.pack(side='right',fill='y')
        self.setup_processing_scroll=tk.Canvas(self.setup_processing_viewport,bg=SETUP_NAVY_DARK,highlightthickness=0,
                                               yscrollcommand=scrollbar.set)
        self.setup_processing_scroll.pack(side='left',fill='both',expand=True)
        scrollbar.configure(command=self.setup_processing_scroll.yview)
        self.setup_processing_host=tk.Frame(self.setup_processing_scroll,bg=SETUP_NAVY_DARK)
        self.setup_processing_window=self.setup_processing_scroll.create_window(
            (0,0),window=self.setup_processing_host,anchor='nw')
        self.setup_processing_host.bind('<Configure>',lambda _e:self.setup_processing_scroll.configure(
            scrollregion=self.setup_processing_scroll.bbox('all')))
        self.setup_processing_scroll.bind('<Configure>',lambda e:self.setup_processing_scroll.itemconfigure(
            self.setup_processing_window,width=e.width))

        existing=self.db.get_project_setup(self.project.id) if self.project else None
        active_v=self._active_version() if self.project else None
        if self.project and active_v is not None:
            self.active_version_no=int(active_v['version_no'])
            self._sync_progress_version(self.project.id,self.active_version_no)
        version_validation=(str(active_v['log_validation_json'] or '') if active_v else '')
        self.vs_na_closed_loop_only=version_closed_loop_only(active_v)
        self.vs_log_report=None
        self.vs_log_valid=bool(active_v and str(active_v['log_local_path'] or '').strip())
        self.vs_log_replacement_pending=False;self.vs_log_staged=False
        stored_log_qualification=None
        if version_validation:
            try:
                stored=json.loads(version_validation)
                if isinstance(stored,dict) and isinstance(stored.get('standard_report'),dict):
                    stored_log_qualification=stored
                    self.vs_log_report=stored.get('standard_report')
                    self.vs_log_valid=bool(stored.get('passed'))
                else:
                    self.vs_log_report=stored
                    self.vs_log_valid=bool(self.vs_log_report.get('passed'))
            except Exception:self.vs_log_report=None
        current_log=(str(active_v['log_source_path'] or '') if active_v else '')
        current_htt=(str(active_v['baseline_htt_path'] or '') if active_v else '')
        self.vs_vars={
            'project_name':tk.StringVar(value=(self.db.project_display_name(self.project.id) if self.project else '')),
            'htt':tk.StringVar(value=current_htt),
            'vin':tk.StringVar(value=(existing['vin'] if existing else '')),
            'year':tk.StringVar(value=(str(self.project.model_year) if self.project else '2023')),
            'model':tk.StringVar(value=(self.project.model if self.project else 'Dodge Challenger')),
            'engine':tk.StringVar(value=(({'5.7L':'5.7L Hemi','6.2L':'6.2L Supercharged Hemi','6.4L':'6.4L Hemi'}.get(self.project.engine,self.project.engine)) if self.project else '5.7L Hemi')),
            'transmission':tk.StringVar(value=(str(existing['transmission']) if existing and str(existing['transmission']) in TRANSMISSION_OPTIONS else 'Auto')),
            'log':tk.StringVar(value=current_log),
            'cai':tk.BooleanVar(value=False), 'headers':tk.BooleanVar(value=False),
            'throttle':tk.BooleanVar(value=False), 'intake':tk.BooleanVar(value=False),
            'cam':tk.BooleanVar(value=False), 'lsa':tk.StringVar(value=''),
            'ack':tk.BooleanVar(value=False), 'throttle_ack':tk.BooleanVar(value=False),
            'intake_ack':tk.BooleanVar(value=False),
        }
        # Confirmation belongs to this Setup selection, not to a stored tune
        # identity or an unrelated project previously opened in the same UI.
        self._setup_verified_signature=None
        locked=bool(active_v and int(active_v['run_completed']))
        status=('Current project is read-only.' if locked else 'Select a new Log File for the current version.' if self.project else 'Select the Tune File and Log File, then Submit.')
        if stored_log_qualification:
            spf=stored_log_qualification.get('correction_preflight') or {}
            sd_mode=((spf.get('configuration') or {}).get('airflow_model')=='speed_density')
            initial_log_summary=('PASS — Speed Density log qualification is active.' if sd_mode else logcheck.summary_text(self.vs_log_report))
        elif self.vs_log_report:
            initial_log_summary=logcheck.summary_text(self.vs_log_report)
        else:initial_log_summary=''
        self.vs_status=tk.StringVar(value=status)
        self.vs_eligibility=tk.StringVar(value='')
        self.vs_log_summary=tk.StringVar(value=initial_log_summary)
        self.vs_required_labels={}

        vehicle_header=tk.Frame(left,bg=SETUP_NAVY,height=28)
        vehicle_header.pack(fill='x',pady=(0,8));vehicle_header.pack_propagate(False)
        tk.Label(vehicle_header,text='Vehicle Info',bg=SETUP_NAVY,fg='white',
                 font=('Microsoft Sans Serif',11,'bold')).pack(anchor='w',padx=10,pady=4)
        pairs=tk.Frame(left,bg='white');pairs.pack(fill='x')
        pairs.columnconfigure(0,weight=1,uniform='veh');pairs.columnconfigure(1,weight=1,uniform='veh')
        def combo_cell(row,col,label,key,options,enabled=True):
            cell=tk.Frame(pairs,bg='white');cell.grid(row=row,column=col,sticky='ew',padx=(0,8) if col==0 else (8,0),pady=(0,7))
            tk.Label(cell,text=label,bg='white',fg=C['text'],font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(0,3))
            combo=ttk.Combobox(cell,textvariable=self.vs_vars[key],values=options,state=(('normal' if key in ('year','model','engine') else 'readonly') if enabled else 'disabled'),font=('Microsoft Sans Serif',9))
            combo.pack(fill='x',ipady=2)
            if enabled and key in ('year','model'):
                combo.bind('<<ComboboxSelected>>',lambda _e:self._vehicle_form_update())
            return combo
        combo_cell(0,0,'Model Year','year',MODEL_YEAR_OPTIONS,not self.project)
        combo_cell(0,1,'Vehicle Type','model',MODEL_OPTIONS,not self.project)
        combo_cell(1,0,'Engine','engine',ENGINE_OPTIONS,not self.project)
        combo_cell(1,1,'Transmission','transmission',TRANSMISSION_OPTIONS,not self.project)
        inputs=tk.Frame(left,bg='white');inputs.pack(fill='x',pady=(5,0))
        inputs.grid_columnconfigure(1,weight=1)
        def input_row(row,label,key,command,button_text,required=False,disabled=False,blue=False):
            cap=tk.Frame(inputs,bg='white');cap.grid(row=row,column=0,sticky='w',pady=6)
            tk.Label(cap,text=label,bg='white',fg=C['text'],font=('Microsoft Sans Serif',9)).pack(side='left')
            if required:
                star=tk.Label(cap,text='  *',bg='white',fg=C['danger'],font=('Microsoft Sans Serif',9,'bold'))
                star.pack(side='left');self.vs_required_labels[key]=star
            tk.Entry(inputs,textvariable=self.vs_vars[key],font=('Microsoft Sans Serif',9),relief='solid',bd=1,
                     state=('readonly' if key in ('vin','htt','log') or disabled else 'normal')).grid(row=row,column=1,sticky='ew',padx=(6,8),pady=6,ipady=4)
            button=ttk.Button(inputs,text=button_text,style=('Primary.TButton' if blue else 'Secondary.TButton'),command=command,width=17)
            button.grid(row=row,column=2,sticky='ew',pady=4)
            if disabled:button.state(['disabled'])
            return button
        tk.Label(inputs,text='VIN',bg='white',fg=C['text'],font=('Microsoft Sans Serif',9)).grid(
            row=0,column=0,sticky='w',pady=6)
        self.vs_vin_entry=tk.Entry(inputs,textvariable=self.vs_vars['vin'],
            font=('Microsoft Sans Serif',9),relief='solid',bd=1,state='readonly')
        self.vs_vin_entry.grid(row=0,column=1,columnspan=2,sticky='ew',padx=(6,0),pady=6,ipady=4)
        self.vs_vin_button=None  # No manual VIN entry or Decode / Autofill control.
        needs_initial_htt=(not self.project) or bool(active_v and not str(active_v['baseline_htt_path'] or '').strip())
        self.vs_htt_button=input_row(1,'Tune File (.htt)','htt',self._select_initial_htt,'Select .htt',required=True,disabled=not needs_initial_htt)
        self.vs_log_button=input_row(2,'Log File (.hpl):','log',self._select_current_log,'Select Log File',required=True,disabled=locked,blue=True)
        self.setup_primary_actions=tk.Frame(left,bg='white')
        self.setup_primary_actions.pack(anchor='w',pady=(8,0))
        self.setup_workflow_button=ttk.Button(self.setup_primary_actions,text='Submit',
            style='Primary.TButton',command=self._invoke_setup_action,width=17)
        self.setup_workflow_button.pack(side='left')
        # Compatibility references for the existing Build/Submit worker gates.
        self.vs_save=self.setup_workflow_button
        self.vs_log_submit_button=self.setup_workflow_button
        self.run_btn=self.setup_workflow_button
        self.setup_workflow_button.state(['disabled'])
        self.setup_status_text=tk.StringVar(value='')
        self.setup_summary_text=tk.StringVar(value='')
        # Compatibility handles for the existing validation logic; intentionally
        # never packed because feedback is displayed in the message panel.
        self.setup_status_label=tk.Label(left,textvariable=self.setup_status_text)
        self.vs_log_summary_label=tk.Label(left,textvariable=self.setup_summary_text,
                                           fg=(C['success'] if self.vs_log_valid else C['muted']))
        self.setup_processing_active=False
        self.vs_status.trace_add('write',self._setup_processing_changed)
        self.vs_log_summary.trace_add('write',self._setup_processing_changed)
        self._render_setup_activity()
        if current_log and self.vs_log_valid and not locked:
            self._show_setup_vehicle_verification()
        elif not self.project or self.setup_panel_message is None:
            self._set_setup_panel_message('WARNING',OPENING_EMISSIONS_WARNING,align='center')
        else:self._render_setup_panel_message()
        # Inline review may replace the right-side message and its buttons.
        # Do not redraw that panel after these interactive widgets are made.
        self._render_setup_lower_view()
        for key in ('project_name','htt','vin','year','model','engine','transmission','log'):
            callback=(self._setup_vehicle_identity_changed if key in ('year','model','engine','transmission','vin')
                      else lambda *_:self._vehicle_form_update())
            self.vs_vars[key].trace_add('write',callback)
        self._vehicle_form_update()

    def page_projects(self):
        b=self._watermark_frame(self.content,24,16)
        self.header(b,'Projects','Open, recover, or manage stored VE Optimizer projects and versions.')
        rows=self.db.list_user_projects(self.user.id)
        proj_o,proj=self.card(b,12,8);proj_o.pack(fill='x')
        top=tk.Frame(proj,bg='white');top.pack(fill='x')
        tk.Label(top,text='PROJECTS',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(side='left')
        ttk.Button(top,text='New Project',style='Primary.TButton',command=self._new_project_setup).pack(side='right')
        if not rows:
            tk.Label(proj,text='No projects are stored for this user.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',10),pady=22).pack(anchor='w')
            return
        # The project root is V0.  Each later stored tune baseline is displayed
        # beneath it as V1, V2, V3, ... so the visible tree matches the actual
        # calibration lineage instead of adding a duplicate project-summary row.
        total_rows=sum(max(1,len(self.db.list_versions(int(r['id'])))) for r in rows)
        cols=('project','version','year','model','log','status','updated')
        self.project_tree=ttk.Treeview(proj,columns=cols,show='tree headings',height=min(12,max(2,total_rows)),selectmode='browse')
        self.project_tree.heading('#0',text='Delete');self.project_tree.column('#0',width=54,minwidth=48,anchor='w',stretch=False)
        for k,t,w,stretch in [
            ('project','Project Name',160,True),('version','Version',55,False),('year','MY',48,False),
            ('model','Model',120,True),('log','Log File',145,True),('status','Status',105,True),('updated','Updated',92,False)
        ]:
            self.project_tree.heading(k,text=t);self.project_tree.column(k,width=w,minwidth=(45 if stretch else w),anchor='w',stretch=stretch)
        self.project_delete_checks=set();self.project_delete_nodes={}
        for r in rows:
            pid=int(r['id']);pr=self.db.get_project(pid);versions=self.db.list_versions(pid);pname=self.db.project_display_name(pid)
            if not versions:continue
            v0=versions[0]
            if int(v0['version_no'])!=0:continue
            root_iid=f'p:{pid}'
            log0=Path(v0['log_source_path']).name if v0['log_source_path'] else '—'
            state0=self.db.project_state(pid,0)['state'].replace('_',' ')
            updated0=str(v0['completed_at'] or v0['created_at'] or '')[:10]
            self.project_tree.insert('', 'end', iid=root_iid, text='☐', values=(pname,'V0',pr.model_year,pr.model,log0,state0,updated0),open=True)
            self.project_delete_nodes[root_iid]=('project',pid,None)
            parent=root_iid
            for v in versions[1:]:
                vn=int(v['version_no']);iid=f'v:{pid}:{vn}'
                logn=Path(v['log_source_path']).name if v['log_source_path'] else '—'
                st=self.db.project_state(pid,vn)['state'].replace('_',' ')
                updated=str(v['completed_at'] or v['created_at'] or '')[:10]
                self.project_tree.insert(parent,'end',iid=iid,text='☐',values=('',f'V{vn}',pr.model_year,pr.model,logn,st,updated),open=True)
                self.project_delete_nodes[iid]=('version',pid,vn);parent=iid
        self.project_tree.pack(fill='x',pady=(7,4))
        self.project_tree.bind('<Button-1>',self._project_tree_click)
        self.project_tree.bind('<Double-1>',self._project_tree_double_click)
        self.project_tree.bind('<space>',lambda e:self._project_tree_space())
        self.project_tree.bind('<<TreeviewSelect>>',self._project_tree_selection_changed)
        # Keep the action controls inside the normal non-maximized content width.
        # The continuity note is placed on a second line instead of forcing the
        # page wider than the application viewport.
        act=tk.Frame(proj,bg='white');act.pack(fill='x')
        self.project_open_button=ttk.Button(act,text='Open',style='Secondary.TButton',command=self._open_selected_project,state='disabled');self.project_open_button.pack(side='left')
        ttk.Button(act,text='Recover .htt',style='Secondary.TButton',command=self._recover_selected_version).pack(side='left',padx=6)
        self.delete_all_var=tk.BooleanVar(value=False)
        ttk.Checkbutton(act,text='Delete All',variable=self.delete_all_var,command=self._project_delete_all_toggle).pack(side='left',padx=(14,4))
        ttk.Button(act,text='Delete Selected',style='Secondary.TButton',command=self._delete_from_setup).pack(side='left')
        info=tk.Frame(proj,bg='white');info.pack(fill='x',pady=(5,0))
        tk.Label(info,text='Selecting a version also selects every later version to preserve continuity.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8),anchor='w',justify='left',wraplength=560).pack(side='left',fill='x',expand=True)
        if self.project and self.active_version_no is not None:
            iid=(f'p:{self.project.id}' if int(self.active_version_no)==0 else f'v:{self.project.id}:{self.active_version_no}')
            if self.project_tree.exists(iid):
                self.project_tree.selection_set(iid);self.project_tree.see(iid)
                tk.Label(info,text=f'Active: {self.db.project_display_name(self.project.id)} V{self.active_version_no}',bg='white',fg=C['accent'],font=('Microsoft Sans Serif',8,'bold')).pack(side='right',padx=(12,0))
        self._project_tree_selection_changed()

    def _project_tree_selection_changed(self,_event=None):
        btn=getattr(self,'project_open_button',None)
        if btn is None:return
        try:
            if self._selected_tree_version():btn.state(['!disabled'])
            else:btn.state(['disabled'])
        except Exception:
            try:btn.state(['disabled'])
            except Exception:pass

    def _project_tree_info(self,iid):
        try:
            if str(iid).startswith('p:'):
                return ('project',int(str(iid).split(':',1)[1]),None)
            if str(iid).startswith('v:'):
                _,pid_s,v_s=str(iid).split(':',2);return ('version',int(pid_s),int(v_s))
        except Exception:
            pass
        return None
    def _selected_tree_version(self):
        sel=self.project_tree.selection() if hasattr(self,'project_tree') else ()
        if not sel:return None
        info=self._project_tree_info(sel[0])
        if not info:return None
        kind,pid,vn=info
        if kind=='version':return pid,vn
        # The visible project root is V0.  Opening the row therefore opens V0;
        # later current versions are selected from their explicit V1/V2/... rows.
        v0=self.db.get_version(pid,0)
        return (pid,0) if v0 else None
    def _refresh_project_delete_checks(self):
        if not hasattr(self,'project_tree'):return
        for iid in self.project_delete_nodes:
            if self.project_tree.exists(iid):self.project_tree.item(iid,text=('☑' if iid in self.project_delete_checks else '☐'))
        if getattr(self,'delete_all_var',None) is not None:
            all_nodes=set(self.project_delete_nodes)
            should_all=bool(all_nodes) and all_nodes.issubset(self.project_delete_checks)
            if bool(self.delete_all_var.get())!=should_all:self.delete_all_var.set(should_all)
    def _toggle_project_delete_node(self,iid):
        info=self._project_tree_info(iid)
        if not info:return
        kind,pid,vn=info
        version_nodes=[]
        for node,node_info in self.project_delete_nodes.items():
            if node_info[0]=='version' and node_info[1]==pid:version_nodes.append((int(node_info[2]),node))
        version_nodes.sort()
        root=f'p:{pid}'
        if kind=='project':
            nodes=[root]+[node for _,node in version_nodes]
            if root in self.project_delete_checks:
                for node in nodes:self.project_delete_checks.discard(node)
            else:
                self.project_delete_checks.update(nodes)
        else:
            descendants=[node for num,node in version_nodes if num>=int(vn)]
            if iid in self.project_delete_checks:
                # A checked ancestor owns the descendant selection. The user
                # must clear that earlier version first; otherwise the visual
                # selection could imply an impossible orphaned deletion.
                if int(vn)==0:
                    for node in [root]+[node for _,node in version_nodes]:self.project_delete_checks.discard(node)
                else:
                    checked_ancestor=(root in self.project_delete_checks) or any(num<int(vn) and node in self.project_delete_checks for num,node in version_nodes)
                    if not checked_ancestor:
                        for node in descendants:self.project_delete_checks.discard(node)
                        self.project_delete_checks.discard(root)
            else:
                self.project_delete_checks.update(descendants)
                if version_nodes and all(node in self.project_delete_checks for _,node in version_nodes):self.project_delete_checks.add(root)
        self._refresh_project_delete_checks()
    def _project_tree_click(self,event):
        if not hasattr(self,'project_tree'):return
        iid=self.project_tree.identify_row(event.y);col=self.project_tree.identify_column(event.x)
        if iid and col=='#0':
            self.project_tree.selection_set(iid);self._toggle_project_delete_node(iid);self._project_tree_selection_changed();return 'break'
    def _project_tree_double_click(self,event):
        if self.project_tree.identify_column(event.x)=='#0':return 'break'
        self._open_selected_project();return 'break'
    def _project_tree_space(self):
        sel=self.project_tree.selection() if hasattr(self,'project_tree') else ()
        if sel:self._toggle_project_delete_node(sel[0]);self._project_tree_selection_changed()
        return 'break'
    def _project_delete_all_toggle(self):
        if not hasattr(self,'project_delete_nodes'):return
        if self.delete_all_var.get():self.project_delete_checks=set(self.project_delete_nodes)
        else:self.project_delete_checks.clear()
        self._refresh_project_delete_checks()
    def _project_delete_plan(self):
        plan={}
        for iid in getattr(self,'project_delete_checks',set()):
            info=self._project_tree_info(iid)
            if not info:continue
            kind,pid,vn=info
            if kind=='project':plan[pid]=0
            elif pid not in plan or (plan[pid]!=0 and int(vn)<plan[pid]):plan[pid]=int(vn)
        return plan
    def _open_selected_project(self):
        picked=self._selected_tree_version()
        if not picked:messagebox.showinfo('Projects','Select a project version first.');return
        pid,vn=picked;pr=self.db.get_project(pid)
        if not pr:return
        self.db._assert_owner(pid,self.user.id);v=self.db.get_version(pid,vn);latest=self.db.latest_version(pid)
        if not v:return
        if latest and vn==int(latest['version_no']) and not int(v['run_completed']) and vn>0:
            # Successor versions open directly in Setup.  Their inherited project
            # metadata and stored tune baseline are fixed; the user supplies only
            # the new VCM Scanner Log File (.hpl), then explicitly continues from
            # the existing Setup action button after qualification passes.
            self.project=pr;self.active_version_no=vn;self.metrics=dict(self.fixed_metrics);self.surface_cache={};self.surface_display_cache=None;self.run_trim_chart_data={'cells':{},'sample_count':0};self.shell();self.goto('setup')
            return
        self.project=pr;self.active_version_no=vn;self.metrics=dict(self.fixed_metrics);self.surface_cache={};self.surface_display_cache=None;self.run_trim_chart_data={'cells':{},'sample_count':0};self.shell();self.goto('setup')
    def _reset_project_workflow_state(self):
        # A new project must never inherit presentation or processing state from
        # the previously opened/completed project. Database project data remain
        # untouched; this clears only the active UI/workflow context.
        self.project=None;self.active_version_no=None;self.metrics={};self.fixed_metrics={}
        self.surface_cache={};self.surface_display_cache=None
        self.run_trim_chart_data={'cells':{},'sample_count':0,'max_abs_sample':0.0};self.run_trim_canvas=None
        self.run_quality_vars={};self.run_quality_activity_widget=None;self.run_quality_activity_lines=[];self._run_quality_last_activity=None;self._run_quality_active_stage=None;self._progress_activity_times={}
        self.correction_source_selection=None;self.correction_preflight_cache=None;self.correction_preflight_context=None;self.correction_rescale_approved=False;self.correction_preflight_running=False
        self._stop_setup_header_blink()
        self.setup_panel_message=None
        self.setup_activity_state=None
        self._setup_header_mode=None;self._setup_action_command=None
        self._progress_context=None
        self._setup_lower_mode='status';self._staged_project_name=None
        self._setup_build_in_progress=False;self._correction_launch_pending=False
        # Submit starts one unattended workflow. Safety decisions pause it;
        # changing the staged inputs, errors or leaving Setup cancels it.
        self._cancel_auto_submit()
        self._failed_log_detail=None;self._failed_log_report=None
        self._vin_lookup_generation+=1
        self._vin_lookup_pending=False
        self.vs_na_closed_loop_only=False
        self.application_selected_percent=None;self.application_selection_context=None;self.application_preview_candidate=None;self.application_preview_accepted=None;self.application_preview_metrics=None;self.application_checks={};self.application_buttons={};self.application_preview_host=None;self.build_it_btn=None
        self.progress.set(0);self.run_title.set('Ready');self.run_detail.set('');self.run_pct.set('');self.run_elapsed.set('')
        self.page_history=[];self.current_page=None
        self._stop_run_trim_watch()

    def _new_project_setup(self):
        if getattr(self,'_setup_build_in_progress',False):return
        self._reset_project_workflow_state();self.shell();self.goto('setup',record_history=False)
    def _select_initial_htt(self):
        self._cancel_auto_submit()
        if self.project:
            v=self._active_version()
            if not v or int(v['version_no'])!=0 or str(v['baseline_htt_path'] or '').strip():return
        p=filedialog.askopenfilename(title='Select Tune File (.htt)',filetypes=[('HP Tuners Template File','*.htt')])
        if not p:return
        try:
            self.db.validate_initial_htt(Path(p));self._setup_verified_signature=None
            self.vs_vars['htt'].set(p)
            self.vs_status.set('Tune File (.htt) validated.')
            # Changing the Tune File never submits or processes a staged Log File.
            # The user can review both selections before pressing Submit Files.
            self.vs_log_valid=False;self.vs_log_staged=bool(self.vs_vars['log'].get().strip())
            self.vs_log_report=None
            self.vs_log_summary.set('Tune File changed. Review both files, then select Submit.')
            self.vs_status.set('Files selected. Submit to validate.')
            self.setup_processing_active=True
            if self.vs_log_staged:self._show_setup_vehicle_verification()
            else:self._set_setup_panel_message('Tune File Selected',
                'Tune File accepted. Select the corresponding Log File (.hpl), then Submit for validation.',requires_action=False)
            self._setup_processing_changed()
            self._vehicle_form_update()
        except Exception as e:
            self._set_setup_panel_message('Tune File Error',str(e))
            return
    def _recover_selected_version(self):
        picked=self._selected_tree_version()
        if not picked:messagebox.showinfo('Projects','Select a completed version first.');return
        pid,vn=picked
        try:
            v=self.db.get_version(pid,vn)
            if not v or not int(v['run_completed']):raise ValueError('That version has no stored review result to recover.')
            recovery_mode=self.license_status().get('mode')
            processed=recovery_mode in ('licensed','trial')
            if processed:
                src=Path(str(v['result_htt_path'] or ''));expected=str(v['result_htt_sha256'] or '')
            else:
                src=Path(str(v['baseline_htt_path'] or ''));expected=str(v['baseline_htt_sha256'] or '')
            if not src.is_file() or (expected and s5.sha256_file(src)!=expected):raise ValueError('Stored .htt source failed integrity validation.')
            dest=Path.home()/'Downloads';dest.mkdir(parents=True,exist_ok=True)
            target=dest/f'{self.db.version_result_prefix(pid,vn)}_Result.htt';shutil.copy2(src,target)
            if s5.sha256_file(target)!=s5.sha256_file(src):raise ValueError('Recovered .htt failed integrity verification.')
            open_path(dest)
            note='' if processed else '\n\nDEMO recovery is an unchanged copy of the input .htt.'
            messagebox.showinfo('Version Recovery',f'Recovered:\n{target}{note}')
        except Exception as e:messagebox.showerror('Version Recovery',str(e))
    def _delete_selected_project(self):
        # Compatibility helper for older callers: mark the currently highlighted
        # node, then use the Candidate 11 lineage-safe deletion path.
        sel=self.project_tree.selection() if hasattr(self,'project_tree') else ()
        if not sel:messagebox.showinfo('Projects','Check the project or version(s) you want to delete.');return
        self._toggle_project_delete_node(sel[0]);self._delete_from_setup()
    def _delete_from_setup(self):
        plan=self._project_delete_plan()
        if not plan:
            messagebox.showinfo('Projects','Check the project or version(s) you want to delete.');return
        lines=[]
        try:
            for pid,start in sorted(plan.items()):
                self.db._assert_owner(pid,self.user.id);versions=self.db.list_versions(pid)
                if not versions:raise ValueError('A selected project no longer has stored versions.')
                latest=int(versions[-1]['version_no']);name=self.db.project_display_name(pid)
                if int(start)<=0:
                    lines.append(f'{name}: entire project (V0-V{latest})')
                else:
                    if int(start)>latest:raise ValueError(f'{name}: selected version no longer exists.')
                    lines.append(f'{name}: V{int(start)}-V{latest} (rollback to V{int(start)-1}; fresh V{int(start)} workspace will be created)')
        except Exception as e:
            messagebox.showerror('Delete Selection',str(e));return
        prompt='Delete the selected project/version data?\n\n'+'\n'.join('• '+x for x in lines)+'\n\nLater versions are deleted automatically with any selected earlier version so the calibration lineage cannot be orphaned. This cannot be undone.'
        if not messagebox.askyesno('Delete Selected Projects / Versions',prompt):return
        active_pid=(int(self.project.id) if self.project else None);active_v=self.active_version_no
        try:
            for pid,start in sorted(plan.items()):
                if int(start)<=0:self.db.delete_project_tree(pid,self.user.id)
                else:self.db.delete_version_suffix(pid,self.user.id,int(start))
            if active_pid in plan:
                start=int(plan[active_pid])
                if start<=0:
                    self.project=None;self.active_version_no=None
                elif active_v is None or int(active_v)>=start:
                    self.project=self.db.get_project(active_pid);self.active_version_no=start
                else:
                    self.project=self.db.get_project(active_pid)
            elif self.project:
                self.project=self.db.get_project(self.project.id)
            self.shell();self.goto('projects')
        except Exception as e:messagebox.showerror('Delete Selection',str(e))
    def _identify_selected_log_vehicle(self,log_path):
        # Read native VIN and decode optional identity asynchronously.
        # A missing VIN or network failure cannot block processing.
        self._vin_lookup_generation+=1
        generation=self._vin_lookup_generation
        vin=extract_hpl_vin(log_path)
        self.vs_vars['vin'].set(vin)
        self._vin_lookup_pending=False
        if not vin:
            self._record_processing_fact('VIN','Not available (optional)')
            self._show_setup_vehicle_verification()
            return
        self._record_processing_fact('VIN','Available')
        if self.project:
            # Project identity/calibration lineage cannot be rewritten by a
            # later version's HPL. VIN is still displayed for log selection.
            self._show_setup_vehicle_verification()
            return
        self._vin_lookup_pending=True
        initial_identity=tuple(self.vs_vars[key].get() for key in
                               ('year','model','engine','transmission'))
        self._set_setup_activity('Vehicle identification',
            'Identifying vehicle model, engine and transmission.',busy=True)
        self._show_setup_vehicle_verification()
        self._vehicle_form_update()
        def worker():
            try:return decode_vin_optional(vin)
            except (OSError,ValueError,TimeoutError,KeyError,TypeError):return None
        def done(decoded):
            if generation!=self._vin_lookup_generation or self.current_page!='setup':return
            if self.vs_vars['log'].get()!=str(log_path):return
            self._vin_lookup_pending=False
            current=tuple(self.vs_vars[key].get() for key in
                          ('year','model','engine','transmission'))
            if decoded and current==initial_identity:
                for key,field in (('year','model_year'),('model','model_name'),
                                  ('engine','engine'),('transmission','transmission')):
                    if decoded.get(field):self.vs_vars[key].set(decoded[field])
                self._record_processing_fact('Vehicle','Information populated — Verify to confirm')
            else:
                self._record_processing_fact('Vehicle','Review displayed information and select Verify')
            self._set_setup_activity('Vehicle identification complete',
                'Review the vehicle details and select Verify.',busy=False)
            self._show_setup_vehicle_verification()
            self._vehicle_form_update()
        self._run_background_task(worker,done)
    def _show_log_requirements(self):
        tune=self._setup_candidate_tune_path()
        try:
            airflow_model=wideband.detect_airflow_model(tune) if tune is not None else 'neural_network'
        except Exception as exc:
            messagebox.showerror('Required Channels',f'Unable to determine optimization method from Tune File: {exc}')
            return
        top=tk.Toplevel(self.root);top.title('Required Log Data / Recommended Polling');top.geometry('930x600');top.minsize(820,520);top.configure(bg=C['bg']);top.transient(self.root)
        wrap=tk.Frame(top,bg=C['bg']);wrap.pack(fill='both',expand=True,padx=22,pady=18)
        tk.Label(wrap,text='Required Log Data',bg=C['bg'],fg=C['text'],font=('Microsoft Sans Serif',18,'bold')).pack(anchor='w')
        profile=('Method B — Speed Density Optimization (Neural Network disabled)' if airflow_model=='speed_density' else 'Method A — Neural Network Optimization (Neural Network enabled)')
        if tune is None:profile+=' — default until a Tune File is selected'
        tk.Label(wrap,text=f'{profile}. Prepare VCM Scanner with these logical signals. Channel names may vary. Broadcast channels remain at 0 ms; use the listed rate only for a polled counterpart.',bg=C['bg'],fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=880,justify='left').pack(anchor='w',pady=(3,12))
        cols=('signal','required','broadcast','polled','note');tree=ttk.Treeview(wrap,columns=cols,show='headings',height=16)
        setup=[('signal','Data',245),('required','Need',75),('broadcast','Broadcast',85),('polled','Polled counterpart',145),('note','Notes',330)]
        for k,t,w in setup:tree.heading(k,text=t);tree.column(k,width=w,anchor='w')
        for row in logcheck.required_channel_guide(airflow_model):
            polled=f"{int(row['polled_ms'])} ms / {row['polled_hz']:.0f} Hz or faster" if row['polled_ms'] else '—'
            need='Required' if row['required'] else ('Advisory' if row.get('advisory') else ('Reference' if airflow_model=='speed_density' else ('Preferred' if row['key']=='fuel_air_stoich' else 'Optional')))
            note=row['note'] or ('Same underlying data; polling primarily fills empty logging cells.' if row['required'] else '')
            tree.insert('', 'end', values=(row['label'],need,'0 ms',polled,note))
        tree.pack(fill='both',expand=True)
        foot=tk.Frame(wrap,bg=C['bg']);foot.pack(fill='x',pady=(10,0))
        floor_note=('Method B: STFT Bank 1 and Bank 2 presence is mandatory. Other entries are independent reference channels; their minimum density is not a general log acceptance gate.' if airflow_model=='speed_density' else
                    f'Density floors: {logcheck.MIN_REQUIRED_UPDATES:,} fast-channel observations, '
                    f'{logcheck.MIN_SLOW_STATE_UPDATES:,} slow-state observations.')
        tk.Label(foot,text=f'{floor_note} Correction-source Preflight may impose additional requirements.',bg=C['bg'],fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=760,justify='left').pack(side='left',anchor='w')
        ttk.Button(foot,text='Close',style='Secondary.TButton',command=top.destroy).pack(side='right')
        ttk.Button(foot,text='Help',style='Secondary.TButton',command=lambda:self.show_help('minimum_channels',top)).pack(side='right',padx=(0,8))

    def _offer_na_closed_loop_only(self,report,tune_path,log_path):
        """Compatibility helper: do not silently approve absent knock channels."""
        return report

    def _prompt_na_closed_loop_only(self,report,tune_path,log_path,decision):
        """Present the actual user decision in the dynamic upper-right panel."""
        if not logcheck.na_knock_exception_eligible(report):
            self.vs_na_closed_loop_only=False;decision(report,False);return
        from ve_optimizer_boost_review import na_closed_loop_evidence
        verified,_=na_closed_loop_evidence(tune_path,log_path,report['airflow_model'])
        if not verified:
            self.vs_na_closed_loop_only=False;decision(report,False);return
        def choose(approved):
            if not approved:
                self._cancel_auto_submit()
                # Declining cannot silently fall back to a less restrictive
                # correction source. Require explicit selection of a new HPL.
                self.vs_na_closed_loop_only=False
                self.vs_log_valid=False
                self.vs_log_staged=False
                self.vs_log_report=None
                self.vs_vars['log'].set('')
                self._setup_lower_mode='status'
                self._render_setup_lower_view()
                self._vehicle_form_update()
                self._set_setup_panel_message('SELECT ANOTHER LOG FILE',
                    'This Log File was not approved for closed-loop-only correction. '
                    'Select a different Log File (.hpl) to continue.')
                self._select_current_log()
                return
            self.vs_na_closed_loop_only=True
            self._set_setup_panel_message('Log File Validation',
                'Applying the approved naturally aspirated closed-loop-only qualification.',requires_action=False)
            decision(logcheck.allow_na_closed_loop_only(report),True)
        self._set_setup_panel_message('KNOCK DATA NOT FOUND',
            'The current log file does not include montioring knock status. '
            'Without this information, it would be too risky to attempt anything other than a closed loop tune. '
            'Wide Open Throttle, (WOT), data will not be included. '
            'Select Yes to proceed or No to select a different log file.',
            align='center', actions=(('Yes',lambda:choose(True)),('No',lambda:choose(False))))

    def _show_log_validation(self,report=None,require_decision=False,qualified_override=None,qualification=None):
        report=report or self.vs_log_report
        if not report:messagebox.showinfo('Log File Validation','Select a Log File first.');return None
        # Older projects may contain a cached validation report with the wrong
        # airflow model or an obsolete channel-density policy.  Refresh on view
        # so saved ECT failure statuses are not displayed after policy changes.
        tune=self._setup_candidate_tune_path()
        if tune is not None:
            try:
                active_model=wideband.detect_airflow_model(tune)
                if (report.get('airflow_model') != active_model or
                    report.get('validation_policy_revision') != logcheck.LOG_VALIDATION_POLICY_REVISION):
                    active_v=self._active_version() if self.project else None
                    source=str(self.vs_vars['log'].get() or '').strip()
                    if not source or not Path(source).is_file():
                        source=str(active_v['log_local_path'] or '') if active_v else ''
                    if not source or not Path(source).is_file():
                        raise ValueError('Stored Log File cannot be found for model-specific revalidation.')
                    report=logcheck.analyze_log(Path(source),airflow_model=active_model)
                    approved=version_closed_loop_only(active_v)
                    if approved:
                        report=logcheck.approved_na_closed_loop_report(report,tune,Path(source))
                    qualification=wideband_integration.qualify_log_for_tune(
                        Path(source),tune,report,closed_loop_only=approved)
                    qualified_override=bool(qualification['passed'])
                    self.vs_log_report=report;self.vs_log_valid=qualified_override
            except Exception as exc:
                messagebox.showerror('Log File Validation',f'Unable to refresh the saved Log File channel profile: {exc}')
                return None
        top=tk.Toplevel(self.root);top.title('Log File Channel / Density Validation — '+str(report.get('optimization_method') or ''));top.configure(bg=C['bg']);top.transient(self.root)
        sw=top.winfo_screenwidth();sh=top.winfo_screenheight();ww=min(1040,max(860,sw-50));wh=min(680,max(560,sh-110));x=max(0,(sw-ww)//2);y=max(0,(sh-wh)//2);top.geometry(f'{ww}x{wh}+{x}+{y}');top.minsize(min(860,ww),min(540,wh))
        decision={'value':'return'}
        def close_with(value='return'):
            decision['value']=value
            try:top.grab_release()
            except Exception:pass
            top.destroy()
        top.bind('<Escape>',lambda _e:close_with('return'));top.protocol('WM_DELETE_WINDOW',lambda:close_with('return'))
        wrap=tk.Frame(top,bg=C['bg']);wrap.pack(fill='both',expand=True,padx=12,pady=10);wrap.grid_columnconfigure(0,weight=1);wrap.grid_rowconfigure(2,weight=1)
        passed=(bool(qualified_override) if qualified_override is not None else bool(report['passed']))
        # Data-channel qualification and usable correction-source qualification
        # are separate.  When all channels pass, do not misleadingly label the
        # log itself incomplete just because the selected source has no valid
        # closed-loop/PE events (or its channel names were unrecognized).
        title=('LOG FILE READY' if passed else
               'CORRECTION SOURCE NOT QUALIFIED' if report.get('passed') else
               'LOG FILE INCOMPLETE')
        tk.Label(wrap,text=title,bg=C['bg'],fg=(C['success'] if passed else C['danger']),font=('Microsoft Sans Serif',18,'bold')).grid(row=0,column=0,sticky='w')
        profile=(str(report.get('checkpoint') or '')+' — '+str(report.get('optimization_method') or ('Speed Density Optimization' if report.get('airflow_model')=='speed_density' else 'Neural Network Optimization')))
        tk.Label(wrap,text=f"{profile}  •  Duration {report['duration_text']}  •  {report['row_count']:,} timed scanner rows  •  PASS/FAIL uses actual populated density and coverage, not expected polling cadence.",bg=C['bg'],fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=max(700,ww-55),justify='left').grid(row=1,column=0,sticky='ew',pady=(3,9))
        table_host=tk.Frame(wrap,bg=C['bg']);table_host.grid(row=2,column=0,sticky='nsew');table_host.grid_rowconfigure(0,weight=1);table_host.grid_columnconfigure(0,weight=1)
        table_scroll=tk.Scrollbar(table_host,orient='vertical');table_scroll.grid(row=0,column=1,sticky='ns')
        table_canvas=tk.Canvas(table_host,bg=C['border'],highlightthickness=0,yscrollcommand=table_scroll.set);table_canvas.grid(row=0,column=0,sticky='nsew');table_scroll.config(command=table_canvas.yview)
        table=tk.Frame(table_canvas,bg=C['border'],highlightbackground=C['border'],highlightthickness=1);table_window=table_canvas.create_window((0,0),window=table,anchor='nw')
        def _validation_table_resize(_e=None):
            table_canvas.configure(scrollregion=table_canvas.bbox('all'))
        def _validation_canvas_resize(e):
            table_canvas.itemconfigure(table_window,width=e.width)
        table.bind('<Configure>',_validation_table_resize);table_canvas.bind('<Configure>',_validation_canvas_resize)
        # Show the complete physical HPL channel inventory, including values
        # outside the selected method's independent minimum-channel list.
        # Unpopulated configured channels and missing minimum-list signals are
        # shown explicitly as No Data.
        headers=[('Channel',300),('Status',90),('Updates',75),('Actual density',95),
                 ('Minimum',75),('Coverage',70),('Channel ID / Unit',130)]
        for col,(title,minsize) in enumerate(headers):
            table.grid_columnconfigure(col,weight=(1 if col in (0,6) else 0),minsize=minsize)
            tk.Label(table,text=title,bg='#EEF2F7',fg=C['text'],font=('Microsoft Sans Serif',9,'bold'),anchor='w',padx=7,pady=6,highlightbackground=C['border'],highlightthickness=1).grid(row=0,column=col,sticky='nsew')
        logical={q['key']:q for q in report['signals']}
        for row_index,entry in enumerate(report.get('logged_channels',[]),start=1):
            matched=[logical[k] for k in entry.get('logical_keys',[]) if k in logical]
            requirement=next((q for q in matched if q['required']),None)
            updates=int(entry.get('updates',0))
            duration=float(report.get('duration_s') or 0)
            obs=f'{updates/duration:.2f} Hz' if updates and duration>0 else '—'
            # Display measured density and coverage for every channel,
            # including additional available channels that are not required.
            measured=next((q for q in matched if q.get('count')),None)
            minimum_source=(requirement or measured or {})
            minimum_hz=minimum_source.get('minimum_hz_for_current_duration')
            if minimum_hz is None:minimum_hz=entry.get('minimum_hz_for_current_duration')
            minimum=f'{float(minimum_hz):.2f} Hz' if minimum_hz is not None else '0.00 Hz'
            coverage_value=(measured or {}).get('coverage_ratio')
            if coverage_value is None:coverage_value=entry.get('physical_coverage_ratio',0.0)
            coverage=f'{float(coverage_value)*100:.0f}%'
            status_text=str(entry.get('status','No Data'))
            status_fg=(C['success'] if status_text in ('Pass','Available') else
                       '#000000' if status_text=='No Data' else C['danger'])
            channel_id=str(entry.get('parameter_id') or '—')
            unit=str(entry.get('unit') or '').strip()
            identification=channel_id+(f' / {unit}' if unit else '')
            values=(entry.get('name',''),status_text,f'{updates:,}',obs,minimum,coverage,identification)
            bg='white' if row_index%2 else '#FBFCFE'
            for col,value in enumerate(values):
                fg=status_fg if col==1 else C['text']
                font=('Microsoft Sans Serif',9,'bold') if col==1 else ('Microsoft Sans Serif',9)
                tk.Label(table,text=value,bg=bg,fg=fg,font=font,anchor='w',padx=7,pady=3,highlightbackground=C['border'],highlightthickness=1).grid(row=row_index,column=col,sticky='nsew')
        recs=tk.Frame(wrap,bg='white',highlightbackground=C['border'],highlightthickness=1,height=92);recs.grid(row=3,column=0,sticky='ew',pady=(9,0));recs.grid_propagate(False);recs.grid_columnconfigure(0,weight=1)
        tk.Label(recs,text='RESULT',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).grid(row=0,column=0,sticky='w',padx=12,pady=(7,1))
        if report.get('na_closed_loop_only'):
            summary=('Knock Retard data: No Data. Naturally aspirated closed-loop-only '
                     'correction was approved. Only samples with FA Enrichment = 0.000 '
                     'and FA Power Enrichment = 0.000 will be used. WOT/PE corrections '
                     'are excluded.')
        elif passed and (report.get('recommendations') or not report.get('passed')):
            qpf=(qualification or {}).get('correction_preflight') or {}
            cfg=qpf.get('configuration') or {}
            source_note='selected tune/correction path'
            if cfg.get('airflow_model')=='speed_density':source_note='Speed Density correction path'
            summary=(f'This Log File qualifies for the {source_note}. Any incomplete generic channel-density checks '
                     'were assessed separately by the qualifying correction-source preflight. '
                     'DEGRADED Fuel Flow is advisory here but may block adaptive trims. Review the rows, then select Continue.')
        elif not passed and report.get('passed'):
            source_report=((qualification or {}).get('correction_preflight') or {}).get('sources') or {}
            causes=[]
            adaptive_reason=(source_report.get('adaptive') or {}).get('reason')
            wideband_reason=(source_report.get('wideband') or {}).get('reason')
            preflight_error=(qualification or {}).get('preflight_error')
            if adaptive_reason:
                causes.append('Adaptive/STFT: ' + str(adaptive_reason))
            if wideband_reason:
                causes.append('Wideband: ' + str(wideband_reason))
            if preflight_error:
                causes.append('Correction preflight: ' + str(preflight_error))
            summary=('All required log channels meet density and coverage checks. '
                     'However, no correction source currently qualifies for this tune.'
                     + (' Reasons: ' + ' | '.join(causes) if causes else
                        ' Review Correction Preflight for the selected tune.'))
        elif report.get('map_source_valid') is False:
            summary=str(report.get('map_source_error') or
                        'MAP source is likely invalid. Choose a different MAP channel in VCM Scanner.')
        elif report['recommendations']:
            summary='Some required logical signals did not meet the minimum requirements. Review the FAILED rows above and either correct the channel setup or select another log file.'
        else:
            summary='All required logical signals passed channel availability, actual-density, and temporal-coverage checks.'
            if report.get('warnings'):
                summary += ' Warnings are advisory only; the affected signals still have acceptable actual data density. Review the table above for details.'
        tk.Message(recs,text=summary,bg='white',fg=C['text'],font=('Microsoft Sans Serif',8),width=max(580,ww-90),justify='left').grid(row=1,column=0,sticky='ew',padx=10,pady=(1,8))
        foot=tk.Frame(wrap,bg=C['bg']);foot.grid(row=4,column=0,sticky='ew',pady=(9,0));foot.grid_columnconfigure(0,weight=1)
        tk.Label(foot,text='All channels in the Log File are listed. Method A and Method B use separate minimum-channel checkpoints. No Data means no logged values.',bg=C['bg'],fg=C['muted'],font=('Microsoft Sans Serif',8),wraplength=max(500,ww-430),justify='left').grid(row=0,column=0,sticky='w')
        ttk.Button(foot,text='Help',style='Secondary.TButton',command=lambda:self.show_help('log_file_ready',top)).grid(row=0,column=1,padx=(8,8))
        if require_decision:
            ttk.Button(foot,text='Return to Setup',style='Secondary.TButton',command=lambda:close_with('return')).grid(row=0,column=2,padx=(0,8))
            if passed:ttk.Button(foot,text='Continue',style='Primary.TButton',command=lambda:close_with('continue')).grid(row=0,column=3)
            else:ttk.Button(foot,text='Select Another Log',style='Primary.TButton',command=lambda:close_with('select_another')).grid(row=0,column=3)
            top.grab_set();top.focus_force();self.root.wait_window(top);return decision['value']
        ttk.Button(foot,text='Exit',style='Secondary.TButton',command=lambda:close_with('return')).grid(row=0,column=2)
        return None

    def _setup_candidate_tune_path(self):
        # Resolve this path ONLY on the Tk/main thread.  A project V1+ owns a
        # fixed, inherited full-tune baseline (original V0 plus the committed
        # previous run's applied changes).  Never substitute a partial export
        # or an arbitrary file selected in the old form if the inherited
        # baseline is missing/corrupt.
        if self.project:
            av=self._active_version()
            if av:
                raw=str(av['baseline_htt_path'] or '').strip()
                if raw:
                    path=Path(raw)
                    if not path.is_file():return None
                    expected=str(av['baseline_htt_sha256'] or '').strip()
                    if expected and s5.sha256_file(path)!=expected:return None
                    return path
                if int(av['version_no'])>0:return None
        vars_obj=getattr(self,'vs_vars',{})
        if isinstance(vars_obj,dict) and 'htt' in vars_obj:
            raw=str(vars_obj['htt'].get() or '').strip()
            if raw and Path(raw).is_file():return Path(raw)
        return None

    def _qualify_log_file(self,path:Path,show_details=True,require_decision=False):
        self.vs_status.set('Testing correction sources and data density...');self.root.update_idletasks()
        try:
            tune=self._setup_candidate_tune_path()
            if tune is None:
                raise ValueError('Select the vehicle Tune File (.htt) before validating its Log File. Required channels depend on Neural Network enabled/disabled status.')
            report=logcheck.analyze_log(Path(path),airflow_model=wideband.detect_airflow_model(tune))
            report=self._offer_na_closed_loop_only(report,tune,Path(path))
        except Exception as e:
            self.vs_log_report=None;self.vs_log_valid=False;self.vs_log_summary.set('FAIL — Log File could not be qualified.');self.vs_log_summary_label.configure(fg=C['danger']);self.vs_log_details_btn.state(['disabled']);self.vs_status.set('Log File validation failed.');messagebox.showerror('Log File Validation',str(e));self.vs_log_validation_action='return';return False
        qualification=None
        if tune is not None:
            try:qualification=wideband_integration.qualify_log_for_tune(
                Path(path),tune,report,closed_loop_only=self.vs_na_closed_loop_only)
            except Exception:qualification=None
        adaptive_ok=bool(qualification.get('adaptive_ready')) if qualification is not None else bool(report.get('passed'))
        wideband_ok=bool(qualification and qualification.get('wideband_ready'))
        passed=bool(adaptive_ok or wideband_ok)
        self.vs_log_report=report;self.vs_log_valid=passed;self.vs_log_details_btn.state(['!disabled'])
        if adaptive_ok:
            qpf=(qualification or {}).get('correction_preflight') or {};sd_mode=((qpf.get('configuration') or {}).get('airflow_model')=='speed_density')
            if sd_mode and not report.get('passed'):
                self.vs_log_summary.set('PASS — Neural Network is disabled; Speed Density fuel trims are qualified.')
            else:self.vs_log_summary.set(logcheck.summary_text(report))
            self.vs_status.set('Log File qualification passed.')
        elif wideband_ok:
            qpf=(qualification or {}).get('correction_preflight') or {}
            sd_mode=((qpf.get('configuration') or {}).get('airflow_model')=='speed_density')
            if sd_mode:
                self.vs_log_summary.set('PASS — Neural Network is disabled; Speed Density mode and valid Wideband data detected.')
                self.vs_status.set('Log File qualified for Speed Density/Wideband processing.')
            else:
                self.vs_log_summary.set('PASS — Valid Wideband correction data detected; adaptive LTFT/STFT requirements are incomplete.')
                self.vs_status.set('Log File qualified for Wideband processing. Correction Preflight will select the usable source.')
        else:
            self.vs_log_summary.set(logcheck.summary_text(report));self.vs_status.set('Log File failed qualification. Review the recommendations.')
        self.vs_log_summary_label.configure(fg=(C['success'] if passed else C['danger']))
        if show_details:
            self.vs_log_validation_action=self._show_log_validation(report,require_decision=require_decision,qualified_override=passed,qualification=qualification)
        else:self.vs_log_validation_action=None
        return passed

    def _select_current_log(self):
        if getattr(self,'_setup_build_in_progress',False):return
        self._cancel_auto_submit()
        self._failed_log_detail=None;self._failed_log_report=None
        if self.user.role=='guest':messagebox.showinfo('Read-only','Guest users cannot change Setup.');return
        if self._setup_candidate_tune_path() is None:
            messagebox.showinfo('Full Engine .htt Required','Select the vehicle Full Engine .htt first. Log requirements depend on whether Neural Network is enabled.');return
        av=self._active_version() if self.project else None
        if av and int(av['run_completed']):messagebox.showinfo('Read-only',f"V{int(av['version_no'])} is historical and locked/read-only.");return
        if self.project:
            latest=self.db.latest_version(self.project.id)
            if not latest or not av or int(av['version_no'])!=int(latest['version_no']):messagebox.showinfo('Read-only','Only the current/latest project version can accept a new Log File.');return
        old_path=str(av['log_source_path'] or '') if av else self.vs_vars['log'].get()
        title='Change Current HP Tuners Log File' if old_path else 'Select Current HP Tuners Log File'
        p=filedialog.askopenfilename(title=title,filetypes=[('HP Tuners Log File','*.hpl')])
        if not p:return
        self._setup_verified_signature=None
        self.vs_vars['log'].set(p)
        self.vs_log_staged=True
        self.vs_log_valid=False
        self.vs_na_closed_loop_only=False
        self.vs_log_report=None
        self.vs_log_summary.set('Log File selected but not submitted. Select Submit to validate.')
        self.vs_status.set('Review Tune File and Log File, then select Submit.')
        self.setup_processing_active=True
        self._set_setup_activity('Log File selected',
            'Reading optional vehicle profile and preparing vehicle confirmation.',busy=False)
        self._identify_selected_log_vehicle(p)
        self._setup_processing_changed()
        self._setup_lower_mode='status'
        self._render_setup_lower_view()
        self._vehicle_form_update()

    def _cancel_auto_submit(self):
        """Stop auto-navigation without modifying any calibration/database data."""
        self._auto_submit_active=False
        self._auto_submit_signature=None
        self._auto_submit_generation=getattr(self,'_auto_submit_generation',0)+1

    def _auto_build_after_log(self):
        """Successful, unchanged and user-verified Submit continues to Build."""
        if not self._auto_submit_active:return
        if (self.current_page!='setup' or not self.vs_log_valid or
                self.vs_log_staged or not self._setup_vehicle_is_verified() or
                self._setup_vehicle_signature()!=self._auto_submit_signature):
            self._cancel_auto_submit()
            return
        self._save_vehicle_setup()

    def _auto_advance_preflight(self):
        """One qualified source auto-runs; two sources pause for an explicit choice."""
        if not self._auto_submit_active or self.current_page!='setup' or self.running:
            return
        if self._setup_lower_mode!='preflight' or self.correction_preflight_running:
            return
        if (self.setup_panel_message or {}).get('requires_action'):
            # An unresolved Yes/No, source choice or safety issue must stop here.
            return
        if self.correction_preflight_context!=self._correction_context():return
        sources=(self.correction_preflight_cache or {}).get('choices') or []
        enabled=[x.get('id') for x in sources if x.get('id') in ('adaptive','wideband')
                 and x.get('enabled')]
        if len(enabled)==1 and self.correction_source_selection==enabled[0]:
            # Never bypass the source/block gates in _run_selected_correction.
            self._run_selected_correction()

    def _view_failed_log_diagnostics(self):
        """Single fixed VIEW action, with no false success on unreadable HPL."""
        report=getattr(self,'_failed_log_report',None)
        if report is not None:
            self._show_log_validation(report,qualified_override=False)
        else:
            messagebox.showerror('Log File Validation',
                self._failed_log_detail or 'This Log File failed validation; no channel inventory is available.',
                parent=self.root)

    @staticmethod
    def _failed_log_summary(report,qualification):
        """Show the actual failed channel/source reasons in the MESSAGE pane."""
        parts=[]
        if report.get('map_source_error'):parts.append(str(report['map_source_error']))
        parts.extend(str(item) for item in (report.get('recommendations') or []) if item)
        q=(qualification or {}).get('correction_preflight') or {}
        for key in ('adaptive','wideband'):
            reason=((q.get('sources') or {}).get(key) or {}).get('reason')
            if reason:parts.append(f'{key.title()}: {reason}')
        error=(qualification or {}).get('preflight_error')
        if error:parts.append(f'Correction preflight: {error}')
        # Do not manufacture a cause when validation supplies only a pass flag.
        if not parts:
            parts=[str(logcheck.summary_text(report))]
        return 'Log File qualification failed. ' + ' | '.join(parts)

    def _submit_selected_log(self):
        """Submit initiates a guarded, pause-on-decision path through Results."""
        if getattr(self,'_setup_build_in_progress',False):return
        p=str(self.vs_vars['log'].get() or '').strip()
        if not p or not Path(p).is_file():
            self._set_setup_panel_message('Log File Required','Select a Log File (.hpl) before submitting.')
            return
        if not self._setup_vehicle_is_verified():
            self._show_setup_vehicle_verification()
            self._vehicle_form_update()
            return
        # Snapshot the tune baseline on the Tk thread before starting the log
        # worker.  The former worker called _setup_candidate_tune_path(), which
        # queries the main-thread SQLite connection and Tk StringVars.  SQLite
        # raises a thread-ownership error on V1+; the lookup swallowed it and
        # incorrectly reported that a Full Engine .htt was missing.
        tune=self._setup_candidate_tune_path()
        if tune is None:
            self._set_setup_panel_message('Tune File Required',
                'The stored full Tune File (.htt) is missing or failed integrity verification. '
                'The project will not substitute a partial template or change its baseline.')
            return
        tune_sha=s5.sha256_file(tune)
        av=self._active_version() if self.project else None
        if av and int(av['run_completed']):
            messagebox.showinfo('Read-only','Completed projects are locked.',parent=self.root)
            return
        old_path=str(av['log_source_path'] or '') if av else ''
        try:self.vs_log_submit_button.state(['disabled'])
        except Exception:pass
        prior_sha=''
        if self.project and av and int(av['version_no'])>0:
            prior=self.db.get_version(self.project.id,int(av['version_no'])-1)
            prior_sha=str(prior['log_sha256'] or '') if prior else ''
        prior_report=self.vs_log_report;prior_valid=self.vs_log_valid;prior_summary=self.vs_log_summary.get();prior_log=self.vs_vars['log'].get()
        prior_na_approval=bool(self.vs_na_closed_loop_only)
        self._auto_submit_generation+=1
        generation=self._auto_submit_generation
        self._auto_submit_active=True
        self._auto_submit_signature=self._setup_vehicle_signature()
        self._failed_log_detail=None;self._failed_log_report=None
        self.setup_processing_active=True
        self.vs_status.set('Validating selected Log File (.hpl)...')
        self._set_setup_panel_message('Log File Validation',
            'Checking the selected log for valid required channels and available correction data.',requires_action=False)
        def restore_prior(status_text=None):
            self.vs_na_closed_loop_only=prior_na_approval
            self.vs_log_report=prior_report;self.vs_log_valid=prior_valid;self.vs_log_summary.set(prior_summary);self.vs_vars['log'].set(prior_log);self.vs_log_summary_label.configure(fg=(C['success'] if prior_valid else C['muted']));self.vs_log_details_btn.state(['!disabled'] if prior_report else ['disabled'])
            if status_text:self.vs_status.set(status_text)
            self._render_setup_lower_view()
            self._vehicle_form_update()
        self._show_working_overlay('Log File validation', 'Checking native HPL format and required channels.')
        def worker():
            try:
                ok,msg=validate_hp_tuners_log(Path(p))
                if not ok:return ('invalid',msg,None)
                if prior_sha and s5.sha256_file(Path(p))==prior_sha:return ('duplicate','The new Log File is identical to the prior stored Log File. Select a different VCM Scanner Log File (.hpl).',None)
                # The worker uses only the immutable path/hash captured on the
                # UI thread; no UI or SQLite lookups are allowed here.
                if not tune.is_file() or s5.sha256_file(tune)!=tune_sha:
                    raise ValueError('The stored full Tune File changed during Log File validation. Processing was stopped.')
                report=logcheck.analyze_log(Path(p),airflow_model=wideband.detect_airflow_model(tune))
                qualification=None
                if tune is not None:
                    try:qualification=wideband_integration.qualify_log_for_tune(Path(p),tune,report)
                    except Exception:qualification=None
                return ('report','',(report,qualification))
            except Exception as e:return ('error',str(e),None)
        def done(result):
            # Ignore a stale HPL result after replacing files or submitting
            # again; never overwrite a newer user selection.
            if generation!=self._auto_submit_generation:return
            if (not self._auto_submit_active or self.current_page!='setup' or
                    self._setup_vehicle_signature()!=self._auto_submit_signature):
                self._cancel_auto_submit()
                self._hide_working_overlay()
                self.vs_log_valid=False;self.vs_log_staged=True;self.vs_log_report=None
                self._set_setup_panel_message('Log File Selection Changed',
                    'The selected Log File or vehicle changed during validation. Verify the current selection and Submit again.')
                self._vehicle_form_update()
                return
            self._hide_working_overlay();kind,msg,payload=result
            try:self.vs_log_submit_button.state(['!disabled'])
            except Exception:pass
            if kind!='report':
                self._cancel_auto_submit()
                restore_prior('Log File validation failed.' if kind in ('invalid','error') else None)
                self._failed_log_detail=str(msg);self._failed_log_report=None
                self._set_setup_panel_message('Log File Error',msg)
                return
            report,qualification=payload
            names=(report.get('channel_inventory') or report.get('channel_names') or
                   report.get('signals') or [])
            if names:self._record_processing_fact('Channels',f'{len(names):,} available')
            def decision(updated_report,approved):
                if not approved:
                    finish_validation(updated_report,qualification)
                    return
                self.vs_status.set('Validating approved closed-loop-only correction...')
                self._show_working_overlay('Closed-loop-only qualification', 'Rechecking the accepted HPL events after approval.')
                def approved_worker():
                    try:
                        q=wideband_integration.qualify_log_for_tune(
                            Path(p),tune,updated_report,closed_loop_only=True)
                        return ('ok',q)
                    except Exception as exc:return ('error',str(exc))
                def approved_done(updated):
                    if generation!=self._auto_submit_generation or not self._auto_submit_active:return
                    self._hide_working_overlay()
                    if updated[0]!='ok':
                        self._cancel_auto_submit()
                        restore_prior('Log File qualification could not complete.')
                        self._failed_log_detail=str(updated[1]);self._failed_log_report=None
                        self._set_setup_panel_message('Log File Validation Error',str(updated[1]))
                        return
                    finish_validation(updated_report,updated[1])
                self._run_background_task(approved_worker,approved_done)
            try:self._prompt_na_closed_loop_only(report,tune,Path(p),decision)
            except Exception as exc:
                self._cancel_auto_submit()
                restore_prior('Log File qualification could not complete.')
                self._failed_log_detail=str(exc);self._failed_log_report=None
                self._set_setup_panel_message('Log File Validation Error',str(exc))
        def finish_validation(report,qualification):
            if generation!=self._auto_submit_generation or not self._auto_submit_active:return
            adaptive_ok=(bool(qualification.get('adaptive_ready')) if qualification is not None else bool(report.get('passed')));wideband_ok=bool(qualification and qualification.get('wideband_ready'));passed=adaptive_ok or wideband_ok
            self._record_processing_fact('Fuel trims','Qualified' if adaptive_ok else 'Not qualified')
            self._record_processing_fact('Wideband','Qualified' if wideband_ok else 'Not qualified')
            self.vs_log_report=report;self.vs_log_valid=passed;self.vs_log_details_btn.state(['!disabled'])
            if adaptive_ok:
                qpf=(qualification or {}).get('correction_preflight') or {};sd_mode=((qpf.get('configuration') or {}).get('airflow_model')=='speed_density')
                if sd_mode and not report.get('passed'):
                    self.vs_log_summary.set('PASS — Neural Network is disabled; Speed Density fuel trims are qualified.')
                else:self.vs_log_summary.set(logcheck.summary_text(report))
                self.vs_log_summary_label.configure(fg=C['success']);self.vs_status.set('Log File qualification passed.')
            elif wideband_ok:
                qpf=(qualification or {}).get('correction_preflight') or {};sd_mode=((qpf.get('configuration') or {}).get('airflow_model')=='speed_density')
                if sd_mode:
                    self.vs_log_summary.set('PASS — Neural Network is disabled; Speed Density mode and valid Wideband data detected.');self.vs_status.set('Log File qualified for Speed Density/Wideband processing.')
                else:
                    self.vs_log_summary.set('PASS — Valid Wideband correction data detected; adaptive LTFT/STFT requirements are incomplete.');self.vs_status.set('Log File qualified for Wideband processing.')
                self.vs_log_summary_label.configure(fg=C['success'])
            else:
                self.vs_log_summary.set(logcheck.summary_text(report));self.vs_log_summary_label.configure(fg=C['danger']);self.vs_status.set('Log File failed qualification. Review the recommendations.')
            if not passed:
                self._cancel_auto_submit()
                self._failed_log_report=report
                self._failed_log_detail=self._failed_log_summary(report,qualification)
            self._set_setup_panel_message('LOG FILE READY' if passed else 'LOG FILE INCOMPLETE',
                self.vs_log_summary.get() if passed else self._failed_log_detail,
                align='left',requires_action=not passed)
            self._setup_processing_changed()
            # Detailed channel inventory is exposed by the fixed VIEW button
            # only if validation fails; passing logs continue automatically.
            self.vs_log_validation_action=None
            self._setup_lower_mode='status'
            self._render_setup_lower_view()
            if not passed:
                # Keep the rejected report available through View so the user can
                # identify missing channels without approving or storing this log.
                self.vs_log_valid=False
                self.vs_log_staged=True
                self._render_setup_lower_view()
                self._vehicle_form_update()
                return
            self.vs_vars['log'].set(p);self.vs_log_staged=False;self.vs_log_replacement_pending=bool(old_path and os.path.abspath(old_path)!=os.path.abspath(p))
            if self.project and av:
                self.vs_status.set(f"V{int(av['version_no'])} Log File qualification passed.")
                self._vehicle_form_update()
                self.root.after_idle(self._auto_build_after_log)
                return
            self.vs_status.set('Initial Log File qualification passed.');self._vehicle_form_update()
            self.root.after_idle(self._auto_build_after_log)
        self._run_background_task(worker,done)
    def _vehicle_form_update(self):
        if getattr(self,'_setup_build_in_progress',False):
            for name in ('vs_save','vs_log_submit_button','vs_log_button'):
                widget=getattr(self,name,None)
                if widget is not None:
                    try:widget.state(['disabled'])
                    except tk.TclError:pass
            return
        eligible=True;detail=''
        try:
            year=int(self.vs_vars['year'].get().strip())
            if not self._valid_vehicle_year(year):eligible=False
            if not self.vs_vars['model'].get().strip():eligible=False
            if not self.vs_vars['engine'].get().strip():eligible=False
            if self.vs_vars['transmission'].get() not in TRANSMISSION_OPTIONS:eligible=False
            if not self.vs_vars['log'].get().strip() or not self.vs_log_valid:eligible=False
            av0=self._active_version() if self.project else None
            if (not self.project and not self.vs_vars['htt'].get().strip()) or (self.project and av0 and not str(av0['baseline_htt_path'] or '').strip() and not self.vs_vars['htt'].get().strip()):eligible=False
        except Exception:eligible=False
        av=self._active_version() if self.project else None
        if self.user.role=='guest' or not self.license_status().get('active') or (av is not None and int(av['run_completed'])):eligible=False
        if self.project and av is not None:
            latest=self.db.latest_version(self.project.id)
            if not latest or int(av['version_no'])!=int(latest['version_no']):eligible=False
        if hasattr(self,'vs_required_labels'):
            sat={
                'project_name':bool(self.vs_vars['project_name'].get().strip()),
                'htt':bool(self.vs_vars['htt'].get().strip()) or bool(self.project and av and str(av['baseline_htt_path'] or '').strip()),
                'year':False,
                'model':bool(self.vs_vars['model'].get().strip()),
                'transmission':self.vs_vars['transmission'].get() in TRANSMISSION_OPTIONS,
                'log':bool(self.vs_vars['log'].get().strip()) and bool(self.vs_log_valid),
            }
            try: sat['year']=self._valid_vehicle_year(self.vs_vars['year'].get().strip())
            except Exception:sat['year']=False
            for key,star in self.vs_required_labels.items():
                try:
                    if sat.get(key,False):star.pack_forget()
                    elif not star.winfo_ismapped():star.pack(side='left')
                except Exception:pass
        if hasattr(self,'vs_log_submit_button'):
            if getattr(self,'vs_log_staged',False) and not (av and int(av['run_completed'])):
                self.vs_log_submit_button.state(['!disabled'])
            else:self.vs_log_submit_button.state(['disabled'])
        # All workflow states share one physical, fixed-size action button.
        self._update_setup_workflow_action()
        if detail:self.vs_status.set(detail)

        if detail:self.vs_status.set(detail)

    def _begin_setup_build(self,title,detail):
        """Lock one Setup Build request before queueing any long-running work."""
        if getattr(self,'_setup_build_in_progress',False):return False
        self._setup_build_in_progress=True
        self._setup_build_locked_widgets=[]
        for name in ('setup_workflow_button','vs_log_button','vs_htt_button'):
            widget=getattr(self,name,None)
            if widget is None:continue
            try:
                original_disabled=widget.instate(['disabled'])
                self._setup_build_locked_widgets.append((widget,original_disabled))
                widget.state(['disabled'])
            except tk.TclError:pass
        self._show_working_overlay(title,detail)
        return True

    def _end_setup_build(self):
        """Release the Build guard on either success or failure, on the Tk thread."""
        self._setup_build_in_progress=False
        self._hide_working_overlay()
        for widget,original_disabled in getattr(self,'_setup_build_locked_widgets',[]):
            try:
                if widget.winfo_exists():
                    widget.state(['disabled'] if original_disabled else ['!disabled'])
            except tk.TclError:pass
        self._setup_build_locked_widgets=[]
        if self.current_page=='setup':self._vehicle_form_update()

    def _save_vehicle_setup(self):
        # A rapid double-click or an already-queued event must never create two
        # initial projects or assign the same large Version 1 HPL twice.
        if getattr(self,'_setup_build_in_progress',False) or not self._operation_allowed():return
        if not self._setup_vehicle_is_verified():
            self._show_setup_vehicle_verification()
            self._vehicle_form_update()
            return
        try:
            year=int(self.vs_vars['year'].get());model=self.vs_vars['model'].get().strip()
            vin=self.vs_vars['vin'].get().strip();engine=self.vs_vars['engine'].get()
            transmission=self.vs_vars['transmission'].get()
            log_path=Path(self.vs_vars['log'].get())
            db_path=Path(self.db.path);uid=int(self.user.id)
            closed_loop_only=bool(self.vs_na_closed_loop_only)
            if not self.project:
                # The initial project was already using a worker. Preserve that
                # behavior while adding the same single-flight guard as V1+.
                htt_path=Path(self.vs_vars['htt'].get())
                args=dict(uid=uid,year=year,model=model,vin=vin,engine=engine,
                          transmission=transmission,htt=htt_path,log=log_path)
                if not self._begin_setup_build('Preparing project',
                       'Staging project data without creating a permanent name.'):return
                def task():
                    db=None
                    try:
                        db=ReviewDatabase(db_path)
                        pr=db.create_staged_initial_project(
                            args['uid'],args['year'],args['model'],args['vin'],
                            args['engine'],args['transmission'],args['htt'],args['log'],
                            na_closed_loop_only=closed_loop_only,
                            mod_cai=False,mod_headers=False,mod_throttle=False,
                            mod_intake=False,mod_camshaft=False,lsa=None,
                            cam_ack=False,throttle_ack=False,intake_ack=False)
                        try:db.record_version_performance(int(pr.id),0,uid)
                        except (OSError,ValueError,KeyError,AttributeError):pass
                        return ('ok',int(pr.id),'')
                    except Exception as exc:return ('err',None,str(exc))
                    finally:
                        if db:db.close()
                def done(result):
                    self._end_setup_build()
                    kind,pid,msg=result
                    if kind!='ok':
                        self._cancel_auto_submit()
                        self._set_setup_activity('Project preparation failed',msg,busy=False,error=True)
                        self._set_setup_panel_message('Project Setup Error',msg)
                        return
                    self.project=self.db.get_project(pid);self.active_version_no=0
                    self.metrics=dict(self.fixed_metrics);self.surface_cache={}
                    self.surface_display_cache=None;self.vs_log_replacement_pending=False
                    self.shell();self.goto('preflight')
                if self._auto_submit_active:
                    self.root.after_idle(self._auto_advance_preflight)
                self._run_background_task(task,done)
                return
            pid=int(self.project.id)
            av=self._active_version();latest=self.db.latest_version(pid)
            if not av or int(av['run_completed']):raise ValueError('Historical versions are locked/read-only.')
            if not latest or int(av['version_no'])!=int(latest['version_no']):
                raise ValueError('Only the current/latest version can accept a new Log File.')
            version_no=int(av['version_no'])
            attach_legacy=version_no==0 and not str(av['baseline_htt_path'] or '').strip()
            htt_path=Path(self.vs_vars['htt'].get()) if attach_legacy else None
            if attach_legacy and not str(self.vs_vars['htt'].get()).strip():
                raise ValueError('A Tune File (.htt) is required for this migrated project.')
            # assign_version_log re-analyzes the native .hpl, hashes it, and
            # copies it to protected storage. This is potentially expensive for
            # large logs and MUST NOT execute on the Tk message-pump thread.
            if not self._begin_setup_build('Preparing project version',
                   f'Validating and storing the V{version_no} Log File. Please wait.'):return
            def task():
                db=None
                try:
                    db=ReviewDatabase(db_path)
                    if attach_legacy:db.attach_initial_htt(pid,uid,htt_path)
                    current=db.get_version(pid,version_no)
                    if not current:raise ValueError('Project version not found.')
                    stored=str(current['log_source_path'] or '')
                    if not stored or os.path.abspath(stored)!=os.path.abspath(str(log_path)):
                        db.assign_version_log(pid,uid,log_path,version_no,
                                              na_closed_loop_only=closed_loop_only)
                    db.conn.execute('UPDATE projects SET model_year=?,model=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                                    (year,model,pid))
                    db.conn.commit()
                    try:db.record_version_performance(pid,version_no,uid)
                    except (OSError,ValueError,KeyError,AttributeError):pass
                    if version_no>0:
                        try:db.record_version_performance(pid,version_no-1,uid)
                        except (OSError,ValueError,KeyError,AttributeError):pass
                    return ('ok',pid,'')
                except Exception as exc:return ('err',None,str(exc))
                finally:
                    if db:db.close()
            def done(result):
                self._end_setup_build()
                kind,_pid,msg=result
                if kind!='ok':
                    self._cancel_auto_submit()
                    self._set_setup_activity('Project preparation failed',msg,busy=False,error=True)
                    self._set_setup_panel_message('Project Setup Error',msg)
                    return
                self.project=self.db.get_project(pid)
                self.metrics=dict(self.fixed_metrics);self.surface_cache={}
                self.surface_display_cache=None;self.vs_log_replacement_pending=False
                self.vs_status.set(f'V{version_no} Log File stored; preparing correction preflight.')
                self.shell();self.goto('preflight')
                if self._auto_submit_active:
                    self.root.after_idle(self._auto_advance_preflight)
            self._run_background_task(task,done)
        except Exception as exc:
            self._cancel_auto_submit()
            if getattr(self,'_setup_build_in_progress',False):self._end_setup_build()
            self._set_setup_panel_message('Project Setup Error',str(exc))

    def _setup_output(self):
        if self.choose_output():self.goto('setup')

    def page_settings(self):
        b=self._watermark_frame(self.content,28,24)
        self.header(b,'Settings','User mode, protected project storage, and Build It save location.')
        mode_o,mode_i=self.card(b,22,18);mode_o.pack(fill='x',pady=(0,12))
        tk.Label(mode_i,text='USER MODE',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w')
        multi_user=tk.BooleanVar(value=self.db.multi_user_enabled())
        mode_check=ttk.Checkbutton(mode_i,text='Enable Multi User mode (requires sign-in at startup)',variable=multi_user)
        mode_check.pack(anchor='w',pady=(7,4))
        tk.Label(mode_i,text='Single User mode is the default. Multi User mode keeps the existing account, role, login, and User Management features and takes effect the next time VE Optimizer starts.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=850,justify='left').pack(anchor='w')
        def save_user_mode(*_):
            self.db.set_multi_user_enabled(bool(multi_user.get()))
        multi_user.trace_add('write',save_user_mode)
        if self.user.role!='admin':mode_check.state(['disabled'])
        o,i=self.card(b,22,18);o.pack(fill='x')
        tk.Label(i,text='PROTECTED PROJECT STORAGE',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w')
        project_root=tk.StringVar(value=str(self.db.get_project_base()))
        row=tk.Frame(i,bg='white');row.pack(fill='x',pady=(7,5))
        tk.Entry(row,textvariable=project_root,state='readonly',font=('Microsoft Sans Serif',10),relief='solid',bd=1).pack(side='left',fill='x',expand=True,ipady=6)
        def open_root():
            try:open_path(Path(self.db.get_project_base()))
            except Exception as e:messagebox.showerror('Settings',str(e))
        ttk.Button(row,text='Open Folder',style='Secondary.TButton',command=open_root).pack(side='left',padx=(7,0))
        tk.Label(i,text='Active VE Optimizer project/version files are stored here automatically and are not user-selectable.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=850,justify='left').pack(anchor='w',pady=(4,16))
        tk.Label(i,text='BUILD IT DEFAULT SAVE LOCATION',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).pack(anchor='w')
        build_root=tk.StringVar(value=str(default_build_output_dir()))
        row2=tk.Frame(i,bg='white');row2.pack(fill='x',pady=(7,5))
        tk.Entry(row2,textvariable=build_root,state='readonly',font=('Microsoft Sans Serif',10),relief='solid',bd=1).pack(side='left',fill='x',expand=True,ipady=6)
        def open_build_root():
            try:open_path(default_build_output_dir())
            except Exception as e:messagebox.showerror('Settings',str(e))
        ttk.Button(row2,text='Open Folder',style='Secondary.TButton',command=open_build_root).pack(side='left',padx=(7,0))
        tk.Label(i,text='Build It opens this HP Tuners folder by default. Files exported there are user-owned and are never deleted by VE Optimizer project deletion.',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9),wraplength=850,justify='left').pack(anchor='w',pady=(4,0))
    def page_diagnostics(self):
        b=self._watermark_frame(self.content,28,24);self.header(b,'Diagnostics','Optional audit information. Nothing on this page is required for normal review.')
        if not self.project:
            o,i=self.card(b);o.pack(fill='x');tk.Label(i,text='Set up the review project first.',bg='white',fg=C['text'],font=('Microsoft Sans Serif',12,'bold')).pack(anchor='w');return
        acts=tk.Frame(b,bg=C['bg']);acts.pack(fill='x',pady=(0,12));ttk.Button(acts,text='Open Diagnostics Folder',style='Secondary.TButton',command=self.open_diag).pack(side='left');
        if self.user.role!='guest':ttk.Button(acts,text='Export Technical Project ZIP',style='Secondary.TButton',command=self.export_zip).pack(side='left',padx=8)
        nb=ttk.Notebook(b);nb.pack(fill='both',expand=True)
        for title,cols,rows in [('Runs',[('type','Run',150),('accepted','Accepted',100),('mae','Trim MAE',120),('time','Created',190)],self.db.list_runs(self.project.id)),('Artifacts',[('type','Type',160),('file','File',500),('hash','SHA-256',300)],self.db.list_artifacts(self.project.id)),('Audit Events',[('event','Event',210),('detail','Detail',560),('time','Created',180)],self.db.list_events(self.project.id))]:
            tab=tk.Frame(nb,bg='white');nb.add(tab,text=title);tree=ttk.Treeview(tab,columns=[c[0] for c in cols],show='headings')
            for k,t,w in cols:tree.heading(k,text=t);tree.column(k,width=w,anchor='w')
            for r in rows:
                if title=='Runs':vals=(r['run_type'],r['accepted_count'] or '',f"{r['trim_mae']:.4f}%" if r['trim_mae'] is not None else '',r['created_at'])
                elif title=='Artifacts':vals=(r['artifact_type'],Path(r['path']).name,r['sha256'])
                else:vals=(r['event_type'],r['detail'],r['created_at'])
                tree.insert('', 'end', values=vals)
            tree.pack(fill='both',expand=True,padx=12,pady=12)

    def _save_eula_pdf(self):
        target=filedialog.asksaveasfilename(title='Save VE Optimizer License PDF',defaultextension='.pdf',filetypes=[('PDF document','*.pdf')],initialfile='VE_Optimizer_EULA_1.4.pdf')
        if not target:return
        try:
            shutil.copy2(self.eula_pdf_path,Path(target));messagebox.showinfo('License PDF',f'License PDF saved to:\n{target}')
        except Exception as e:messagebox.showerror('License PDF',str(e))

    def page_legal(self):
        b=self._watermark_frame(self.content,28,24);self.header(b,'About','Copyright, current software license, and your recorded acceptance.')
        meta,i=self.card(b,18,14);meta.pack(fill='x',pady=(0,12))
        top=tk.Frame(i,bg='white');top.pack(fill='x')
        left=tk.Frame(top,bg='white');left.pack(side='left',fill='x',expand=True)
        tk.Label(left,text=COPYRIGHT_NOTICE,bg='white',fg=C['text'],font=('Microsoft Sans Serif',11,'bold')).pack(anchor='w')
        tk.Label(left,text=f'Application: {self.license_status()["label"]}   •   License Terms: {EULA_VERSION}   •   Legal contact: {LEGAL_CONTACT}',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',9)).pack(anchor='w',pady=(4,0));tk.Label(left,text=self.license.mode_summary(),bg='white',fg=C['success'] if self.license_status()['mode']=='licensed' else C['warning'],font=('Microsoft Sans Serif',9,'bold')).pack(anchor='w',pady=(4,0))
        a=self.db.get_eula_acceptance(self.user.id,EULA_VERSION,self.eula_sha) if self.user else None
        status=(f"Accepted {a['accepted_at']}  •  User ID {a['user_id']} ({a['username_snapshot'] or self.user.username})  •  App {a['app_version']}" if a else 'Current license has not been accepted by this User ID.')
        tk.Label(left,text=status,bg='white',fg=C['success'] if a else C['danger'],font=('Microsoft Sans Serif',9,'bold')).pack(anchor='w',pady=(7,0))
        tk.Label(left,text=f'Terms SHA-256: {self.eula_sha}',bg='white',fg=C['muted'],font=('Consolas',8)).pack(anchor='w',pady=(4,0))
        acts=tk.Frame(top,bg='white');acts.pack(side='right')
        ttk.Button(acts,text=('License Details' if self.license_status()['mode']=='licensed' else 'Purchase / License'),style='Secondary.TButton',command=self.show_purchase).pack(side='left',padx=(0,8));ttk.Button(acts,text='Open License PDF',style='Secondary.TButton',command=lambda:open_path(self.eula_pdf_path)).pack(side='left',padx=(0,8))
        ttk.Button(acts,text='Save License PDF...',style='Primary.TButton',command=self._save_eula_pdf).pack(side='left')
        full,fi=self.card(b,0,0);full.pack(fill='both',expand=True)
        sy=tk.Scrollbar(fi,orient='vertical');sy.pack(side='right',fill='y')
        text=tk.Text(fi,wrap='word',yscrollcommand=sy.set,bg='white',fg=C['text'],relief='flat',bd=0,font=('Microsoft Sans Serif',10),padx=20,pady=18,spacing1=1,spacing3=5);text.pack(side='left',fill='both',expand=True);sy.config(command=text.yview)
        text.insert('1.0',self.eula_text_path.read_text(encoding='utf-8'));text.config(state='disabled')

    def page_users(self):
        if self.user.role!='admin':self.goto('setup');return
        b=self._watermark_frame(self.content,28,24);self.header(b,'User management','Admin-only account management. Guest accounts remain view-only.');o,i=self.card(b,18,16);o.pack(fill='both',expand=True);tree=ttk.Treeview(i,columns=('user','role','name','active'),show='headings')
        for k,t,w in [('user','User Name',180),('role','Role',100),('name','Name',260),('active','Active',90)]:tree.heading(k,text=t);tree.column(k,width=w,anchor='w')
        def refresh():
            for q in tree.get_children():tree.delete(q)
            for r in self.db.list_users():tree.insert('', 'end', iid=str(r['id']), values=(r['username_display'],r['role'].title(),f"{r['first_name']} {r['last_name']}",'Yes' if r['active'] else 'No'))
        refresh();tree.pack(fill='both',expand=True);a=tk.Frame(i,bg='white');a.pack(fill='x',pady=(12,0));ttk.Button(a,text='Add User',style='Primary.TButton',command=lambda:self.user_dialog(None,refresh)).pack(side='left')
        def edit():
            s=tree.selection();
            if s:self.user_dialog(int(s[0]),refresh)
        def delete():
            s=tree.selection();
            if not s:return
            try:self.db.delete_user(int(s[0]));refresh()
            except Exception as e:messagebox.showerror('Delete User',str(e))
        ttk.Button(a,text='Edit',style='Secondary.TButton',command=edit).pack(side='left',padx=8);ttk.Button(a,text='Delete',style='Secondary.TButton',command=delete).pack(side='left')
    def user_dialog(self,uid,refresh):
        row=self.db.get_user(uid) if uid else None;w=tk.Toplevel(self.root);w.title('Edit User' if row else 'Add User');w.configure(bg=C['bg']);w.transient(self.root);w.grab_set();card=tk.Frame(w,bg='white',highlightbackground=C['border'],highlightthickness=1);card.pack(padx=18,pady=18)
        tk.Label(card,text='Edit user' if row else 'Add user',bg='white',fg=C['text'],font=('Microsoft Sans Serif',16,'bold')).grid(row=0,column=0,columnspan=2,sticky='w',padx=22,pady=(20,16));defs=[('first_name','First Name'),('last_name','Last Name'),('username_display','User Name'),('password','Password'),('confirm','Confirm Password')];v={}
        for z,(k,label) in enumerate(defs,1):
            v[k]=tk.StringVar(value=(row[k] if row and k in row.keys() and row[k] and k not in ('password','confirm') else ''));tk.Label(card,text=label,bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).grid(row=z,column=0,sticky='w',padx=22,pady=7);tk.Entry(card,textvariable=v[k],show='•' if k in ('password','confirm') else '',width=34,font=('Microsoft Sans Serif',10),relief='solid',bd=1).grid(row=z,column=1,padx=(4,22),pady=7,ipady=5)
        role=tk.StringVar(value=row['role'] if row else 'user');tk.Label(card,text='Role',bg='white',fg=C['muted'],font=('Microsoft Sans Serif',8,'bold')).grid(row=6,column=0,sticky='w',padx=22,pady=7);ttk.Combobox(card,textvariable=role,values=s4.ROLES,state='readonly',width=31).grid(row=6,column=1,padx=(4,22),pady=7);active=tk.BooleanVar(value=bool(row['active']) if row else True);ttk.Checkbutton(card,text='Active',variable=active).grid(row=7,column=1,sticky='w',padx=(4,22),pady=7)
        def save():
            if v['password'].get()!=v['confirm'].get():messagebox.showerror('User','Passwords do not match.',parent=w);return
            try:self.db.save_user(user_id=uid,username=v['username_display'].get(),password=v['password'].get() or None,role=role.get(),first_name=v['first_name'].get(),last_name=v['last_name'].get(),active=active.get());w.destroy();refresh()
            except Exception as e:messagebox.showerror('User',str(e),parent=w)
        f=tk.Frame(card,bg='white');f.grid(row=8,column=0,columnspan=2,sticky='e',padx=22,pady=(14,20));ttk.Button(f,text='Help',style='Secondary.TButton',command=lambda:self.show_help('users',w)).pack(side='left',padx=6);ttk.Button(f,text='Cancel',style='Secondary.TButton',command=w.destroy).pack(side='left',padx=6);ttk.Button(f,text='Save',style='Primary.TButton',command=save).pack(side='left')

    def open_output(self):
        if self.project:
            try:
                v=self._active_version()
                if self.license_status().get('mode')!='licensed':
                    target=default_build_output_dir()
                elif v and int(v['run_completed']):
                    target=Path(v['result_htt_path']).parent
                else:
                    target=Path(self.project.output_dir)
                open_path(target)
            except Exception as e:messagebox.showerror('Open Output Folder',str(e))
    def open_diag(self):
        if self.project:
            p=Path(self.project.output_dir)/DIAG_DIR;p.mkdir(parents=True,exist_ok=True)
            try:open_path(p)
            except Exception as e:messagebox.showerror('Open Diagnostics Folder',str(e))
    def export_zip(self):
        try:
            p=Path(self.project.output_dir)/f'VE_Optimizer_{APP_VERSION}_Technical_Project.zip';s5.export_project_package(self.db,self.project,p);self.db.record_event(self.project.id,'PROJECT_EXPORTED',f'Technical project package: {p}',self.user.id);messagebox.showinfo('Technical Export',f'Technical project package written to:\n{p}')
        except Exception as e:messagebox.showerror('Technical Export',str(e))

# Project Creation Version 4 persistence/lifecycle extension.
import ve_optimizer_version4 as _version4
_version4.install(globals())


def smoke_test(root:Path,assets:Path):
    verify_assets(assets);verify_legal(Path(assets).parent);verify_help(Path(assets).parent);channel_list.bundled_channel_list(Path(assets).parent)
    print('Runtime assets, legal text and help verified. Run tests/test_accepted_method.py for processing verification.')
    return 0

def main():
    here=Path(__file__).resolve().parent;ap=argparse.ArgumentParser();ap.add_argument('--data-dir',type=Path,default=here/'data');ap.add_argument('--asset-dir',type=Path,default=here/'a');ap.add_argument('--smoke-test',action='store_true');ap.add_argument('--smoke-dir',type=Path,default=here/'_review_smoke');a=ap.parse_args()
    if a.smoke_test:return smoke_test(a.smoke_dir,a.asset_dir)
    verify_assets(a.asset_dir);verify_legal(here);verify_help(here);verify_purchase_assets(here);channel_list.bundled_channel_list(here)
    if tk is None:raise RuntimeError('Tkinter is unavailable. Python must include Tcl/Tk support.')
    root=tk.Tk();ReviewApp(root,a.data_dir/DB_NAME,a.asset_dir);root.mainloop();return 0

if __name__=='__main__':raise SystemExit(main())
