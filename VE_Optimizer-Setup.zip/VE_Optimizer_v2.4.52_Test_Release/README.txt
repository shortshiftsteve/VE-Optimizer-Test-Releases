VE OPTIMIZER v2.4.52 — PRIVATE TEST RELEASE SOURCE / WINDOWS BUILD KIT
=====================================================================
Date: 2026-10-15
APP_VERSION: 2.4.52 | BUILD_ID: 2.4.52-Release | Windows EXE: 2.4.52.0

TEST ENVIRONMENT ONLY. NOT AN APPROVED CUSTOMER PRODUCTION RELEASE.
This is SOURCE/BUILD tooling, NOT a signed Windows Setup installer.
The owner controls all uploads/publication. No files were uploaded anywhere.

PURPOSE
Provide a real 2.4.52-Release Windows Setup package for a controlled GitHub
TEST environment. From installed 2.4.51 Review, it should appear as a newer
published Release, allowing Windows update, uninstall, reinstall, relaunch and
preservation of project/license data to be tested. No functional tuning changes.

SOURCE IDENTITY
  Parent: VE_Optimizer_v2.4.51_Review_Source.zip
  SHA-256: eb2163885c168f222924850aba805364397d8c63daa14aa23143a9fab84394ca
  The stable v2.4.5 production source remains untouched.
  Historical v2.4.51 Review source documents are copied unchanged to
    development_history/v2.4.51_review_parent/

VERSION-ONLY PROMOTION
  Application APP_VERSION: 2.4.52
  Application BUILD_ID: 2.4.52-Release
  RELEASE_STAGE: Release (required for signed installer/upgrade validation)
  Numeric and string Windows EXE version: 2.4.52.0
  Installer AppId, install directory, licensing, project storage, update flow,
  data-retaining silent uninstall, purchase validation, EULA content and
  Windows signing/timestamp safeguards are unchanged.
  No Neural Network, Speed Density, Wideband, HPL/HTT, VIN, MAP/knock,
  Dyno, selective export, project schema or fuel-trim calculation was modified.

BUILD ON THE CONFIGURED WINDOWS SIGNING COMPUTER
  1. Extract THIS source ZIP to a fresh directory.
  2. Run from that source root:
       py -3 installer\verify_release_versions.py
       py -3 ve_optimizer_revision9_review.py --smoke-test
       installer\Build_VE_Optimizer_v2.4.52_Installer.bat
  3. Confirm successful Azure Artifact Signing, timestamping, EXE signature,
     signed uninstaller, installer signature and the generated signing record.

Only after successful native Windows build/signing, the expected installer is:
  installer\Output\VE Optimizer v2.4.52 Release Setup.exe

TEST GITHUB RELEASE ASSET — PREPARE ON WINDOWS, DO NOT USE THIS SOURCE ZIP
  Release tag: 2.4.52 (optional leading v is supported)
  Asset filename: VE-Optimizer-Setup.zip
  Asset must contain exactly one signed installer with the exact filename:
    VE Optimizer v2.4.52 Release Setup.exe
  A README may also be included. The ZIP is not the installer; this source
  package is not the GitHub asset to distribute.
  Example (PowerShell, run after verifying signature):
    Compress-Archive -Path 'installer\Output\VE Optimizer v2.4.52 Release Setup.exe' -DestinationPath 'VE-Optimizer-Setup.zip' -Force
  Publish to your separate TEST repository only after the installer is built.
  Do not upload this test Release to the live customer distribution repository.

CRITICAL TEST ENDPOINT BOUNDARY
  The built-in updater currently checks the production repository:
    https://github.com/shortshiftsteve/Software-Distribution
  No test repository URLs have been supplied, so this source does NOT silently
  repoint the updater or change its trust/publisher verification. To test a
  live 2.4.51 -> 2.4.52 update in your separate test repository, we must
  agree on a safe, controlled test-endpoint procedure AFTER you supply URLs.
  No review/test installer should be posted to the production GitHub Releases.

ACCEPTANCE NOT YET PROVEN
  Linux source tests/ZIP verification do not run Windows Setup, sign executables,
  exercise live GitHub test URLs, prove Windows certificate trust/UAC, or prove
  the data-retaining uninstall/reinstall/relaunch sequence. Those are customer-
  controlled Windows acceptance steps before any real production promotion.
  See BUILD_AND_RELEASE_CHECKLIST.txt and TEST_RELEASE_SOURCE_VERIFICATION_2.4.52.txt.
