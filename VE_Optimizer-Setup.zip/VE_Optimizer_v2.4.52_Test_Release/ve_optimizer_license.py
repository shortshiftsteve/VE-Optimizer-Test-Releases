#!/usr/bin/env python3
from __future__ import annotations

import base64, hashlib, json, os, platform, socket
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

PRODUCT = 'VE Optimizer'
RELEASE_VERSION = '2.4.52'
RELEASE_STAGE = 'Release'
PURCHASE_PRICE_USD = '49.99'
PURCHASE_EMAIL = 'shortshiftsteve@gmail.com'
LICENSE_FILE_NAME = 'VEOptimizer.license'
REG_PATH = r'Software\VEOptimizer'
REG_LICENSE_VALUE = 'PurchasedLicense'
REG_TRIAL_VALUE = 'TrialInstalledUtc'  # legacy pre-versioned trial
REG_TRIAL_RELEASES_VALUE = 'TrialStartedUtcByRelease'
LEGACY_TRIAL_RELEASE_VERSION = '2.4.3'
TRIAL_FILE = 'trial_state.json'
TRIAL_HOURS = 72
LICENSE_FILE = 'purchased_license.json'

# Public verification key. The private signing key is never distributed with
# the customer application; it exists only in the owner License Issuer package.
PUBLIC_N = 19781076030863745906075813786002196177939719810584129622407681771309284086643224715088149090800499463388781954855030745444274372627878445607475258382257596265518243139083726542326276616000341970766238170017531574433135385935037267986600080269448074766716054285310898772833601196651009173870455935811212774759011789757163790685047292769880322228886600283473734314044926760507682966130880978395750666696309240518628655752625380857807839702378414312698978412747666416481717740919209592388992018406402967387319080969970113900958398436502619472119603443744383225550105911060972751067407445897484885294199115321978671022337
PUBLIC_E = 65537
_SHA256_DER_PREFIX = bytes.fromhex('3031300d060960864801650304020105000420')


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')


def parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(str(value).replace('Z','+00:00')).astimezone(timezone.utc)


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('utf-8')


def _emsa_pkcs1_v15_sha256(data: bytes, size: int) -> bytes:
    digest = hashlib.sha256(data).digest()
    t = _SHA256_DER_PREFIX + digest
    if size < len(t) + 11:
        raise ValueError('RSA key is too small for SHA-256 signature encoding.')
    return b'\x00\x01' + b'\xff' * (size - len(t) - 3) + b'\x00' + t


def verify_signed_license(doc: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(doc, dict) or not isinstance(doc.get('payload'), dict) or not isinstance(doc.get('signature'), str):
        raise ValueError('License file format is invalid.')
    payload = doc['payload']
    if payload.get('product') != PRODUCT:
        raise ValueError('License is not for VE Optimizer.')
    if payload.get('license_type') != 'purchased':
        raise ValueError('License type is not recognized.')
    sig = base64.b64decode(doc['signature'], validate=True)
    size = (PUBLIC_N.bit_length() + 7) // 8
    if len(sig) != size:
        raise ValueError('License signature length is invalid.')
    recovered = pow(int.from_bytes(sig, 'big'), PUBLIC_E, PUBLIC_N).to_bytes(size, 'big')
    expected = _emsa_pkcs1_v15_sha256(canonical(payload), size)
    if recovered != expected:
        raise ValueError('License signature verification failed.')
    if payload.get('revoked') is True:
        raise ValueError('License is marked revoked.')
    return payload


def _storage_dir() -> Path:
    override = os.environ.get('VE_OPTIMIZER_LICENSE_STATE_DIR')
    if override:
        return Path(override)
    if os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or str(Path.home()/'AppData'/'Local')
        return Path(base)/'VEOptimizer'
    return Path.home()/'.ve_optimizer'


def _read_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return None


def _atomic_write_json(path: Path, obj: Dict[str, Any]):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding='utf-8')
    os.replace(tmp, path)


def _reg_read(name: str) -> Optional[Dict[str, Any]]:
    if os.name != 'nt':
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH) as key:
            value, _ = winreg.QueryValueEx(key, name)
        return json.loads(value)
    except Exception:
        return None


def _reg_write(name: str, obj: Dict[str, Any]):
    if os.name != 'nt':
        return
    try:
        import winreg
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH)
        try:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, json.dumps(obj, sort_keys=True))
        finally:
            winreg.CloseKey(key)
    except Exception:
        pass


def _reg_read_string(name: str) -> Optional[str]:
    if os.name != 'nt':
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH) as key:
            value, _ = winreg.QueryValueEx(key, name)
        return str(value).strip() or None
    except Exception:
        return None

def _reg_write_string(name: str, value: str):
    if os.name != 'nt':
        return
    try:
        import winreg
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, REG_PATH)
        try: winreg.SetValueEx(key, name, 0, winreg.REG_SZ, str(value))
        finally: winreg.CloseKey(key)
    except Exception:
        pass


class LicenseManager:
    """Purchased-license manager with a 72-hour processed-output Trial.

    A valid purchased license removes all restrictions. Without a purchased
    license, the first 72 hours are Trial mode with processed Build It output.
    After 72 hours the application remains usable in DEMO mode, where Build It
    exports an unchanged copy of the input .htt.
    """
    def __init__(self, now: Optional[datetime] = None):
        self.dir = _storage_dir()
        self.license_path = self.dir/LICENSE_FILE
        self.trial_path = self.dir/TRIAL_FILE
        self._now_override = now
        self.dir.mkdir(parents=True, exist_ok=True)
        self._license_doc, self._license_payload = self._load_license()
        self._trial_installed_utc = self._load_or_create_trial_start()

    def _now(self) -> datetime:
        return self._now_override or utcnow()

    def _load_license(self):
        candidates=[]
        f=_read_json(self.license_path)
        r=_reg_read(REG_LICENSE_VALUE)
        if f is not None:candidates.append(f)
        if r is not None:candidates.append(r)
        for doc in candidates:
            try:
                payload=verify_signed_license(doc)
                # Restore both redundant locations from any one valid copy.
                _atomic_write_json(self.license_path, doc); _reg_write(REG_LICENSE_VALUE, doc)
                return doc,payload
            except Exception:
                continue
        return None,None

    def _load_or_create_trial_start(self) -> datetime:
        """Start each release's 72-hour trial once, preserving prior releases.

        Keep a shared, version-keyed history in both local user storage and the
        existing per-user registry branch.  Never reuse an older release's start
        date, and never restart the same release on reinstall.  Purchased
        licenses are managed separately and remain valid across upgrades.
        """
        file_doc = _read_json(self.trial_path) or {}
        reg_doc = _reg_read(REG_TRIAL_RELEASES_VALUE) or {}
        if not isinstance(file_doc, dict):
            file_doc = {}
        if not isinstance(reg_doc, dict):
            reg_doc = {}
        starts = {}
        for source in (file_doc.get('release_starts'), reg_doc.get('release_starts')):
            if not isinstance(source, dict):
                continue
            for version, stored in source.items():
                try:
                    when = parse_iso(stored)
                except (TypeError, ValueError):
                    continue
                version = str(version)
                if version not in starts or when < starts[version]:
                    starts[version] = when

        # v2.4.3 and earlier used one global TrialInstalledUtc.  Associate that
        # value ONLY with v2.4.3, never with a new release.  This preserves the
        # current release's trial even if a development build is reinstalled.
        if LEGACY_TRIAL_RELEASE_VERSION not in starts:
            legacy = []
            for stored in (file_doc.get('installed_utc'), _reg_read_string(REG_TRIAL_VALUE)):
                if stored:
                    try:
                        legacy.append(parse_iso(stored))
                    except (TypeError, ValueError):
                        pass
            if legacy:
                starts[LEGACY_TRIAL_RELEASE_VERSION] = min(legacy)

        # A Review must not start the future Release's 72-hour trial early.
        # Normal Release storage keys remain the unchanged numeric version.
        trial_key = (RELEASE_VERSION if RELEASE_STAGE == 'Release'
                     else f'{RELEASE_VERSION}-{RELEASE_STAGE}')
        start = starts.get(trial_key, self._now())
        starts[trial_key] = start
        serialized = {version: iso(when) for version, when in sorted(starts.items())}
        # Preserve the legacy field, so an older installed release can continue
        # reading its original state if the customer rolls back.
        new_doc = dict(file_doc)
        new_doc['release_starts'] = serialized
        _atomic_write_json(self.trial_path, new_doc)
        _reg_write(REG_TRIAL_RELEASES_VALUE, {'release_starts': serialized})
        return start

    @property
    def trial_expires_at(self) -> datetime:
        from datetime import timedelta
        return self._trial_installed_utc + timedelta(hours=TRIAL_HOURS)

    @property
    def licensed(self) -> bool:
        return self._license_payload is not None

    @property
    def license_payload(self) -> Optional[Dict[str, Any]]:
        return dict(self._license_payload) if self._license_payload else None

    def status(self) -> Dict[str, Any]:
        if self.licensed:
            p=self._license_payload or {}
            return {
                'mode':'licensed','active':True,'expired':False,'hours_remaining':None,'days_remaining':None,
                'label':f'Version {RELEASE_VERSION} {RELEASE_STAGE}','license_id':p.get('license_id',''),
                'licensed_to':p.get('licensed_to',''),'email':p.get('email',''),
                'processed_output':True,
            }
        now=self._now()
        remaining=(self.trial_expires_at-now).total_seconds()/3600.0
        if remaining>0:
            return {
                'mode':'trial','active':True,'expired':False,'hours_remaining':remaining,'days_remaining':remaining/24.0,
                'label':f'TRIAL Version {RELEASE_VERSION} {RELEASE_STAGE}','reason':'72_hour_trial',
                'trial_started_at':iso(self._trial_installed_utc),'trial_expires_at':iso(self.trial_expires_at),
                'processed_output':True,
            }
        return {
            'mode':'demo','active':True,'expired':True,'hours_remaining':0.0,'days_remaining':0.0,
            'label':f'DEMO Version {RELEASE_VERSION} {RELEASE_STAGE}','reason':'trial_expired',
            'trial_started_at':iso(self._trial_installed_utc),'trial_expires_at':iso(self.trial_expires_at),
            'processed_output':False,
        }

    def activate_file(self, source: Path) -> Dict[str, Any]:
        source=Path(source)
        try:
            doc=json.loads(source.read_text(encoding='utf-8'))
        except Exception as e:
            raise ValueError(f'Unable to read license file: {e}') from e
        payload=verify_signed_license(doc)
        _atomic_write_json(self.license_path, doc)
        _reg_write(REG_LICENSE_VALUE, doc)
        self._license_doc=doc; self._license_payload=payload
        return dict(payload)

    def activate_document(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        payload=verify_signed_license(doc)
        _atomic_write_json(self.license_path, doc); _reg_write(REG_LICENSE_VALUE, doc)
        self._license_doc=doc; self._license_payload=payload
        return dict(payload)

    def display_version(self) -> str:
        st=self.status()
        return f'VE Optimizer - {st["label"]}'

    def trial_expiration_label(self) -> str:
        """Return the Trial expiration in the customer's local Windows time.

        The underlying expiration remains the persistent first-install timestamp
        plus 72 hours; this method changes presentation only.
        """
        local_expiry=self.trial_expires_at.astimezone()
        clock=local_expiry.strftime('%I:%M %p').lstrip('0')
        return f'Expires: {local_expiry.month}/{local_expiry.day}/{local_expiry.year} {clock}'

    def mode_summary(self) -> str:
        st=self.status()
        if st['mode']=='licensed':
            who=st.get('licensed_to') or st.get('email') or 'Licensed User'
            return f'Licensed - {who}'
        if st['mode']=='trial':
            hours=max(0.0,float(st.get('hours_remaining') or 0.0))
            return f'3-Day Trial - processed Build It enabled ({hours:.1f} hours remaining)'
        return 'DEMO - Trial expired; Build It exports the input .htt unchanged until licensed'

def main(argv=None):
    import argparse
    ap=argparse.ArgumentParser(description='VE Optimizer local Trial/DEMO/license state utility.')
    ap.add_argument('--status',action='store_true',help='Print current local license status as JSON.')
    a=ap.parse_args(argv)
    m=LicenseManager()
    if a.status:
        print(json.dumps(m.status(),indent=2,sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
