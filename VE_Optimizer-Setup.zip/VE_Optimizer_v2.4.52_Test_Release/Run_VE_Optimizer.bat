@echo off
cd /d "%~dp0"
py -3.12 ve_optimizer_revision9_review.py
