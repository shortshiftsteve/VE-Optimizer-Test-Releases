"""Accepted v0.1.5 processing. This is the sole fuel-trim correction path.

Native bank events -> bank arithmetic means -> >=5 pooled per-bank RPM/PR hits ->
MAX qualifying totals -> one 50% VE target -> frozen quantized NN fit.
"""
from __future__ import annotations
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import bisect, csv, json, math, time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
import ve_optimizer_logcheck as logcheck
import ve_optimizer_stage3 as htt

METHOD_ID='accepted-half-step-0.1.6-dynamic-domain1'
SOLVER_REVISION='all-layer-scaled-slsqp-2'
MIN_HITS=5
FRACTION=.5
QUANTUM=.09765625
ASSETS=Path(__file__).resolve().parent/'a'
if not ASSETS.is_dir():
    import sys
    ASSETS=Path(getattr(sys,'_MEIPASS',Path(sys.executable).parent))/'a'
AXES=json.loads((ASSETS/'reference_axes.json').read_text())
# Legacy aliases are retained only for historical stored projects and regression
# fixtures. New processing derives its entire modeling domain from the input .htt.
RPM=AXES['rpms']
PR=AXES['pratios']
PR_BINS=[round(v,2) for v in PR]
CAM_PAIRS=[tuple(p) for p in AXES['cam_pairs']]

def model_domain(net):
    """Derive the 20x20 axes and five cam-reference samples from this .htt.

    The NN training scalars are calibration data, not vehicle labels.  Five
    equally spaced reference points are sampled across the complete training
    cam domain.  Intake traverses max->min while exhaust traverses min->max,
    reproducing the original 5.7L references exactly and allowing a different
    linked-cam center/LSA to follow the uploaded calibration automatically.
    """
    cfg=config(net);lo=cfg['input_min'];hi=cfg['input_max']
    rpm_lo,rpm_hi=float(lo[2]),float(hi[2])
    pr_lo,pr_hi=float(lo[3]),float(hi[3])
    if rpm_lo>=rpm_hi or pr_lo>=pr_hi:raise ValueError('Invalid RPM/PRatio NN training range')
    rpms=[float(round(rpm_lo+i*(rpm_hi-rpm_lo)/19.0)) for i in range(20)]
    # Preserve exact endpoints even when a calibration has non-integer RPM limits.
    rpms[0]=rpm_lo;rpms[-1]=rpm_hi
    pratios=[pr_lo+i*(pr_hi-pr_lo)/19.0 for i in range(20)]
    intake_min,intake_max=float(lo[0]),float(hi[0])
    exhaust_min,exhaust_max=float(lo[1]),float(hi[1])
    cam_pairs=[]
    for i in range(5):
        f=i/4.0
        cam_pairs.append((intake_max-f*(intake_max-intake_min),
                          exhaust_min+f*(exhaust_max-exhaust_min)))
    lsa_a=(intake_max+exhaust_min)/2.0
    lsa_b=(intake_min+exhaust_max)/2.0
    return {'rpms':rpms,'pratios':pratios,'pr_bins':[round(v,2) for v in pratios],
            'cam_pairs':cam_pairs,'derived_lsa':(lsa_a+lsa_b)/2.0,
            'linked_span_match':abs((intake_max-intake_min)-(exhaust_max-exhaust_min))<=1e-9,
            'input_min':list(map(float,lo)),'input_max':list(map(float,hi)),
            'source':'input_htt_training_ranges'}

def domain_from_htt(path):return model_domain(htt.load_network(path))
SAMPLE_FIELDS=['Bank','Time_s','RPM','MAP_kPa','Baro_kPa','PRatio','Torque_lbft','Coolant_F','FuelFlow_lbh','FA_Enrichment','FA_PowerEnrichment','LTFT_pct','STFT_pct','CellIndex','IntakeCam_deg','ExhaustCam_deg']
PIDS={'rpm':2135,'actual_torque':2706,'ect':2124,'map':2335,'baro':2410,'fa_enrichment':6056,'fa_power_enrichment':6080,'fuel_flow':6509,'ltft_b1':7,'stft_b1':6,'ltft_b2':9,'stft_b2':8,'intake_cam':2196,'exhaust_cam':2195}

class NoQualifyingCells(ValueError):
    pass

class FitConvergenceError(ValueError):
    """A numerical solve failed; no candidate may be committed or exported."""
    def __init__(self, stage, details):
        self.stage = stage
        self.details = dict(details)
        super().__init__(f"{stage} did not converge: {details.get('message', 'unknown reason')}. "
                         "No new candidate was approved. The input calibration is unchanged.")


def _optimizer_record(solve):
    return {'success': bool(solve.success), 'status': int(solve.status),
            'message': str(solve.message), 'iterations': int(solve.nit),
            'evaluations': int(solve.nfev)}


def _require_solve(solve, stage):
    info = _optimizer_record(solve)
    if not (info['success'] and info['status'] == 0 and
            np.all(np.isfinite(solve.x)) and np.isfinite(solve.fun)):
        raise FitConvergenceError(stage, info)
    return info


def _constrained_solve(fun, start, constraint, constraint_jac, scale,
                       maxiter, raw_ftol, progress=None):
    """Condition the SAME all-layer problem; do not alter its feasible set.

    Both objective (including regularization) and inequalities are divided by
    one positive constant, the model's output-neuron-to-VE scale. Their analytic
    derivatives and the absolute stopping tolerance receive the SAME divisor.
    Coefficients, targets, 16:1 weighting and the one-quantum reserve are not
    rescaled. No clock, coefficient locks, arbitrary bounds or backup fit.
    """
    scale = float(scale)
    if not np.isfinite(scale) or scale <= 0:
        raise ValueError('Invalid VE scale for constrained fitting')
    def scaled_fun(q):
        value, gradient = fun(q)
        return value / scale, gradient / scale
    cons = {'type': 'ineq', 'fun': lambda q: constraint(q) / scale,
            'jac': lambda q: constraint_jac(q) / scale}
    iterations = 0
    def callback(q):
        nonlocal iterations
        iterations += 1
        if progress is not None and iterations % 100 == 0:
            solver_pct=min(100.0,100.0*iterations/maxiter)
            progress(min(84, 60 + 24 * iterations / maxiter),
                     f'Constrained all-layer solve: {iterations:,}/{maxiter:,} iterations ({solver_pct:.0f}% of solver limit).')
    solve = minimize(scaled_fun, start.copy(), method='SLSQP', jac=True,
                     constraints=[cons], callback=callback,
                     options={'maxiter': maxiter, 'ftol': raw_ftol / scale,
                              'disp': False})
    info = _optimizer_record(solve)
    if not (np.all(np.isfinite(solve.x)) and np.isfinite(solve.fun)):
        raise FitConvergenceError('Constrained all-layer solve', info)
    residual = np.asarray(constraint(solve.x), dtype=float)
    violation = np.maximum(-residual, 0.)
    strict_tolerance = max(10 * raw_ftol, 100 * np.finfo(float).eps * scale)
    # SLSQP can reach its iteration budget with a point that is already
    # feasible to far below one VE quantum.  In that one case we continue to
    # the exact quantized search instead of discarding a usable calibration.
    # No unsafe result can pass: exact representable coefficients must still
    # have zero constraint violation and zero qualifying-bank issues.
    limit_tolerance = 1e-6
    normal_success = bool(info['success'] and info['status'] == 0)
    feasible_limit = bool((not normal_success) and info['status'] == 9 and
                          info['iterations'] >= int(maxiter) and
                          np.all(np.isfinite(residual)) and
                          float(violation.max(initial=0.0)) <= limit_tolerance)
    info.update(numerical_scaling=scale, raw_ftol=raw_ftol,
                scaled_ftol=raw_ftol / scale, maxiter=maxiter,
                continuous_constraint_min=float(residual.min()),
                continuous_violation_sum=float(violation.sum()),
                continuous_violation_max=float(violation.max(initial=0.0)),
                continuous_feasibility_tolerance=(limit_tolerance if feasible_limit else strict_tolerance),
                feasible_iteration_limit=feasible_limit,
                solver_revision=SOLVER_REVISION,
                elapsed_time_affects_selection=False)
    if normal_success:
        if not np.all(np.isfinite(residual)) or violation.sum() > strict_tolerance:
            info['message'] = 'Solver success flag was not supported by the unscaled feasibility check'
            raise FitConvergenceError('Constrained all-layer solve', info)
    elif not feasible_limit:
        raise FitConvergenceError('Constrained all-layer solve', info)
    return solve, info


def require_verified_result(result):
    """Recheck numerical provenance before packaging or committing a result."""
    if result.get('method_id') != METHOD_ID:
        raise ValueError('Candidate uses a superseded processing implementation; rerun review')
    initial = result.get('initial_optimizer', {})
    if not initial.get('success') or initial.get('status') != 0:
        raise FitConvergenceError('initial_optimizer', initial)
    info = result.get('optimizer', {})
    constrained_accepted=bool((info.get('success') and info.get('status')==0) or info.get('feasible_iteration_limit'))
    if not constrained_accepted:
        raise FitConvergenceError('optimizer', info)
    if info.get('solver_revision') != SOLVER_REVISION:
        raise ValueError('Candidate is missing current numerical verification')
    if (not np.isfinite(info.get('continuous_violation_sum', float('inf'))) or
        info['continuous_violation_sum'] > info.get('continuous_feasibility_tolerance', 0.)):
        raise ValueError('Candidate continuous feasibility verification failed')
    q = np.asarray(result['candidate_coefficients'], dtype=float)
    if not np.all(np.isfinite(q)) or not np.array_equal(q * 2048, rnd(q * 2048)):
        raise ValueError('Candidate contains invalid/unrepresentable coefficients')
    score = result.get('exact_constraint_violation_sum_squares', float('inf'))
    if not np.isfinite(score) or score > 1e-18:
        raise ValueError('Candidate failed exact qualifying-bank limits')
    rows = result.get('rows', [])
    if not rows or not all(np.isfinite(row.get(key, float('nan')))
                           for row in rows for key in ('stock', 'target', 'fitted')):
        raise ValueError('Candidate contains incomplete or nonfinite VE results')
    if result.get('metrics', {}).get('qualifying_bank_issues', 1):
        raise ValueError('Candidate failed qualifying-bank verification')
    if not result.get('verification', {}).get('passed'):
        raise ValueError('Candidate acceptance verification is missing')
    return True


def _seal_verification(result):
    opt=result['optimizer'];constrained_accepted=bool((opt.get('success') and opt.get('status')==0) or opt.get('feasible_iteration_limit'))
    info = {'passed': True, 'solver_revision': SOLVER_REVISION,
            'initial_success': bool(result['initial_optimizer']['success']),
            'constrained_success': constrained_accepted,
            'constrained_feasible_iteration_limit': bool(opt.get('feasible_iteration_limit')),
            'exact_bank_issues': result['metrics']['qualifying_bank_issues'],
            'scope': 'numerical and export validation; not vehicle approval'}
    result['verification'] = info
    result['metrics']['fit_verification'] = dict(info)
    require_verified_result(result)


def rnd(x):return np.sign(x)*np.floor(np.abs(x)+.5)
def pack(a,b,c,d,e,f):return np.concatenate([np.asarray(a).ravel(),b,np.asarray(c).ravel(),d,e,np.atleast_1d(f)])
def unpack(p):
    n=int(round((math.sqrt(4*len(p)+45)-7)/2))
    if n*n+7*n+1!=len(p):raise ValueError('Invalid NN coefficient count')
    a=4*n;b=5*n;c=b+n*n;d=c+n;e=d+n
    return p[:a].reshape(n,4),p[a:b],p[b:c].reshape(n,n),p[c:d],p[d:e],p[e]

def coefficients(net):return pack(*(net[k] for k in ('W1','b1','W2','b2','Wo')),net['bo'][0])
def network(p):
    w1,b1,w2,b2,wo,bo=unpack(p)
    return {'W1':w1.tolist(),'b1':b1.tolist(),'W2':w2.tolist(),'b2':b2.tolist(),'Wo':wo.tolist(),'bo':[float(bo)]}

def config(net):
    cfg=json.loads((ASSETS/'frozen_model.json').read_text())
    t=net['meta']['training']
    cfg['input_min']=[t['intake_min'],t['exhaust_min'],t['rpm_min'],round(t['pratio_min'],4)]
    cfg['input_max']=[t['intake_max'],t['exhaust_max'],t['rpm_max'],round(t['pratio_max'],4)]
    cfg['ve_min']=t['ve_min'];cfg['ve_max']=t['ve_max']
    lut=net['meta'].get('activation')
    if lut is not None:cfg['lut_x']=lut['x'];cfg['lut_y']=lut['y']
    if any(a>=b for a,b in zip(cfg['input_min'],cfg['input_max'])):raise ValueError('Invalid NN training ranges')
    return cfg

class FrozenModel:
    def __init__(self,config):
        self.cfg=config;self.lx=np.array(config['lut_x']);self.ly=rnd(np.array(config['lut_y'])*2048);self.scale=(config['ve_max']-config['ve_min'])/2
    def normalize(self,physical):
        lo=np.array(self.cfg['input_min']);hi=np.array(self.cfg['input_max'])
        return rnd((2*(physical-lo)/(hi-lo)-1)*2048)/2048
    def activation(self,z,exact=True,gradient=False):
        t=np.minimum(np.abs(z)/3.96875,1)
        j=np.clip(np.searchsorted(self.lx,t,side='right')-1,0,len(self.lx)-2)
        slopes=(self.ly[j+1]-self.ly[j])/(self.lx[j+1]-self.lx[j])
        inter=self.ly[j]+(t-self.lx[j])*slopes
        signed=np.sign(z)*inter
        out=np.floor(signed)/2048 if exact else signed/2048
        if gradient:return out,np.where(np.abs(z)<3.96875,slopes/(2048*3.96875),0)
        return out
    def forward(self,p,x,exact=True,cache=False):
        w1,b1,w2,b2,wo,bo=unpack(p);n=len(wo)
        z1=sum(x[:,k,None]*w1[None,:,k] for k in range(4))+b1
        if cache:h1,g1=self.activation(z1,False,True)
        else:h1=self.activation(z1,exact)
        z2=sum(h1[:,k,None]*w2[None,:,k] for k in range(n))+b2
        if cache:h2,g2=self.activation(z2,False,True)
        else:h2=self.activation(z2,exact)
        zo=sum(h2[:,k]*wo[k] for k in range(n))+bo
        ve=(zo+1)*self.scale+self.cfg['ve_min']
        if exact:ve=rnd(ve/QUANTUM)*QUANTUM
        return (ve,(h1,g1,h2,g2)) if cache else ve

def _convert(key,unit,value):
    return logcheck.convert_value(key,unit,value)

def _interpolate(times,values,t):
    i=bisect.bisect_right(times,t)-1
    if i<0:return values[0]
    if i>=len(times)-1 or times[i]==t:return values[i]
    return values[i]+(values[i+1]-values[i])*(t-times[i])/(times[i+1]-times[i])

def prepare_samples(path,domain=None,*,closed_loop_only=False):
    domain=domain or {'rpms':RPM,'pratios':PR,'pr_bins':PR_BINS,'cam_pairs':CAM_PAIRS,'source':'legacy_reference_axes'}
    rpms=domain['rpms'];pr_bins=domain['pr_bins']
    meta=logcheck.read_metadata(Path(path));resolved=logcheck.resolve_indices(Path(path),meta)
    indices={}
    for key,pid in PIDS.items():
        exact=[i for i,v in enumerate(meta.ids) if str(v).strip()==str(pid)]
        # MAP and Baro have already been selected and validated together
        # against logged pressure. Do not override that decision with a
        # misleading pressure PID or the generic VCM Scanner MAP channel.
        matches=(resolved.get(key,[]) if key in ('map','baro')
                 else exact or resolved.get(key,[]))
        if key=='fuel_flow' and not matches:
            matches=[i for i,n in enumerate(meta.names) if n.strip().lower()=='fuel flow rate']
        if not matches:raise ValueError(f'Required processing channel is missing: {key}')
        # The named native parameter wins. Multiple ambiguous alternatives need
        # explicit resolution rather than mixing distinct measurement streams.
        if len(matches)!=1:raise ValueError(f'Ambiguous processing channel: {key}')
        indices[key]=matches[0]
    curves={k:([],[]) for k in PIDS};triggers=[[],[]];record_count=0;previous_t=None
    for t,row in logcheck.iter_data(Path(path),meta.data_start_line):
        # HPT native record times are milliseconds. Preserve their exact integer
        # representation when the CSV timestamp is on that grid.
        ms=t*1000;t=round(ms) if abs(ms-round(ms))<1e-7 else ms
        if previous_t is not None and t<previous_t:raise ValueError('Log timestamps must be in source order')
        previous_t=t;updates=set();record_count+=1
        for key,i in indices.items():
            value=logcheck._fnum(row[i]) if i<len(row) else None
            if value is not None:
                curves[key][0].append(t);curves[key][1].append(_convert(key,meta.units[i],value));updates.add(key)
        for b in (1,2):
            if updates.intersection((f'ltft_b{b}',f'stft_b{b}')):triggers[b-1].append(t)
    if any(not ts for ts,_ in curves.values()):raise ValueError('Required channel has no numeric values')
    start=max(ts[0] for ts,_ in curves.values());rows=[]
    for bank in (1,2):
        bank_rows=[]
        for t in triggers[bank-1]:
            if t<start:continue
            v={k:_interpolate(*c,t) for k,c in curves.items()}
            if closed_loop_only and (abs(v['fa_enrichment'])>1e-9 or abs(v['fa_power_enrichment'])>1e-9):
                continue
            if not(v['rpm']>1000 and v['ect']>164 and v['actual_torque']>1 and v['fuel_flow']>.01 and v['baro']>0):continue
            ratio=v['map']/v['baro'];r=min(range(20),key=lambda i:abs(pr_bins[i]-ratio));c=min(range(20),key=lambda i:abs(rpms[i]-v['rpm']))
            vals=[bank,t/1000,v['rpm'],v['map'],v['baro'],ratio,v['actual_torque'],v['ect'],v['fuel_flow'],v['fa_enrichment'],v['fa_power_enrichment'],v[f'ltft_b{bank}'],v[f'stft_b{bank}'],r*20+c,v['intake_cam'],v['exhaust_cam']]
            bank_rows.append(dict(zip(SAMPLE_FIELDS,vals)))
        bank_rows.sort(key=lambda r:(r['CellIndex'],r['Time_s']));rows.extend(bank_rows)
    return rows,{'source_records':record_count,'bank_events':list(map(len,triggers)),'accepted_bank_samples':[sum(r['Bank']==b for r in rows) for b in (1,2)],'channels':{k:{'id':meta.ids[i],'name':meta.names[i],'unit':meta.units[i]} for k,i in indices.items()},'model_domain':domain,'closed_loop_only':bool(closed_loop_only)}

def write_samples(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=SAMPLE_FIELDS);w.writeheader();w.writerows(rows)

def read_samples(path):
    with Path(path).open(newline='',encoding='utf-8-sig') as f:
        return [{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]

def aggregate(samples):
    # Qualification is deliberately independent of cam position.  HPT's hit
    # count is the accepted bank/RPM/PR cell count, so all accepted events in
    # that cell are pooled before the >=5 test.  Cam pairs are used only when
    # the NN VE surfaces are evaluated/fitted.
    counts=np.zeros((2,400),int);sums=np.zeros((2,400,2))
    for row in samples:
        b=int(row['Bank'])-1;k=int(row['CellIndex']);counts[b,k]+=1
        sums[b,k,0]+=row['LTFT_pct'];sums[b,k,1]+=row['STFT_pct']
    # Divide components separately before adding.
    totals=[[float(sums[b,k,0]/counts[b,k]+sums[b,k,1]/counts[b,k]) if counts[b,k] else None for k in range(400)] for b in range(2)]
    return counts,totals

def make_targets(samples,net,domain=None):
    domain=domain or model_domain(net)
    rpms=domain['rpms'];prs=domain['pratios'];cam_pairs=domain['cam_pairs']
    counts,totals=aggregate(samples);model=FrozenModel(config(net));p0=coefficients(net);rows=[]
    for pair,(inc,exc) in enumerate(cam_pairs):
        for r,pr in enumerate(prs):
            for c,rpm in enumerate(rpms):
                k=r*20+c;n1,n2=map(int,counts[:,k]);q1=n1>=MIN_HITS;q2=n2>=MIN_HITS
                eligible=([totals[0][k]] if q1 else [])+([totals[1][k]] if q2 else [])
                full=max(eligible) if eligible else None
                rows.append(dict(pair=pair+1,row=r,column=c,rpm=rpm,pratio=pr,intake=inc,exhaust=exc,n1=n1,n2=n2,total1=totals[0][k],total2=totals[1][k],eligible_bank1=q1,eligible_bank2=q2,covered=bool(eligible),full_correction=full,correction=FRACTION*full if eligible else None))
    x=model.normalize(np.array([[r['intake'],r['exhaust'],r['rpm'],r['pratio']] for r in rows]));stock=model.forward(p0,x)
    for r,v in zip(rows,stock):
        r['stock']=float(v);r['target']=float(v*(1+r['correction']/100)) if r['covered'] else float(v)
    return rows,model,p0,x

def model_domain_from_rows(rows):
    if not rows:return {}
    pairs=[]
    for r in rows:
        pair=(float(r['intake']),float(r['exhaust']))
        if pair not in pairs:pairs.append(pair)
    rpms=[float(rows[c]['rpm']) for c in range(20)]
    prs=[float(rows[r*20]['pratio']) for r in range(20)]
    return {'rpms':rpms,'pratios':prs,'pr_bins':[round(v,2) for v in prs],
            'cam_pairs':[list(p) for p in pairs],'source':'input_htt_training_ranges'}

def _directions(size):
    n=len(unpack(np.zeros(size))[1]);out=[]
    for j in range(n):
        v=np.zeros(size);v[4*j]=1;v[4*j+1]=-1;out.append(v)
    for j in list(range(2,4*n,4))+list(range(3,4*n,4))+list(range(4*n,size)):
        v=np.zeros(size);v[j]=1;out.append(v)
    return out

def fit(rows,model,p0,x,progress=None,initial_guess=None):
    stock=np.array([r['stock'] for r in rows]);target=np.array([r['target'] for r in rows]);mask=np.array([r['covered'] for r in rows])
    if not mask.any():raise NoQualifyingCells('No correction inputs meet the minimum of 5 hits per bank and cell.')
    if np.any(stock[mask]<=0):raise ValueError('Qualifying cells require positive baseline VE for the accepted percentage correction')
    weights=np.where(mask,16.,1.);regularization=.01;calls=0
    smooth0=model.forward(p0,x,exact=False);smooth_target=smooth0+(target-stock)
    def notify(pct,msg):
        if progress:progress(pct,msg)
    notify(0,'Fitting the accepted half-step targets across the VE surface.')
    def objective(p):
        nonlocal calls
        v,(h1,g1,h2,g2)=model.forward(p,x,exact=False,cache=True);e=v-smooth_target
        loss=np.mean(weights*e*e)+regularization*np.mean((p-p0)**2)
        dv=2*weights*e/len(e)*model.scale;w1,b1,w2,b2,wo,bo=unpack(p)
        d2=dv[:,None]*wo[None,:]*g2;d1=(d2@w2)*g1
        grad=pack(d1.T@x,d1.sum(0),d2.T@h1,d2.sum(0),(dv[:,None]*h2).sum(0),dv.sum())+2*regularization*(p-p0)/len(p)
        calls+=1
        if calls%1000==0:notify(min(45,5+calls/300),f'Fitting VE targets: {calls:,} evaluations.')
        return float(loss),grad
    start=(np.array(initial_guess,dtype=float).copy() if initial_guess is not None else p0.copy())
    solve=minimize(objective,start,method='L-BFGS-B',jac=True,options={'maxiter':12000,'maxls':30,'ftol':1e-10,'gtol':1e-6,'maxcor':30})
    initial_info = _require_solve(solve, 'Initial all-layer solve')
    def exact_loss(p):return float(np.mean(weights*(model.forward(p,x)-target)**2)+regularization*np.mean((p-p0)**2))
    choices=[(exact_loss(p0),p0.copy(),'stock')]
    for a in np.linspace(.1,1,19):
        p=rnd((p0+a*(solve.x-p0))*2048)/2048;choices.append((exact_loss(p),p,f'fit_scale_{a:.2f}'))
    loss,pq,selected=min(choices,key=lambda q:q[0]);directions=_directions(len(p0))
    for step in [4,2,1]:
        for sweep in range(5):
            improvements=0
            for direction in directions:
                best=(loss,pq)
                for sign in [-1,1]:
                    candidate=pq+sign*step/2048*direction;score=exact_loss(candidate)
                    if score<best[0]-1e-12:best=(score,candidate)
                if best[0]<loss-1e-12:loss,pq=best;improvements+=1
            if not improvements:break
    initial_info.update(selection=selected)
    pstart=pq.copy();previous=model.forward(pstart,x)
    full=np.array([r['full_correction'] if r['covered'] else 0. for r in rows])
    lower=stock+stock*np.minimum(full,0)/100
    offset=previous-model.forward(pstart,x,exact=False);calls=0;cache={};n=len(unpack(p0)[1])
    notify(60,'Checking qualifying bank effects while retaining the same half-step targets.')
    def evaluate(p):
        nonlocal calls
        if 'p' in cache and np.array_equal(p,cache['p']):return cache['y'],cache['jac']
        v,(h1,g1,h2,g2)=model.forward(p,x,exact=False,cache=True);w1,b1,w2,b2,wo,bo=unpack(p)
        d2=model.scale*wo[None,:]*g2;d1=(d2@w2)*g1
        jac=np.concatenate([(d1[:,:,None]*x[:,None,:]).reshape(-1,4*n),d1,(d2[:,:,None]*h1[:,None,:]).reshape(-1,n*n),d2,model.scale*h2,np.full((len(x),1),model.scale)],axis=1)
        cache.update(p=p.copy(),y=v+offset,jac=jac);calls+=1
        return cache['y'],jac
    def fun(p):
        y,jac=evaluate(p);err=y-target
        loss=np.mean(weights*err**2)+regularization*np.mean((p-p0)**2)
        grad=jac.T@(2*weights*err/len(y))+2*regularization*(p-p0)/len(p)
        return float(loss),grad
    def constraint(p):return evaluate(p)[0][mask]-lower[mask]-QUANTUM
    def constraint_jac(p):return evaluate(p)[1][mask]
    solve, solver = _constrained_solve(fun, pstart, constraint, constraint_jac,
                                       model.scale, 1000, 1e-9, progress)
    continuous = solve.x
    def exact_score(p):
        y=model.forward(p,x);violation=np.maximum(lower[mask]-y[mask],0)
        return (float(np.sum(violation**2)),float(np.mean(weights*(y-target)**2)+regularization*np.mean((p-p0)**2)))
    # Stock must not masquerade as a completed fitted candidate after fallback.
    # The stock baseline still participates in the first-stage loss comparison.
    choices=[]
    if not np.array_equal(pstart,p0):
        choices.append((exact_score(pstart),pstart.copy(),'converged initial fit'))
    for alpha in np.linspace(.1,1,19):
        p=rnd((p0+alpha*(continuous-p0))*2048)/2048
        if not np.array_equal(p,p0):
            choices.append((exact_score(p),p,f'same-solve coefficient scale {alpha:.2f}'))
    if not choices:
        raise ValueError('The converged solve produced no representable correction; no new candidate was approved')
    score,pq,selected=min(choices,key=lambda a:a[0]);notify(85,'Verifying representable weights, biases, and exact VE output.')
    for step in [4,2,1]:
        for sweep in range(3):
            improvements=0
            for direction in directions:
                best=(score,pq)
                for sign in [-1,1]:
                    candidate=pq+sign*step/2048*direction;trial=exact_score(candidate)
                    if trial<best[0]:best=(trial,candidate)
                if best[0]<score:score,pq=best;improvements+=1
            if not improvements:break
    y=model.forward(pq,x)
    if score[0]>1e-18:raise ValueError('The fitted network did not pass the qualifying-bank effect check')
    for i,r in enumerate(rows):r['fitted']=float(y[i])
    result={'method_id':METHOD_ID,'model_config':model.cfg,'stock_coefficients':p0.tolist(),'candidate_coefficients':pq.tolist(),'rows':rows,'initial_optimizer':initial_info,'optimizer':solver,'exact_candidate_selection':selected,'exact_constraint_violation_sum_squares':score[0],'settings':{'minimum_hit_count':MIN_HITS,'correction_fraction':FRACTION,'fitting_weights':[16,1],'regularization':regularization,'coefficient_quantum':1/2048,'ve_quantum':QUANTUM,'model_domain':model_domain_from_rows(rows)}}
    result['metrics']=review(rows)
    _seal_verification(result)
    notify(100,'Both numerical solves completed; exact candidate and bank checks passed.')
    return result

def fit_reduced(rows,model,p0,x,primary_p,progress=None):
    """Fast Results-only fit for the optional half reduction.

    This does not change the accepted primary half-step process.  It starts from
    the midpoint between the stock and already-verified primary coefficients,
    fits only the user-requested reduced target, then enforces the same exact
    qualifying-bank lower bounds before returning representable coefficients.
    """
    stock=np.array([r['stock'] for r in rows]);target=np.array([r['target'] for r in rows]);mask=np.array([r['covered'] for r in rows])
    if not mask.any():raise NoQualifyingCells('No correction inputs meet the minimum of 5 hits per bank and cell.')
    if np.any(stock[mask]<=0):raise ValueError('Qualifying cells require positive baseline VE for the accepted percentage correction')
    weights=np.where(mask,16.,1.);regularization=.01
    smooth0=model.forward(p0,x,exact=False);smooth_target=smooth0+(target-stock)
    def notify(pct,msg):
        if progress:progress(pct,msg)
    notify(0,'Preparing the reduced Results option.')
    def objective(p):
        v,(h1,g1,h2,g2)=model.forward(p,x,exact=False,cache=True);e=v-smooth_target
        loss=np.mean(weights*e*e)+regularization*np.mean((p-p0)**2)
        dv=2*weights*e/len(e)*model.scale;w1,b1,w2,b2,wo,bo=unpack(p)
        d2=dv[:,None]*wo[None,:]*g2;d1=(d2@w2)*g1
        grad=pack(d1.T@x,d1.sum(0),d2.T@h1,d2.sum(0),(dv[:,None]*h2).sum(0),dv.sum())+2*regularization*(p-p0)/len(p)
        return float(loss),grad
    primary_p=np.array(primary_p,dtype=float)
    start=rnd((p0+0.5*(primary_p-p0))*2048)/2048
    solve=minimize(objective,start,method='L-BFGS-B',jac=True,options={'maxiter':12000,'maxls':20,'ftol':1e-9,'gtol':1e-6,'maxcor':20})
    reduced_initial_info = _require_solve(solve, 'Reduced initial all-layer solve')
    notify(35,'Checking qualifying-bank limits for the reduced option.')
    pstart=rnd(solve.x*2048)/2048
    previous=model.forward(pstart,x)
    full=np.array([r['full_correction'] if r['covered'] else 0. for r in rows])
    lower=stock+stock*np.minimum(full,0)/100
    offset=previous-model.forward(pstart,x,exact=False);cache={};n=len(unpack(p0)[1])
    def evaluate(p):
        if 'p' in cache and np.array_equal(p,cache['p']):return cache['y'],cache['jac']
        v,(h1,g1,h2,g2)=model.forward(p,x,exact=False,cache=True);w1,b1,w2,b2,wo,bo=unpack(p)
        d2=model.scale*wo[None,:]*g2;d1=(d2@w2)*g1
        jac=np.concatenate([(d1[:,:,None]*x[:,None,:]).reshape(-1,4*n),d1,(d2[:,:,None]*h1[:,None,:]).reshape(-1,n*n),d2,model.scale*h2,np.full((len(x),1),model.scale)],axis=1)
        cache.update(p=p.copy(),y=v+offset,jac=jac);return cache['y'],jac
    def fun(p):
        y,jac=evaluate(p);err=y-target
        loss=np.mean(weights*err**2)+regularization*np.mean((p-p0)**2)
        grad=jac.T@(2*weights*err/len(y))+2*regularization*(p-p0)/len(p)
        return float(loss),grad
    def constraint(p):return evaluate(p)[0][mask]-lower[mask]-QUANTUM
    def constraint_jac(p):return evaluate(p)[1][mask]
    constrained, reduced_solver_info = _constrained_solve(
        fun, pstart, constraint, constraint_jac, model.scale, 1000, 1e-8)
    notify(65,'Selecting exact representable reduced coefficients.')
    def exact_score(p):
        y=model.forward(p,x);violation=np.maximum(lower[mask]-y[mask],0)
        return (float(np.sum(violation**2)),float(np.mean(weights*(y-target)**2)+regularization*np.mean((p-p0)**2)))
    choices=[]
    for alpha in np.linspace(.05,1,20):
        q=rnd((p0+alpha*(constrained.x-p0))*2048)/2048;choices.append((exact_score(q),q,f'reduced constrained scale {alpha:.2f}'))
    q=rnd(constrained.x*2048)/2048;choices.append((exact_score(q),q,'reduced constrained direct'))
    safe=[item for item in choices if item[0][0]<=1e-18]
    directions=_directions(len(p0))
    if safe:
        score,pq,selected=min(safe,key=lambda item:item[0][1])
    else:
        # Quantization can move an otherwise feasible continuous point across a
        # bank limit. Repair representability exactly before optimizing loss.
        score,pq,selected=min(choices,key=lambda item:item[0])
        for step in [4,2,1]:
            for sweep in range(4):
                improvements=0
                for direction in directions:
                    best=(score,pq)
                    for sign in (-1,1):
                        candidate=pq+sign*step/2048*direction;trial=exact_score(candidate)
                        if trial<best[0]:best=(trial,candidate)
                    if best[0]<score:score,pq=best;improvements+=1
                if not improvements:break
        if score[0]>1e-18:raise ValueError('A safe reduced candidate could not be represented with the accepted coefficient quantum')
        selected += ' + exact feasibility repair'
    for step in [2,1]:
        for sweep in range(2):
            improvements=0
            for direction in directions:
                best=(score,pq)
                for sign in (-1,1):
                    candidate=pq+sign*step/2048*direction;trial=exact_score(candidate)
                    if trial[0]<=1e-18 and trial[1]<best[0][1]-1e-12:best=(trial,candidate)
                if best[1] is not pq:score,pq=best;improvements+=1
            if not improvements:break
    y=model.forward(pq,x)
    for i,r in enumerate(rows):r['fitted']=float(y[i])
    result={'method_id':METHOD_ID,'model_config':model.cfg,'stock_coefficients':p0.tolist(),'candidate_coefficients':pq.tolist(),'rows':rows,'initial_optimizer':dict(reduced_initial_info,selection='reduced midpoint start'),'optimizer':reduced_solver_info,'exact_candidate_selection':selected,'exact_constraint_violation_sum_squares':score[0],'settings':{'minimum_hit_count':MIN_HITS,'correction_fraction':FRACTION/2,'fitting_weights':[16,1],'regularization':regularization,'coefficient_quantum':1/2048,'ve_quantum':QUANTUM,'results_only_reduction':True,'model_domain':model_domain_from_rows(rows)}}
    result['metrics']=review(rows)
    if result['metrics']['qualifying_bank_issues']:raise ValueError('Reduced candidate failed qualifying-bank verification')
    _seal_verification(result)
    notify(100,'Reduced Results option verified.')
    return result


def review(rows):
    before=[];after=[];issues=0;positive_improved=0;positive_unchanged=0;positive_remaining=0
    errors=[];desired=[];reverse=0
    for r in rows:
        if not r['covered']:continue
        achieved=100*(r['fitted']-r['stock'])/r['stock'];banks=[]
        for b in (1,2):
            if r[f'n{b}']<MIN_HITS:continue
            total=r[f'total{b}'];residual=total-achieved
            issue=(total>0 and residual>total+1e-10) or (total<=0 and residual>1e-10)
            issues+=int(issue);positive_improved+=int(total>0 and residual<total-1e-10);positive_unchanged+=int(total>0 and abs(residual-total)<=1e-10);positive_remaining+=int(residual>1e-10)
            before.append(abs(total));after.append(abs(residual));banks.append({'bank':b,'hits':r[f'n{b}'],'before':total,'estimated_after':residual})
        r['qualifying_banks']=banks
        errors.append(abs(r['fitted']-r['target']));desired.append(abs(r['target']-r['stock']))
        reverse+=int((r['target']-r['stock'])*(r['fitted']-r['stock'])<0)
    b=float(np.mean(before)) if before else 0.;a=float(np.mean(after)) if after else 0.
    e=float(np.mean(errors)) if errors else 0.;d=float(np.mean(desired)) if desired else 0.
    return {'method_id':METHOD_ID,'qualifying_cells':len(errors),'qualifying_bank_entries':len(before),'bank_mae_before':b,'bank_mae_after':a,'bank_improvement_pct':100*(1-a/b) if b else 0.,'target_mae':e,'target_max_error':max(errors,default=0.),'target_error_reduction_pct':100*(1-e/d) if d else 0.,'qualifying_bank_issues':issues,'positive_bank_improved':positive_improved,'positive_bank_unchanged':positive_unchanged,'positive_bank_remaining':positive_remaining,'reverse_qualified_cells':reverse,'application_percent':50.0,'nn_architecture':{},'accepted':0,'changes':{}}

def run(input_csv,baseline_htt,output_dir,progress=None):
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    for name in ('Candidate_FullEngine.htt', 'Processing_Result.json', 'Fit_Failure.json'):
        old = out/name
        if old.resolve() == Path(baseline_htt).resolve():
            raise ValueError('Input calibration cannot be used as a generated output path')
        old.unlink(missing_ok=True)
    baseline_net=htt.load_network(baseline_htt);domain=model_domain(baseline_net)
    samples,prep=prepare_samples(input_csv,domain);sample_path=out/'Accepted_Bank_Events.csv';write_samples(sample_path,samples)
    rows,model,p0,x=make_targets(samples,baseline_net,domain)
    try:
        result=fit(rows,model,p0,x,progress)
    except FitConvergenceError as exc:
        (out/'Fit_Failure.json').write_text(json.dumps(
            {'approved':False,'stage':exc.stage,'details':exc.details},indent=2))
        raise
    require_verified_result(result)
    result['preparation']=prep;result['metrics']['accepted']=len(samples);result['metrics']['nn_architecture']=htt.architecture_summary(baseline_htt)
    candidate=out/'Candidate_FullEngine.htt';htt.write_candidate(baseline_htt,candidate,network(np.array(result['candidate_coefficients'])))
    if coefficients(htt.load_network(candidate)).tolist()!=result['candidate_coefficients']:raise ValueError('Candidate coefficient round-trip failed')
    if not np.array_equal(model.forward(coefficients(htt.load_network(candidate)),x),np.array([r['fitted'] for r in result['rows']])):raise ValueError('Candidate VE round-trip failed')
    bn=htt.load_network(baseline_htt);cn=htt.load_network(candidate)
    result['metrics']['changes']={k:int(np.count_nonzero(np.array(bn[k])!=np.array(cn[k]))) for k in ('W1','b1','W2','b2','Wo','bo')}
    (out/'Processing_Result.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    return result,sample_path,candidate

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('log');parser.add_argument('baseline');parser.add_argument('output')
    args=parser.parse_args();r,_,_=run(args.log,args.baseline,args.output,lambda pct,msg:print(f'{pct:.0f}% {msg}',flush=True));print(json.dumps(r['metrics'],indent=2))
