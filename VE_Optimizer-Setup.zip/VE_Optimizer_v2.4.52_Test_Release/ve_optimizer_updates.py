"""On-demand, Windows-only, GitHub Releases updater for VE Optimizer.

The customer publishes Releases; the application never uploads or publishes them.
Updates are checked only on explicit user request.  No tuning or license logic is
implemented here.  Windows installer installation is delegated to a temporary,
separate helper process after the running application exits.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import uuid
import zipfile

REPOSITORY = 'shortshiftsteve/Software-Distribution'
LATEST_API = f'https://api.github.com/repos/{REPOSITORY}/releases/latest'
ASSET_NAME = 'VE-Optimizer-Setup.zip'
MAX_METADATA_BYTES = 256 * 1024
MAX_ZIP_BYTES = 1024 * 1024 * 1024
MAX_INSTALLER_BYTES = 600 * 1024 * 1024


class UpdateError(RuntimeError):
    """An update check, download, integrity check or handoff failed safely."""


@dataclass(frozen=True)
class PublishedRelease:
    version: str
    tag: str
    asset_url: str
    sha256: str | None = None


def version_tuple(version: str) -> tuple[int, ...]:
    match = re.fullmatch(r'v?([0-9]+(?:\.[0-9]+){2,3})', str(version).strip())
    if not match:
        raise UpdateError('GitHub returned an unsupported VE Optimizer version tag.')
    parts = tuple(int(part) for part in match.group(1).split('.'))
    if any(part > 65535 for part in parts):
        raise UpdateError('GitHub returned an invalid VE Optimizer version.')
    return parts + (0,) * (4 - len(parts))


def newer_than(available: str, installed: str) -> bool:
    return version_tuple(available) > version_tuple(installed)


def _release_asset_url(tag: str) -> str:
    # Use the version-specific asset so a newly published Release cannot
    # change what gets downloaded after the user approved a particular version.
    return f'https://github.com/{REPOSITORY}/releases/download/{urllib.parse.quote(tag, safe="")}/{ASSET_NAME}'


def parse_release(payload: object) -> PublishedRelease:
    if not isinstance(payload, dict) or payload.get('draft') or payload.get('prerelease'):
        raise UpdateError('No published production Release is available.')
    tag = str(payload.get('tag_name') or '').strip()
    version_tuple(tag)  # Reject malformed and nonnumeric tags.
    version = tag[1:] if tag.startswith('v') else tag
    assets = payload.get('assets')
    if not isinstance(assets, list):
        raise UpdateError('The GitHub Release does not provide an installer ZIP.')
    named = [a for a in assets if isinstance(a, dict) and a.get('name') == ASSET_NAME]
    if len(named) != 1:
        raise UpdateError(f'The GitHub Release must contain exactly one {ASSET_NAME}.')
    asset = named[0]
    url = str(asset.get('browser_download_url') or '')
    if url != _release_asset_url(tag):
        raise UpdateError('GitHub returned an unexpected installer download address.')
    digest = asset.get('digest')
    sha256 = None
    if digest is not None:
        if not isinstance(digest, str) or not re.fullmatch(r'sha256:[0-9a-fA-F]{64}', digest):
            raise UpdateError('GitHub returned an unsupported installer digest.')
        sha256 = digest.split(':', 1)[1].lower()
    return PublishedRelease(version, tag, url, sha256)


def fetch_latest_release(*, opener=None, timeout=20) -> PublishedRelease:
    opener = opener or urllib.request.urlopen
    request = urllib.request.Request(
        LATEST_API, headers={'Accept': 'application/vnd.github+json',
                             'User-Agent': 'VE-Optimizer-Windows-Updater',
                             'X-GitHub-Api-Version': '2022-11-28'})
    try:
        with opener(request, timeout=timeout) as response:
            raw = response.read(MAX_METADATA_BYTES + 1)
    except (OSError, ValueError) as exc:
        raise UpdateError(f'Unable to check GitHub Releases: {exc}') from exc
    if len(raw) > MAX_METADATA_BYTES:
        raise UpdateError('GitHub Release metadata exceeds the permitted size.')
    try:
        return parse_release(json.loads(raw.decode('utf-8')))
    except (ValueError, UnicodeError) as exc:
        raise UpdateError('GitHub returned invalid Release metadata.') from exc


def filename_for_version(version: str) -> str:
    version_tuple(version)
    return f'VE Optimizer v{version} Release Setup.exe'


def download_installer(release: PublishedRelease, target_dir: Path, *, opener=None,
                       timeout=60) -> Path:
    """Download and unpack one safely named installer; verify GitHub digest if supplied.

    Windows Authenticode and embedded installer version checks MUST pass later,
    before launching installation.  An archive/hash check alone is insufficient.
    """
    if release.asset_url != _release_asset_url(release.tag):
        raise UpdateError('Installer download address differs from the approved Release.')
    target_dir = Path(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    zip_path = target_dir / ASSET_NAME
    opener = opener or urllib.request.urlopen
    request = urllib.request.Request(release.asset_url, headers={
        'Accept': 'application/octet-stream', 'User-Agent': 'VE-Optimizer-Windows-Updater'})
    digest = hashlib.sha256()
    count = 0
    try:
        with opener(request, timeout=timeout) as response, zip_path.open('wb') as dst:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                count += len(block)
                if count > MAX_ZIP_BYTES:
                    raise UpdateError('The downloaded update exceeds the size limit.')
                digest.update(block)
                dst.write(block)
        if release.sha256 and digest.hexdigest() != release.sha256:
            raise UpdateError('The installer ZIP does not match the GitHub SHA-256 digest.')
        try:
            with zipfile.ZipFile(zip_path) as archive:
                entries = archive.infolist()
                if not 1 <= len(entries) <= 30:
                    raise UpdateError('The installer ZIP has an unexpected file count.')
                for item in entries:
                    path = PurePosixPath(item.filename.replace('\\', '/'))
                    if (path.is_absolute() or '..' in path.parts or
                            ':' in item.filename or item.file_size > MAX_INSTALLER_BYTES):
                        raise UpdateError('The installer ZIP contains an unsafe entry.')
                installers = [entry for entry in entries if not entry.is_dir() and
                              re.fullmatch(r'VE Optimizer v[0-9.]+ Release Setup\.exe',
                                           PurePosixPath(entry.filename).name, re.I)]
                if len(installers) != 1 or sum(1 for e in entries if e.filename.lower().endswith('.exe')) != 1:
                    raise UpdateError('The installer ZIP must contain one VE Optimizer Release Setup.exe.')
                member = installers[0]
                if filename_for_version(release.version).lower() != PurePosixPath(member.filename).name.lower():
                    raise UpdateError('The installer filename does not match the published version.')
                filename = PurePosixPath(member.filename).name
                installer = target_dir / filename
                with archive.open(member) as src, installer.open('wb') as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
                if installer.stat().st_size != member.file_size:
                    raise UpdateError('The extracted installer is incomplete.')
                return installer
        except (zipfile.BadZipFile, OSError, EOFError) as exc:
            raise UpdateError('The downloaded installer ZIP is damaged.') from exc
    except Exception:
        # Never expose a partly downloaded archive/installer as a runnable update.
        for file in target_dir.glob('*Setup.exe'):
            file.unlink(missing_ok=True)
        zip_path.unlink(missing_ok=True)
        raise


def _powershell_executable() -> Path:
    system_root = os.environ.get('SystemRoot', r'C:\Windows')
    return Path(system_root) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'


_SIGNATURE_CHECK = r'''
$ErrorActionPreference = 'Stop'
$target = $env:VE_UPDATE_TARGET
$existing = $env:VE_UPDATE_EXISTING
$expected = $env:VE_UPDATE_VERSION
if (!(Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Missing downloaded installer' }
if (!(Test-Path -LiteralPath $existing -PathType Leaf)) { throw 'Missing installed application' }
$old = Get-AuthenticodeSignature -LiteralPath $existing
$new = Get-AuthenticodeSignature -LiteralPath $target
if ($old.Status -ne 'Valid' -or $new.Status -ne 'Valid') { throw 'The Windows signing verification failed' }
if (!$old.SignerCertificate -or !$new.SignerCertificate) { throw 'Publisher certificates are missing' }
if ($old.SignerCertificate.Subject -ne $new.SignerCertificate.Subject) { throw 'Publisher identity changed' }
$version = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($target)
if ($version.ProductVersion -ne $expected -and $version.ProductVersion -ne $expected.Substring(0, $expected.LastIndexOf('.'))) { throw 'Installer version differs from published Release' }
if ($version.ProductName -ne 'VE Optimizer') { throw 'Installer product identity differs' }
'''


def verify_windows_installer(installer: Path, version: str, *, installed_exe=None, runner=None) -> None:
    """Require a valid Microsoft Authenticode signature and the same publisher.

    This verification intentionally fails closed on platforms other than Windows,
    on unsigned Review builds, and if native Windows version/signing checks fail.
    """
    if os.name != 'nt':
        raise UpdateError('Installing updates requires a signed Windows build.')
    existing = Path(installed_exe or sys.executable)
    expected_version = '.'.join(map(str, version_tuple(version)))
    env = dict(os.environ, VE_UPDATE_TARGET=str(installer), VE_UPDATE_EXISTING=str(existing),
               VE_UPDATE_VERSION=expected_version)
    try:
        proc = (runner or subprocess.run)(
            [str(_powershell_executable()), '-NoProfile', '-NonInteractive', '-Command',
             _SIGNATURE_CHECK], env=env, capture_output=True, text=True, timeout=35,
            check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise UpdateError('Windows could not validate the installer signature.') from exc
    if proc.returncode:
        raise UpdateError('The downloaded update could not be authenticated or its version verified.')


_UPDATE_LAUNCHER = r'''param(
  [Parameter(Mandatory=$true)][int]$ParentPid,
  [Parameter(Mandatory=$true)][string]$Uninstaller,
  [Parameter(Mandatory=$true)][string]$Installer,
  [Parameter(Mandatory=$true)][string]$ExpectedVersion,
  [Parameter(Mandatory=$true)][string]$AppDir,
  [Parameter(Mandatory=$true)][string]$BackupDir,
  [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference = 'Stop'
try {
  # The parent must exit before Inno can remove its executable.
  try { Wait-Process -Id $ParentPid -Timeout 180 -ErrorAction Stop } catch {
    if (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue) {
      throw 'VE Optimizer did not close within three minutes.'
    }
  }
  if (!(Test-Path -LiteralPath $Uninstaller -PathType Leaf)) { throw 'Uninstaller is missing.' }
  if (!(Test-Path -LiteralPath $Installer -PathType Leaf)) { throw 'Installer is missing.' }
  # Recheck the staged file before uninstalling the signed existing application.
  $oldExe = Join-Path $AppDir 'VE_Optimizer.exe'
  $oldSig = Get-AuthenticodeSignature -LiteralPath $oldExe
  $newSig = Get-AuthenticodeSignature -LiteralPath $Installer
  if ($oldSig.Status -ne 'Valid' -or $newSig.Status -ne 'Valid' -or
      $oldSig.SignerCertificate.Subject -ne $newSig.SignerCertificate.Subject) {
    throw 'The publisher signature changed or is invalid.'
  }
  $stagedVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($Installer).ProductVersion
  if ($stagedVersion -ne $ExpectedVersion -and
      $stagedVersion -ne $ExpectedVersion.Substring(0, $ExpectedVersion.LastIndexOf('.'))) {
    throw 'The staged installer version differs from the approved Release.'
  }
  # Preserve data stored inside the application's installation folder.
  $data = Join-Path $AppDir 'data'
  $saved = Join-Path $BackupDir 'data'
  New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
  if (Test-Path -LiteralPath $data -PathType Container) {
    Copy-Item -LiteralPath $data -Destination $saved -Recurse -Force
  }
  # Silent uninstall is only used during an explicitly approved upgrade. The
  # new uninstaller's data prompt is skipped, retaining projects and licenses.
  $u = Start-Process -FilePath $Uninstaller -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART') -PassThru
  $u.WaitForExit()
  if ($u.ExitCode -ne 0) { throw "Uninstaller returned exit code $($u.ExitCode)." }
  # Inno may finish removing locked files after the initial uninstaller exits.
  $deadline = (Get-Date).AddSeconds(120)
  $oldExeAfterUninstall = Join-Path $AppDir 'VE_Optimizer.exe'
  while ((Test-Path -LiteralPath $oldExeAfterUninstall) -and ((Get-Date) -lt $deadline)) {
    Start-Sleep -Milliseconds 500
  }
  if (Test-Path -LiteralPath $oldExeAfterUninstall) {
    throw 'The previous application was not fully removed; installation was stopped.'
  }
  # Restore before Setup: the existing [Run] entry can launch VE Optimizer
  # as soon as Setup completes.
  if (Test-Path -LiteralPath $saved -PathType Container) {
    New-Item -ItemType Directory -Force -Path $data | Out-Null
    # Copy only missing files. Inno may already have preserved the entire
    # folder; copying a folder over an existing folder can nest data/data.
    Get-ChildItem -LiteralPath $saved -Recurse -File -Force | ForEach-Object {
      $relative = $_.FullName.Substring($saved.Length + 1)
      $target = Join-Path $data $relative
      if (!(Test-Path -LiteralPath $target)) {
        New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
        Copy-Item -LiteralPath $_.FullName -Destination $target -Force
      }
    }
  }
  # Interactive initial setup and normal postinstall launch, as requested.
  # Explicit /DIR keeps customized installation locations after uninstall
  # has removed Inno Setup's previous-directory registry entry.
  $installDirectory = '/DIR="' + $AppDir + '"'
  $s = Start-Process -FilePath $Installer -ArgumentList $installDirectory -PassThru
  $s.WaitForExit()
  if ($s.ExitCode -ne 0) { throw "Setup returned exit code $($s.ExitCode)." }
  'VE Optimizer update installed successfully.' | Out-File -LiteralPath $LogPath -Encoding UTF8
} catch {
  ('VE Optimizer update stopped: ' + $_.Exception.Message) | Out-File -LiteralPath $LogPath -Encoding UTF8
  # Keep the backup and verified installer for manual recovery on failure.
  exit 1
}
'''


def start_update_handoff(installer: Path, version: str, *, installed_exe=None,
                         starter=None) -> Path:
    """Spawn a separate script outside {app}; caller then exits VE Optimizer.

    Only call from an explicit Download and Install user action, after successful
    download/signature/version validation.  No silent publisher-controlled install.
    """
    if os.name != 'nt':
        raise UpdateError('Automatic installation is available only on Windows.')
    exe = Path(installed_exe or sys.executable).resolve()
    uninstaller = exe.parent / 'unins000.exe'
    if not uninstaller.is_file():
        raise UpdateError('The current Windows uninstaller could not be located.')
    verify_windows_installer(installer, version, installed_exe=exe)
    user_dir = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'VEOptimizer'
    update_dir = user_dir / 'updates' / uuid.uuid4().hex
    update_dir.mkdir(parents=True, exist_ok=False)
    installer_copy = update_dir / Path(installer).name
    shutil.copy2(installer, installer_copy)
    launcher = update_dir / 'run_update.ps1'
    launcher.write_text(_UPDATE_LAUNCHER, encoding='utf-8-sig')
    backup = update_dir / 'backup'
    log = update_dir / 'update-result.txt'
    cmd = [str(_powershell_executable()), '-NoProfile', '-ExecutionPolicy', 'Bypass',
           '-File', str(launcher), '-ParentPid', str(os.getpid()),
           '-Uninstaller', str(uninstaller), '-Installer', str(installer_copy),
           '-ExpectedVersion', '.'.join(map(str, version_tuple(version))),
           '-AppDir', str(exe.parent), '-BackupDir', str(backup), '-LogPath', str(log)]
    try:
        (starter or subprocess.Popen)(cmd, cwd=str(update_dir),
                                      creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                                      close_fds=True)
    except OSError as exc:
        raise UpdateError('Unable to start the independent update installer.') from exc
    return log
