#!/usr/bin/env python3
"""Account, project and audit storage. Numerical processing lives in ve_optimizer_processing."""
from __future__ import annotations

import argparse
import atexit
import csv
import hashlib
import hmac
import os
import secrets
import shutil
import sqlite3
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception:  # allows --smoke-test on systems without Tk
    tk = None
    filedialog = messagebox = ttk = None


import ve_optimizer_stage3 as stage3

APP_NAME = "VE Optimizer"
APP_VERSION = "0.0.1-stage4"
DB_NAME = "ve_optimizer.db"
PBKDF2_ITERATIONS = 310_000
ROLES = ("admin", "user", "guest")


class ResourceRegistry:
    """Track close/release callbacks for deterministic clean shutdown."""
    def __init__(self):
        self._closers: List[Callable[[], None]] = []
        self._closed = False

    def register(self, closer: Callable[[], None]):
        self._closers.append(closer)

    def close_all(self):
        if self._closed:
            return
        self._closed = True
        for closer in reversed(self._closers):
            try:
                closer()
            except Exception:
                pass
        self._closers.clear()


RESOURCES = ResourceRegistry()
atexit.register(RESOURCES.close_all)


def _hash_password(password: str, salt: Optional[bytes] = None) -> Tuple[str, str]:
    if salt is None:
        salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return salt.hex(), digest.hex()


def _verify_password(password: str, salt_hex: str, digest_hex: str) -> bool:
    salt = bytes.fromhex(salt_hex)
    _, candidate = _hash_password(password, salt)
    return hmac.compare_digest(candidate, digest_hex)


@dataclass
class User:
    id: int
    username: str
    role: str
    first_name: str
    last_name: str


@dataclass
class Project:
    id: int
    name: str
    model_year: int
    model: str
    engine: str
    output_dir: str
    baseline_trim_mae: Optional[float]
    baseline_trim_median: Optional[float]
    stage3_candidate_applied: bool


class Database:
    """SQLite persistence with automatic recovery from pre-Stage-4/5 schemas.

    SQLite's CREATE TABLE IF NOT EXISTS does not add missing columns to an
    existing table.  Older VE Optimizer development builds could therefore
    leave a ``users`` or ``projects`` table that has the right name but an
    incompatible layout.  Before opening the production connection we inspect
    the core schema.  If it is incompatible, the complete legacy database is
    backed up with SQLite's online-backup API, a clean current database is
    created, and compatible user/project records are imported best-effort.
    The backup is never deleted automatically.
    """

    USERS_COLUMNS = {
        "id", "username_norm", "username_display", "salt", "password_hash",
        "role", "first_name", "last_name", "address", "city", "state",
        "zip", "phone", "active", "created_at", "updated_at",
    }
    PROJECTS_COLUMNS = {
        "id", "name", "model_year", "model", "engine", "output_dir",
        "baseline_trim_mae", "baseline_trim_median", "stage3_candidate_applied",
        "created_by", "created_at", "updated_at",
    }

    def __init__(self, path: Path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.legacy_backup = self._backup_incompatible_database(path)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()
        if self.legacy_backup is not None:
            self._import_legacy_core(self.legacy_backup)
        self._ensure_default_admin()
        RESOURCES.register(self.close)

    @classmethod
    def _table_columns(cls, conn: sqlite3.Connection, table: str):
        try:
            return {str(r[1]) for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        except sqlite3.DatabaseError:
            return set()

    @classmethod
    def _backup_incompatible_database(cls, path: Path) -> Optional[Path]:
        if not path.exists() or path.stat().st_size == 0:
            return None
        probe = sqlite3.connect(path)
        try:
            tables = {r[0] for r in probe.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            users_cols = cls._table_columns(probe, "users") if "users" in tables else set()
            projects_cols = cls._table_columns(probe, "projects") if "projects" in tables else set()
            incompatible = (
                (users_cols and not cls.USERS_COLUMNS.issubset(users_cols)) or
                (projects_cols and not cls.PROJECTS_COLUMNS.issubset(projects_cols))
            )
            if not incompatible:
                return None

            # Checkpoint any WAL content before taking the backup.  Failure is
            # non-fatal because sqlite3.Connection.backup still produces a
            # transactionally consistent copy of the connection's view.
            try:
                probe.execute("PRAGMA wal_checkpoint(FULL)")
            except sqlite3.DatabaseError:
                pass

            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup = path.with_name(f"{path.stem}_pre_migration_{stamp}.db")
            n = 1
            while backup.exists():
                backup = path.with_name(f"{path.stem}_pre_migration_{stamp}_{n}.db")
                n += 1
            dest = sqlite3.connect(backup)
            try:
                probe.backup(dest)
                dest.commit()
            finally:
                dest.close()
        finally:
            probe.close()

        # Start with a clean current-format database.  The complete original
        # remains in ``backup`` for manual recovery if a legacy field could not
        # be mapped automatically.
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        for suffix in ("-wal", "-shm"):
            sidecar = Path(str(path) + suffix)
            try:
                sidecar.unlink()
            except FileNotFoundError:
                pass
        return backup

    @staticmethod
    def _legacy_value(row: sqlite3.Row, *names, default=None):
        lookup = {str(k).lower(): k for k in row.keys()}
        for name in names:
            key = lookup.get(str(name).lower())
            if key is not None:
                value = row[key]
                if value is not None:
                    return value
        return default

    def _import_legacy_core(self, backup: Path):
        legacy = sqlite3.connect(backup)
        legacy.row_factory = sqlite3.Row
        try:
            tables = {r[0] for r in legacy.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "users" in tables:
                for row in legacy.execute("SELECT * FROM users"):
                    username = str(self._legacy_value(
                        row, "username_display", "username_norm", "username", "user_name", "user", default=""
                    ) or "").strip()
                    if not username:
                        continue
                    role = str(self._legacy_value(row, "role", "user_type", "type", default="user") or "user").lower()
                    if role not in ROLES:
                        role = "user"
                    first = str(self._legacy_value(row, "first_name", "firstname", "first", default="Migrated") or "Migrated").strip()
                    last = str(self._legacy_value(row, "last_name", "lastname", "last", default="User") or "User").strip()
                    salt = self._legacy_value(row, "salt")
                    digest = self._legacy_value(row, "password_hash", "hash")
                    active = int(bool(self._legacy_value(row, "active", "enabled", default=1)))
                    if not (salt and digest):
                        plain = self._legacy_value(row, "password", "passwd", "pass")
                        if plain is not None:
                            salt, digest = _hash_password(str(plain))
                        elif username.lower() == "admin":
                            salt, digest = _hash_password("admin")
                            role = "admin"
                            active = 1
                        else:
                            # Preserve the account record but require an admin
                            # to set a new password before it can authenticate.
                            salt, digest = _hash_password(secrets.token_hex(24))
                            active = 0
                    self.conn.execute(
                        """INSERT OR IGNORE INTO users
                        (username_norm,username_display,salt,password_hash,role,first_name,last_name,
                         address,city,state,zip,phone,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (username.lower(), username, str(salt), str(digest), role, first or "Migrated", last or "User",
                         str(self._legacy_value(row, "address", default="") or ""),
                         str(self._legacy_value(row, "city", default="") or ""),
                         str(self._legacy_value(row, "state", default="") or ""),
                         str(self._legacy_value(row, "zip", "zipcode", "postal_code", default="") or ""),
                         str(self._legacy_value(row, "phone", "telephone", default="") or ""), active),
                    )

            if "projects" in tables:
                for row in legacy.execute("SELECT * FROM projects"):
                    year = self._legacy_value(row, "model_year", "year")
                    model = str(self._legacy_value(row, "model", "vehicle_model", default="") or "").strip()
                    engine = str(self._legacy_value(row, "engine", "engine_size", default="") or "").strip()
                    if not (year and model and engine):
                        continue
                    try:
                        year = int(year)
                    except (TypeError, ValueError):
                        continue
                    name = str(self._legacy_value(row, "name", "project_name", default=f"{year} {model} {engine}") or f"{year} {model} {engine}")
                    output_dir = str(self._legacy_value(row, "output_dir", "project_dir", "path", default=self.path.parent / "projects" / name) or "")
                    self.conn.execute(
                        """INSERT OR IGNORE INTO projects
                        (name,model_year,model,engine,output_dir,baseline_trim_mae,baseline_trim_median,stage3_candidate_applied,created_by)
                        VALUES(?,?,?,?,?,?,?,?,NULL)""",
                        (name, year, model, engine, output_dir,
                         self._legacy_value(row, "baseline_trim_mae"),
                         self._legacy_value(row, "baseline_trim_median"),
                         int(bool(self._legacy_value(row, "stage3_candidate_applied", "candidate_applied", default=0)))),
                    )
            self.conn.commit()
        finally:
            legacy.close()

    def close(self):
        if self.conn is not None:
            try:
                self.conn.commit()
                self.conn.close()
            finally:
                self.conn = None

    def _init_schema(self):
        self.conn.executescript(
            """
            PRAGMA foreign_keys=ON;
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username_norm TEXT NOT NULL UNIQUE,
                username_display TEXT NOT NULL,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin','user','guest')),
                first_name TEXT NOT NULL,
                last_name TEXT NOT NULL,
                address TEXT DEFAULT '',
                city TEXT DEFAULT '',
                state TEXT DEFAULT '',
                zip TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                model_year INTEGER NOT NULL,
                model TEXT NOT NULL,
                engine TEXT NOT NULL,
                output_dir TEXT NOT NULL,
                baseline_trim_mae REAL,
                baseline_trim_median REAL,
                stage3_candidate_applied INTEGER NOT NULL DEFAULT 0,
                created_by INTEGER,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            """
        )
        self.conn.commit()

    def _ensure_default_admin(self):
        row = self.conn.execute("SELECT id FROM users WHERE username_norm='admin'").fetchone()
        if row:
            return
        salt, digest = _hash_password("admin")
        self.conn.execute(
            """INSERT INTO users
            (username_norm, username_display, salt, password_hash, role, first_name, last_name)
            VALUES ('admin','admin',?,?, 'admin','System','Administrator')""",
            (salt, digest),
        )
        self.conn.commit()

    def authenticate(self, username: str, password: str) -> Optional[User]:
        row = self.conn.execute(
            "SELECT * FROM users WHERE username_norm=? AND active=1", (username.strip().lower(),)
        ).fetchone()
        if not row or not _verify_password(password, row["salt"], row["password_hash"]):
            return None
        return User(row["id"], row["username_display"], row["role"], row["first_name"], row["last_name"])

    def list_users(self):
        return self.conn.execute(
            "SELECT id, username_display, role, first_name, last_name, active FROM users ORDER BY username_norm"
        ).fetchall()

    def get_user(self, user_id: int):
        return self.conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()

    def save_user(self, *, user_id: Optional[int], username: str, password: Optional[str], role: str,
                  first_name: str, last_name: str, address: str = "", city: str = "", state: str = "",
                  zip_code: str = "", phone: str = "", active: bool = True):
        username = username.strip()
        if not username or not first_name.strip() or not last_name.strip():
            raise ValueError("First Name, Last Name, and User Name are mandatory.")
        if role not in ROLES:
            raise ValueError("Invalid role.")
        if user_id is None:
            if not password:
                raise ValueError("Password is mandatory for a new user.")
            salt, digest = _hash_password(password)
            self.conn.execute(
                """INSERT INTO users
                (username_norm, username_display, salt, password_hash, role, first_name, last_name,
                 address, city, state, zip, phone, active)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (username.lower(), username, salt, digest, role, first_name.strip(), last_name.strip(),
                 address.strip(), city.strip(), state.strip(), zip_code.strip(), phone.strip(), int(active)),
            )
        else:
            existing = self.get_user(user_id)
            if not existing:
                raise ValueError("User not found.")
            if existing["username_norm"] == "admin" and role != "admin":
                raise ValueError("The default admin account must retain admin privileges.")
            if password:
                salt, digest = _hash_password(password)
                self.conn.execute(
                    """UPDATE users SET username_norm=?, username_display=?, salt=?, password_hash=?, role=?,
                    first_name=?, last_name=?, address=?, city=?, state=?, zip=?, phone=?, active=?,
                    updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (username.lower(), username, salt, digest, role, first_name.strip(), last_name.strip(),
                     address.strip(), city.strip(), state.strip(), zip_code.strip(), phone.strip(), int(active), user_id),
                )
            else:
                self.conn.execute(
                    """UPDATE users SET username_norm=?, username_display=?, role=?, first_name=?, last_name=?,
                    address=?, city=?, state=?, zip=?, phone=?, active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?""",
                    (username.lower(), username, role, first_name.strip(), last_name.strip(), address.strip(), city.strip(),
                     state.strip(), zip_code.strip(), phone.strip(), int(active), user_id),
                )
        self.conn.commit()

    def delete_user(self, user_id: int):
        row = self.get_user(user_id)
        if not row:
            return
        if row["username_norm"] == "admin":
            raise ValueError("The default admin account cannot be deleted.")
        self.conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        self.conn.commit()

    def create_project(self, model_year: int, model: str, engine: str, output_dir: str, created_by: int) -> Project:
        model = model.strip(); engine = engine.strip()
        if not model or not engine:
            raise ValueError("Model and engine are required.")
        name = f"{model_year} {model} {engine}"
        self.conn.execute(
            "INSERT INTO projects(name,model_year,model,engine,output_dir,created_by) VALUES(?,?,?,?,?,?)",
            (name, int(model_year), model, engine, output_dir, created_by),
        )
        self.conn.commit()
        return self.get_project_by_name(name)

    def list_projects(self):
        return self.conn.execute("SELECT * FROM projects ORDER BY updated_at DESC, name").fetchall()

    def get_project(self, project_id: int) -> Project:
        row = self.conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
        return self._row_to_project(row) if row else None

    def get_project_by_name(self, name: str) -> Project:
        row = self.conn.execute("SELECT * FROM projects WHERE name=?", (name,)).fetchone()
        return self._row_to_project(row) if row else None

    def _row_to_project(self, row) -> Project:
        return Project(
            row["id"], row["name"], row["model_year"], row["model"], row["engine"], row["output_dir"],
            row["baseline_trim_mae"], row["baseline_trim_median"], bool(row["stage3_candidate_applied"])
        )

    def update_baseline(self, project_id: int, mae: float, median: float):
        self.conn.execute(
            "UPDATE projects SET baseline_trim_mae=?, baseline_trim_median=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (float(mae), float(median), project_id),
        )
        self.conn.commit()

    def mark_candidate_applied(self, project_id: int, applied: bool = True):
        self.conn.execute(
            "UPDATE projects SET stage3_candidate_applied=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (int(applied), project_id),
        )
        self.conn.commit()

