#!/usr/bin/env python3
"""Read and write the *observed* HP Tuners HPT R v3 template container.

This module implements the exact container grammar confirmed byte-for-byte
against multiple VCM Editor-generated full-engine and partial-template files.
It is intentionally limited to this observed format. An unknown revision,
truncated section, duplicate parameter ID, unsupported flags or trailing
bytes is an error, not a reason to guess record boundaries.

This file is a container codec, not the VE or fuel-trim processor. It does not
make claims about VCM Editor's private compatibility requirements.
"""
from __future__ import annotations

from dataclasses import dataclass
import struct
from typing import Literal

Kind = Literal["switch", "scalar", "table"]
HEADER = b"HPT R\x03" + b"\x00" * 14
FOOTER = b"\x00" * 6
KINDS: tuple[Kind, ...] = ("switch", "scalar", "table")


@dataclass(frozen=True)
class HTTRecord:
    kind: Kind
    key: int
    raw: bytes  # exactly key + flags + encoded content; table includes 2-byte suffix


@dataclass(frozen=True)
class HTTDocument:
    header: bytes
    switches: tuple[HTTRecord, ...]
    scalars: tuple[HTTRecord, ...]
    tables: tuple[HTTRecord, ...]
    footer: bytes

    def group(self, kind: Kind) -> tuple[HTTRecord, ...]:
        return {"switch": self.switches, "scalar": self.scalars, "table": self.tables}[kind]

    def by_key(self) -> dict[int, HTTRecord]:
        return {r.key: r for kind in KINDS for r in self.group(kind)}


class UnsupportedHTTFormat(ValueError):
    """Unrecognized or malformed .htt container; never emit a partial import."""


def _read_varint(blob: bytes, pos: int) -> tuple[int, int]:
    value = 0
    for i in range(5):
        if pos >= len(blob):
            raise UnsupportedHTTFormat("Truncated .htt table/switch length")
        c = blob[pos]
        pos += 1
        value |= (c & 0x7f) << (7*i)
        if not (c & 0x80):
            if i > 0 and value < (1 << (7 * i)):
                raise UnsupportedHTTFormat("Noncanonical .htt record length")
            return value, pos
    raise UnsupportedHTTFormat("Unsupported .htt length encoding")


def parse_htt(blob: bytes) -> HTTDocument:
    if len(blob) < len(HEADER) + len(FOOTER) + 6 or blob[:20] != HEADER:
        raise UnsupportedHTTFormat("Unsupported HP Tuners .htt header or format revision")
    offset = 20
    sections: dict[str, tuple[HTTRecord, ...]] = {}
    all_ids: set[int] = set()
    for kind in KINDS:
        if offset + 2 > len(blob):
            raise UnsupportedHTTFormat(f"Truncated .htt {kind} count")
        count = struct.unpack_from('<H', blob, offset)[0]
        offset += 2
        rows = []
        for _ in range(count):
            start = offset
            if offset + 4 > len(blob):
                raise UnsupportedHTTFormat(f"Truncated .htt {kind} record header")
            key, flags = struct.unpack_from('<HH', blob, offset)
            offset += 4
            if flags != 0:
                raise UnsupportedHTTFormat(f"Unsupported {kind} flags for record {key}")
            if key in all_ids:
                raise UnsupportedHTTFormat(f"Duplicate .htt record ID {key}")
            all_ids.add(key)
            if kind == "scalar":
                # Little-endian float64 + one scalar metadata/type byte.
                offset += 9
                if offset > len(blob):
                    raise UnsupportedHTTFormat(f"Truncated .htt scalar {key}")
            else:
                length, offset = _read_varint(blob, offset)
                offset += length
                if offset > len(blob):
                    raise UnsupportedHTTFormat(f"Truncated .htt {kind} payload for {key}")
                if kind == "table":
                    if blob[offset:offset+2] != b"\x00\x00":
                        raise UnsupportedHTTFormat(f"Missing .htt table record terminator for {key}")
                    offset += 2
            rows.append(HTTRecord(kind=kind, key=key, raw=blob[start:offset]))
        sections[kind] = tuple(rows)
    if blob[offset:] != FOOTER:
        raise UnsupportedHTTFormat("Unsupported trailing data after the .htt table section")
    return HTTDocument(header=blob[:20], switches=sections["switch"],
                       scalars=sections["scalar"], tables=sections["table"],
                       footer=blob[offset:])


def build_htt(doc: HTTDocument, selected_keys: set[int] | None = None) -> bytes:
    """Encode a byte-identical full document or grouped selected-record subset."""
    if doc.header != HEADER or doc.footer != FOOTER:
        raise UnsupportedHTTFormat("Unsupported .htt document framing")
    all_keys = set(doc.by_key())
    selected = all_keys if selected_keys is None else set(selected_keys)
    if not selected.issubset(all_keys):
        raise ValueError(f"Unknown .htt record IDs: {sorted(selected - all_keys)}")
    output = bytearray(doc.header)
    for kind in KINDS:
        chosen = [rec for rec in doc.group(kind) if rec.key in selected]
        if len(chosen) > 65535:
            raise UnsupportedHTTFormat("Too many .htt records in section")
        output.extend(struct.pack('<H', len(chosen)))
        for rec in chosen:
            output.extend(rec.raw)
    output.extend(doc.footer)
    result = bytes(output)
    check = parse_htt(result)
    if set(check.by_key()) != selected:
        raise AssertionError("Encoded .htt record selection did not round-trip")
    return result
