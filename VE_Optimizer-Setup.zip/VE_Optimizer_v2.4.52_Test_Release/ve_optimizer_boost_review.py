"""Read-only, method-independent HPL/HTT boost and WOT calibration review.

Never infers hardware identity from MAP > Baro, never changes a tune, and
never selects a target WOT AFR without the operator's approval.
"""
from __future__ import annotations

import bisect
import math
from pathlib import Path
from typing import Optional

from hpl_decoder_v1_0_0 import decode_hpl
from ve_optimizer_logcheck import convert_value
import ve_optimizer_wideband as wb

HELLCAT_2BAR = {
    'map_sensor_linear_kpa_per_v':45.42,
    'map_offset_kpa':7.0,
    'map_sensor_offset_v':0.1001,
}


def _channel_candidates(channels, predicate):
    return [(i, c) for i,c in channels.items() if predicate(str(c.get('name','')).lower())]


def _pressure_channel(c):
    try:
        convert_value('map',str(c.get('unit','')),100.0)
        return True
    except (ValueError, TypeError):
        return False


def _as_kpa(c,value):
    try:
        if not isinstance(value,(int,float)):return None
        v=convert_value('map',str(c.get('unit','')),float(value))
        return v if math.isfinite(v) else None
    except (TypeError,ValueError):return None


def _latest(times,values,t):
    k=bisect.bisect_right(times,t)-1
    return values[k] if k>=0 else None


def _knock_summary(decoded):
    channels=decoded['channels']
    keys={
        'short_term': ('knock retard short term','short term knock retard'),
        'long_term': ('knock retard long term','long term knock retard'),
        'total': ('total knock retard','knock retard total'),
    }
    result={}
    for key,aliases in keys.items():
        candidates=_channel_candidates(channels,lambda n:any(a in n for a in aliases))
        if not candidates:
            result[key]={'present':False,'updates':0,'max':None,'min':None}
            continue
        index,c=candidates[0]
        times,vals=wb._history(decoded,index)
        numeric=[float(v) for v in vals if isinstance(v,(int,float)) and math.isfinite(float(v))]
        result[key]={'present':bool(numeric),'updates':len(numeric),
                     'max':max(numeric) if numeric else None,
                     'min':min(numeric) if numeric else None,
                     'unit':c.get('unit',''),'channel':c.get('name','')}
    result['primary_wot_indicator']='short_term'
    result['short_term_target_deg']=0.0
    return result


def _tune_characteristics(tune):
    sensors={}
    for label,slope,offset,voltage in (
        ('MAP1',wb.MAP1_LINEAR_SCALAR,wb.MAP1_OFFSET_KPA_SCALAR,wb.MAP1_OFFSET_V_SCALAR),
        ('MAP2',wb.MAP2_LINEAR_SCALAR,wb.MAP2_OFFSET_KPA_SCALAR,wb.MAP2_OFFSET_V_SCALAR),
    ):
        sensors[label]={
            'map_sensor_linear_kpa_per_v':wb._read_optional_scalar(tune,slope),
            'map_offset_kpa':wb._read_optional_scalar(tune,offset),
            'map_sensor_offset_v':wb._read_optional_scalar(tune,voltage),
            'record_ids':(slope,offset,voltage),
        }
    try:sensed=wb.read_switch(tune,wb.SENSED_MAP_ENABLE_SWITCH)
    except (KeyError,ValueError):sensed=None
    pe=wb._pe_table_axis_status(tune)
    return {'sensed_map_switch':sensed,'map_sensors':sensors,
            'pe_switch':pe.get('value'), 'pe_switch_present':pe.get('present',False),
            'pe_record_id':wb.PE_TABLE_SELECT_SWITCH}


def inspect(tune_file,log_file,method):
    """Return verified recorded evidence and tune fields; no calibration writes."""
    if method not in ('neural_network','speed_density'):
        raise ValueError('Unknown optimization method')
    tune_file=Path(tune_file);log_file=Path(log_file)
    if log_file.suffix.lower() != '.hpl':raise ValueError('Native .hpl Log File required')
    decoded=decode_hpl(log_file)
    channels=decoded['channels']
    from ve_optimizer_map_sources import select_hpl_map
    selected = select_hpl_map(decoded, boost_pratio_threshold=wb.BOOST_PRATIO_THRESHOLD)
    primary = selected.get('source')
    alternates = selected.get('alternatives') or []
    voltage_candidates=_channel_candidates(channels,lambda n:'manifold absolute pressure sensor voltage' in n or 'map sensor voltage' in n)
    return {
        'method':method,'map_source':primary,'alternative_map_sources':alternates,
        'baro_source':selected.get('baro_source'),
        'map_source_valid':bool(selected['valid']),
        'map_source_error':selected.get('reason'),
        # Raw MAP > Baro remains a separate, strict NA missing-knock gate.
        'pressure_exceeds_baro':bool(primary and primary['exceeds_baro']>0),
        # Hardware review instead follows the accepted boost preflight rule.
        'boost_review_required':bool(primary and primary.get('boost_pratio_hits',0)>=wb.BOOST_MIN_PE_SAMPLES),
        'boost_review_pratio_threshold':wb.BOOST_PRATIO_THRESHOLD,
        'boost_review_min_samples':wb.BOOST_MIN_PE_SAMPLES,
        'sensor_voltage_channels':[c.get('name','') for _,c in voltage_candidates],
        'tune':_tune_characteristics(tune_file),
        'knock_retard':_knock_summary(decoded),
        'two_bar_hellcat_reference':dict(HELLCAT_2BAR),
    }


def estimate_map_from_voltage(log_file, preferred_map_name=None, existing_voltage_offset=None):
    """Estimate pressure transfer slope/offset from concurrent voltage+MAP readings.

    A pressure/voltage regression only identifies slope and intercept.
    A user-supplied reference voltage offset is required to distinguish
    pressure offset from voltage offset.  No guess is made for that offset.
    """
    from statistics import fmean
    decoded=decode_hpl(Path(log_file));chs=decoded['channels']
    voltages=_channel_candidates(chs,lambda n:'manifold absolute pressure sensor voltage' in n or 'map sensor voltage' in n)
    from ve_optimizer_map_sources import eligible_map_indices
    maps=[(i,chs[i]) for i in eligible_map_indices(chs) if _pressure_channel(chs[i])]
    if preferred_map_name:
        maps=[p for p in maps if p[1].get('name')==preferred_map_name]
    if not voltages or not maps:
        return {'possible':False,'reason':'A matching logged MAP pressure channel and MAP sensor voltage channel are required.'}
    if existing_voltage_offset is None:
        return {'possible':False,'reason':'A verified voltage offset is required; slope and both offsets cannot be uniquely solved from pressure/voltage readings alone.'}
    vi,vc=voltages[0];pi,pc=maps[0]
    vt,vv=wb._history(decoded,vi);pt,pv=wb._history(decoded,pi)
    pairs=[]
    for t,p in zip(pt,pv):
        pressure=_as_kpa(pc,p);v=_latest(vt,vv,t)
        if pressure is not None and isinstance(v,(int,float)) and math.isfinite(float(v)) and 0<=float(v)<=5.0:
            pairs.append((float(v),pressure))
    if len(pairs)<2:return {'possible':False,'reason':'Too few concurrent voltage/pressure observations.'}
    mx=fmean(x for x,_ in pairs);my=fmean(y for _,y in pairs)
    variance=sum((x-mx)**2 for x,_ in pairs)
    if variance<1e-9:return {'possible':False,'reason':'Insufficient MAP sensor voltage variation for a calibration estimate.'}
    slope=sum((x-mx)*(y-my) for x,y in pairs)/variance
    if slope<=0:return {'possible':False,'reason':'Logged voltage/pressure values do not support a positive MAP calibration slope.'}
    intercept=my-slope*mx
    offset_kpa=intercept+slope*float(existing_voltage_offset)
    mse=fmean((y-(slope*x+intercept))**2 for x,y in pairs)
    return {'possible':True,'samples':len(pairs),'map_sensor_linear_kpa_per_v':slope,
            'map_offset_kpa':offset_kpa,'map_sensor_offset_v':float(existing_voltage_offset),
            'rms_residual_kpa':math.sqrt(mse),'requires_user_approval':True,
            'note':'Estimate depends on logged MAP pressure accuracy and the pre-existing voltage offset.'}


def na_closed_loop_evidence(tune_file, log_file, method):
    """Check recorded MAP/Baro before asking the operator to confirm NA hardware.

    No positive MAP/Baro event is NOT proof of NA; the Yes button supplies
    explicit hardware confirmation. Missing pressure evidence never qualifies.
    """
    review = inspect(tune_file, log_file, method)
    selected = review.get('map_source') or {}
    valid = bool(selected.get('compared', 0) > 0 and not review.get('pressure_exceeds_baro'))
    return valid, review
