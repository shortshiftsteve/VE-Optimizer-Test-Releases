"""Regression for removal of automatic PE calibration from v2.4.4."""
from pathlib import Path
import inspect
import struct
import numpy as np
import pytest

import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as wi
import ve_optimizer_revision9_review as app
from ve_optimizer_htt_codec import HTTDocument, HTTRecord, HEADER, FOOTER, build_htt, parse_htt


def _status(boosted=True, peak=1.65):
    return {"valid":True,"boosted_detected":boosted,
            "observed_pratio_max":peak,"dual_gate_samples":10,
            "reason":None}


def _pe_preflight(monkeypatch, *, method='Aircharge', axis_max=1.5, boosted=True):
    monkeypatch.setattr(wb,'_pe_operating_pratio_status',lambda _: _status(boosted))
    monkeypatch.setattr(wb,'_pe_table_axis_status',lambda _: {
        'value':method,'present':True,'valid':True,'detection_source':'switch','warning':None})
    monkeypatch.setattr(wb,'parse_numeric_2d_table',lambda path,key: {
        'x_axis':np.linspace(500,6000,17),'y_axis':np.linspace(.25,axis_max,17),
        'z':np.zeros((17,17))})
    return wb.pe_strategy_preflight(Path('none.hpl'), Path('none.htt'))


def test_automatic_pe_writer_fails_closed_without_creating_output(tmp_path):
    output=tmp_path/'never_written.htt'
    with pytest.raises(RuntimeError,match='removed'):
        wb.prepare_pe_strategy(tmp_path/'log.hpl',tmp_path/'stock.htt',output)
    assert not output.exists()
    assert not hasattr(wi,'_prepare_pe_if_needed')


def test_boosted_pe_aircharge_and_inadequate_axis_require_manual_review(monkeypatch):
    pf=_pe_preflight(monkeypatch,method='Aircharge',axis_max=1.5)
    assert pf['blocking'] and pf['manual_review_required']
    assert pf['switch_change_required'] and pf['pratio_rescale_required']
    assert pf['automatic_change_allowed'] is False
    assert pf['calibration_write_enabled'] is False
    assert pf['proposed_pratio_axis'].size==0
    assert pf['recommended_pratio_table_max'] is None
    assert 'manually' in ' '.join(pf['issues'])


def test_boosted_stored_pratio_axis_insufficient_blocks_even_without_switch_change(monkeypatch):
    pf=_pe_preflight(monkeypatch,method='PRatio',axis_max=1.4)
    assert pf['blocking'] and pf['manual_review_required']
    assert not pf['switch_change_required']
    assert pf['pratio_rescale_required']


def test_pe_storage_matching_boost_axis_does_not_claim_fueling_accuracy(monkeypatch):
    pf=_pe_preflight(monkeypatch,method='PRatio',axis_max=1.8)
    assert not pf['blocking']
    assert not pf['manual_review_required']
    assert 'DOES NOT verify' in pf['message']
    assert pf['automatic_change_allowed'] is False


def test_na_pe_preflight_is_read_only_even_with_aircharge(monkeypatch):
    pf=_pe_preflight(monkeypatch,method='Aircharge',axis_max=1.1,boosted=False)
    assert not pf['blocking']
    assert not pf['manual_review_required']
    assert not pf['switch_change_required']
    assert pf['automatic_change_allowed'] is False


def test_incompatible_pe_does_not_block_ve_correction_sources(monkeypatch,tmp_path):
    import ve_optimizer_boost_review
    monkeypatch.setattr(wb,'detect_configuration',lambda p:{'airflow_model':'speed_density'})
    monkeypatch.setattr(wb,'inspect_correction_sources',lambda *a,**k:{
        'adaptive':{'valid':True},'wideband':{'valid':False},
        'choices':[{'id':'adaptive','enabled':True},{'id':'wideband','enabled':True}]})
    monkeypatch.setattr(wb,'airflow_map_preflight',lambda *a:{'blocking':False})
    monkeypatch.setattr(wb,'speed_density_axis_preflight',lambda *a:{'needs_rescale':False,'blocking':False,'message':'Mock calibrated axes valid'})
    monkeypatch.setattr(wb,'pe_strategy_preflight',lambda *a:{
        'blocking':True,'manual_review_required':True,'message':'Manual PE calibration required',
        'issues':['Incompatible PE axis']})
    monkeypatch.setattr(ve_optimizer_boost_review,'inspect',lambda *a:{'boost_review_required':False})
    pf=wb.build_correction_preflight(tmp_path/'none.hpl',tmp_path/'none.htt')
    assert pf['pe_preparation_required'] is False
    assert pf['pe_manual_review_required'] is False
    assert pf['choices'][0]['enabled'] is True  # qualified STFT retained
    assert pf['choices'][1]['enabled'] is False  # no usable wideband measurements
    assert not hasattr(wi,'_pe_safety_error')


def _example_doc(key,kind,payload):
    raw=struct.pack('<HH',key,0)+bytes([len(payload)])+payload+(b'\0\0' if kind=='table' else b'')
    rec=HTTRecord(kind,key,raw)
    return HTTDocument(HEADER,(rec,) if kind=='switch' else (),(),(rec,) if kind=='table' else (),FOOTER)


@pytest.mark.parametrize('key,kind',[ (wb.PE_TABLE_SELECT_SWITCH,'switch'),(wb.PE_PRATIO_TABLE,'table'),(wb.PE_AIRCHARGE_TABLE,'table') ])
def test_selective_export_rejects_all_pe_mutations(tmp_path,key,kind):
    before=_example_doc(key,kind,b'Aircharge')
    after=_example_doc(key,kind,b'PRatio')
    base=tmp_path/'baseline.htt';candidate=tmp_path/'candidate.htt';out=tmp_path/'result.htt'
    base.write_bytes(build_htt(before));candidate.write_bytes(build_htt(after))
    with pytest.raises(ValueError,match='unrelated'):
        wb.export_speed_density_changed_tables(base,candidate,out)
    assert not out.exists()


def test_no_pe_results_controls_or_automatic_pe_call():
    viewer=inspect.getsource(app.ReviewApp._build_surface_viewer)
    assert "('pe','PE')" not in viewer
    assert 'surface_pe_picker=ttk.Combobox' not in viewer
    assert not hasattr(app.ReviewApp,'_surface_pe_dataset')
    assert 'prepare_pe_strategy' not in inspect.getsource(wi.build_wideband_preview)
    assert 'prepare_pe_strategy' not in inspect.getsource(wi.build_adaptive_speed_density_preview)
    assert 'prepare_pe_strategy' not in inspect.getsource(wi.build_combined_preview)


def test_hidden_pe_mode_falls_back_to_ve_without_display():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj._results_airflow_model=lambda:'neural_network'
    obj.surface_format=type('Var',(),{'set':lambda self,value:setattr(self,'value',value)})()
    obj._refresh_surface_widgets=lambda:None
    obj._set_surface_format('pe')
    assert obj.surface_format.value=='neural_network'


@pytest.mark.parametrize('builder,mode',[
    (wi.build_wideband_preview,'neural_network'),
    (wi.build_adaptive_speed_density_preview,'speed_density'),
    (wi.build_combined_preview,'speed_density'),
])
def test_all_preview_paths_continue_past_pe_calibration_checks(monkeypatch,tmp_path,builder,mode):
    preflight={
        'configuration':{'airflow_model':mode},
        'airflow_map_preflight':{'blocking':False},
        'pe_preflight':{'blocking':True,'issues':['Boosted PE strategy requires manual correction']},
        'sources':{'wideband':{'processor_ready':True},'adaptive':{'valid':True}},
    }
    monkeypatch.setattr(wi.wb,'build_correction_preflight',lambda *args,**kwargs:preflight)
    def next_stage(*args,**kwargs):
        raise RuntimeError('NEXT_STAGE_REACHED')
    monkeypatch.setattr(wi,'_prepare_airflow_if_needed',next_stage)
    output_dir=tmp_path/'preview'
    with pytest.raises(RuntimeError,match='NEXT_STAGE_REACHED'):
        builder(tmp_path/'missing.htt',tmp_path/'missing.hpl',output_dir)
    assert not list(output_dir.glob('*.htt'))
