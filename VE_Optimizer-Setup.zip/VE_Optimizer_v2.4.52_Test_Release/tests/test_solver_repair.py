"""Numerical-failure regression tests; never writes a usable tune on failure."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
import copy,inspect,json,tempfile,sys,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from scipy.optimize import OptimizeResult
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import ve_optimizer_processing as p
import ve_optimizer_revision9_review as app


def fake_result(x, success=True, status=0, message='test injection', value=0.):
    return OptimizeResult(x=np.asarray(x).copy(), success=success, status=status,
                          message=message, fun=value, nit=1, nfev=1)

class SolverRepairTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference=json.loads((ROOT/'tests/fixtures/reference_solver_repair1.json').read_text())
        # Keep the numerical fixture but stamp it with the current verification IDs
        # so non-version-specific rejection tests exercise the intended condition.
        cls.reference['method_id']=p.METHOD_ID
        cls.reference['optimizer']['solver_revision']=p.SOLVER_REVISION
        cls.reference['verification']['solver_revision']=p.SOLVER_REVISION
        cls.reference['metrics']['method_id']=p.METHOD_ID
        cls.reference['metrics']['fit_verification']['solver_revision']=p.SOLVER_REVISION
        cls.net=p.htt.load_network(ROOT/'tests/fixtures/stock.htt')
        cls.p0=p.coefficients(cls.net);cls.model=p.FrozenModel(p.config(cls.net))
        cls.rows=copy.deepcopy(cls.reference['rows'])
        cls.x=cls.model.normalize(np.array([[r['intake'],r['exhaust'],r['rpm'],r['pratio']] for r in cls.rows]))

    def test_scaling_is_algebraically_equivalent(self):
        x=np.array([.4,-.2]);s=self.model.scale;rawtol=1e-9
        def fun(q):return float(np.sum(q*q)),2*q
        c=lambda q:q+2.;j=lambda q:np.eye(2)
        def examine(f,start,**kw):
            for q in [x,np.array([.8,-.9]),np.zeros(2)]:
                a,g=f(q);b,h=fun(q)
                np.testing.assert_allclose(a*s,b,rtol=1e-15,atol=1e-15)
                np.testing.assert_allclose(g*s,h,rtol=1e-15,atol=1e-15)
                np.testing.assert_allclose(kw['constraints'][0]['fun'](q)*s,c(q))
                np.testing.assert_allclose(kw['constraints'][0]['jac'](q)*s,j(q))
            self.assertEqual(kw['options']['ftol'],rawtol/s)
            self.assertNotIn('bounds',kw)
            return fake_result(start,value=f(start)[0])
        with patch.object(p,'minimize',side_effect=examine):
            _,r=p._constrained_solve(fun,x,c,j,s,1000,rawtol)
        self.assertTrue(r['success']);self.assertFalse(r['elapsed_time_affects_selection'])

    def test_failed_constrained_status_is_never_promoted(self):
        for status in [4,8,9]:
            with self.subTest(status=status),patch.object(p,'minimize',return_value=fake_result(np.zeros(2),False,status)):
                with self.assertRaises(p.FitConvergenceError) as cm:
                    p._constrained_solve(lambda q:(0.,q),np.zeros(2),lambda q:np.ones(2),lambda q:np.eye(2),50.,1000,1e-9)
                self.assertEqual(cm.exception.details['status'],status)

    def test_full_iteration_limit_with_numerically_feasible_constraints_continues_to_exact_checks(self):
        start=np.zeros(2);scale=50.;rawtol=1e-9
        result=OptimizeResult(x=start.copy(),success=False,status=9,message='Iteration limit reached',fun=0.,nit=1000,nfev=1001)
        with patch.object(p,'minimize',return_value=result):
            _,info=p._constrained_solve(lambda q:(0.,q),start,lambda q:np.array([-2e-8,1.]),lambda q:np.eye(2),scale,1000,rawtol)
        self.assertTrue(info['feasible_iteration_limit']);self.assertEqual(info['status'],9)

    def test_success_flag_with_nan_is_rejected(self):
        with patch.object(p,'minimize',return_value=fake_result([np.nan,0])):
            with self.assertRaises(p.FitConvergenceError):
                p._constrained_solve(lambda q:(0.,q),np.zeros(2),lambda q:np.ones(2),lambda q:np.eye(2),50.,1000,1e-9)

    def test_success_flag_with_infeasible_point_is_rejected(self):
        with patch.object(p,'minimize',return_value=fake_result(np.zeros(2))):
            with self.assertRaises(p.FitConvergenceError):
                p._constrained_solve(lambda q:(0.,q),np.zeros(2),lambda q:np.array([-1.,0.]),lambda q:np.eye(2),50.,1000,1e-9)

    def test_invalid_scale_is_rejected(self):
        for scale in [0.,-1.,float('nan')]:
            with self.subTest(scale=scale),self.assertRaises(ValueError):
                p._constrained_solve(lambda q:(0.,q),np.zeros(2),lambda q:np.ones(2),lambda q:np.eye(2),scale,1000,1e-9)

    def test_initial_failure_removes_stale_output_and_stops(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)
            for name in ('Candidate_FullEngine.htt','Processing_Result.json'):(out/name).write_text('old output')
            with patch.object(p,'prepare_samples',return_value=([],{})),patch.object(p,'make_targets',return_value=(copy.deepcopy(self.rows),self.model,self.p0,self.x)),patch.object(p,'minimize',return_value=fake_result(self.p0,False,9)) as solver:
                with self.assertRaises(p.FitConvergenceError):p.run('not-read',ROOT/'tests/fixtures/stock.htt',out)
            self.assertEqual(solver.call_count,1)
            self.assertFalse((out/'Candidate_FullEngine.htt').exists())
            self.assertFalse((out/'Processing_Result.json').exists())
            failure=json.loads((out/'Fit_Failure.json').read_text())
            self.assertFalse(failure['approved']);self.assertEqual(failure['details']['status'],9)

    def test_slsqp_failure_stops_before_any_export(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)
            def injected(fun,start,**kw):
                return fake_result(start,kw['method']=='L-BFGS-B',0 if kw['method']=='L-BFGS-B' else 8,value=fun(start)[0])
            with patch.object(p,'prepare_samples',return_value=([],{})),patch.object(p,'make_targets',return_value=(copy.deepcopy(self.rows),self.model,self.p0,self.x)),patch.object(p,'minimize',side_effect=injected):
                with self.assertRaises(p.FitConvergenceError):p.run('not-read',ROOT/'tests/fixtures/stock.htt',out)
            self.assertFalse(list(out.glob('*.htt')))
            self.assertFalse((out/'Processing_Result.json').exists())
            self.assertEqual(json.loads((out/'Fit_Failure.json').read_text())['details']['status'],8)

    def test_failed_result_is_rejected_at_packaging(self):
        r=copy.deepcopy(self.reference);r['optimizer']['success']=False;r['optimizer']['status']=8
        with tempfile.TemporaryDirectory() as td,self.assertRaises(p.FitConvergenceError):
            app._package_preview_level(None,r,None,None,td,50,None,None,None,'Auto')

    def test_old_result_is_rejected(self):
        r=copy.deepcopy(self.reference);r['method_id']='accepted-half-step-0.1.5'
        with self.assertRaises(ValueError):p.require_verified_result(r)

    def test_missing_or_failed_verification_is_rejected(self):
        for key in ['initial_optimizer','optimizer']:
            r=copy.deepcopy(self.reference);r[key]['success']=False
            with self.subTest(stage=key),self.assertRaises(p.FitConvergenceError):p.require_verified_result(r)
        r=copy.deepcopy(self.reference);r.pop('verification')
        with self.assertRaises(ValueError):p.require_verified_result(r)

    def test_bad_lattice_is_rejected(self):
        r=copy.deepcopy(self.reference);r['candidate_coefficients'][0]+=.00001
        with self.assertRaises(ValueError):p.require_verified_result(r)

    def test_nonfinite_exact_score_or_surface_is_rejected(self):
        r=copy.deepcopy(self.reference);r['exact_constraint_violation_sum_squares']=float('nan')
        with self.assertRaises(ValueError):p.require_verified_result(r)
        r=copy.deepcopy(self.reference);r['rows'][0]['fitted']=float('nan')
        with self.assertRaises(ValueError):p.require_verified_result(r)

    def test_build_it_rejects_failed_numerical_verification(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'Metrics.json';m=copy.deepcopy(self.reference['metrics'])
            v={'run_completed':1,'metrics_json':str(f),'application_percent':50}
            f.write_text(json.dumps(m));self.assertTrue(app.build_it_application_gate(v,50)[0])
            m['fit_verification']['constrained_success']=False
            f.write_text(json.dumps(m));self.assertFalse(app.build_it_application_gate(v,50)[0])
            m.pop('fit_verification');f.write_text(json.dumps(m));self.assertFalse(app.build_it_application_gate(v,50)[0])

    def test_no_clock_or_reference_file_in_numerical_path(self):
        source=inspect.getsource(p.fit)+inspect.getsource(p.fit_reduced)+inspect.getsource(p._constrained_solve)
        for forbidden in ['monotonic(', 'perf_counter(', 'time.time(', 'reference_v0.1.5', "'stock'),(exact_score"]:
            self.assertNotIn(forbidden,source)

    def test_all_layers_are_still_available(self):
        w1,b1,w2,b2,wo,bo=p.unpack(np.asarray(self.reference['candidate_coefficients']))
        for a,b in zip([w1,b1,w2,b2,wo,np.array([bo])],p.unpack(self.p0)):
            self.assertTrue(np.any(a!=b))
        self.assertEqual(len(self.reference['candidate_coefficients']),79)

if __name__=='__main__':unittest.main(verbosity=2)
