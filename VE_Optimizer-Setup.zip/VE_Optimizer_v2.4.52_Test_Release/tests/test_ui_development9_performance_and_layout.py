"""Approved Development 9: version naming, informational log-performance, layout."""
from __future__ import annotations

import hashlib
import math
import os
from pathlib import Path
import inspect
import tkinter as tk
from types import SimpleNamespace

import pytest
import ve_optimizer_performance as perf
import ve_optimizer_revision9_review as app


def test_versioned_output_name_does_not_stack_suffixes():
    assert perf.performance_export_stem('Fred 1',0)=='Fred 1_V0'
    assert perf.performance_export_stem('Fred 1',1)=='Fred 1_V1'
    assert perf.performance_export_stem('Fred 1_V0',2)=='Fred 1_V2'
    assert perf.performance_export_stem('Fred / 1',2)=='Fred _ 1_V2'
    assert 'performance_export_stem(display,int(v[\'version_no\']))' in inspect.getsource(app.ReviewApp._build_output_sources)


def test_time_matched_power_and_torque_unit_conversion(monkeypatch,tmp_path):
    native={'source_sha256':'a'*64,
        'channels':{1:{'name':'Actual Torque','unit':'N m'},5:{'name':'Engine RPM','unit':'rpm'}},
        'frames':[
            {'timestamp_ms':0,'updates':{5:1000.0}},
            {'timestamp_ms':100,'updates':{1:135.581794833}},
            {'timestamp_ms':150,'updates':{5:3000.0}},
            {'timestamp_ms':200,'updates':{1:271.163589666}},
            {'timestamp_ms':1000,'updates':{5:6000.0}},
            {'timestamp_ms':1300,'updates':{1:271.163589666}}, # too old RPM; not 6000 x 200
            {'timestamp_ms':1550,'updates':{5:4000.0}},      # recent torque; 4000 x 200
            {'timestamp_ms':1700,'updates':{1:100.0}},
        ]}
    monkeypatch.setattr(perf,'_native',lambda _:native)
    measured=perf.summarize_log_performance(tmp_path/'native.hpl')
    assert measured['max_rpm']==6000
    assert math.isclose(measured['max_torque_lbft'],200,rel_tol=1e-10)
    assert math.isclose(measured['max_hp'],200*4000/5252,rel_tol=1e-10)
    assert measured['paired_samples']>=2


def test_no_horsepower_without_matched_samples(monkeypatch,tmp_path):
    native={'source_sha256':'b'*64,
        'channels':{1:{'name':'Actual Torque','unit':'N m'},5:{'name':'Engine RPM','unit':'rpm'}},
        'frames':[{'timestamp_ms':0,'updates':{5:5800}},
                  {'timestamp_ms':500,'updates':{1:300}}]}
    monkeypatch.setattr(perf,'_native',lambda _:native)
    measured=perf.summarize_log_performance(tmp_path/'native.hpl')
    assert measured['max_hp'] is None and measured['paired_samples']==0
    assert measured['max_rpm']==5800 and measured['max_torque_lbft']>200


def test_independent_versions_retain_performance_and_reject_old_log_sha(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    db=app.ReviewDatabase(tmp_path/'perftest.db')
    try:
        uid=db.single_user_identity().id
        project=db.create_project_draft(uid,2023,'Dodge Challenger','',engine='5.7L Hemi')
        logs=[]
        for vn,val in ((0,b'V0 log'),(1,b'V1 log')):
            log=tmp_path/f'v{vn}.hpl';log.write_bytes(val)
            digest=hashlib.sha256(val).hexdigest();logs.append((log,digest))
            db.conn.execute('''INSERT INTO project_versions(project_id,version_no,log_local_path,log_sha256)
                VALUES(?,?,?,?)''',(project.id,vn,str(log),digest))
        db.conn.commit()
        def fake_summary(path):
            log,digest=next((a,b) for a,b in logs if a==path)
            index=0 if path==logs[0][0] else 1
            return dict(max_rpm=5500+index*200,max_torque_lbft=300+index*15,
                max_hp=200+index*20,rpm_samples=1,torque_samples=1,paired_samples=1,
                log_sha256=digest)
        monkeypatch.setattr(app,'summarize_log_performance',fake_summary)
        v0=db.record_version_performance(project.id,0,uid)
        v1=db.record_version_performance(project.id,1,uid)
        assert v0['max_hp']==200 and v1['max_hp']==220
        assert db.get_version_performance(project.id,0)['max_hp']==200
        assert db.get_version_performance(project.id,1)['max_rpm']==5700
        db.conn.execute('UPDATE project_versions SET log_sha256=? WHERE project_id=? AND version_no=1',('changed',project.id))
        db.conn.commit()
        assert db.get_version_performance(project.id,1) is None
        assert db.get_version_performance(project.id,0) is not None
    finally:db.close()


def test_native_fixture_peaks_are_real_not_composed_from_independent_maxima():
    log=Path(__file__).resolve().parent/'fixtures'/'fresh_log.hpl'
    if not log.exists():pytest.skip('Fixture unavailable')
    result=perf.summarize_log_performance(log)
    assert result['rpm_samples']>10000 and result['torque_samples']>10000
    assert result['paired_samples']>10000
    assert result['max_rpm']>=result['max_hp']>=0
    assert result['max_hp'] <= result['max_torque_lbft']*result['max_rpm']/5252
    assert result['torque_channel']=='Actual Torque'


def test_no_map_sensor_choice_or_confirmation_and_safeguards_retained():
    assert not hasattr(app.ReviewApp,'_review_map_and_pe')
    prompt=inspect.getsource(app.ReviewApp._show_preflight_prompt)
    assert '_review_map_and_pe' not in prompt
    import ve_optimizer_wideband as wb
    preflight=inspect.getsource(wb.build_correction_preflight)
    assert 'airflow_preflight.get("blocking")' in preflight


def test_progress_is_one_pinned_bar_and_source_log_in_one_row(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1280x900+0+0')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        assert ui.setup_activity_host is ui.setup_progress_view  # upper-right Progress
        assert ui.setup_header_label.cget('text')=='WARNING'
        ui._set_setup_panel_message('PROGRESS READY','Status',requires_action=False)
        root.update()
        assert ui.setup_activity_host.winfo_viewable()
        assert ui.setup_progress_log.winfo_viewable()
        assert ui.setup_activity_bar.winfo_viewable()
        assert ui.performance_vars['rpm'].get()=='—'  # no fabricated baseline
        assert ui.setup_panel_message['heading']=='PROGRESS READY'
        ui._set_setup_activity('Fitting VE','',percent=40,step=4,total=5,busy=True)
        root.update()
        assert int(float(ui.setup_activity_bar['value']))==40
        assert ui.setup_activity_status_var.get().endswith('40%')
        assert ui.setup_header_label.cget('text')=='PROCESSING'
        ui.running=True;ui._append_run_quality_activity(40,'Fit Neural Network','')
        root.update()
        assert 'Fit Neural Network' in ui.setup_progress_log.get('1.0','end')
    finally:
        if ui:
            try:ui.setup_activity_bar.stop()
            except Exception:pass
            ui.db.close()
        root.destroy()
