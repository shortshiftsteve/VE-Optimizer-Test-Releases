"""Development 1: distribute the supplied VCM Scanner channels XML unmodified."""
from __future__ import annotations

import hashlib
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import ve_optimizer_channel_list as channels


def test_shipped_channels_are_original_and_parse():
    path = channels.bundled_channel_list(ROOT)
    assert path.name == 'Updated VE Optimizer Channels.Channels.xml'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == channels.CHANNEL_LIST_SHA256
    tree = ET.parse(path)
    assert tree.getroot().tag == 'Channels'
    assert len(tree.getroot()) == 68


def test_copies_exact_bytes_into_downloads(tmp_path):
    out_dir = tmp_path / 'Downloads'
    path, status = channels.export_channel_list(ROOT, out_dir)
    assert status == 'saved'
    assert path == out_dir / channels.CHANNEL_LIST_FILENAME
    assert path.read_bytes() == channels.bundled_channel_list(ROOT).read_bytes()
    assert not any(p.suffix == '.tmp' for p in out_dir.iterdir())


def test_repeated_download_is_idempotent(tmp_path):
    first, status = channels.export_channel_list(ROOT, tmp_path)
    assert status == 'saved'
    orig_ns = first.stat().st_mtime_ns
    second, status = channels.export_channel_list(ROOT, tmp_path)
    assert second == first
    assert status == 'already_current'
    assert second.stat().st_mtime_ns == orig_ns


def test_existing_modified_file_is_not_silently_overwritten(tmp_path):
    target = tmp_path / channels.CHANNEL_LIST_FILENAME
    target.write_bytes(b'<Channels>existing user content</Channels>')
    with pytest.raises(FileExistsError):
        channels.export_channel_list(ROOT, tmp_path)
    assert target.read_bytes() == b'<Channels>existing user content</Channels>'
    saved, status = channels.export_channel_list(ROOT, tmp_path, overwrite=True)
    assert status == 'saved'
    assert saved.read_bytes() == channels.bundled_channel_list(ROOT).read_bytes()


def test_bad_or_missing_app_resource_fails_closed(tmp_path):
    with pytest.raises(FileNotFoundError):
        channels.export_channel_list(tmp_path, tmp_path / 'Downloads')
    app_root = tmp_path / 'application'
    (app_root / 'help').mkdir(parents=True)
    (app_root / 'help' / channels.CHANNEL_LIST_FILENAME).write_bytes(b'<Channels/>')
    with pytest.raises(ValueError, match='integrity'):
        channels.export_channel_list(app_root, tmp_path / 'Downloads')
    assert not (tmp_path / 'Downloads').exists()


def test_existing_directory_named_like_channel_file_is_preserved(tmp_path):
    (tmp_path / channels.CHANNEL_LIST_FILENAME).mkdir()
    with pytest.raises(OSError):
        channels.export_channel_list(ROOT, tmp_path)


def test_bundle_and_tools_menu_source_contract():
    source = (ROOT / 've_optimizer_revision9_review.py').read_text(encoding='utf-8')
    spec = (ROOT / 'installer' / 'VE_Optimizer.spec').read_text(encoding='utf-8')
    assert "downloads_menu=tk.Menu(tools_menu,tearoff=False,font=('Microsoft Sans Serif',10))" in source
    assert "downloads_menu.add_command(label='Channel List',command=self._download_channel_list)" in source
    assert "tools_menu.add_cascade(label='Downloads',menu=downloads_menu)" in source
    assert "'help'" in spec and "('a','help','legal','purchase','data','ui')" in spec
    assert 'channel_list.bundled_channel_list(here)' in source


def test_tools_command_export_and_overwrite_permission(tmp_path, monkeypatch):
    import ve_optimizer_revision9_review as app
    target_dir = tmp_path / 'Downloads'
    monkeypatch.setattr(channels, 'downloads_folder', lambda: target_dir)
    results = []
    prompts = []
    monkeypatch.setattr(app.messagebox, 'showinfo', lambda *a, **k: results.append((a, k)))
    monkeypatch.setattr(app.messagebox, 'showerror', lambda *a, **k: pytest.fail(str(a)))
    monkeypatch.setattr(app.messagebox, 'askyesno', lambda *a, **k: prompts.append((a, k)) or False)
    obj = app.ReviewApp.__new__(app.ReviewApp)
    obj.app_dir = ROOT
    obj.root = None
    obj._download_channel_list()
    assert len(results) == 1
    target = target_dir / channels.CHANNEL_LIST_FILENAME
    assert target.read_bytes() == channels.bundled_channel_list(ROOT).read_bytes()
    # A different user file requires explicit confirmation, cancellation preserves it.
    target.write_text('user data', encoding='utf-8')
    obj._download_channel_list()
    assert len(prompts) == 1
    assert target.read_text('utf-8') == 'user data'
    monkeypatch.setattr(app.messagebox, 'askyesno', lambda *a, **k: True)
    obj._download_channel_list()
    assert target.read_bytes() == channels.bundled_channel_list(ROOT).read_bytes()
    assert len(results) == 2


def test_default_folder_on_non_windows(tmp_path, monkeypatch):
    if sys.platform == 'win32':
        pytest.skip('Known Folder API is exercised by Windows field testing')
    monkeypatch.setattr(channels.Path, 'home', staticmethod(lambda: tmp_path))
    assert channels.downloads_folder() == tmp_path / 'Downloads'
