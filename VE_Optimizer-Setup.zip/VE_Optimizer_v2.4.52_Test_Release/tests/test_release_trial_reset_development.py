"""Each numbered release has its own persistent 72-hour trial start."""
from datetime import datetime, timedelta, timezone
import json

import ve_optimizer_license as licensing

import pytest

@pytest.fixture(autouse=True)
def release_only_trials(monkeypatch):
    """These inherited tests exercise Release, not a Review build."""
    monkeypatch.setattr(licensing, 'RELEASE_STAGE', 'Release')


def test_each_release_starts_a_new_trial_and_same_release_does_not_reset(tmp_path, monkeypatch):
    monkeypatch.setenv('VE_OPTIMIZER_LICENSE_STATE_DIR',str(tmp_path))
    v243=datetime(2026,10,12,12,tzinfo=timezone.utc)
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.3')
    old=licensing.LicenseManager(now=v243)
    assert old.status()['mode']=='trial'
    assert licensing.LicenseManager(now=v243+timedelta(hours=73)).status()['mode']=='demo'

    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.5')
    later=v243+timedelta(days=5)
    upgraded=licensing.LicenseManager(now=later)
    assert upgraded.status()['mode']=='trial'
    assert upgraded.status()['trial_started_at']==licensing.iso(later)
    assert licensing.LicenseManager(now=later+timedelta(hours=71)).status()['mode']=='trial'
    assert licensing.LicenseManager(now=later+timedelta(hours=73)).status()['mode']=='demo'

    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.3')
    assert licensing.LicenseManager(now=later+timedelta(hours=74)).status()['mode']=='demo'
    state=json.loads((tmp_path/licensing.TRIAL_FILE).read_text())
    assert state['release_starts']=={
        '2.4.3':licensing.iso(v243),'2.4.5':licensing.iso(later)}


def test_existing_243_legacy_trial_preserved_but_not_applied_to_new_release(tmp_path,monkeypatch):
    monkeypatch.setenv('VE_OPTIMIZER_LICENSE_STATE_DIR',str(tmp_path))
    old=datetime(2026,9,1,13,tzinfo=timezone.utc)
    (tmp_path/licensing.TRIAL_FILE).write_text(json.dumps({'installed_utc':licensing.iso(old)}))
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.3')
    assert licensing.LicenseManager(now=old+timedelta(days=90)).status()['mode']=='demo'
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.5')
    now=datetime(2026,10,25,16,tzinfo=timezone.utc)
    obj=licensing.LicenseManager(now=now)
    assert obj.status()['mode']=='trial'
    stored=json.loads((tmp_path/licensing.TRIAL_FILE).read_text())
    assert stored['installed_utc']==licensing.iso(old)
    assert stored['release_starts']=={'2.4.3':licensing.iso(old),'2.4.5':licensing.iso(now)}


def test_later_version_reuses_earliest_recorded_start(tmp_path,monkeypatch):
    monkeypatch.setenv('VE_OPTIMIZER_LICENSE_STATE_DIR',str(tmp_path))
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.5')
    now=datetime(2026,11,2,12,tzinfo=timezone.utc)
    state={'release_starts':{'2.4.5':licensing.iso(now)}}
    (tmp_path/licensing.TRIAL_FILE).write_text(json.dumps(state))
    earlier=datetime(2026,11,2,11,tzinfo=timezone.utc)
    monkeypatch.setattr(licensing,'_reg_read',lambda name:{'release_starts':{'2.4.5':licensing.iso(earlier)}})
    monkeypatch.setattr(licensing,'_reg_write',lambda *args:None)
    obj=licensing.LicenseManager(now=now+timedelta(hours=30))
    assert obj.status()['trial_started_at']==licensing.iso(earlier)
    assert json.loads((tmp_path/licensing.TRIAL_FILE).read_text())['release_starts']['2.4.5']==licensing.iso(earlier)


def test_review_build_preserves_243_legacy_mapping():
    assert licensing.RELEASE_VERSION == '2.4.52'
    assert licensing.LEGACY_TRIAL_RELEASE_VERSION == '2.4.3'
    assert licensing.TRIAL_HOURS == 72
