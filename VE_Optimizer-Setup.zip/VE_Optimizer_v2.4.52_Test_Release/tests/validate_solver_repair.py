"""Repeatable local validation: python tests/validate_solver_repair.py --output OUTPUT.
Uses the bundled original stock/log fixtures, not saved coefficients as fit input.
Runs numerical tests and source-application lifecycle tests, not a native EXE.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import numpy as np
import ve_optimizer_processing as p

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    results=[];digests=[];fixture=ROOT/'tests/fixtures'
    for i in range(1,4):
        dest=out/f'repeat_{i}'
        cmd=[sys.executable,str(ROOT/'ve_optimizer_processing.py'),str(fixture/'fresh_log.hpl'),str(fixture/'stock.htt'),str(dest)]
        with (out/f'repeat_{i}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True,cwd=ROOT)
        r=json.loads((dest/'Processing_Result.json').read_text());p.require_verified_result(r)
        results.append(r);digests.append(hashlib.sha256((dest/'Candidate_FullEngine.htt').read_bytes()).hexdigest())
        print(f'Repeat {i}: initial and constrained solves passed; {digests[-1]}',flush=True)
    assert len(set(digests))==1,'Repeat outputs differ'
    for r in results[1:]:
        assert r['candidate_coefficients']==results[0]['candidate_coefficients']
        assert [v['fitted'] for v in r['rows']]==[v['fitted'] for v in results[0]['rows']]
    for name in ['test_solver_repair.py','test_pooled_hit_qualification.py','test_results_reduction.py','test_trial_and_ui_v230.py','test_release_ui_contract.py']:
        with (out/(name+'.log')).open('w') as log:
            subprocess.run([sys.executable,str(ROOT/'tests'/name)],stdout=log,stderr=subprocess.STDOUT,check=True,cwd=ROOT)
    with (out/'lifecycle.log').open('w') as log:
        subprocess.run([sys.executable,str(ROOT/'tests/test_accepted_method.py'),'--log',str(fixture/'fresh_log.hpl'),'--baseline',str(fixture/'stock.htt'),'--reference',str(fixture/'reference_solver_repair1.json'),'--output',str(out/'lifecycle')],stdout=log,stderr=subprocess.STDOUT,check=True,cwd=ROOT)
    (out/'Summary.json').write_text(json.dumps({'status':'PASS','method_id':p.METHOD_ID,'identical_repeats':3,'htt_sha256':digests[0],'initial_optimizer':results[0]['initial_optimizer'],'optimizer':results[0]['optimizer'],'metrics':results[0]['metrics'],'windows_exe_and_vehicle_validation':'not performed by this script'},indent=2))
    print('PASS: numerical/source-workflow validation. No vehicle approval.',flush=True)
if __name__=='__main__':main()
