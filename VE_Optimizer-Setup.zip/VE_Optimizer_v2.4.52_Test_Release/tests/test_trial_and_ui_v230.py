from pathlib import Path
from datetime import datetime, timezone, timedelta
import os, tempfile, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_license as licensing
import ve_optimizer_revision9_review as app

def test_trial_transition():
    with tempfile.TemporaryDirectory() as td:
        old=os.environ.get('VE_OPTIMIZER_LICENSE_STATE_DIR')
        os.environ['VE_OPTIMIZER_LICENSE_STATE_DIR']=td
        try:
            t0=datetime(2026,10,2,12,0,0,tzinfo=timezone.utc)
            m0=licensing.LicenseManager(now=t0)
            s0=m0.status()
            assert s0['mode']=='trial' and s0['processed_output'] is True
            exp=m0.trial_expires_at.astimezone()
            clock=exp.strftime('%I:%M %p').lstrip('0')
            assert m0.trial_expiration_label()==f'Expires: {exp.month}/{exp.day}/{exp.year} {clock}'
            m71=licensing.LicenseManager(now=t0+timedelta(hours=71,minutes=59))
            assert m71.status()['mode']=='trial'
            m72=licensing.LicenseManager(now=t0+timedelta(hours=72))
            s72=m72.status()
            assert s72['mode']=='demo' and s72['processed_output'] is False and s72['expired'] is True
        finally:
            if old is None: os.environ.pop('VE_OPTIMIZER_LICENSE_STATE_DIR',None)
            else: os.environ['VE_OPTIMIZER_LICENSE_STATE_DIR']=old

def test_vehicle_options():
    assert app.MODEL_YEAR_OPTIONS==tuple(str(y) for y in range(2023,2009,-1))
    assert app.MODEL_OPTIONS==('Dodge Challenger','Dodge Charger','Hellcat','Trackhawk')
    assert app.ENGINE_OPTIONS==('5.7L Hemi','6.2L Supercharged Hemi','6.4L Hemi')

if __name__=='__main__':
    test_trial_transition();test_vehicle_options();print('V230_TRIAL_UI_PASS')
