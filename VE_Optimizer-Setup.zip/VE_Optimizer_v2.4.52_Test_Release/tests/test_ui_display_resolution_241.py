"""Display-only changes following the accepted v2.4.1 HPL decoder repair.

The correction source review still enforces the original safety and qualification
logic, and the performance calculations are intentionally unchanged.
"""
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
from tkinter import ttk

import pytest
import ve_optimizer_revision9_review as app


def descendants(widget):
    for child in widget.winfo_children():
        yield child
        yield from descendants(child)


def widgets_of_type(parent, cls):
    return [x for x in descendants(parent) if isinstance(x, cls)]


def visible_title(inst):
    bar=inst.setup_message_host.winfo_children()[0]
    labels=[x for x in bar.winfo_children() if isinstance(x, tk.Label)]
    assert len(labels)==1
    return labels[0].cget('text')


@pytest.fixture
def ui(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1334x880+0+0')
    inst=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
    inst.user=inst.db.single_user_identity()
    inst.shell();inst.goto('setup');root.update()
    try:yield root,inst
    finally:
        inst.db.close();root.destroy()


def set_sources(inst, adaptive, wideband):
    inst.project=SimpleNamespace(id=31)
    inst._setup_lower_mode='preflight'
    inst.correction_source_selection=None
    inst.correction_preflight_cache={
        'configuration':{'airflow_model':'neural_network'},
        'choices':[{'id':'adaptive','label':'Adaptive Fuel Trims (LTFT + STFT)',
                    'enabled':adaptive},
                   {'id':'wideband','label':'Wideband O2','enabled':wideband,
                    'reason':'Wideband Lambda channel not found.'}],
        'sources':{'wideband':{'present':wideband}},
    }
    inst._show_correction_source_message()
    inst.root.update()
    buttons=[x for x in widgets_of_type(inst.setup_primary_actions,ttk.Button)
             if x.cget('text')=='Continue']
    assert not widgets_of_type(inst.setup_message_host,ttk.Button)
    assert len(buttons)==(1 if adaptive or wideband else 0)
    return buttons[0] if buttons else None


def test_warning_is_initial_and_subsequent_caption_is_messages(ui):
    root,inst=ui
    assert visible_title(inst)=='WARNING'
    assert inst.setup_panel_message['heading']=='WARNING'
    warning_bar=inst.setup_message_host.winfo_children()[0]
    warning_label=next(w for w in warning_bar.winfo_children() if isinstance(w,tk.Label))
    assert warning_label.cget('anchor')=='center'
    inst._set_setup_panel_message('KNOCK DATA NOT FOUND','Sensor data missing.')
    root.update()
    assert visible_title(inst)=='MESSAGE'
    assert inst.setup_panel_message['heading']=='KNOCK DATA NOT FOUND'
    bar=inst.setup_message_host.winfo_children()[0]
    label=next(w for w in bar.winfo_children() if isinstance(w,tk.Label))
    assert label.cget('anchor')=='center'
    assert label.cget('justify')=='center'
    assert abs((label.winfo_rootx()+label.winfo_width()/2)
               -(bar.winfo_rootx()+bar.winfo_width()/2)) < 3
    inst._new_project_setup();root.update()
    assert visible_title(inst)=='WARNING'


def test_only_adaptive_shows_run_but_no_choice_or_missing_wideband_message(ui):
    root,inst=ui
    btn=set_sources(inst,True,False)
    assert inst.correction_source_selection=='adaptive'
    assert not btn.instate(['disabled'])
    assert not widgets_of_type(inst.setup_message_host,ttk.Radiobutton)
    assert visible_title(inst)=='PROGRESS'
    text=' '.join(x.cget('text') for x in widgets_of_type(inst.setup_message_host,tk.Label))
    assert 'Wideband' not in text
    assert 'Choose' not in text


def test_only_wideband_auto_selected_without_source_choice(ui):
    _root,inst=ui
    btn=set_sources(inst,False,True)
    assert inst.correction_source_selection=='wideband'
    assert not btn.instate(['disabled'])
    assert not widgets_of_type(inst.setup_message_host,ttk.Radiobutton)


def test_both_sources_require_explicit_choice_and_run_is_disabled_until_selected(ui):
    _root,inst=ui
    btn=set_sources(inst,True,True)
    assert inst.correction_source_selection is None
    assert btn.instate(['disabled'])
    choices=widgets_of_type(inst.setup_message_host,ttk.Radiobutton)
    assert sorted(x.cget('text') for x in choices)==['Adaptive Fuel Trims (LTFT + STFT)','Wideband O2']
    choices[1].invoke();inst.root.update()
    assert inst.correction_source_selection=='wideband'
    btn=[x for x in widgets_of_type(inst.setup_primary_actions,ttk.Button) if x.cget('text')=='Continue'][0]
    assert not btn.instate(['disabled'])


def test_no_source_prevents_run_and_no_false_choice(ui):
    _root,inst=ui
    btn=set_sources(inst,False,False)
    assert btn is None  # an unqualified log must not offer Run
    assert not widgets_of_type(inst.setup_message_host,ttk.Radiobutton)


def test_performance_matrix_uses_compact_space_but_remains_visible(ui):
    _root,inst=ui
    assert int(inst.setup_performance_panel.cget('height'))==110
    assert inst.setup_performance_panel.winfo_viewable()
    assert inst.performance_table_interior.winfo_viewable()
    assert inst.performance_cells[0]['hp'].get()=='—'
    assert inst.setup_message_host.winfo_height()>180
    assert inst.performance_table_interior.winfo_reqheight() <= 110
    assert 'Max HP:' in [x.cget('text') for x in widgets_of_type(inst.setup_performance_panel,tk.Label)]
