from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_logcheck as logcheck

EXPECTED=[
    'Engine RPM',
    'Actual Torque',
    'Intake Cam Center Pos',
    'Exhaust Cam Center Pos',
    'MAP - Hi-Res',
    'Barometric Pressure - Hi Res',
    'Long Term Fuel Trim Bank 1 (SAE)',
    'Long Term Fuel Trim Bank 2 (SAE)',
    'Short Term Fuel Trim Bank 1 (SAE)',
    'Short Term Fuel Trim Bank 2 (SAE)',
    'Engine Coolant Temp',
    'FA Enrichment',
    'FA Power Enrichment',
    'Fuel Flow Rate',
    'FA Stoich',
    'Knock Retard Long Term',
    'Knock Retard Short Term',
    'Total Knock Retard',
]

class RequiredChannelStatusDisplayTests(unittest.TestCase):
    def test_required_channel_labels_and_count(self):
        required=[s.label for s in logcheck.SPECS if s.required]
        self.assertEqual(required,EXPECTED)
        self.assertEqual(len(required),18)

    def test_bundled_log_reports_every_required_channel_pass(self):
        report=logcheck.analyze_log(ROOT/'tests'/'fixtures'/'fresh_log.hpl')
        required=[q for q in report['signals'] if q['required']]
        self.assertEqual([q['label'] for q in required],EXPECTED)
        # This archived HPL predates mandatory knock-retard logging.
        # Required channels that exist qualify; missing knock channels block.
        self.assertFalse(report['passed'])
        self.assertEqual({q['label'] for q in required if q['status']=='MISSING'},
                         {'Knock Retard Long Term','Knock Retard Short Term','Total Knock Retard'})
        self.assertTrue(all(q['status']=='PASS' for q in required if 'Knock' not in q['label']))
        self.assertTrue(any(q['label']=='Fuel Flow Rate' for q in required))

    def test_validation_dialog_displays_complete_channel_inventory(self):
        app=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
        self.assertIn("report.get('logged_channels',[])",app)
        self.assertIn("headers=[('Channel',300)",app)
        self.assertIn("status_text=='No Data'",app)
        self.assertIn("status_text in ('Pass','Available')",app)

if __name__=='__main__':
    unittest.main()
