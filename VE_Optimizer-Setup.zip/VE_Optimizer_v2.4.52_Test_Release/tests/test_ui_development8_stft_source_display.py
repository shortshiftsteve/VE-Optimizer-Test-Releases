"""UI Development 8: Show Method B's STFT correction source accurately.

Pure presentation tests only; never execute an optimization, HPL decode, or
change tune settings.  `adaptive` remains the internal method/source ID.
"""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_revision9_review as app


def source_display(payload, preflight=None, selection='adaptive'):
    ui=app.ReviewApp.__new__(app.ReviewApp)
    ui._application_payload=lambda:payload
    ui.correction_source_selection=selection
    ui.correction_preflight_cache=preflight or {}
    return ui._run_quality_source_model()


def test_speed_density_adaptive_source_is_stft_only():
    source,label,model,model_label,_,_=source_display({
        'correction_source':'adaptive','airflow_model':'speed_density',
        'preflight':{'sources':{'adaptive':{'mode':'stft_only'}}},
    })
    assert source=='adaptive'       # no internal processing source alteration
    assert label=='STFT'
    assert model=='speed_density'
    assert model_label=='Speed Density VE Tables'


def test_speed_density_stored_metrics_preserve_stft_label(tmp_path):
    path=tmp_path/'metrics.json'
    path.write_text(json.dumps({'correction_source':'adaptive','airflow_model':'speed_density'}),encoding='utf-8')
    source,label,model,_,_,_=source_display({'levels':{'50':{'metrics_json':str(path)}}})
    assert (source,label,model)==('adaptive','STFT','speed_density')


def test_neural_network_adaptive_source_reports_both_trims():
    source,label,model,_,_,_=source_display({
        'correction_source':'adaptive','airflow_model':'neural_network'})
    assert (source,label,model)==('adaptive','LTFT+STFT','neural_network')


def test_speed_density_wideband_source_stays_wideband():
    source,label,model,_,_,_=source_display({
        'correction_source':'wideband','airflow_model':'speed_density'},selection='wideband')
    assert (source,label,model)==('wideband','Wideband O2','speed_density')
