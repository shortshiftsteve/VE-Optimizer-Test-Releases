"""Preflight MAP confirmation and read-only PE safety hold are independently displayed.

Run with xvfb-run when no graphical desktop is available.
"""
import tkinter as tk
from types import SimpleNamespace
import ve_optimizer_revision9_review as app


def all_label_text(parent):
    texts=[]
    for widget in parent.winfo_children():
        if isinstance(widget,tk.Label):
            texts.append(widget.cget('text'))
        texts.append(all_label_text(widget))
    return '\n'.join(texts)


def test_preflight_confirmed_map_and_separate_pe_hold():
    root=tk.Tk(); root.geometry('1050x750')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.content=tk.Frame(root,bg=app.C['bg']); obj.content.pack(fill='both',expand=True)
        obj.project=SimpleNamespace(id=123)
        obj.db=SimpleNamespace(version_setup_complete=lambda pid,v:True)
        obj._active_version=lambda: {'version_no':1}
        obj._correction_context=lambda:('current','tune','log')
        obj.correction_preflight_context=('current','tune','log')
        obj.boost_review_approval_context=('current','tune','log')
        obj.correction_source_selection=None
        obj.correction_rescale_approved=False
        obj.header_action=None
        obj.page_canvas=None
        obj.correction_preflight_cache={
            'configuration':{'airflow_model':'speed_density','pe_table_axis':'PRatio'},
            'choices':[], 'sources':{}, 'domain_preflight':{}, 'airflow_map_preflight':{},
            'pe_preflight':{'current_pe_method':'PRatio','required_pe_method':'PRatio',
                            'current_pratio_table_max':1.5,'recommended_pratio_table_max':1.70,
                            'pratio_rescale_required':True,'switch_change_required':False,
                            'blocking':True,'manual_review_required':True,'boosted_detected':True,
                            'issues':['Logged boosted PRatio exceeds PE axis'], 'operating':{'observed_pratio_max':1.64056}},
            'engine_review':{'pressure_exceeds_baro':True,'boost_review_required':True,'map_source':{'exceeds_baro':414},
                             'tune':{'sensed_map_switch':'Enabled'},
                             'knock_retard':{'short_term':{'present':False}}},
        }
        obj.current_page='preflight'
        obj.help_context='run_review'
        app.ReviewApp.page_preflight(obj)
        root.update()
        screen=all_label_text(obj.content)
        assert 'Boost / MAP / WOT Review' in screen
        assert 'OBSERVED' in screen
        assert 'PE Calibration Safety' not in screen
        assert 'MANUAL REVIEW' not in screen
        assert 'Stored selector: PRatio' not in screen
        assert 'VE Optimizer will automatically rescale' not in screen
    finally:
        root.destroy()


def test_non_setup_processing_overlay_is_static_and_follows_viewport():
    root=tk.Tk();root.geometry('900x600')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.page_canvas=tk.Canvas(root,bg='white',height=420)
        obj.page_canvas.pack(fill='both',expand=True)
        obj.content=tk.Frame(obj.page_canvas,bg='white')
        w=obj.page_canvas.create_window((0,0),window=obj.content,anchor='nw')
        obj.page_canvas.bind('<Configure>',lambda e:obj.page_canvas.itemconfig(w,width=e.width))
        for i in range(80):tk.Label(obj.content,text=f'Item {i}').pack()
        obj.content.update_idletasks()
        obj.page_canvas.configure(scrollregion=obj.page_canvas.bbox('all'))
        root.update()
        obj.page_canvas.yview_moveto(0.98);root.update()
        obj._working_overlay=None;obj._working_after_id=None;obj._working_visible=True
        app.ReviewApp._show_working_overlay(obj)
        root.update()
        assert obj._working_overlay.master is obj.page_canvas
        assert obj._working_label.winfo_viewable()
        assert abs(obj._working_label.winfo_rooty()-obj.page_canvas.winfo_rooty()-obj.page_canvas.winfo_height()/2)<75
        app.ReviewApp._hide_working_overlay(obj)
    finally:
        root.destroy()
