from pathlib import Path
import bisect
import math
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

import ve_optimizer_processing as processing
import ve_optimizer_surface as surface
import ve_optimizer_revision9_review as app

EXPECTED_RPMS=(416.0,608.0,800.0,992.0,1184.0,1376.0,1664.0,1952.0,2240.0,2976.0,3616.0,4016.0,4416.0,4768.0,5216.0,5600.0,5984.0)
EXPECTED_PRATIOS=(0.150390625,0.2001953125,0.25,0.2998046875,0.349609375,0.400390625,0.4501953125,0.5,0.5498046875,0.599609375,0.650390625,0.7001953125,0.75,0.7998046875,0.849609375,0.900390625,1.0)
BASELINE=ROOT/'a'/'stock_nn.htt'


def _bilinear(grid,rpm,pr):
    xs=grid['rpms'];ys=grid['pratios'];z=grid['original']
    ci=max(0,min(len(xs)-2,bisect.bisect_right(xs,rpm)-1))
    ri=max(0,min(len(ys)-2,bisect.bisect_right(ys,pr)-1))
    x0,x1=xs[ci],xs[ci+1];y0,y1=ys[ri],ys[ri+1]
    tx=(rpm-x0)/(x1-x0);ty=(pr-y0)/(y1-y0)
    z00=z[ri][ci];z10=z[ri][ci+1];z01=z[ri+1][ci];z11=z[ri+1][ci+1]
    return (1-ty)*((1-tx)*z00+tx*z10)+ty*((1-tx)*z01+tx*z11)


class SpeedDensitySurfaceTests(unittest.TestCase):
    def test_speed_density_axes_match_workbook(self):
        self.assertEqual(surface.SPEED_DENSITY_RPMS,EXPECTED_RPMS)
        self.assertEqual(surface.SPEED_DENSITY_PRATIOS,EXPECTED_PRATIOS)

    def test_speed_density_is_direct_exact_nn_evaluation_not_20x20_interpolation(self):
        speed=surface.build_speed_density_maps(BASELINE,BASELINE)
        combined=speed['combined']
        self.assertEqual(combined['surface_format'],'speed_density')
        self.assertEqual((len(combined['pratios']),len(combined['rpms'])),(17,17))
        self.assertEqual(len(combined['original']),17)
        self.assertTrue(all(len(row)==17 for row in combined['original']))
        self.assertEqual(combined['stats']['total_cells'],289)
        self.assertEqual(len(speed['pair_surfaces']),5)

        # Frozen regression checkpoint for the supplied production 5.7L baseline.
        self.assertEqual(combined['original'][0][0],40.21484375)
        self.assertEqual(combined['new'][0][0],40.21484375)
        self.assertEqual(combined['delta'][0][0],0.0)

        # The combined cell is the arithmetic mean of five independently
        # quantized cam-reference evaluations, matching accepted Results math.
        pair_values=[p['original'][0][0] for p in speed['pair_surfaces']]
        self.assertEqual(combined['original'][0][0],sum(pair_values)/5.0)
        for pair in speed['pair_surfaces']:
            for row in pair['original']:
                for value in row:
                    q=value/processing.QUANTUM
                    self.assertTrue(math.isclose(q,round(q),abs_tol=1e-10))

        # Guard the core requirement: 17x17 is NOT bilinear resampling of the
        # displayed 20x20 table. The production baseline materially differs.
        nn20=surface.build_display_maps(BASELINE,BASELINE)['combined']
        interpolated=_bilinear(nn20,EXPECTED_RPMS[0],EXPECTED_PRATIOS[0])
        self.assertGreater(abs(combined['original'][0][0]-interpolated),0.4)

    def test_speed_density_refuses_out_of_domain_axes(self):
        with self.assertRaisesRegex(ValueError,'outside this calibration NN domain'):
            surface.build_surfaces_on_axes(BASELINE,BASELINE,[416.0,7000.0],[0.2,0.5])

    def test_copy_with_axes_preserves_exact_speed_density_breakpoints(self):
        data=surface.build_speed_density_maps(BASELINE,BASELINE)['combined']
        viewer=app.ReviewApp.__new__(app.ReviewApp)
        viewer.surface_selection=(0,0,1,1)
        viewer.surface_selected_cell=(0,0)
        text=app.ReviewApp._surface_selection_tsv(viewer,data,'original',True)
        lines=text.split('\r\n')
        self.assertEqual(lines[0],'PRatio/RPM\t416\t608')
        self.assertTrue(lines[1].startswith('0.150390625\t'))
        self.assertTrue(lines[2].startswith('0.2001953125\t'))


if __name__=='__main__':
    unittest.main()
