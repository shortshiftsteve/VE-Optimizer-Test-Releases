"""Method B optional LTFT + STFT bank correction; Method A remains independent."""
from pathlib import Path
from unittest.mock import patch
import sys
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integration
import ve_optimizer_logcheck as logcheck
from ve_optimizer_htt_codec import parse_htt
from test_sd_map1_maxrpm_scaling import _minimal_sd_tune


def decoded_sd(*, ltft_b1=True, ltft_b2=True, events=12, ltft_async=False,
               ltft_b2_populated=True, stft_b2_events=None):
    names = {
        0: ('Engine RPM', 'rpm', 2135),
        1: ('Actual Torque', 'lb-ft', 2706),
        2: ('MAP - Hi-Res', 'kPa', 2335),
        3: ('Barometric Pressure', 'kPa', 2410),
        4: ('Engine Coolant Temp', 'deg F', 2124),
        5: ('Short Term Fuel Trim Bank 1 (SAE)', '%', 6),
        6: ('Short Term Fuel Trim Bank 2', '%', 8),
        7: ('FA Enrichment', '', 6056),
        8: ('FA Power Enrichment', '', 6080),
    }
    if ltft_b1:
        names[9] = ('Long Term Fuel Trim Bank 1', '%', 7)
    if ltft_b2:
        names[10] = ('Long Term Fuel Trim Bank 2 (SAE)', '%', 9)
    values = {0: 1500.0, 1: 30.0, 2: 80.0, 3: 100.0, 4: 190.0,
              5: -3.0, 6: 2.0, 7: 0.04, 8: 0.03, 9: 8.0, 10: -4.0}
    # B1 total +5%; B2 total -2%. Both banks are 5-hit qualified.
    # +50% of dominant B1 => +2.5% VE at this operating cell.
    frames = []
    for i in range(events):
        updates = {k: v for k, v in values.items() if k in names}
        if stft_b2_events is not None and i >= stft_b2_events:
            updates.pop(6, None)
        if ltft_async:
            updates.pop(9, None)
            updates.pop(10, None)
        if not ltft_b2_populated:
            updates.pop(10, None)
        frames.append({'timestamp_ms': i * 100, 'updates': updates})
    if ltft_async:
        # Five slow LTFT readings interleaved with the 12 STFT triggers.
        for i in range(5):
            frames.append({'timestamp_ms': i * 240, 'updates': {9: 8.0, 10: -4.0}})
        frames.sort(key=lambda row: row['timestamp_ms'])
    return {'channels': {idx: {'name': name, 'unit': unit, 'parameter_id': pid}
                         for idx, (name, unit, pid) in names.items()},
            'frames': frames}


def analyze_sd(decoded, tune_path=Path('unused.htt')):
    rpm = np.array([0., 1500., 3000.]); pr = np.array([0.5, 0.8, 1.5]); ve = np.ones((3,3))
    with patch.object(wb, 'decode_hpl', return_value=decoded), \
         patch.object(wb, 'parse_ve_table', return_value=(b'fake', rpm, pr, ve)):
        return integration._adaptive_sd_analysis(Path('unused.hpl'), tune_path)


def test_both_banks_use_total_trims_with_dominant_bank_bias_and_half_step():
    log = decoded_sd()
    status = wb._adaptive_trim_status(log, 'speed_density')
    assert status['valid'] and status['mode'] == 'ltft_plus_stft'
    assert status['ltft_available'] and status['accepted_events_bank1'] == 12
    analysis = analyze_sd(log)
    assert analysis['trim_mode'] == 'ltft_plus_stft'
    assert analysis['hit_counts'][:,1,1].tolist() == [12, 12]
    assert analysis['qualifying_cell_count'] == 1
    assert analysis['full_correction_pct'][1,1] == 5.0  # max(+5, -2)
    assert analysis['applied_correction_pct'][1,1] == 2.5
    assert analysis['applied_correction_pct'][1,1] != 1.0  # not STFT-only dominant Bank 2


@pytest.mark.parametrize('ltft_b1,ltft_b2,populated', [
    (False,False,True), (False,True,True), (True,False,True),
    (True,True,False),
])
def test_missing_or_empty_ltft_reverts_both_banks_to_stft_only(ltft_b1,ltft_b2,populated):
    log = decoded_sd(ltft_b1=ltft_b1, ltft_b2=ltft_b2, ltft_b2_populated=populated)
    status = wb._adaptive_trim_status(log, 'speed_density')
    assert status['valid'] and status['mode'] == 'stft_only'
    assert status['ltft_available'] is False
    analysis = analyze_sd(log)
    assert analysis['trim_mode'] == 'stft_only'
    assert analysis['hit_counts'][:,1,1].tolist() == [12,12]
    assert analysis['full_correction_pct'][1,1] == 2.0  # max(-3, +2)
    assert analysis['applied_correction_pct'][1,1] == 1.0


def test_late_ltft_is_not_allowed_to_block_usable_stft_only_data():
    log = decoded_sd()
    for frame in log['frames'][:-1]:
        frame['updates'].pop(9, None)
        frame['updates'].pop(10, None)
    status = wb._adaptive_trim_status(log, 'speed_density')
    analysis = analyze_sd(log)
    assert status['valid'] and status['mode'] == 'stft_only'
    assert status['accepted_events_bank1'] == 12
    assert status['accepted_events_bank2'] == 12
    assert analysis['hit_counts'][:,1,1].tolist() == [12, 12]
    assert analysis['full_correction_pct'][1,1] == 2.0


def test_both_negative_bank_totals_select_less_negative_bank():
    log = decoded_sd()
    for frame in log['frames']:
        frame['updates'][9] = -5.0  # Bank 1: -3 - 5 = -8%
        frame['updates'][10] = -5.0  # Bank 2: +2 - 5 = -3%
    analysis = analyze_sd(log)
    assert analysis['trim_mode'] == 'ltft_plus_stft'
    assert analysis['full_correction_pct'][1,1] == -3.0
    assert analysis['applied_correction_pct'][1,1] == -1.5


def test_asynchronous_ltft_updates_do_not_inflate_stft_hit_counts():
    log = decoded_sd(ltft_async=True)
    status = wb._adaptive_trim_status(log, 'speed_density')
    analysis = analyze_sd(log)
    assert status['mode'] == analysis['trim_mode'] == 'ltft_plus_stft'
    assert status['accepted_events_bank1'] == 12
    assert status['accepted_events_bank2'] == 12
    assert analysis['hit_counts'][:,1,1].tolist() == [12,12]
    assert analysis['full_correction_pct'][1,1] == 5.0


def test_independent_five_hit_threshold_on_two_banks():
    log = decoded_sd(events=8, stft_b2_events=4)
    status = wb._adaptive_trim_status(log, 'speed_density')
    # Source qualification still requires five valid events per bank.
    assert not status['valid'] and status['accepted_events_bank2'] == 4
    analysis = analyze_sd(log)
    assert analysis['hit_counts'][:,1,1].tolist() == [8,4]
    assert analysis['qualifying_cell_count'] == 1
    assert status['mode'] == analysis['trim_mode'] == 'stft_only'
    assert analysis['full_correction_pct'][1,1] == -3.0  # Bank 2 excluded
    assert analysis['applied_correction_pct'][1,1] == -1.5


def test_method_a_remains_independent_and_requires_ltft_fuel_flow():
    assert logcheck.METHOD_A_CHANNELS is not logcheck.METHOD_B_CHANNELS
    assert logcheck._profile_required(logcheck.SPEC_BY_KEY['ltft_b1'], 'neural_network')
    assert not logcheck._profile_required(logcheck.SPEC_BY_KEY['ltft_b1'], 'speed_density')
    assert logcheck.METHOD_A_CHECKPOINT['strict_required_keys'] != logcheck.METHOD_B_CHECKPOINT['strict_required_keys']
    result = wb._adaptive_trim_status(decoded_sd(ltft_b2=False), 'neural_network')
    assert not result['valid'] and 'ltft_b2' in result['missing'] and 'fuel_flow' in result['missing']


def test_sd_source_selection_reports_adaptive_mode_without_wideband_blending():
    log = decoded_sd()
    with patch.object(wb, 'decode_hpl', return_value=log), \
         patch.object(wb, '_wideband_data_status', return_value={'valid':True}), \
         patch.object(wb, '_narrowband_status', return_value={'valid':False}), \
         patch.object(wb, '_maf_status', return_value={'valid':False}):
        sources = wb.inspect_correction_sources(Path('unused.hpl'), airflow_model='speed_density')
    assert sources['adaptive']['mode'] == 'ltft_plus_stft'
    choices = {row['id']:row for row in sources['choices']}
    assert choices['adaptive']['label'] == 'Adaptive Fuel Trims (LTFT + STFT)'
    assert choices['adaptive']['enabled'] and choices['wideband']['enabled']
    assert all(row['id'] != 'combined' for row in sources['choices'])


def test_native_speed_density_htt_correction_only_modifies_two_ve_tables(tmp_path):
    source = _minimal_sd_tune(tmp_path/'source.htt')
    tune = tmp_path/'axis_prepared.htt'
    wb.rescale_speed_density_axes(source, tune)
    assert wb.detect_airflow_model(tune) == 'speed_density'
    _,rpm,pr,_ = wb.parse_ve_table(tune, wb.VE_BANK1_TABLE)
    _,rpm2,pr2,_ = wb.parse_ve_table(tune, wb.VE_BANK2_TABLE)
    assert np.array_equal(rpm, rpm2) and np.array_equal(pr, pr2)
    log = decoded_sd()
    with patch.object(wb, 'decode_hpl', return_value=log):
        analysis = integration._adaptive_sd_analysis(Path('unused.hpl'),tune)
    r = wb._nearest_index(pr, 0.8)
    c = wb._nearest_index(rpm, 1500)
    assert analysis['full_correction_pct'][r,c] == 5.0
    assert analysis['applied_correction_pct'][r,c] == 2.5
    candidate = tmp_path/'candidate.htt'
    integration._export_sd_map(tune, analysis['qualifying'], analysis['applied_correction_pct'], candidate)
    before,after = parse_htt(tune.read_bytes()),parse_htt(candidate.read_bytes())
    changed={key for key,rec in before.by_key().items() if rec.raw != after.by_key()[key].raw}
    assert changed == {wb.VE_BANK1_TABLE, wb.VE_BANK2_TABLE}
    for key in changed:
        _,x0,y0,old=wb.parse_ve_table(tune,key)
        _,x1,y1,new=wb.parse_ve_table(candidate,key)
        assert np.array_equal(x0,x1) and np.array_equal(y0,y1)
        assert new[r,c] == pytest.approx(old[r,c] * 1.025, abs=wb.VE_QUANTUM)
        changed_cells=np.argwhere(old != new)
        assert changed_cells.tolist() == [[r,c]]
    selective = tmp_path/'selective.htt'
    info = wb.export_speed_density_changed_tables(tune,candidate,selective)
    assert set(info['changed_tables']) == changed
    assert set(parse_htt(selective.read_bytes()).by_key()) == changed
