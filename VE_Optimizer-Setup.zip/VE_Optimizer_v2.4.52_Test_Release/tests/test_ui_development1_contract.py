"""Accepted v2.4.4 UI Development1 tests (no display required)."""
from pathlib import Path
import inspect
import ve_optimizer_revision9_review as app


def test_warning_is_initial_replaceable_state_not_fixed_widget():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.setup_message_host=None
    obj.setup_panel_message=None
    obj._set_setup_panel_message('WARNING',app.OPENING_EMISSIONS_WARNING,align='center')
    assert obj.setup_panel_message['heading']=='WARNING'
    assert obj.setup_panel_message['body']==app.OPENING_EMISSIONS_WARNING
    assert obj.setup_panel_message['align']=='center'
    obj._set_setup_panel_message('Review Prompt','Check logged channels.',align='left')
    assert obj.setup_panel_message=={'heading':'Review Prompt','body':'Check logged channels.',
                                     'align':'left','actions':(),'requires_action':True}
    assert 'Clean Air Act' not in obj.setup_panel_message['body']


def test_emissions_disclaimer_exactly_matches_approved_text():
    expected=('Modifying, removing, or disabling emissions-related components on vehicles '
              'driven on public roads is prohibited under federal law (Clean Air Act) '
              'and may violate local and/or state regulations. Any information shown here '
              'is intended for off-road or racing use only. Always follow all applicable '
              'laws and consult a licensed professional before performing vehicle modifications.')
    assert app.OPENING_EMISSIONS_WARNING==expected


def test_three_panel_shell_and_dynamic_lower_panel():
    setup=inspect.getsource(app.ReviewApp.page_setup)
    assert "lpanel.grid(row=0,column=0" in setup
    assert "rpanel.grid(row=0,column=1" in setup
    assert "lower.grid(row=1,column=0,columnspan=2" in setup
    assert "self._set_setup_panel_message('WARNING',OPENING_EMISSIONS_WARNING,align='center')" in setup
    assert "text='Processing Information'" not in setup
    assert "text='Messages / Warnings / Review'" not in setup
    assert 'self.setup_processing_active=False' in setup


def test_font_and_removed_controls():
    src=Path(app.__file__).read_text(encoding='utf-8')
    assert 'Segoe UI' not in src
    assert 'Microsoft Sans Serif' in src
    assert "text='Required Channels'" not in inspect.getsource(app.ReviewApp.page_setup)
    assert "text='Recommended Channels'" not in inspect.getsource(app.ReviewApp.page_setup)
    assert 'customer photo' not in inspect.getsource(app.ReviewApp.page_settings).lower()


def test_current_release_version_and_no_solver_edits():
    assert app.APP_VERSION=='2.4.52'
