from pathlib import Path
import json,sys,numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import ve_optimizer_processing as p

fixture=ROOT/'tests'/'fixtures'
samples,_=p.prepare_samples(fixture/'fresh_log.hpl')
net=p.htt.load_network(fixture/'stock.htt')
rows,model,p0,x=p.make_targets(samples,net)
ref=json.loads((fixture/'reference_solver_repair1.json').read_text())
primary_p=np.array(ref['candidate_coefficients'],dtype=float)
primary_y=model.forward(primary_p,x)
stock=np.array([r['stock'] for r in rows])
for row,py in zip(rows,primary_y):
    target=float(row['stock']+0.5*(float(py)-float(row['stock'])))
    row['target']=target
    if row['covered'] and row['stock']>0:
        row['correction']=100.0*(target-row['stock'])/row['stock']
result=p.fit_reduced(rows,model,p0,x,primary_p)
assert result['metrics']['qualifying_bank_issues']==0
assert result['initial_optimizer']['success'] and result['optimizer']['success']
p.require_verified_result(result)
reduced_y=model.forward(np.array(result['candidate_coefficients']),x)
primary_movement=float(np.mean(np.abs(primary_y-stock)))
reduced_movement=float(np.mean(np.abs(reduced_y-stock)))
ratio=reduced_movement/primary_movement
assert 0.45 <= ratio <= 0.60,ratio
midpoint=stock+0.5*(primary_y-stock)
assert float(np.mean(np.abs(reduced_y-midpoint))) < 0.12
print('RESULTS_REDUCTION_PASS',round(ratio,6))
