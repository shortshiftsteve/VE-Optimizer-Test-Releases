"""UI Development 3: all five user-requested changes; baseline tuning math unchanged."""
from pathlib import Path
import inspect
import tkinter as tk
from tkinter import ttk
from types import SimpleNamespace
import ve_optimizer_revision9_review as app
import ve_optimizer_boost_review as boost


def descendants(host):
    for item in host.winfo_children():
        yield item
        yield from descendants(item)


def button(host,text):
    matches=[item for item in descendants(host) if hasattr(item,'invoke') and item.cget('text')==text]
    assert matches, f'Missing visible control: {text}'
    return matches[0]


def make_panel(root):
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.root=root
    obj.setup_message_host=tk.Frame(root,bg='white')
    obj.setup_message_host.pack(fill='both',expand=True)
    obj.setup_header_label=tk.Label(obj.setup_message_host,text='PROGRESS')
    obj.setup_header_label.pack()
    obj.setup_action_view=tk.Frame(obj.setup_message_host,bg='white')
    obj.setup_progress_view=tk.Frame(obj.setup_message_host,bg='white')
    obj.setup_workflow_button=ttk.Button(root,text='Build',command=obj._invoke_setup_action,width=17)
    obj.setup_workflow_button.pack()
    obj.setup_choice_var=None;obj.setup_choice_actions={}
    obj._setup_header_mode=None;obj._setup_header_blink_after_id=None;obj._setup_header_blink_on=False
    obj._setup_verify_blink_after_id=None;obj._setup_verify_button=None
    obj.setup_panel_message=None;obj.setup_activity_state=None;obj._setup_action_command=None
    obj.current_page='setup';obj._setup_lower_mode='status';obj.running=False
    obj._setup_build_in_progress=False;obj.correction_preflight_running=False
    obj.project=None;obj.user=SimpleNamespace(role='guest')
    obj._setup_vehicle_signature=lambda:()
    obj._active_version=lambda:None
    obj.license_status=lambda:{'active':False}
    obj._render_setup_lower_view=lambda:None
    return obj


def test_installer_agreement_acknowledgement_is_exact_and_still_gated():
    root=Path(app.__file__).resolve().parent
    iss=(root/'installer'/'VE_Optimizer_v2.4.52.iss').read_text()
    assert "LicenseAcceptLabel.Caption := '   I have read and I understand the End User License Agreement';" in iss
    assert 'By selecting the acceptance checkbox' not in iss
    assert '(CurPageID = wpLicense)' in iss
    assert '(not LicenseAcceptCheck.Checked)' in iss


def test_knock_warning_is_centered_exact_text_and_no_rejects_log(monkeypatch):
    root=tk.Tk();root.geometry('1100x800')
    try:
        obj=make_panel(root)
        obj.vs_na_closed_loop_only=False
        obj.vs_log_report={'passed':False}
        obj.vs_log_valid=False
        obj.vs_log_staged=True
        obj.vs_vars={'log':tk.StringVar(value='bad_log.hpl')}
        obj._setup_lower_mode='status'
        events=[]
        obj._render_setup_lower_view=lambda:events.append('lower refreshed')
        obj._vehicle_form_update=lambda:events.append('form refreshed')
        obj._select_current_log=lambda:events.append('select a different log')
        monkeypatch.setattr(app.logcheck,'na_knock_exception_eligible',lambda report:True)
        monkeypatch.setattr(boost,'na_closed_loop_evidence',lambda *args:(True,{}))
        obj._prompt_na_closed_loop_only({'airflow_model':'neural_network'},Path('tune.htt'),Path('bad.hpl'),lambda *_:events.append('decision'))
        root.update()
        assert obj.setup_panel_message['heading']=='KNOCK DATA NOT FOUND'
        assert obj.setup_panel_message['align']=='center'
        assert obj.setup_panel_message['body']==(
            'The current log file does not include montioring knock status. '
            'Without this information, it would be too risky to attempt anything other than a closed loop tune. '
            'Wide Open Throttle, (WOT), data will not be included. '
            'Select Yes to proceed or No to select a different log file.')
        assert button(root,'Continue').instate(['disabled'])
        radios=[w for w in descendants(root) if isinstance(w,ttk.Radiobutton)]
        assert {w.cget('text') for w in radios}=={'Yes','No'}
        next(w for w in radios if w.cget('text')=='No').invoke()
        button(root,'Continue').invoke()
        root.update()
        assert 'select a different log' in events
        assert 'decision' not in events
        assert obj.vs_vars['log'].get()==''
        assert obj.setup_panel_message['heading']=='SELECT ANOTHER LOG FILE'
    finally:root.destroy()


def test_knock_yes_keeps_existing_closed_loop_gate(monkeypatch):
    root=tk.Tk()
    try:
        obj=make_panel(root)
        obj.vs_na_closed_loop_only=False
        monkeypatch.setattr(app.logcheck,'na_knock_exception_eligible',lambda report:True)
        monkeypatch.setattr(app.logcheck,'allow_na_closed_loop_only',lambda report:{'approval':'closed-loop-only'})
        monkeypatch.setattr(boost,'na_closed_loop_evidence',lambda *args:(True,{}))
        got=[]
        obj._prompt_na_closed_loop_only({'airflow_model':'neural_network'},Path('tune.htt'),Path('log.hpl'),lambda *args:got.append(args))
        next(w for w in descendants(root) if isinstance(w,ttk.Radiobutton) and w.cget('text')=='Yes').invoke()
        button(root,'Continue').invoke()
        assert obj.vs_na_closed_loop_only is True
        assert got==[({'approval':'closed-loop-only'},True)]
    finally:root.destroy()


def test_lower_processing_quality_has_no_discouraged_generic_text():
    quality=inspect.getsource(app.ReviewApp._build_run_quality_panel)
    assert 'This panel is used for every correction method' not in quality
    assert 'Values update as processing advances' not in quality
    assert "text='Processing Quality'" in quality
    assert 'self.run_quality_vars=' in quality


def test_preflight_no_longer_renders_map_review_or_correction_options_in_lower_panel():
    source=inspect.getsource(app.ReviewApp.page_preflight)
    assert "text='Review'" not in source
    assert "text='CORRECTION SOURCE'" not in source
    assert "text='Continue to Run/Review'" not in source
    assert 'Confirm hardware and MAP sensor in the upper-right message panel.' not in source
    assert 'Correction Preflight' in source
    prompt=inspect.getsource(app.ReviewApp._show_preflight_prompt)
    assert '_review_map_and_pe' not in prompt
    assert 'self._show_correction_source_message()' in prompt
    assert 'self._show_preflight_prompt()' in inspect.getsource(app.ReviewApp._run_correction_preflight)


def test_correction_source_selection_and_continue_are_in_right_panel():
    root=tk.Tk();root.geometry('1100x800')
    try:
        obj=make_panel(root)
        obj.correction_source_selection=None
        obj.correction_rescale_approved=False
        obj.current_page='setup'
        obj._setup_lower_mode='preflight'
        obj.correction_preflight_running=False
        obj.running=False
        obj.correction_preflight_cache={
            'configuration':{'airflow_model':'speed_density'},
            'choices':[{'id':'adaptive','label':'Short Term Fuel Trims (STFT)','enabled':True},
                       {'id':'wideband','label':'Wideband O2','enabled':True}],
            'sources':{'wideband':{'present':True}}}
        visited=[]
        obj.goto=lambda page:(visited.append(page),setattr(obj,'_setup_lower_mode','review'))
        obj.start_review=lambda:visited.append('start_review')
        obj.project=SimpleNamespace(id=1)
        obj._review_result_ready=lambda:False
        obj._show_correction_source_message()
        root.update()
        assert obj.setup_panel_message['heading']=='CORRECTION SOURCE'
        btn=button(root,'Continue')
        assert btn.instate(['disabled'])
        button(root,'Wideband O2').invoke();root.update()
        assert obj.correction_source_selection=='wideband'
        assert not button(root,'Continue').instate(['disabled'])
        button(root,'Continue').invoke()
        assert visited==['review','start_review']
    finally:root.destroy()


def test_map_review_priority_and_source_selection_after_confirmation():
    root=tk.Tk()
    try:
        obj=make_panel(root)
        obj._correction_context=lambda:('new','tune','log')
        obj.boost_review_approval_context=None
        obj.correction_source_selection=None
        obj.correction_preflight_cache={
            'hardware_review_pending':True,
            'engine_review':{'pressure_exceeds_baro':True,'boost_review_required':True,'tune':{},'map_source':{}},
            'choices':[{'id':'adaptive','enabled':True,'label':'STFT'}]}
        obj._show_preflight_prompt()
        assert obj.setup_panel_message['heading']=='CORRECTION SOURCE'
        obj.boost_review_approval_context=('new','tune','log')
        obj.correction_preflight_cache['hardware_review_pending']=False
        obj._show_preflight_prompt()
        assert obj.setup_panel_message['heading']=='CORRECTION SOURCE'
    finally:root.destroy()
