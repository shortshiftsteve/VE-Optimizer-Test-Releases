"""v2.4.5 Review duplicate-name HPL channel resolution regression.

A Scanner log may repeat a signal under distinct native HPL channel indices.
Such repetition must not be mistaken for duplicate *binary channel indices*.
"""
from pathlib import Path
import sys
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integration


def _rpm_duplicate_log(*, conflicting=False, primary_update_count=120):
    channels = {
        0: {'name': 'Engine RPM', 'unit': 'rpm', 'parameter_id': 2135},
        2: {'name': 'Engine RPM', 'unit': 'rpm', 'parameter_id': 2135},
        3: {'name': 'Engine RPM', 'unit': 'rpm', 'parameter_id': 2135},
        4: {'name': 'Actual Torque', 'unit': 'lb-ft', 'parameter_id': 2706},
        5: {'name': 'MAP - Hi-Res', 'unit': 'kPa', 'parameter_id': 2335},
        6: {'name': 'Barometric Pressure', 'unit': 'kPa', 'parameter_id': 2410},
        7: {'name': 'Engine Coolant Temp', 'unit': 'deg F', 'parameter_id': 2124},
        8: {'name': 'Short Term Fuel Trim Bank 1 (SAE)', 'unit': '%', 'parameter_id': 6},
        9: {'name': 'Short Term Fuel Trim Bank 2 (SAE)', 'unit': '%', 'parameter_id': 8},
    }
    frames = []
    for tick in range(primary_update_count):
        v = 1800.0 + 5.0 * tick
        updates = {0: v, 4: 30.0, 5: 85.0, 6: 100.0,
                   7: 190.0, 8: 2.0, 9: -1.0}
        if tick % 5 == 0:
            updates[2] = (v + 1000.0) if conflicting else v
        frames.append({'timestamp_ms': tick * 10, 'updates': updates})
    return {'channels': channels, 'frames': frames}


def test_duplicate_name_resolution_uses_populated_primary_without_event_merge():
    d = _rpm_duplicate_log()
    assert wb._resolve_optional_name(d['channels'], 'Engine RPM', decoded=d) == 0
    assert wb._resolve_optional_name(d['channels'], 'Engine RPM', decoded=d) == 0
    # Duplicate channels neither fabricate nor multiply STFT events.
    status = wb._adaptive_trim_status(d, 'speed_density')
    assert status['valid']
    assert status['accepted_events_bank1'] == 120
    assert status['accepted_events_bank2'] == 120
    assert wb._resolve_first_available(d['channels'], ('Engine RPM',), decoded=d) == (0, 'Engine RPM')


def test_conflicting_duplicate_rpm_is_rejected_not_silently_selected():
    d = _rpm_duplicate_log(conflicting=True)
    with pytest.raises(ValueError, match='Conflicting duplicate HPL.*Engine RPM'):
        wb._resolve_optional_name(d['channels'], 'Engine RPM', decoded=d)


def test_no_data_in_redundant_names_does_not_block_good_signal():
    d = _rpm_duplicate_log()
    del d['channels'][2]
    assert wb._resolve_optional_name(d['channels'], 'Engine RPM', decoded=d) == 0


def test_metadata_only_duplicate_cannot_guess_a_channel():
    d = _rpm_duplicate_log()
    with pytest.raises(ValueError, match='requires populated HPL'):
        wb._resolve_optional_name(d['channels'], 'Engine RPM')


def test_duplicate_units_conflict_is_not_silently_ignored():
    d = _rpm_duplicate_log()
    d['channels'][2]['unit'] = 'km/h'
    with pytest.raises(ValueError, match='Incompatible units.*Engine RPM'):
        wb._resolve_optional_name(d['channels'], 'Engine RPM', decoded=d)


def test_integration_uses_same_duplicate_resolution_as_adaptive_preflight():
    d = _rpm_duplicate_log()
    import numpy as np
    rpm = np.array([0.0, 2500.0, 6000.0]); pr = np.array([0.3, 0.85, 1.5]); z=np.ones((3,3))
    with patch.object(wb, 'decode_hpl', return_value=d), \
         patch.object(wb, 'parse_ve_table', return_value=(b'fake',rpm,pr,z)):
        result = integration._adaptive_sd_analysis(Path('dummy.hpl'), Path('dummy.htt'))
    assert result['trim_mode'] == 'stft_only'
    assert int(result['hit_counts'].sum()) == 240


def test_duplicate_metadata_is_not_a_duplicate_hpl_index():
    from hpl_decoder_v1_0_0 import HplDecodeError
    d = _rpm_duplicate_log()
    assert len({idx for idx, c in d['channels'].items() if c['name']=='Engine RPM'}) == 3
    assert len(d['channels']) == len(set(d['channels']))


def test_temperature_duplicate_with_equivalent_f_and_c_units():
    d = _rpm_duplicate_log()
    d['channels'][10] = {'name': 'Engine Coolant Temp', 'unit': 'deg C', 'parameter_id': 2124}
    for i, f in enumerate(d['frames']):
        if i % 5 == 0:
            f['updates'][10] = (190.0 - 32.0) / 1.8
    assert wb._resolve_optional_name(d['channels'], 'Engine Coolant Temp', decoded=d) == 7


def test_real_trackhawk_log_duplicate_resolution_if_attached():
    from hpl_decoder_v1_0_0 import decode_hpl
    log = Path('/mnt/data/Re-save rev04-TCM_PCM-second-drive+O2.hpl')
    tune = Path('/mnt/data/Tuned 6.2L Trackhawk (Hellcat).htt')
    if not log.exists() or not tune.exists():
        pytest.skip('User-supplied Trackhawk log/tune not mounted')
    d = decode_hpl(log)
    rpm = wb._resolve_optional_name(d['channels'], wb.RPM_NAME, decoded=d)
    assert d['channels'][rpm]['parameter_id'] == 2135
    assert wb._adaptive_trim_status(d, 'speed_density')['valid']
    sources = wb.inspect_correction_sources(log, airflow_model='speed_density')
    assert sources['adaptive']['valid']
    pressure = wb.airflow_map_preflight(log, tune)
    # Duplicate channel resolution succeeds; RPM exceeding the last TMAP
    # multiplier breakpoint is informational, since stock factory tunes do so.
    assert pressure['map_channel']
    assert pressure['sensed_map_enable']=='Disabled'
    assert pressure['blocking'] is False
    assert pressure['throttle_based_map_multiplier']['rpm_endpoint_advisory']
    assert any('6259 RPM' in item for item in pressure['warnings'])
