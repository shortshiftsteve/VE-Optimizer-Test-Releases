"""Development 6: nonblocking V1 Build, duplicate-click protection and final Run action.

The heavy HPL worker is substituted in these UI tests; calibration processing
and HP Tuners outputs are not modified by these tests.
"""
from __future__ import annotations

import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
import tkinter as tk
from tkinter import ttk

import ve_optimizer_revision9_review as app


def find_buttons(parent, label):
    found=[]
    def walk(item):
        for child in item.winfo_children():
            if isinstance(child,ttk.Button) and child.cget('text')==label:
                found.append(child)
            walk(child)
    walk(parent)
    return found


@pytest.fixture
def ui(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1250x850')
    inst=app.ReviewApp(root,tmp_path/'test.db',Path(app.__file__).resolve().parent/'a')
    inst.user=inst.db.single_user_identity()
    inst.shell();inst.goto('setup');root.update()
    try:
        yield root,inst
    finally:
        try:
            if inst.setup_activity_bar is not None:inst.setup_activity_bar.stop()
            inst.db.close()
        finally:
            root.destroy()


def mock_version_one(monkeypatch,ui):
    """Create a read-only UI fixture; its worker is isolated in each test."""
    root,inst=ui
    inst.project=SimpleNamespace(id=42)
    inst.active_version_no=1
    inst.vs_vars['year'].set('2023')
    inst.vs_vars['model'].set('Dodge Challenger')
    inst.vs_vars['engine'].set('5.7L Hemi')
    inst.vs_vars['transmission'].set('Auto')
    inst.vs_vars['log'].set('/fixture/big-v1.hpl')
    inst.vs_log_staged=False
    inst.vs_log_valid=True
    inst.vs_log_report={'passed':True}
    version={'version_no':1,'run_completed':0,
             'baseline_htt_path':'/fixture/V1/Baseline.htt','log_source_path':''}
    monkeypatch.setattr(inst,'_active_version',lambda:version)
    monkeypatch.setattr(inst.db,'latest_version',lambda _pid:version)
    inst._setup_verified_signature=inst._setup_vehicle_signature()
    inst._vehicle_form_update()
    root.update()
    return inst


def test_v1_build_double_click_queues_exactly_one_worker_and_restores_after_error(ui,monkeypatch):
    root,inst=ui
    mock_version_one(monkeypatch,ui)
    queued=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda work,done:queued.append((work,done)))
    inst._save_vehicle_setup()
    assert inst._setup_build_in_progress is True
    assert inst.vs_save.instate(['disabled'])
    assert inst.vs_log_button.instate(['disabled'])
    assert inst.setup_activity_state['busy'] is True
    inst._save_vehicle_setup()
    assert len(queued)==1,'Second Build would start another HPL assignment'
    queued[0][1](('err',None,'Simulated failure while copying a large log'))
    root.update()
    assert inst._setup_build_in_progress is False
    assert inst.setup_panel_message['heading']=='Project Setup Error'
    assert inst.setup_activity_state['error'] is True
    inst._save_vehicle_setup()
    assert len(queued)==2,'Build should become usable again after failure'
    queued[1][1](('err',None,'Release guard'))


def test_initial_build_also_has_single_flight_guard(ui,monkeypatch):
    _root,inst=ui
    inst.project=None
    inst.vs_vars['htt'].set('/fixture/original.htt')
    inst.vs_vars['log'].set('/fixture/original.hpl')
    inst._setup_verified_signature=inst._setup_vehicle_signature()
    queued=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda task,done:queued.append((task,done)))
    inst._save_vehicle_setup()
    inst._save_vehicle_setup()
    assert len(queued)==1
    queued[0][1](('err',None,'Initial project test cleanup'))
    assert inst._setup_build_in_progress is False


def test_long_v1_log_operation_runs_off_ui_thread_and_main_window_keeps_pumping(ui,monkeypatch):
    root,inst=ui
    mock_version_one(monkeypatch,ui)
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda task,done:jobs.append((task,done)))
    inst._save_vehicle_setup()
    assert len(jobs)==1
    task,done=jobs[0]
    was_started=threading.Event()
    release=threading.Event()
    called=[]

    class FakeConnection:
        def execute(self,*args):called.append(('sql',threading.current_thread().name))
        def commit(self):pass

    class FakeWorkerDB:
        def __init__(self,_path):self.conn=FakeConnection()
        def get_version(self,_pid,_vn):return {'log_source_path':''}
        def assign_version_log(self,*args,**kwargs):
            called.append(('assign_version_log',threading.current_thread().name))
            was_started.set()
            assert release.wait(timeout=5),'Timed out waiting for the main thread to release the test worker'
        def close(self):pass

    monkeypatch.setattr(app,'ReviewDatabase',FakeWorkerDB)
    output=[]
    worker=threading.Thread(target=lambda:output.append(task()),name='LargeLogWorker',daemon=True)
    worker.start()
    assert was_started.wait(timeout=2)
    # The application can still dispatch scheduled UI work during a long log
    # assignment.  In Development 5, this operation ran synchronously on Tk.
    ticks=[]
    root.after(15,lambda:ticks.append('tk alive'))
    stop=time.monotonic()+0.18
    while time.monotonic()<stop:
        root.update()
        time.sleep(.01)
    assert ticks==['tk alive']
    assert inst._setup_build_in_progress is True
    assert inst.setup_activity_state['busy'] is True
    assert worker.is_alive()
    release.set();worker.join(timeout=2)
    assert output==[('ok',42,'')]
    assert ('assign_version_log','LargeLogWorker') in called
    # The result handler is exclusively dispatched on Tk's main thread.
    monkeypatch.setattr(inst.db,'get_project',lambda _pid:SimpleNamespace(id=42))
    moved=[]
    monkeypatch.setattr(inst,'shell',lambda:moved.append('shell'))
    monkeypatch.setattr(inst,'goto',lambda page:moved.append(page))
    done(output[0])
    assert moved==['shell','preflight']
    assert inst._setup_build_in_progress is False


def test_final_correction_choice_has_one_run_button_that_starts_processing(ui,monkeypatch):
    root,inst=ui
    inst.current_page='setup'
    inst.project=SimpleNamespace(id=77)
    inst._setup_lower_mode='preflight'
    inst.correction_preflight_running=False
    inst.running=False
    inst.correction_source_selection='wideband'
    inst.correction_preflight_cache={
        'configuration':{'airflow_model':'speed_density'},
        'choices':[{'id':'adaptive','label':'Short Term Fuel Trims (STFT)','enabled':True},
                   {'id':'wideband','label':'Wideband O2','enabled':True}],
        'sources':{'wideband':{'present':True}}}
    monkeypatch.setattr(inst,'_review_source_block_reason',lambda:None)
    calls=[]
    def goto(page):
        calls.append(('goto',page))
        inst._setup_lower_mode='review'
    def start_review():
        calls.append(('start_review',None))
        inst.running=True
    monkeypatch.setattr(inst,'goto',goto)
    monkeypatch.setattr(inst,'start_review',start_review)
    inst._show_correction_source_message();root.update()
    buttons=find_buttons(inst.setup_primary_actions,'Continue')
    assert len(buttons)==1 and buttons[0] is inst.setup_workflow_button
    assert not find_buttons(inst.setup_message_host,'Run')
    assert not find_buttons(inst.setup_message_host,'Continue to Run/Review')
    buttons[0].invoke();buttons[0].invoke()
    assert calls==[('goto','review'),('start_review',None)]


def test_final_run_is_not_offered_without_a_valid_source(ui):
    root,inst=ui
    inst.project=SimpleNamespace(id=78)
    inst._setup_lower_mode='preflight'
    inst.correction_source_selection=None
    inst.correction_preflight_cache={
        'configuration':{'airflow_model':'speed_density'},
        'choices':[{'id':'adaptive','label':'STFT','enabled':False},
                   {'id':'wideband','label':'Wideband O2','enabled':False}],
        'sources':{'wideband':{'present':True}}}
    inst._show_correction_source_message();root.update()
    assert not find_buttons(inst.setup_primary_actions,'Continue')  # no qualified source
    assert inst.setup_workflow_button.cget('text')=='Refresh Preflight'
    assert not inst.setup_workflow_button.instate(['disabled'])  # safe retry remains possible


def test_run_not_blocked_by_obsolete_hardware_review_flag(ui,monkeypatch):
    root,inst=ui
    inst.project=SimpleNamespace(id=79)
    inst._setup_lower_mode='preflight'
    inst.correction_source_selection='wideband'
    inst.correction_preflight_cache={
        'hardware_review_pending':True,
        'configuration':{'airflow_model':'speed_density'},
        'choices':[{'id':'wideband','label':'Wideband O2','enabled':True}],
        'sources':{'wideband':{'present':True}}}
    inst._show_correction_source_message();root.update()
    run=find_buttons(inst.setup_primary_actions,'Continue')[0]
    assert not find_buttons(inst.setup_message_host,'Run')
    assert not run.instate(['disabled'])
    assert inst._review_source_block_reason() is None
    assert 'Confirm boosted hardware' not in inst.setup_panel_message['body']
