"""Method B: calibrated 0..Maximum RPM and full MAP1 range, never MAP2/log peak."""
from __future__ import annotations

import math
import struct
from dataclasses import replace
from pathlib import Path

import numpy as np
import pytest

import ve_optimizer_stage3 as s3
import ve_optimizer_wideband as wb
from ve_optimizer_htt_codec import HEADER, FOOTER, HTTDocument, HTTRecord, build_htt, parse_htt


def _minimal_sd_tune(path: Path, *, rpm_max=6000.0, slope1=21.46,
                     include_map1=True, enabled=False):
    def switch(k, value):
        raw = value.encode("ascii")
        return HTTRecord("switch", k, struct.pack("<HH", k, 0) + s3._encode_uleb128(len(raw)) + raw)

    def scalar(k, value):
        return HTTRecord("scalar", k, struct.pack("<HHdB", k, 0, float(value), 0))

    def table(k, bank):
        rpms = np.array([416,608,800,992,1184,1376,1664,1952,2240,2976,3616,4016,4416,4768,5216,5600,5984], float)
        prs = np.array([0.150390625,0.2001953125,0.25,0.2998046875,0.349609375,0.400390625,0.4501953125,0.5,0.5498046875,0.599609375,0.650390625,0.7001953125,0.75,0.7998046875,0.849609375,0.900390625,1.0],float)
        lines = ["%\t" + "\t".join(str(int(r)) for r in rpms) + "\trpm"]
        for j, pr in enumerate(prs):
            vals = [
                round((43.0 + 2.0*bank + 0.003*float(rpm) + 8.0*float(pr) + 0.008 * j * ((i % 3)-1)) / wb.VE_QUANTUM)*wb.VE_QUANTUM
                for i, rpm in enumerate(rpms)
            ]
            lines.append(str(pr) + "\t" + "\t".join(str(v) for v in vals))
        payload = ("\r\n".join(lines) + "\r\n").encode()
        return HTTRecord("table",k,struct.pack("<HH",k,0) + s3._encode_uleb128(len(payload)) + payload + b"\x00\x00")

    scalars = [
        scalar(wb.MAXIMUM_RPM_SCALAR,rpm_max), scalar(44483,5500),
        scalar(44489,6100),scalar(44299,3600),scalar(3396,7000),
        scalar(wb.MAP2_LINEAR_SCALAR,61.85),scalar(wb.MAP2_OFFSET_KPA_SCALAR,6.8),
        scalar(wb.MAP2_OFFSET_V_SCALAR,0.1),
    ]
    if include_map1:
        scalars.extend([
            scalar(wb.MAP1_LINEAR_SCALAR,slope1),scalar(wb.MAP1_OFFSET_KPA_SCALAR,7),
            scalar(wb.MAP1_OFFSET_V_SCALAR,0.09768009768009768),
        ])
    scalars.sort(key=lambda r:r.key)
    document = HTTDocument(HEADER, (switch(wb.USE_NEURAL_NETWORK_SWITCH,"Enabled" if enabled else "Disabled"),),
                           tuple(scalars),(table(wb.VE_BANK1_TABLE,0),table(wb.VE_BANK2_TABLE,1)),FOOTER)
    path.write_bytes(build_htt(document))
    return path


def test_method_b_domain_uses_only_map1_and_maximum_rpm(tmp_path):
    source = _minimal_sd_tune(tmp_path/"source.htt")
    domain = wb.speed_density_axis_preflight(source)
    assert domain["rpm_source_record"] == 44490
    assert domain["recommended_rpm_min"] == 0.0
    assert domain["recommended_rpm_max"] == 6000.0  # not 5500, 6100 or 7000
    assert domain["recommended_pratio_min"] == pytest.approx((7-21.46*0.09768009768009768)/101.325)
    assert domain["recommended_pratio_max"] == pytest.approx((7+21.46*(5-0.09768009768009768))/101.325)
    assert domain["recommended_pratio_max"] < 1.2  # MAP2 is a 3-bar calibration; ignored
    assert (domain["proposed_rpm_axis"].size,domain["proposed_pratio_axis"].size) == (17,17)
    assert domain["needs_rescale"] and domain["rpm_rescale_required"] and domain["pratio_rescale_required"]


def test_rescale_both_banks_only_preserve_shape_and_htt_scope(tmp_path):
    original = _minimal_sd_tune(tmp_path/"in.htt")
    candidate = tmp_path/"scaled.htt"
    res = wb.rescale_speed_density_axes(original,candidate)
    assert res["scope_verified"] and res["rpm_rescaled"] and res["pratio_rescaled"]
    assert res["new_rpm_min"] == 0 and res["new_rpm_max"] == 6000
    assert res["new_pratio_max"] > 1.10
    assert res["old_rpm_min"] == 416 and res["old_rpm_max"] == 5984
    assert res["original_table_shape"] == res["new_table_shape"] == [17,17]
    a,b = parse_htt(original.read_bytes()),parse_htt(candidate.read_bytes())
    changed = {k for k in a.by_key() if a.by_key()[k].raw != b.by_key()[k].raw}
    assert changed == {wb.VE_BANK1_TABLE,wb.VE_BANK2_TABLE}
    assert wb.speed_density_axis_preflight(candidate)["needs_rescale"] is False
    result = wb.export_speed_density_changed_tables(original,candidate,tmp_path/"template.htt")
    assert set(result["changed_records"]) == changed
    assert set(parse_htt((tmp_path/"template.htt").read_bytes()).by_key()) == changed
    second = tmp_path/"again.htt"
    rr = wb.rescale_speed_density_axes(candidate,second)
    assert rr["changed"] is False
    assert candidate.read_bytes() == second.read_bytes()


def test_domain_does_not_depend_on_log_peak_or_wideband_availability(tmp_path):
    source = _minimal_sd_tune(tmp_path/"stock.htt")
    analysis = {"airflow_model":"speed_density","tune_path":str(source),
                "accepted_samples":[{"rpm":1300.,"pratio":0.5}],"outside_domain_samples":[]}
    result = wb.speed_density_domain_preflight(analysis)
    assert result["needs_rescale"]
    assert result["observed_rpm_max"] == 1300.0
    assert result["recommended_rpm_max"] == 6000.0
    assert result["recommended_pratio_max"] > 1.1
    analysis["accepted_samples"] = []
    assert wb.speed_density_domain_preflight(analysis)["needs_rescale"] is True


def test_user_changes_maximum_rpm_and_map1_not_other_limits(tmp_path):
    a = wb.speed_density_axis_preflight(_minimal_sd_tune(tmp_path/"sd1.htt",rpm_max=6000))
    b = wb.speed_density_axis_preflight(_minimal_sd_tune(tmp_path/"sd2.htt",rpm_max=6700,slope1=61.85))
    assert a["recommended_rpm_max"] == 6000
    assert b["recommended_rpm_max"] == 6700
    assert b["recommended_pratio_max"] > 3.0
    assert a["recommended_pratio_max"] < 1.2


def test_missing_map1_must_not_fallback_to_map2(tmp_path):
    source = _minimal_sd_tune(tmp_path/"missing_map1.htt",include_map1=False)
    output = tmp_path/"do_not_generate.htt"
    with pytest.raises(ValueError,match="MAP1"):
        wb.rescale_speed_density_axes(source,output)
    assert not output.exists()


def test_no_method_b_changes_when_nn_is_enabled(tmp_path):
    source = _minimal_sd_tune(tmp_path/"nn.htt",enabled=True)
    with pytest.raises(ValueError,match="Neural Network disabled"):
        wb.speed_density_axis_preflight(source)
    with pytest.raises(ValueError,match="Neural Network disabled"):
        wb.rescale_speed_density_axes(source,tmp_path/"no_output.htt")
    assert not (tmp_path/"no_output.htt").exists()


def test_rescaler_does_not_overwrite_original(tmp_path):
    source = _minimal_sd_tune(tmp_path/"original.htt")
    data = source.read_bytes()
    with pytest.raises(ValueError,match="overwrite"):
        wb.rescale_speed_density_axes(source,source)
    assert source.read_bytes() == data


def test_integration_uses_calibration_scaler(tmp_path):
    from ve_optimizer_wideband_integration import _scale_sd_if_needed
    source = _minimal_sd_tune(tmp_path/"stock.htt")
    path,result = _scale_sd_if_needed(source,tmp_path)
    assert result["map_source"] == "MAP1"
    assert result["rpm_source_record"] == 44490
    assert path != source and path.exists()
    path2,result2 = _scale_sd_if_needed(path,tmp_path)
    assert path2 == path and result2 is None
