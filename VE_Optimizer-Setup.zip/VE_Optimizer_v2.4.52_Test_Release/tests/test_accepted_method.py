"""Boundary and integration tests. Reference files are supplied explicitly.

python tests/test_accepted_method.py --log native.hpl --baseline stock.htt
    --reference reference_solver_repair1.json --output TEST_OUTPUT
"""
from pathlib import Path
import sys,os,tempfile,json,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import ve_optimizer_processing as p
import ve_optimizer_revision9_review as app
import ve_optimizer_surface as surf


def boundary_tests(net):
    def samples(n1,n2,t1,t2):
        out=[]
        for bank,count,total in [(1,n1,t1),(2,n2,t2)]:
            for i in range(count):out.append(dict(Bank=bank,Time_s=i,RPM=1926,MAP_kPa=38,Baro_kPa=100,PRatio=.38,Torque_lbft=10,Coolant_F=200,FuelFlow_lbh=5,FA_Enrichment=0,FA_PowerEnrichment=0,LTFT_pct=total,STFT_pct=0,CellIndex=106,IntakeCam_deg=143.5,ExhaustCam_deg=85))
        return out
    cases=[(5,4,-8,12,-8),(4,5,12,-8,-8),(5,5,-8,12,12),(5,5,-8,-3,-3),(5,0,-8,0,-8),(0,5,0,-8,-8),(4,4,20,20,None),(5,5,0,-2,0),(5,5,.2,-.2,.2),(5,5,45,42,45)]
    for n1,n2,t1,t2,expected in cases:
        rows,_,_,_=p.make_targets(samples(n1,n2,t1,t2),net);r=rows[106]
        assert r['full_correction']==expected,(n1,n2,t1,t2,r)
        assert r['covered']==(expected is not None)
        assert r['target']==r['stock']*(1+.5*expected/100) if expected is not None else r['target']==r['stock']
    # Retain a reverse change when qualifying bank estimates remain nonpositive.
    r=dict(stock=100.,target=98.,fitted=101.,covered=True,n1=5,n2=5,total1=-8.,total2=-4.)
    m=p.review([r]);assert m['qualifying_bank_issues']==0 and m['reverse_qualified_cells']==1
    r['fitted']=95.;assert p.review([r])['qualifying_bank_issues']==1
    r.update(total1=2.,total2=-8.,target=101.,fitted=99.);assert p.review([r])['qualifying_bank_issues']==1
    r.update(n1=4,n2=5,total1=99.,total2=-8.,target=96.,fitted=96.);assert p.review([r])['qualifying_bank_entries']==1
    return len(cases)+4



def chart_project_isolation_tests(out):
    """A project/version switch must load that version's own Run Review chart."""
    chart_dir=out/'chart_isolation';chart_dir.mkdir(parents=True,exist_ok=True)
    def sample(total):
        return dict(Bank=1,Time_s=0,RPM=p.RPM[0],MAP_kPa=14,Baro_kPa=100,PRatio=p.PR[0],Torque_lbft=10,Coolant_F=200,FuelFlow_lbh=5,FA_Enrichment=0,FA_PowerEnrichment=0,LTFT_pct=total,STFT_pct=0,CellIndex=0,IntakeCam_deg=143.5,ExhaustCam_deg=85)
    csv_a=chart_dir/'A.csv';csv_b=chart_dir/'B.csv'
    p.write_samples(csv_a,[dict(sample(-5),Time_s=i) for i in range(5)])
    p.write_samples(csv_b,[dict(sample(7),Time_s=i) for i in range(5)])
    def preview(csv_path,name):
        pj=chart_dir/f'{name}.json';pj.write_text(json.dumps({'method_id':p.METHOD_ID,'accepted_csv':str(csv_path),'accepted_sha256':app.s5.sha256_file(csv_path)}));return pj
    va={'run_completed':0,'accepted_csv_path':'','preview_json_path':str(preview(csv_a,'A'))}
    vb={'run_completed':0,'accepted_csv_path':'','preview_json_path':str(preview(csv_b,'B'))}
    sa=app.stored_run_trim_chart_snapshot(va);sb=app.stored_run_trim_chart_snapshot(vb)
    assert sa['cells'][(0,0)]==-5.0 and sb['cells'][(0,0)]==7.0 and sa!=sb
    ca={'run_completed':1,'accepted_csv_path':str(csv_a),'preview_json_path':''}
    cb={'run_completed':1,'accepted_csv_path':str(csv_b),'preview_json_path':''}
    assert app.stored_run_trim_chart_snapshot(ca)['cells'][(0,0)]==-5.0
    assert app.stored_run_trim_chart_snapshot(cb)['cells'][(0,0)]==7.0
    return 4

def integration(log,baseline,reference,out):
    out.mkdir(parents=True,exist_ok=True);os.environ['LOCALAPPDATA']=str(out/'local_appdata')
    original_log=app.s5.sha256_file(log);original_tune=app.s5.sha256_file(baseline)
    db=app.ReviewDatabase(out/'test.db');user=db.authenticate('admin','admin');assert user
    project=db.create_initial_project(user.id,'Accepted_Method_Test',2023,'Dodge Challenger','','5.7L','Auto',baseline,log)
    assert db.project_state(project.id,0)['state']=='READY_TO_RUN'
    # A pending legacy preview cannot enter the new workflow.
    old=out/'legacy_preview.json';old.write_text(json.dumps({'levels':{'100':{}}}))
    db.conn.execute('UPDATE project_versions SET preview_ready=1,preview_json_path=? WHERE project_id=?',(str(old),project.id));db.conn.commit()
    assert db.project_state(project.id,0)['state']=='READY_TO_RUN'
    try:app.apply_candidate_result(db,project.id,user.id,0,ROOT/'a')
    except ValueError as e:assert 'accepted processing method' in str(e)
    else:raise AssertionError('Legacy preview was accepted')
    review=app.execute_review(db,project.id,user.id,ROOT/'a',progress=lambda pct,step,msg:print(step,int(pct),flush=True),version_no=0)
    assert review['state']['state']=='READY_TO_APPLY'
    payload=json.loads(Path(review['preview_json']).read_text());assert list(payload['levels'])==['50']
    level=payload['levels']['50'];result=json.loads(Path(level['processing_result']).read_text())
    ref=json.loads(reference.read_text())
    for a,b in zip(result['rows'],ref['rows']):
        for key in ['stock','target','n1','n2','total1','total2','covered','fitted']:assert a[key]==b[key],(key,a,b)
    assert result['candidate_coefficients']==ref['candidate_coefficients']
    assert result['metrics']['qualifying_bank_issues']==0
    assert result['initial_optimizer']['success'] and result['optimizer']['success']
    p.require_verified_result(result)
    assert result['preparation']['accepted_bank_samples']==[7029,7026]
    full=Path(level['candidate_htt']);export=Path(level['export_htt'])
    for file in [full,export]:assert p.coefficients(p.htt.load_network(file)).tolist()==ref['candidate_coefficients']
    # Full template must be byte-identical outside the six normal NN payloads.
    def outside(blob):
        ranges=sorted((p.htt._find_length_payload(blob,k)[1],p.htt._find_length_payload(blob,k)[3]) for k in p.htt.NN_KEYS.values());parts=[];cursor=0
        for a,b in ranges:parts.append(blob[cursor:a]);cursor=b
        parts.append(blob[cursor:]);return parts
    assert outside(baseline.read_bytes())==outside(full.read_bytes())
    assert p.htt.load_network(baseline)['meta']==p.htt.load_network(full)['meta']
    surfaces=surf.build_display_maps(baseline,full)
    for i in range(5):
        values=[v for row in surfaces[f'pair{i+1}']['new'] for v in row];assert values==[r['fitted'] for r in ref['rows'][400*i:400*(i+1)]]
    # Results view is the cell-by-cell arithmetic mean of all five accepted cam surfaces.
    combined=surfaces['combined']['new']
    for r in range(20):
        for c in range(20):
            expected=sum(surfaces[f'pair{i+1}']['new'][r][c] for i in range(5))/5.0
            assert combined[r][c]==expected,(r,c,combined[r][c],expected)
    chart=app.run_trim_chart_snapshot(Path(payload['accepted_csv']));assert chart['sample_count']==14055
    assert app.build_it_application_gate(db.get_version(project.id,0),50)[0] is False
    committed=app.apply_candidate_result(db,project.id,user.id,0,ROOT/'a');assert committed['state']['state']=='READY_FOR_REVIEW'
    v=db.get_version(project.id,0);assert app.build_it_application_gate(v,50)[0]
    assert app.s5.sha256_file(Path(v['result_htt_path']))==app.s5.sha256_file(full)
    assert not str(v['result_txt_path'] or '').strip() and not str(v['result_txt_sha256'] or '').strip()
    assert not list(db.version_dir(project.id,0).glob('*_Result.txt'))
    # Drive Build It without a GUI. Licensed output is processed .htt; DEMO output is exact input .htt.
    class FakeLicense:
        def __init__(self,mode):self.mode=mode
        def status(self):return {'mode':self.mode,'active':True,'expired':False,'label':self.mode}
    ui=object.__new__(app.ReviewApp);ui.db=db;ui.user=user;ui.project=project;ui.active_version_no=0;ui.application_selected_percent=50
    ui.license=FakeLicense('licensed')
    licensed_files,licensed_mode,licensed_source=ui._build_output_files(out/'export_licensed');assert licensed_mode=='licensed' and len(licensed_files)==1
    assert licensed_files[0].suffix.lower()=='.htt' and app.s5.sha256_file(licensed_files[0])==app.s5.sha256_file(export)
    assert not list((out/'export_licensed').glob('*.txt'))
    ui.license=FakeLicense('trial')
    trial_files,trial_mode,trial_source=ui._build_output_files(out/'export_trial');assert trial_mode=='trial' and len(trial_files)==1
    assert app.s5.sha256_file(trial_files[0])==app.s5.sha256_file(export)
    ui.license=FakeLicense('demo')
    demo_files,demo_mode,demo_source=ui._build_output_files(out/'export_demo');assert demo_mode=='demo' and len(demo_files)==1
    assert demo_files[0].suffix.lower()=='.htt' and app.s5.sha256_file(demo_files[0])==original_tune
    assert demo_files[0].read_bytes()==baseline.read_bytes()
    assert not list((out/'export_demo').glob('*.txt'))
    lineage=ui._complete_build_lineage(demo_source);assert lineage['next_version_no']==1
    successor=db.get_version(project.id,1);assert successor['log_local_path']==''
    assert successor['baseline_htt_sha256']==original_tune
    assert db.project_state(project.id,1)['state']=='SETUP_REQUIRED'
    assert db.create_successor_after_build(project.id,0,user.id,baseline_source=baseline)['version_no']==1
    assert len(db.list_versions(project.id))==2
    assert app.s5.sha256_file(log)==original_log and app.s5.sha256_file(baseline)==original_tune
    summary={'status':'PASS','method_id':p.METHOD_ID,'bank_samples':[7029,7026],'qualifying_cells':260,'qualifying_bank_entries':515,'candidate_coefficients_matched':79,'exact_ve_values_matched':2000,'adverse_qualifying_bank_effects':0,'full_template_sha256':app.s5.sha256_file(full),'export_template_sha256':app.s5.sha256_file(export),'non_NN_template_bytes_preserved':True,'raw_100_never_exposed':True,'reduced_option_lazy':True,'legacy_preview_rejected':True,'apply_build_and_successor':'PASS','source_files_unchanged':True,'native_UI_Windows_HP_Tuners_vehicle_validation':'pending'}
    (out/'Validation.json').write_text(json.dumps(summary,indent=2));db.close();return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--log',type=Path,required=True);parser.add_argument('--baseline',type=Path,required=True);parser.add_argument('--reference',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    n=boundary_tests(p.htt.load_network(args.baseline));print('Boundary cases PASS',n,flush=True)
    c=chart_project_isolation_tests(args.output.resolve());print('Run Review project isolation PASS',c,flush=True)
    print(json.dumps(integration(args.log.resolve(),args.baseline.resolve(),args.reference.resolve(),args.output.resolve()),indent=2))
