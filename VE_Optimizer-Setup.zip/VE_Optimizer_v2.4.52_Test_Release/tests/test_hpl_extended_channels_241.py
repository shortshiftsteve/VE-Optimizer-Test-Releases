"""v2.4.1: native HPL channel-count and wide channel-reference regressions.

Construct miniature native-format HPL fixtures. The customer's log is not
bundled into the source/build release.
"""
import struct
import zlib

import pytest

from hpl_decoder_v1_0_0 import HplDecodeError, decode_hpl


_HEADER = b'HPT \x60\x09' + b'SS\x00\x00SYNC' + b'\x00' * 6 + b'SC' + b'\x00' * 17
assert len(_HEADER) == 39


def make_hpl(channel_ids, frames, *, extended=None):
    if extended is None:
        extended = max(channel_ids) >= 128
    directory = bytearray(struct.pack('<H', len(channel_ids)))
    for idx in channel_ids:
        directory.extend(struct.pack('<HHHdd', idx, 2135, 0x0A00, 1.0, 0.0))
        directory.extend(b'\x03RPM\x03rpm')

    native = bytearray(struct.pack('<H', len(frames)))
    for ms, events in frames:
        native.extend(ms.to_bytes(3, 'little'))
        native.append(len(events))
        for idx, value, repeat in events:
            mask = 0x8000 if extended else 0x80
            ref = idx | (mask if repeat else 0)
            native.extend(struct.pack('<H' if extended else '<B', ref))
            if not repeat:
                native.extend(struct.pack('<d', value))
    compressor = zlib.compressobj(wbits=-15)
    compressed = compressor.compress(bytes(native)) + compressor.flush()
    block = b'CDG\x00' + struct.pack('<II', len(compressed), len(native)) + compressed
    return _HEADER + directory + block


def decode_bytes(tmp_path, content):
    p = tmp_path / 'fixture.hpl'
    p.write_bytes(content)
    return decode_hpl(p)


def test_over_128_channels_wide_updates_and_repeat_values(tmp_path):
    ids = list(range(131))
    frames = [(20, [(0, 1000.0, False), (128, 2500.0, False), (130, 3500.0, False)]),
              (30, [(130, None, True), (128, 2502.5, False)]),
              (45, [(0, 1200.0, False)])]
    result = decode_bytes(tmp_path, make_hpl(ids, frames))
    assert len(result['channels']) == 131
    assert len(result['frames']) == 3
    assert [x['timestamp_ms'] for x in result['frames']] == [20, 30, 45]
    assert result['frames'][0]['updates'] == {0: 1000.0, 128: 2500.0, 130: 3500.0}
    assert result['frames'][1]['updates'] == {130: 3500.0, 128: 2502.5}
    assert result['frames'][2]['updates'] == {0: 1200.0}
    assert result['blocks'][0]['frame_count'] == 3


def test_wide_references_selected_by_channel_identifier_not_count(tmp_path):
    # Two channel definitions, but index 143 still requires two-byte updates.
    result = decode_bytes(tmp_path, make_hpl([2, 143], [
        (3, [(2, 800.0, False), (143, 1200.0, False)]),
        (4, [(143, None, True)]),
    ]))
    assert result['frames'][0]['updates'][143] == 1200.0
    assert result['frames'][1]['updates'][143] == 1200.0


def test_narrow_channel_reference_and_repeat_remain_supported(tmp_path):
    result = decode_bytes(tmp_path, make_hpl([0, 127], [
        (100, [(127, 1250.0, False), (0, 2100.0, False)]),
        (120, [(127, None, True)]),
    ]))
    assert result['frames'][0]['updates'][127] == 1250.0
    assert result['frames'][1]['updates'][127] == 1250.0


def test_extended_unknown_channel_still_rejected(tmp_path):
    with pytest.raises(HplDecodeError, match='Unknown or duplicate channel update'):
        decode_bytes(tmp_path, make_hpl([1, 130], [(100, [(143, 5.0, False)])]))


def test_extended_repeat_before_initialization_still_rejected(tmp_path):
    with pytest.raises(HplDecodeError, match='Repeat value before channel initialization'):
        decode_bytes(tmp_path, make_hpl([1, 130], [(100, [(130, None, True)])]))


def test_empty_directory_still_rejected(tmp_path):
    with pytest.raises(HplDecodeError, match='Log contains no channel definitions'):
        decode_bytes(tmp_path, make_hpl([], [(5, [])], extended=False))


def test_extended_duplicate_channel_definition_still_rejected(tmp_path):
    with pytest.raises(HplDecodeError, match='Unsupported or duplicate channel definition'):
        decode_bytes(tmp_path, make_hpl([128, 128], [(5, [])]))


def test_extended_invalid_block_still_rejected(tmp_path):
    content = make_hpl([1, 130], [(100, [(130, 1.0, False)])])
    with pytest.raises(HplDecodeError):
        decode_bytes(tmp_path, content[:-4])
