"""v2.4.51 Review: update detection, package validation, install safeguards."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from unittest.mock import patch

import ve_optimizer_updates as updates

ROOT = Path(__file__).resolve().parents[1]


def published(tag='v2.4.5', *, filename=updates.ASSET_NAME, digest=None):
    url = f'https://github.com/{updates.REPOSITORY}/releases/download/{tag}/{filename}'
    return {'tag_name': tag, 'draft': False, 'prerelease': False,
            'assets': [{'name': filename, 'browser_download_url': url,
                        **({'digest': digest} if digest else {})}]}


class WebResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class UpdateTests(unittest.TestCase):
    def test_version_comparison_is_numeric_with_optional_v(self):
        self.assertTrue(updates.newer_than('2.4.51', 'v2.4.5'))
        self.assertTrue(updates.newer_than('v2.4.100', '2.4.51'))
        self.assertFalse(updates.newer_than('v2.4.5', '2.4.5.0'))
        self.assertFalse(updates.newer_than('v2.4.9', '2.4.51'))
        self.assertTrue(updates.newer_than('2.4.51', '2.4.5'))
        with self.assertRaises(updates.UpdateError):
            updates.newer_than('2.4.51-rc1', '2.4.5')
        with self.assertRaises(updates.UpdateError):
            updates.newer_than('v2.4', '2.4.5')

    def test_release_metadata_accepts_specified_github_asset(self):
        r = updates.parse_release(published(tag='2.4.51'))
        self.assertEqual(r.version, '2.4.51')
        self.assertEqual(r.asset_url,
                         f'https://github.com/{updates.REPOSITORY}/releases/download/2.4.51/{updates.ASSET_NAME}')
        self.assertIsNone(r.sha256)

    def test_release_metadata_has_single_asset_and_no_prerelease_or_draft(self):
        for payload in (dict(published(), prerelease=True), dict(published(), draft=True),
                        dict(published(), assets=[]), dict(published(), assets=[published()['assets'][0]]*2),
                        published(filename='Unknown.zip')):
            with self.subTest(payload=payload), self.assertRaises(updates.UpdateError):
                updates.parse_release(payload)

    def test_release_asset_url_cannot_change_publisher(self):
        item = published()
        item['assets'][0]['browser_download_url'] = 'https://example.com/installer.zip'
        with self.assertRaises(updates.UpdateError):
            updates.parse_release(item)

    def test_latest_metadata_uses_github_releases_api(self):
        seen = []
        def opener(req, timeout):
            seen.append(req.full_url)
            return WebResponse(json.dumps(published()).encode('utf-8'))
        info = updates.fetch_latest_release(opener=opener)
        self.assertEqual(info.version, '2.4.5')
        self.assertEqual(seen, [updates.LATEST_API])

    @staticmethod
    def zipped(version, *, extra_exe=False, malformed_name=False):
        memory = io.BytesIO()
        with zipfile.ZipFile(memory, 'w', zipfile.ZIP_DEFLATED) as out:
            name = ('unexpected.exe' if malformed_name
                    else updates.filename_for_version(version))
            out.writestr('release/' + name, b'MZ' + b'VESIGNED' * 16)
            out.writestr('README.txt', b'Customer installer package.')
            if extra_exe:
                out.writestr('setup2.exe', b'BAD')
        return memory.getvalue()

    def test_download_extraction_uses_versioned_filename_and_digest(self):
        binary = self.zipped('2.4.51')
        info = updates.parse_release(published('2.4.51', digest='sha256:' + hashlib.sha256(binary).hexdigest()))
        with tempfile.TemporaryDirectory() as d:
            out = updates.download_installer(info, Path(d), opener=lambda *a, **k: WebResponse(binary))
            self.assertEqual(out.name, 'VE Optimizer v2.4.51 Release Setup.exe')
            self.assertTrue(out.read_bytes().startswith(b'MZ'))

    def test_hash_mismatch_fails_closed(self):
        binary = self.zipped('2.4.51')
        info = updates.parse_release(published('2.4.51', digest='sha256:'+'0'*64))
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(updates.UpdateError, 'SHA-256'):
                updates.download_installer(info, Path(d), opener=lambda *a, **k: WebResponse(binary))
            self.assertFalse(list(Path(d).glob('*.exe')))

    def test_zip_rejects_wrong_version_other_exe_and_unsafe_path(self):
        info = updates.parse_release(published('2.4.51'))
        samples = [self.zipped('2.4.5'), self.zipped('2.4.51', extra_exe=True),
                   self.zipped('2.4.51', malformed_name=True)]
        malicious = io.BytesIO()
        with zipfile.ZipFile(malicious, 'w') as out:
            out.writestr('../bad.txt', 'BAD')
            out.writestr(updates.filename_for_version('2.4.51'), 'MZ')
        samples.append(malicious.getvalue())
        for n,binary in enumerate(samples):
            with tempfile.TemporaryDirectory() as d, self.subTest(n=n):
                with self.assertRaises(updates.UpdateError):
                    updates.download_installer(info, Path(d), opener=lambda *a, **k: WebResponse(binary))

    def test_signed_windows_build_is_required_for_automatic_install(self):
        if updates.os.name != 'nt':
            with self.assertRaisesRegex(updates.UpdateError, 'signed Windows'):
                updates.verify_windows_installer(Path('fake.exe'), '2.4.51')
            with self.assertRaisesRegex(updates.UpdateError, 'Windows'):
                updates.start_update_handoff(Path('fake.exe'), '2.4.51')

    def test_independent_launcher_retains_data_and_interactive_setup(self):
        script = updates._UPDATE_LAUNCHER
        self.assertIn('Wait-Process -Id $ParentPid', script)
        self.assertIn("'/VERYSILENT'", script)
        self.assertIn("Copy-Item -LiteralPath $data", script)
        self.assertIn("Copy-Item -LiteralPath $_.FullName -Destination $target", script)
        self.assertIn('Start-Process -FilePath $Installer', script)
        self.assertIn("$installDirectory = '/DIR=", script)
        self.assertNotIn(' /VERYSILENT', script.split('Start-Process -FilePath $Installer')[1])
        self.assertIn('Get-AuthenticodeSignature', script)

    def test_installer_eula_and_refund_box_dimensions_match(self):
        source = (ROOT / 'installer/VE_Optimizer_v2.4.52.iss').read_text()
        self.assertIn('WizardForm.LicenseMemo.Width := WizardForm.InfoBeforeMemo.Width', source)
        self.assertIn('WizardForm.LicenseMemo.Height := WizardForm.InfoBeforeMemo.Height', source)
        self.assertIn('LicenseFile=..\\legal\\VE_EULA_1.4.txt', source)
        self.assertIn('InfoBeforeFile=..\\legal\\REFUND_POLICY_1.2.txt', source)

    def test_manual_uninstall_questions_silent_updates_do_not(self):
        source = (ROOT / 'installer/VE_Optimizer_v2.4.52.iss').read_text()
        self.assertIn('if not UninstallSilent then', source)
        self.assertIn('Do you want to keep your VE Optimizer user data?', source)
        self.assertIn('MB_YESNO or MB_DEFBUTTON1', source)
        self.assertIn('RemoveUserDataOnUninstall', source)
        self.assertIn("DelTree(ExpandConstant('{app}\\data')", source)
        self.assertIn("RegDeleteKeyIncludingSubkeys(HKCU, 'Software\\VEOptimizer')", source)

    def test_menu_updates_are_opt_in(self):
        src = (ROOT / 've_optimizer_revision9_review.py').read_text()
        self.assertIn("help_menu.add_command(label='Check for Updates',command=self.check_for_updates)", src)
        self.assertIn('updates.fetch_latest_release()', src)
        self.assertIn('updates.start_update_handoff(installer, release.version)', src)
        self.assertIn('messagebox.askyesno', src)


if __name__ == '__main__':
    unittest.main()
