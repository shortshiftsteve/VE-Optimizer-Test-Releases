"""Release packaging/version regression tests. No GUI/scientific dependencies."""
from __future__ import annotations

import json
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "installer" / "verify_release_versions.py"
VERIFY = runpy.run_path(str(CHECKER))["verify_release_versions"]


class ReleaseVersionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="VE release (2) ")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        for name in ("ve_optimizer_revision9_review.py", "ve_optimizer_license.py",
                     "ve_optimizer_purchase.py", "MANIFEST.json",
                     "installer/version_info.txt", "installer/VE_Optimizer_v2.4.52.iss",
                     "installer/VE_Optimizer.spec", "installer/verify_release_versions.py"):
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / name).read_bytes())

    def replace(self, name: str, before: str, after: str):
        path = self.root / name
        source = path.read_text(encoding="utf-8")
        self.assertIn(before, source)
        path.write_text(source.replace(before, after), encoding="utf-8")

    def run_spec(self, analysis):
        path = self.root / "installer" / "VE_Optimizer.spec"
        exec(compile(path.read_text(encoding="utf-8"), str(path), "exec"),
             {"SPECPATH": str(path.parent), "Analysis": analysis})

    def test_current_release_matches(self):
        self.assertEqual(VERIFY(ROOT), "2.4.52")

    def test_path_with_spaces_and_parentheses(self):
        self.assertEqual(VERIFY(self.root), "2.4.52")

    def test_original_stale_numeric_pair_is_rejected(self):
        self.replace("installer/version_info.txt", "(2, 4, 52, 0)", "(2, 2, 1, 0)")
        with self.assertRaisesRegex(ValueError, "filevers"):
            VERIFY(self.root)

    def test_numeric_product_version_is_rejected(self):
        self.replace("installer/version_info.txt", "prodvers=(2, 4, 52, 0)", "prodvers=(2, 2, 1, 0)")
        with self.assertRaisesRegex(ValueError, "prodvers"):
            VERIFY(self.root)

    def test_displayed_file_version_is_rejected(self):
        self.replace("installer/version_info.txt", "'FileVersion', '2.4.52.0'", "'FileVersion', '2.2.1.0'")
        with self.assertRaisesRegex(ValueError, "FileVersion"):
            VERIFY(self.root)

    def test_displayed_product_version_is_rejected(self):
        self.replace("installer/version_info.txt", "'ProductVersion', '2.4.52.0'", "'ProductVersion', '2.2.1.0'")
        with self.assertRaisesRegex(ValueError, "ProductVersion"):
            VERIFY(self.root)

    def test_missing_version_field_is_rejected(self):
        self.replace("installer/version_info.txt", "    filevers=(2, 4, 52, 0),\n", "")
        with self.assertRaisesRegex(ValueError, "filevers"):
            VERIFY(self.root)

    def test_duplicate_version_field_is_rejected(self):
        self.replace("installer/version_info.txt", "filevers=(2, 4, 52, 0),",
                     "filevers=(2, 4, 52, 0), filevers=(2, 4, 52, 0),")
        with self.assertRaisesRegex(ValueError, "filevers"):
            VERIFY(self.root)

    def test_boolean_in_numeric_version_is_rejected(self):
        self.replace("installer/version_info.txt", "filevers=(2, 4, 52, 0)", "filevers=(2, 2, 2, False)")
        with self.assertRaisesRegex(ValueError, "four-integer"):
            VERIFY(self.root)

    def test_license_version_mismatch_is_rejected(self):
        self.replace("ve_optimizer_license.py", "RELEASE_VERSION = '2.4.52'", "RELEASE_VERSION = '2.2.1'")
        with self.assertRaisesRegex(ValueError, "RELEASE_VERSION"):
            VERIFY(self.root)

    def test_purchase_version_mismatch_is_rejected(self):
        self.replace("ve_optimizer_purchase.py", "PRODUCT_VERSION = '2.4.52'", "PRODUCT_VERSION = '2.2.1'")
        with self.assertRaisesRegex(ValueError, "PRODUCT_VERSION"):
            VERIFY(self.root)

    def test_manifest_version_mismatch_is_rejected(self):
        self.replace("MANIFEST.json", '"app_version": "2.4.52"', '"app_version": "2.2.1"')
        with self.assertRaisesRegex(ValueError, "MANIFEST.json"):
            VERIFY(self.root)

    def test_installer_version_mismatch_is_rejected(self):
        self.replace("installer/VE_Optimizer_v2.4.52.iss", '#define MyAppVersion "2.4.52"',
                     '#define MyAppVersion "2.2.1"')
        with self.assertRaisesRegex(ValueError, "MyAppVersion"):
            VERIFY(self.root)

    def test_installer_appversion_override_is_rejected(self):
        self.replace("installer/VE_Optimizer_v2.4.52.iss", "AppVersion={#MyAppVersion}", "AppVersion=2.2.1")
        with self.assertRaisesRegex(ValueError, "AppVersion"):
            VERIFY(self.root)

    def test_installer_output_filename_mismatch_is_rejected(self):
        self.replace("installer/VE_Optimizer_v2.4.52.iss", "OutputBaseFilename=VE Optimizer v2.4.52 Release Setup",
                     "OutputBaseFilename=VE Optimizer v2.2.1 Setup")
        with self.assertRaisesRegex(ValueError, "OutputBaseFilename"):
            VERIFY(self.root)

    def test_installer_uninstall_name_mismatch_is_rejected(self):
        self.replace("installer/VE_Optimizer_v2.4.52.iss", "UninstallDisplayName=VE Optimizer 2.4.52 Release",
                     "UninstallDisplayName=VE Optimizer 2.2.1")
        with self.assertRaisesRegex(ValueError, "UninstallDisplayName"):
            VERIFY(self.root)

    def test_installer_numeric_override_is_rejected(self):
        self.replace("installer/VE_Optimizer_v2.4.52.iss", "[Setup]", "[Setup]\nVersionInfoVersion=2.2.1.0")
        with self.assertRaisesRegex(ValueError, "VersionInfoVersion"):
            VERIFY(self.root)

    def test_future_release_version_without_hardcoded_current_number(self):
        # A future multi-digit release works after all its actual metadata is updated.
        for path in self.root.rglob("*"):
            if path.is_file() and path.name != "verify_release_versions.py":
                source = path.read_text(encoding="utf-8")
                path.write_text(source.replace("2.4.52", "2.10.3").replace("(2, 4, 52, 0)", "(2, 10, 3, 0)"),
                                encoding="utf-8")
        (self.root / "installer/VE_Optimizer_v2.4.52.iss").rename(self.root / "installer/VE_Optimizer_v2.10.3.iss")
        self.assertEqual(VERIFY(self.root), "2.10.3")
        self.replace("installer/version_info.txt", "prodvers=(2, 10, 3, 0)", "prodvers=(2, 4, 52, 0)")
        with self.assertRaisesRegex(ValueError, "prodvers"):
            VERIFY(self.root)

    def test_app_and_license_stage_disagreement_is_rejected(self):
        self.replace('ve_optimizer_license.py', "RELEASE_STAGE = 'Release'", "RELEASE_STAGE = 'Review'")
        with self.assertRaisesRegex(ValueError, 'RELEASE_STAGE'):
            VERIFY(self.root)

    def test_wrong_release_installer_name_is_rejected(self):
        self.replace('installer/VE_Optimizer_v2.4.52.iss',
                     'OutputBaseFilename=VE Optimizer v2.4.52 Release Setup',
                     'OutputBaseFilename=VE Optimizer v2.4.52 Review Setup')
        with self.assertRaisesRegex(ValueError, 'OutputBaseFilename'):
            VERIFY(self.root)

    def test_cli_from_other_working_directory_is_read_only(self):
        before = {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
        checker = self.root / "installer" / "verify_release_versions.py"
        run = subprocess.run([sys.executable, str(checker)], cwd=self.root.parent,
                             capture_output=True, text=True, timeout=15)
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("PASS:", run.stdout)
        self.assertEqual(before, {p: p.read_bytes() for p in self.root.rglob("*") if p.is_file()})

    def test_cli_returns_failure_for_original_bug(self):
        self.replace("installer/version_info.txt", "(2, 4, 52, 0)", "(2, 2, 1, 0)")
        run = subprocess.run([sys.executable, str(CHECKER), "--root", str(self.root)],
                             capture_output=True, text=True, timeout=15)
        self.assertEqual(run.returncode, 1)
        self.assertIn("filevers", run.stderr)
        self.assertIn("expected (2, 4, 52, 0)", run.stderr)

    def test_direct_spec_rejects_mismatch_before_analysis(self):
        self.replace("installer/version_info.txt", "(2, 4, 52, 0)", "(2, 2, 1, 0)")
        with self.assertRaisesRegex(ValueError, "filevers"):
            self.run_spec(lambda *a, **kw: self.fail("Analysis must not start on a mismatch"))

    def test_direct_spec_reaches_analysis_with_correct_versions(self):
        class AtAnalysis(Exception):
            pass
        def reached(*args, **kwargs):
            raise AtAnalysis()
        with self.assertRaises(AtAnalysis):
            self.run_spec(reached)

    def test_build_batch_has_quoted_preflight_before_compilation(self):
        source = (ROOT / "installer" / "Build_VE_Optimizer_v2.4.52_Installer.bat").read_text(encoding="utf-8")
        call = 'py -3 "%~dp0verify_release_versions.py"'
        self.assertIn(call, source)
        self.assertLess(source.index(call), source.index("pyinstaller --noconfirm"))
        self.assertLess(source.index(call), source.index('call :SignFile "%APP_EXE%"'))
        following = source[source.index(call):source.index(call) + 240]
        self.assertIn("if errorlevel 1 (", following)
        self.assertIn("exit /b 1", following)


if __name__ == "__main__":
    unittest.main()
