"""v2.3.1 next-test contract: A/B isolation, required logs, boost review safeguards."""
import math
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import ve_optimizer_logcheck as lc
import ve_optimizer_boost_review as review
import ve_optimizer_processing as proc
import ve_optimizer_wideband as wb


def test_required_chans_and_knock_target():
    assert {'fuel_air_stoich','knock_short','knock_long','knock_total'} <= lc.METHOD_A_MANDATORY_KEYS
    assert {'knock_short','knock_long','knock_total'} <= lc.METHOD_B_MANDATORY_KEYS
    assert 'fuel_air_stoich' not in lc.METHOD_B_MANDATORY_KEYS
    assert lc.METHOD_B_MANDATORY_KEYS == {
        'rpm','ect','actual_torque','fa_enrichment','fa_power_enrichment',
        'map','baro','stft_b1','stft_b2',
        'knock_short','knock_long','knock_total'}
    assert lc.METHOD_A_CHANNELS is not lc.METHOD_B_CHANNELS
    assert all(a is not b for a,b in zip(lc.METHOD_A_CHANNELS,lc.METHOD_B_CHANNELS))


def test_2bar_hellcat_reference_is_exact():
    assert review.HELLCAT_2BAR == {'map_sensor_linear_kpa_per_v':45.42,
                                   'map_offset_kpa':7.0,'map_sensor_offset_v':0.1001}


def fake_decoded():
    channels={
        0:{'name':'MAP - Hi-Res','unit':'kPa'},
        1:{'name':'Barometric Pressure','unit':'kPa'},
        2:{'name':'Calculated Manifold Absolute Pressure','unit':'kPa'},
        3:{'name':'Manifold Absolute Pressure Sensor Voltage','unit':'V'},
        4:{'name':'Knock Retard Short Term','unit':'°'},
        5:{'name':'Knock Retard Long Term','unit':'°'},
        6:{'name':'Total Knock Retard','unit':'°'},
    }
    # One MAP > Baro sample establishes raw pressure evidence, not confirmed
    # boosted operation. The hardware review requires five PRatio > 1.06 hits.
    frames=[]
    for i in range(5):
        voltage=1.0+0.2*i
        pressure=7.0+45.42*(voltage-0.1001)
        frames.append({'timestamp_ms':i*100,'updates':{
            0:105.0 if i==3 else pressure,1:100.0,2:pressure,
            3:voltage,4:1.0 if i==3 else 0.0,5:0.0,6:1.0 if i==3 else 0.0,
        }})
    return {'channels':channels,'frames':frames}


def test_single_map_excursion_does_not_trigger_hardware_review(tmp_path):
    log=tmp_path/'test.hpl';log.write_bytes(b'test')
    with patch.object(review,'decode_hpl',return_value=fake_decoded()),\
         patch.object(review,'_tune_characteristics',return_value={'sensed_map_switch':'Disabled'}):
        data=review.inspect('unused.htt',log,'speed_density')
    assert data['pressure_exceeds_baro'] is True
    assert data['boost_review_required'] is False
    assert data['map_source']['boost_pratio_hits']==0
    assert data['map_source']['exceeds_baro']==1
    assert data['alternative_map_sources'][0]['name']=='Calculated Manifold Absolute Pressure'
    assert data['knock_retard']['short_term']['max']==1.0
    assert data['knock_retard']['short_term_target_deg']==0.0


def test_3bar_voltage_estimate_only_solves_with_known_voltage_offset(tmp_path):
    log=tmp_path/'test.hpl';log.write_bytes(b'test')
    with patch.object(review,'decode_hpl',return_value=fake_decoded()):
        unknown=review.estimate_map_from_voltage(log,preferred_map_name='Calculated Manifold Absolute Pressure')
        estimate=review.estimate_map_from_voltage(log,preferred_map_name='Calculated Manifold Absolute Pressure',existing_voltage_offset=0.1001)
    assert not unknown['possible']
    assert estimate['possible']
    assert math.isclose(estimate['map_sensor_linear_kpa_per_v'],45.42,abs_tol=1e-6)
    assert math.isclose(estimate['map_offset_kpa'],7.0,abs_tol=1e-6)
    assert estimate['requires_user_approval']


def test_boost_review_never_writes_to_tune(tmp_path):
    p=Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt')
    log=Path('/mnt/data/fresh log_latest_VCM Ver.hpl')
    if p.exists() and log.exists():
        before=p.read_bytes()
        out=review.inspect(p,log,'speed_density')
        assert p.read_bytes()==before
        assert out['tune']['pe_switch'] in ('Aircharge','PRatio',None)
        assert out['knock_retard']['short_term']['present'] is False  # no knock channels in this reference


def test_no_blind_map_or_pe_switch_changes():
    code=Path(wb.__file__).read_text()
    assert 'Sensed MAP (2100) and MAP sensor transfer values are never changed.' in code
    assert 'Automatic Power Enrichment calibration has been removed' in code
    assert 'def prepare_pe_strategy(' in code
    assert "SENSED_MAP_ENABLE_SWITCH = 2100" in code
    assert "QUARANTINED_SWITCH_ID = 44433" in code


def test_enrichment_values_not_hard_rejected_in_nn_trim_conditioning():
    code=Path(proc.__file__).read_text()
    assert "v['fa_enrichment']==0" not in code
    assert "v['fa_power_enrichment']==0" not in code
    code_wb=Path(wb.__file__).read_text()
    pos=code_wb.index('def _adaptive_trim_status(')
    nxt=code_wb.index('def _narrowband_status(',pos)
    assert 'float(fa) == 0' not in code_wb[pos:nxt]
    assert 'float(pe) == 0' not in code_wb[pos:nxt]
