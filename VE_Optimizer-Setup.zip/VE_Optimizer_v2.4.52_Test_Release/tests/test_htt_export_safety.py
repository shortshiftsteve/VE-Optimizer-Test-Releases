"""Fail-closed compatibility tests for the v2.3.0 NN-only export path."""
import copy
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_stage3 as htt

class HTTExportSafetyTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.root = Path(self.folder.name)
        self.base = self.root / 'base.htt'
        self.candidate = self.root / 'candidate.htt'
        self.carrier = self.root / 'carrier.htt'
        self.output = self.root / 'output.htt'
        self.base.write_bytes((ROOT/'tests/fixtures/stock.htt').read_bytes())
        self.carrier.write_bytes((ROOT/'a/stock_nn.htt').read_bytes())
        network = copy.deepcopy(htt.load_network(self.base))
        network['bo'][0] += 1/2048
        htt.write_candidate(self.base, self.candidate, network)

    def test_valid_export_preserves_input_bytes(self):
        originals = [p.read_bytes() for p in (self.base, self.candidate, self.carrier)]
        changed = htt.write_changed_nn_template(self.base,self.candidate,self.output,self.carrier)
        self.assertIn('bo', changed)
        self.assertTrue(self.output.exists())
        self.assertEqual(originals, [p.read_bytes() for p in (self.base,self.candidate,self.carrier)])

    def test_unknown_header_rejects_without_replacing_previous_output(self):
        self.output.write_bytes(b'previous validated export')
        self.carrier.write_bytes(b'XXXX' + self.carrier.read_bytes()[4:])
        with self.assertRaisesRegex(ValueError, 'framing'):
            htt.write_changed_nn_template(self.base,self.candidate,self.output,self.carrier)
        self.assertEqual(self.output.read_bytes(),b'previous validated export')

    def test_ambiguous_duplicate_nn_key_rejected(self):
        blob = self.carrier.read_bytes()
        key = htt.NN_KEYS['bo'].to_bytes(2,'little')+b'\x00\x00'
        self.carrier.write_bytes(blob[:-8] + key + blob[-8:])
        with self.assertRaisesRegex(ValueError, 'Ambiguous'):
            htt.write_changed_nn_template(self.base,self.candidate,self.output,self.carrier)
        self.assertFalse(self.output.exists())

    def test_never_overwrite_source(self):
        before=self.base.read_bytes()
        with self.assertRaisesRegex(ValueError, 'must not overwrite'):
            htt.write_changed_nn_template(self.base,self.candidate,self.base,self.carrier)
        self.assertEqual(self.base.read_bytes(),before)

if __name__ == '__main__': unittest.main()
