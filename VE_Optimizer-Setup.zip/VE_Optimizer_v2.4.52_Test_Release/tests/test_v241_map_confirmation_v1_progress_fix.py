"""v2.4.1: V1+ pinned progress is version-specific and MAP confirmation is read-only."""
import inspect
import tkinter as tk

import ve_optimizer_revision9_review as app


def test_progress_resets_when_version_changes_but_not_same_version():
    root=tk.Tk()
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.setup_activity_host=None
        obj.setup_progress_log=None
        obj._progress_context=None
        obj.progress=tk.DoubleVar(value=100)
        obj.run_title=tk.StringVar(value='Processing complete')
        obj.run_detail=tk.StringVar(value='V0 complete')
        obj.run_pct=tk.StringVar(value='COMPLETE • 100%')
        obj.run_elapsed=tk.StringVar(value='Elapsed: 03:30')
        obj.run_quality_activity_lines=['OVERALL 100%  V0 Processing complete']
        obj._run_quality_last_activity='Processing complete'
        obj._run_quality_active_stage='Fit Neural Network'
        obj._progress_activity_times={'V0':'19:57:10'}
        assert obj._sync_progress_version(9,0)
        assert obj._progress_context==(9,0)
        assert obj.progress.get()==0
        obj.run_quality_activity_lines=['WORKING  V0 current']
        obj.progress.set(45)
        assert not obj._sync_progress_version(9,0)
        assert obj.progress.get()==45
        assert obj.run_quality_activity_lines==['WORKING  V0 current']
        assert obj._sync_progress_version(9,1)
        assert obj._progress_context==(9,1)
        assert obj.run_quality_activity_lines==[]
        assert obj._progress_activity_times=={}
        assert obj._run_quality_active_stage is None
        assert obj.progress.get()==0
        assert obj.setup_activity_state['title']=='V1 ready'
        assert obj.setup_activity_state['percent']==0
        assert not obj.setup_activity_state['busy']
        assert 'V1' in obj.setup_activity_state['detail']
    finally:root.destroy()


def test_progress_version_reset_is_wired_to_setup_page():
    code=inspect.getsource(app.ReviewApp.page_setup)
    assert 'self._sync_progress_version(self.project.id,self.active_version_no)' in code
    assert 'self._progress_context=None' in inspect.getsource(app.ReviewApp._reset_project_workflow_state)


def test_map_confirmation_removed_without_automatic_sensor_calibration():
    assert not hasattr(app.ReviewApp, '_review_map_and_pe')
    prompt=inspect.getsource(app.ReviewApp._show_preflight_prompt)
    assert 'self._show_correction_source_message()' in prompt
    assert 'Yes' not in prompt and 'No' not in prompt
    import ve_optimizer_wideband as wb
    auto=inspect.getsource(wb.prepare_airflow_strategy)
    assert 'MAP1_LINEAR_SCALAR' not in auto
    assert 'MAP2_LINEAR_SCALAR' not in auto
