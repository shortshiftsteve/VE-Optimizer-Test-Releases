import json
from pathlib import Path
import copy,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import ve_optimizer_processing as p
import ve_optimizer_stage3 as s3

stock=s3.load_network(ROOT/'tests/fixtures/stock.htt')
axes=json.loads((ROOT/'a/reference_axes.json').read_text())
d=p.model_domain(stock)
assert d['rpms']==axes['rpms']
assert d['pratios']==axes['pratios']
assert [list(x) for x in d['cam_pairs']]==axes['cam_pairs']
assert d['derived_lsa']==114.25 and d['linked_span_match']

other=copy.deepcopy(stock)
t=other['meta']['training']
t.update(exhaust_min=97.0,exhaust_max=135.0,intake_min=106.0,intake_max=144.0,
         rpm_min=31.0,rpm_max=7001.0,pratio_min=0.1103515625,pratio_max=1.2001953125,
         ve_min=20.01953125,ve_max=100.9765625)
d2=p.model_domain(other)
assert d2['rpms'][0]==31.0 and d2['rpms'][-1]==7001.0
assert d2['pratios'][0]==0.1104 and abs(d2['pratios'][-1]-1.2002)<1e-12
assert d2['cam_pairs']==[(144.0,97.0),(134.5,106.5),(125.0,116.0),(115.5,125.5),(106.0,135.0)]
assert d2['derived_lsa']==120.5 and d2['linked_span_match']
assert d2['rpms']!=d['rpms'] and d2['cam_pairs']!=d['cam_pairs']

custom=copy.deepcopy(stock)
tc=custom['meta']['training']
# Equal 43-degree spans centered on a 110.25-degree linked-cam LSA.
tc.update(intake_min=96.5,intake_max=139.5,exhaust_min=81.0,exhaust_max=124.0)
d3=p.model_domain(custom)
assert d3['derived_lsa']==110.25 and d3['linked_span_match']
assert d3['cam_pairs'][0]==(139.5,81.0) and d3['cam_pairs'][-1]==(96.5,124.0)

print('DYNAMIC_DOMAIN_PASS')
