"""Review 9 follow-up: automatic Submit-to-dyno, manual Results, Back, and faux composite performance.

Production tuner, solver, Speed Density and calibration arithmetic are untouched.
"""
from pathlib import Path
from types import SimpleNamespace
import math
import tkinter as tk
from tkinter import ttk

import pytest
import ve_optimizer_revision9_review as app
import ve_optimizer_dyno as dyno


@pytest.fixture
def ui(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1360x850+0+0')
    obj=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
    obj.user=obj.db.single_user_identity();obj.shell();obj.goto('setup');root.update()
    try:yield root,obj
    finally:
        obj._stop_setup_header_blink();obj._stop_setup_verify_blink()
        obj.db.close();root.destroy()


def _staged_files(root,obj,tmp_path):
    htt=tmp_path/'full.htt';htt.write_bytes(b'HTT validation fixture')
    hpl=tmp_path/'fresh.hpl';hpl.write_bytes(b'HPL validation fixture')
    obj.vs_vars['htt'].set(str(htt));obj.vs_vars['log'].set(str(hpl))
    obj.vs_log_staged=True;obj.vs_log_valid=False
    obj._show_setup_vehicle_verification();root.update()
    assert obj.setup_workflow_button.cget('text')=='Verify'
    obj.setup_workflow_button.invoke();root.update()
    assert obj._setup_vehicle_is_verified()
    assert obj.setup_workflow_button.cget('text')=='Submit'
    return htt,hpl


def _stub_qualification(monkeypatch,obj,ready):
    monkeypatch.setattr(app,'validate_hp_tuners_log',lambda p:(True,'ok'))
    monkeypatch.setattr(app.wideband,'detect_airflow_model',lambda _: 'speed_density')
    report={'passed':ready,'airflow_model':'speed_density','recommendations':(
        [] if ready else ['STFT Bank 2: No Data'])}
    monkeypatch.setattr(app.logcheck,'analyze_log',lambda *a,**k:report)
    monkeypatch.setattr(app.logcheck,'summary_text',lambda rep:'PASS' if rep['passed'] else 'FAILED')
    if ready:
        qualifier={'adaptive_ready':True,'wideband_ready':False}
    else:
        qualifier={'adaptive_ready':False,'wideband_ready':False,
                   'correction_preflight':{'sources':{
                       'adaptive':{'reason':'STFT Bank 2: no qualified samples'},
                       'wideband':{'reason':'No valid wideband stream'}}}}
    monkeypatch.setattr(app.wideband_integration,'qualify_log_for_tune',lambda *a,**k:qualifier)
    monkeypatch.setattr(obj,'_prompt_na_closed_loop_only',
                        lambda report,tune,path,done:done(report,False))
    # Exercise the callback logic on the UI thread, without running a HPL parser
    # against intentionally small fixture bytes or creating a tuning project.
    monkeypatch.setattr(obj,'_run_background_task',lambda task,done:obj.root.after(0,lambda:done(task())))


def test_submit_success_advances_to_build_without_second_click(ui,tmp_path,monkeypatch):
    root,obj=ui
    htt,hpl=_staged_files(root,obj,tmp_path)
    monkeypatch.setattr(obj,'_setup_candidate_tune_path',lambda:htt)
    _stub_qualification(monkeypatch,obj,True)
    calls=[]
    monkeypatch.setattr(obj,'_save_vehicle_setup',lambda:calls.append('build'))
    obj.setup_workflow_button.invoke()
    root.update()
    assert calls==['build']
    assert obj._auto_submit_active
    assert obj.vs_log_valid and not obj.vs_log_staged
    assert obj.setup_panel_message['heading']=='LOG FILE READY'
    assert obj.setup_header_label.cget('text')=='PROGRESS'
    assert obj.setup_actions.winfo_manager()==''


def test_failed_channel_qualification_routes_primary_button_to_view(ui,tmp_path,monkeypatch):
    root,obj=ui
    htt,hpl=_staged_files(root,obj,tmp_path)
    monkeypatch.setattr(obj,'_setup_candidate_tune_path',lambda:htt)
    _stub_qualification(monkeypatch,obj,False)
    attempted=[]
    monkeypatch.setattr(obj,'_save_vehicle_setup',lambda:attempted.append('unexpected build'))
    reports=[]
    monkeypatch.setattr(obj,'_show_log_validation',lambda report,*a,**kw:reports.append((report,kw)))
    obj.setup_workflow_button.invoke();root.update()
    assert not attempted
    assert not obj._auto_submit_active
    assert obj.setup_panel_message['heading']=='LOG FILE INCOMPLETE'
    assert 'STFT Bank 2' in obj.setup_panel_message['body']
    assert obj.setup_header_label.cget('text')=='MESSAGE'
    assert obj.setup_workflow_button.cget('text')=='VIEW'
    assert not obj.setup_workflow_button.instate(['disabled'])
    assert obj.setup_actions.winfo_manager()==''  # no second View in lower panel
    obj.setup_workflow_button.invoke()
    assert len(reports)==1 and reports[0][0]['passed'] is False
    assert reports[0][1]['qualified_override'] is False


def test_invalid_hpl_without_decodable_channel_report_still_has_view(ui,tmp_path,monkeypatch):
    root,obj=ui
    htt,hpl=_staged_files(root,obj,tmp_path)
    monkeypatch.setattr(obj,'_setup_candidate_tune_path',lambda:htt)
    monkeypatch.setattr(app,'validate_hp_tuners_log',lambda *_:(False,'HPL record is malformed'))
    monkeypatch.setattr(obj,'_run_background_task',lambda task,done:root.after(0,lambda:done(task())))
    calls=[]
    monkeypatch.setattr(app.messagebox,'showerror',lambda *args,**kwargs:calls.append(args))
    obj.setup_workflow_button.invoke();root.update()
    assert obj.setup_workflow_button.cget('text')=='VIEW'
    assert not obj._auto_submit_active
    assert 'malformed' in obj.setup_panel_message['body']
    obj.setup_workflow_button.invoke()
    assert len(calls)==1 and 'malformed' in calls[0][-1]


def test_changed_log_cannot_auto_build_old_qualification(ui,tmp_path,monkeypatch):
    root,obj=ui
    htt,hpl=_staged_files(root,obj,tmp_path)
    monkeypatch.setattr(obj,'_setup_candidate_tune_path',lambda:htt)
    _stub_qualification(monkeypatch,obj,True)
    calls=[]
    monkeypatch.setattr(obj,'_save_vehicle_setup',lambda:calls.append('build'))
    queued=[]
    monkeypatch.setattr(obj,'_run_background_task',lambda work,done:queued.append((work,done)))
    obj.setup_workflow_button.invoke()
    assert len(queued)==1
    obj.vs_vars['log'].set(str(tmp_path/'another.hpl'))  # changed before async completion
    work,done=queued.pop()
    done(work())
    root.update()
    assert calls==[] and not obj._auto_submit_active


def _preflight_obj(obj,kind):
    obj.project=SimpleNamespace(id=42)
    obj._setup_lower_mode='preflight'
    obj._correction_context=lambda:'current'
    obj.correction_preflight_context='current'
    obj._auto_submit_active=True
    obj._render_setup_lower_view=lambda:None
    obj._review_result_ready=lambda:False
    choices=[{'id':'adaptive','label':'LTFT + STFT','enabled':True}]
    if kind=='two':choices.append({'id':'wideband','label':'Wideband O2','enabled':True})
    obj.correction_preflight_cache={'choices':choices,
                                    'sources':{'adaptive':{'mode':'ltft_plus_stft'}}}
    obj.correction_source_selection=None
    calls=[]
    obj.goto=lambda page,*a,**kw:(calls.append(page),setattr(obj,'_setup_lower_mode',page))
    obj.start_review=lambda:calls.append('start_review')
    return calls


def test_single_qualified_source_continues_automatically(ui):
    root,obj=ui
    calls=_preflight_obj(obj,'one')
    obj._show_preflight_prompt()
    assert obj.correction_source_selection=='adaptive'
    assert obj.setup_panel_message['requires_action'] is False
    obj._auto_advance_preflight()
    assert calls==['review','start_review']


def test_dual_source_pauses_until_user_selects_and_clicks_continue(ui):
    root,obj=ui
    calls=_preflight_obj(obj,'two')
    obj._show_preflight_prompt();root.update()
    assert obj.setup_header_label.cget('text')=='MESSAGE'
    assert obj.setup_workflow_button.cget('text')=='Continue'
    assert obj.setup_workflow_button.instate(['disabled'])
    obj._auto_advance_preflight()
    assert calls==[]
    radios=[]
    def descend(parent):
        for child in parent.winfo_children():
            if isinstance(child,ttk.Radiobutton):radios.append(child)
            descend(child)
    descend(obj.setup_action_view)
    next(x for x in radios if x.cget('text')=='Wideband O2').invoke()
    root.update()
    assert not obj.setup_workflow_button.instate(['disabled'])
    assert calls==[]  # selecting radio is NOT approval to run
    obj.setup_workflow_button.invoke()
    assert calls==['review','start_review'] and obj._auto_submit_active


def test_unresolved_safety_decision_blocks_auto_advance(ui):
    root,obj=ui
    calls=_preflight_obj(obj,'one')
    obj.correction_source_selection='adaptive'
    obj._set_setup_panel_message('KNOCK DATA NOT FOUND','Approval required',
        actions=(('Yes',lambda:None),('No',lambda:None)))
    obj._auto_advance_preflight()
    assert calls==[]
    assert obj.setup_workflow_button.cget('text')=='Continue'
    assert obj.setup_workflow_button.instate(['disabled'])


def test_completed_run_opens_dyno_workspace_not_results(ui):
    _root,obj=ui
    pages=[]
    obj._review_result_ready=lambda:True
    obj.goto=lambda page,**kw:pages.append((page,kw))
    obj._show_completed_dyno_after_run()
    assert pages==[('review',{'record_history':False})]
    obj._review_result_ready=lambda:False
    obj._show_completed_dyno_after_run()
    assert len(pages)==1
    assert obj.setup_panel_message['heading']=='PROCESSING ERROR'


def test_speed_density_source_label_matches_stored_trim_mode(ui,tmp_path):
    import json
    _root,obj=ui
    a=tmp_path/'metrics.json'
    obj._application_payload=lambda:{'correction_source':'adaptive','airflow_model':'speed_density',
                                      'preflight':{'sources':{'adaptive':{'mode':'stft_only'}}},
                                      'levels':{'50':{'metrics_json':str(a)}}}
    obj.correction_source_selection='adaptive';obj.correction_preflight_cache={}
    a.write_text(json.dumps({'trim_mode':'ltft_plus_stft'}),encoding='utf-8')
    assert obj._run_quality_source_model()[1]=='LTFT+STFT'
    a.write_text(json.dumps({'trim_mode':'stft_only'}),encoding='utf-8')
    assert obj._run_quality_source_model()[1]=='STFT'
    a.write_text(json.dumps({}),encoding='utf-8')
    assert obj._run_quality_source_model()[1]=='STFT'
    obj.correction_preflight_cache={'sources':{'adaptive':{'mode':'ltft_plus_stft'}}}
    assert obj._run_quality_source_model()[1]=='LTFT+STFT'


class RecordingCanvas:
    def __init__(self):self.lines=[]
    def delete(self,*args):pass
    def winfo_width(self):return 1120
    def winfo_height(self):return 310
    def create_line(self,*p,**opts):self.lines.append((p,opts))
    def create_text(self,*a,**k):pass


def test_horsepower_and_lbft_torque_have_equal_scale_at_5252_rpm():
    pts=[]
    for rpm,torque in [(5000,500),(5252,550),(6100,560)]:
        pts.append({'rpm':rpm,'torque_lbft':torque,
                    'hp':torque*rpm/5252,'kind':'logged','segment':0})
    canvas=RecordingCanvas()
    dyno.draw_dyno_chart(canvas,{'points':pts})
    hp=[coords for coords,style in canvas.lines if style.get('fill')=='#60CDF5' and 'dash' in style]
    tq=[coords for coords,style in canvas.lines if style.get('fill')=='#F2B366' and 'dash' in style]
    assert len(hp)==len(tq)==2
    # first line ends at the same (x,y) for both horsepower and torque
    assert math.isclose(hp[0][2],tq[0][2],abs_tol=1e-10)
    assert math.isclose(hp[0][3],tq[0][3],abs_tol=1e-10)


def test_result_back_always_returns_to_main_dyno_workspace(ui,monkeypatch):
    root,obj=ui
    obj.project=SimpleNamespace(id=17)
    # Keep the test focused on navigation semantics, not project data contents.
    monkeypatch.setattr(obj,'page_results',lambda:None)
    monkeypatch.setattr(obj,'page_setup',lambda:None)
    obj.goto('results')
    root.update()
    assert obj.back_button.instate(['!disabled'])
    assert obj.current_page=='results'
    obj.go_back()
    assert obj.current_page=='setup'
    assert 'results' not in obj.page_history
    obj.goto('results',record_history=False)
    obj.page_history=[]
    obj._update_back_button()
    assert obj.back_button.instate(['!disabled'])
    obj.back_button.invoke()
    assert obj.current_page=='setup'


def test_preflight_runs_from_upper_panel_without_white_lower_page(ui,monkeypatch):
    root,obj=ui
    obj.project=SimpleNamespace(id=25)
    obj._setup_lower_mode='preflight'
    obj.correction_preflight_cache={'sources':{'adaptive':{'mode':'stft_only'}}}
    obj.correction_preflight_context='prior version'
    obj.correction_source_selection='adaptive'
    obj.correction_preflight_running=False
    calls=[]
    monkeypatch.setattr(obj,'_dyno_processed_versions',lambda:[])
    monkeypatch.setattr(obj,'_active_version',lambda:{'version_no':0})
    monkeypatch.setattr(obj,'_correction_context',lambda:'new version')
    monkeypatch.setattr(obj.db,'version_setup_complete',lambda *_:True)
    monkeypatch.setattr(obj,'_run_correction_preflight',lambda:calls.append('preflight'))
    monkeypatch.setattr(obj,'_build_run_quality_panel',lambda host:tk.Label(host,text='Processing Quality').pack())
    monkeypatch.setattr(obj,'page_preflight',lambda host:(_ for _ in ()).throw(AssertionError('Old lower preflight should not be drawn')))
    obj._render_setup_lower_view()
    root.after(75,root.quit)
    root.mainloop()
    assert calls==['preflight']
    assert obj.correction_source_selection is None  # prior version not reused
    assert not any(w.cget('text')=='Correction Preflight'
                   for w in obj.setup_processing_host.winfo_children() if isinstance(w,tk.Label))


def test_completed_real_project_results_back_restores_composite_dyno(ui,tmp_path,monkeypatch):
    import json
    import shutil
    root,obj=ui
    project=obj.db.create_project_draft(obj.user.id,2023,'Dodge Challenger','',engine='5.7L Hemi')
    obj.db.conn.execute('INSERT INTO project_setup(project_id,project_name) VALUES(?,?)',
                        (project.id,'Navigation Composite Test'))
    vdir=obj.db.version_dir(project.id,0)
    model=Path(app.__file__).resolve().parent/'a'/'stock_nn.htt'
    tune=vdir/'Baseline.htt';shutil.copy2(model,tune)
    log=vdir/'Log.hpl';log.write_bytes(b'NAVIGATION TEST ONLY')
    import hashlib
    digest=hashlib.sha256(log.read_bytes()).hexdigest()
    preview=vdir/'_Application_Preview'/'Candidate.json'
    preview.parent.mkdir(exist_ok=True)
    preview.write_text(json.dumps({'method_id':app.processing.METHOD_ID}),encoding='utf-8')
    obj.db.conn.execute('''INSERT INTO project_versions
        (project_id,version_no,baseline_htt_path,baseline_htt_sha256,
         log_local_path,log_source_path,log_sha256,preview_ready,preview_json_path)
         VALUES(?,?,?,?,?,?,?,?,?)''',
        (project.id,0,str(tune),app.s5.sha256_file(tune),str(log),str(log),digest,1,str(preview)))
    obj.db.conn.commit()
    obj.project=obj.db.get_project(project.id)
    obj.active_version_no=0
    obj._setup_lower_mode='review'
    mock_curve={'status':'ready','basis':'WOT','sweep_count':2,'logged_bins':2,
                'reconstructed_bins':1,'points':[
                 {'rpm':1500,'hp':85,'torque_lbft':300,'kind':'logged','segment':1},
                 {'rpm':1600,'hp':95,'torque_lbft':310,'kind':'interpolated'},
                 {'rpm':1700,'hp':110,'torque_lbft':340,'kind':'logged','segment':2}]}
    monkeypatch.setattr(obj,'_dyno_processed_versions',lambda:[(0,log,digest)])
    obj._dyno_curve_cache[(str(log),digest)]=mock_curve
    obj.goto('setup');root.update()
    assert obj.setup_workflow_button.cget('text')=='Results'
    assert obj.dyno_caption.get().startswith('Composite from 2 WOT instances')
    monkeypatch.setattr(obj,'page_results',lambda:None)
    obj.setup_workflow_button.invoke();root.update()
    assert obj.current_page=='results' and obj.back_button.instate(['!disabled'])
    obj.back_button.invoke();root.update()
    assert obj.current_page=='setup'
    assert obj.setup_workflow_button.cget('text')=='Results'
    assert obj.dyno_caption.get().startswith('Composite from 2 WOT instances')
    obj.setup_workflow_button.invoke();root.update()
    obj.back_button.invoke();root.update()
    assert obj.current_page=='setup' and obj.setup_workflow_button.cget('text')=='Results'


def test_faux_curve_keeps_hp_torque_colors_with_dashed_estimates():
    pts=[{'rpm':1700,'hp':150,'torque_lbft':460,'kind':'logged','segment':1},
         {'rpm':1800,'hp':158,'torque_lbft':460,'kind':'interpolated'},
         {'rpm':1900,'hp':172,'torque_lbft':475,'kind':'logged','segment':2}]
    canvas=RecordingCanvas()
    dyno.draw_dyno_chart(canvas,{'points':pts})
    colored_dashes=[style.get('fill') for _,style in canvas.lines
                    if style.get('dash')==(5,4)]
    assert '#60CDF5' in colored_dashes and '#F2B366' in colored_dashes
