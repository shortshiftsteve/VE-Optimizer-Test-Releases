"""Targeted NA/no-knock user-consent exception: Log File qualification to correction."""
import json
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_logcheck as lc
import ve_optimizer_processing as proc
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as wbi
import ve_optimizer_revision9_review as app

LOG = ROOT / 'tests' / 'fixtures' / 'fresh_log.hpl'
TUNE = Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt')


def test_default_rejects_missing_knock_and_yes_retains_no_data():
    report = lc.analyze_log(LOG, 'neural_network')
    assert not report['passed']
    assert lc.na_knock_exception_eligible(report)
    if TUNE.exists():
        approved = lc.approved_na_closed_loop_report(report, TUNE, LOG)
    else:
        with patch('ve_optimizer_boost_review.na_closed_loop_evidence', return_value=(True, {})):
            approved = lc.approved_na_closed_loop_report(report, 'tune.htt', LOG)
    assert approved['passed'] and approved['na_closed_loop_only']
    assert approved['correction_scope'] == 'closed_loop_only'
    rows = {r['name']: r for r in approved['logged_channels']}
    for name in ('Knock Retard Long Term','Knock Retard Short Term','Total Knock Retard'):
        assert rows[name]['status'] == 'No Data'
        assert rows[name]['required']
    assert len(approved['blocking']) == 0
    with patch('ve_optimizer_boost_review.na_closed_loop_evidence', return_value=(False, {})):
        with pytest.raises(ValueError):
            lc.approved_na_closed_loop_report(report, 'tune.htt', LOG)


def test_no_exception_when_another_required_channel_is_missing():
    report=lc.analyze_log(LOG,'speed_density')
    changed=dict(report)
    sigs=[dict(s) for s in report['signals']]
    next(s for s in sigs if s['key']=='stft_b2')['count']=0
    next(s for s in sigs if s['key']=='stft_b2')['status']='MISSING'
    changed['signals']=sigs
    assert not lc.na_knock_exception_eligible(changed)
    with pytest.raises(ValueError):lc.allow_na_closed_loop_only(changed)


def fake_sd_decoded():
    values={'rpm':1500.,'torque':30.,'map':80.,'baro':100.,'ect':190.,
            'fa':0.,'pe':0.,'flow':15.,'stft_b1':4.,'stft_b2':-2.}
    names=[('rpm','Engine RPM','rpm',21),('torque','Actual Torque','lb-ft',22),
           ('map','MAP - Hi-Res','kPa',23),('baro','Barometric Pressure','kPa',24),
           ('ect','Engine Coolant Temp','deg F',25),('fa','FA Enrichment','',26),
           ('pe','FA Power Enrichment','',27),('flow','Fuel Flow Rate','lb/h',wb.FUEL_FLOW_PID),
           ('stft_b1','Short Term Fuel Trim Bank 1','%',30),('stft_b2','Short Term Fuel Trim Bank 2','%',31)]
    channels={i:{'name':n,'unit':u,'parameter_id':pid} for i,(_,n,u,pid) in enumerate(names)}
    frames=[]
    for i in range(12):
        vals=dict(values)
        if i%2:
            vals['fa']=0.01
        frames.append({'timestamp_ms':100*i,'updates':{j:vals[key] for j,(key,_,_,_) in enumerate(names)}})
    return {'channels':channels,'frames':frames}


def test_sd_zero_enrichment_gate_is_opt_in_and_matches_preflight():
    d=fake_sd_decoded()
    default=wb._adaptive_trim_status(d,'speed_density')
    selected=wb._adaptive_trim_status(d,'speed_density',closed_loop_only=True)
    assert (default['accepted_events_bank1'],default['accepted_events_bank2'])==(12,12)
    assert (selected['accepted_events_bank1'],selected['accepted_events_bank2'])==(6,6)
    assert selected['valid']
    rpm=np.array([0.,1500.,3000.]);pr=np.array([0.5,0.8,1.5]);z=np.ones((3,3))
    with patch.object(wb,'decode_hpl',return_value=d),patch.object(wb,'parse_ve_table',return_value=(b'fake',rpm,pr,z)):
        baseline=wbi._adaptive_sd_analysis('fake.hpl','fake.htt')
        approved=wbi._adaptive_sd_analysis('fake.hpl','fake.htt',closed_loop_only=True)
    assert int(baseline['hit_counts'][0].sum())==12
    assert int(approved['hit_counts'][0].sum())==6
    assert int(approved['hit_counts'][1].sum())==6
    assert approved['closed_loop_only']


def test_nn_event_stream_gated_only_on_user_optin():
    specs=list(proc.PIDS.items());ids=['s']+[str(pid) for _,pid in specs]
    meta=lc.Metadata(ids,['Time']+[key for key,_ in specs],['s']+[('°F' if key=='ect' else 'kPa' if key in ('map','baro') else 'lb-ft' if key=='actual_torque' else 'lb/h' if key=='fuel_flow' else 'rpm' if key=='rpm' else 'deg' if key in ('intake_cam','exhaust_cam') else '%') for key,_ in specs],1)
    default=dict(rpm=1500.,actual_torque=40.,ect=190.,map=80.,baro=100.,fa_enrichment=0.,fa_power_enrichment=0.,fuel_flow=20.,ltft_b1=0.,stft_b1=2.,ltft_b2=0.,stft_b2=-1.,intake_cam=110.,exhaust_cam=115.)
    rows=[]
    for i in range(4):
        vals=dict(default)
        if i==1:vals['fa_enrichment']=0.1
        if i==3:vals['fa_power_enrichment']=0.01
        rows.append((i/10.,[str(i/10.)]+[str(vals[key]) for key,_ in specs]))
    # MAP and BARO are selected by the validated pressure-source resolver;
    # this synthetic numerical fixture supplies those two selected indices.
    pressure_indices={key:[list(proc.PIDS).index(key)+1] for key in ('map','baro')}
    with patch.object(proc.logcheck,'read_metadata',return_value=meta),\
         patch.object(proc.logcheck,'resolve_indices',return_value=pressure_indices),\
         patch.object(proc.logcheck,'iter_data',side_effect=lambda *_: iter(rows)):
        all_events,_=proc.prepare_samples('dummy.csv')
        gated,details=proc.prepare_samples('dummy.csv',closed_loop_only=True)
    assert len(all_events)==8
    assert len(gated)==4
    assert details['closed_loop_only']
    assert all(x['FA_Enrichment']==0.0 and x['FA_PowerEnrichment']==0.0 for x in gated)


def test_selected_log_report_flag_survives_version_storage():
    assert app.version_closed_loop_only({'log_validation_json':json.dumps({'na_closed_loop_only':True})})
    assert app.version_closed_loop_only({'log_validation_json':json.dumps({'standard_report':{'na_closed_loop_only':True}})})
    assert not app.version_closed_loop_only({'log_validation_json':json.dumps({'na_closed_loop_only':False})})
    assert not app.version_closed_loop_only({'log_validation_json':''})


class SimpleVar:
    def __init__(self,value):self.value=value
    def set(self,value):self.value=value
    def get(self):return self.value


def test_na_exception_uses_explicit_in_panel_consent():
    report=lc.analyze_log(LOG,'neural_network')
    fake=app.ReviewApp.__new__(app.ReviewApp)
    fake.setup_panel_message=None;fake.setup_message_host=None
    fake.vs_vars={'log':SimpleVar('missing-knock.hpl')}
    fake.vs_na_closed_loop_only=False;fake.vs_log_valid=False;fake.vs_log_staged=True
    fake.vs_log_report=report
    fake._render_setup_lower_view=lambda:None
    fake._vehicle_form_update=lambda:None
    selected_another=[]
    fake._select_current_log=lambda:selected_another.append(True)
    responses=[]
    with patch('ve_optimizer_boost_review.na_closed_loop_evidence',return_value=(True,{})), \
         patch.object(app.messagebox,'askyesno') as ask:
        fake._prompt_na_closed_loop_only(report,'tune.htt',LOG,
            lambda updated,approved:responses.append((updated,approved)))
        assert not responses, 'No qualification before explicit button selection.'
        assert fake.setup_panel_message['heading']=='KNOCK DATA NOT FOUND'
        actions=dict(fake.setup_panel_message['actions'])
        assert set(actions)=={'Yes','No'}
        ask.assert_not_called()
        actions['No']()
        assert selected_another and not responses
        assert fake.vs_vars['log'].get()==''
        fake._prompt_na_closed_loop_only(report,'tune.htt',LOG,
            lambda updated,approved:responses.append((updated,approved)))
        dict(fake.setup_panel_message['actions'])['Yes']()
        assert responses[0][1] and responses[0][0]['na_closed_loop_only']
    with patch('ve_optimizer_boost_review.na_closed_loop_evidence',return_value=(False,{})):
        fake._prompt_na_closed_loop_only(report,'tune.htt',LOG,
            lambda updated,approved:responses.append((updated,approved)))
        assert not responses[-1][1]


def test_no_knock_wideband_cannot_override_explicit_consent_gate():
    report=lc.analyze_log(LOG,'neural_network')
    with patch.object(wb,'detect_airflow_model',return_value='neural_network'), patch.object(wb,'build_correction_preflight',return_value={
        'configuration':{'airflow_model':'neural_network'},
        'sources':{'adaptive':{'valid':True},'wideband':{'valid':True,'processor_ready':True}},
        'airflow_map_preflight':{'blocking':False},
    }):
        q=wbi.qualify_log_for_tune(LOG,'tune.htt',report)
    assert not q['passed']
    assert not q['adaptive_ready']
    assert not q['wideband_ready']
