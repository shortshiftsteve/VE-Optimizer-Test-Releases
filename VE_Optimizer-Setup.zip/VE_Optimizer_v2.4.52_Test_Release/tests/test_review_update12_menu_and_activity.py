"""Review Update 12: focused UI-only menu and PROCESSING presentation checks."""
from pathlib import Path
import tkinter as tk

import ve_optimizer_revision9_review as app


class ActivityWidget:
    """Minimal read-only Tk Text substitute for checking recorded presentation."""
    def __init__(self):
        self.parts=[]
    def winfo_exists(self):return True
    def configure(self,**_):pass
    def delete(self,*_):self.parts=[]
    def insert(self,_where,value,*_style):self.parts.append(value)
    def see(self,*_):pass
    @property
    def text(self):return ''.join(self.parts)


def test_activity_is_readable_and_hides_internal_prefixes():
    ui=app.ReviewApp.__new__(app.ReviewApp)
    ui.setup_progress_log=ActivityWidget()
    ui.setup_activity_state=None
    ui._progress_activity_times={}
    ui.run_quality_activity_lines=[
        'DATA    VIN: Available',
        'DATA    Vehicle: Information populated — Verify to confirm',
        'DATA    Channels: 19 available',
        'DATA    Fuel trims: Qualified',
        'DATA    Wideband: Qualified',
        'WORKING  Prepare review',
        'COMPLETE 100%  Prepare review',
        'OVERALL 100%  Processing complete — Candidate verified.',
    ]
    ui._refresh_progress_activity()
    rendered=ui.setup_progress_log.text
    assert 'RECENT ACTIVITY' in rendered
    for expected in ('VIN  —  Available','Vehicle  —  Information populated',
                     'Channels  —  19 available', 'Fuel trims  —  Qualified',
                     'Wideband  —  Qualified', 'In progress  —  Prepare review',
                     'Completed  —  Prepare review','Candidate verified.'):
        assert expected in rendered
    for forbidden in ('DATA    ','WORKING  ','COMPLETE 100%  ','native metadata','HPL profile'):
        assert forbidden not in rendered
    # The original processing records remain untouched for processing logic.
    assert ui.run_quality_activity_lines[0]=='DATA    VIN: Available'


def test_processing_facts_do_not_expose_vin_provenance():
    source=(Path(app.__file__).read_text(encoding='utf-8'))
    assert "self._record_processing_fact('VIN','Available')" in source
    assert "self._record_processing_fact('VIN','Not available (optional)')" in source
    assert "VIN recovered from HPL. Identifying" not in source
    assert "17-character VIN recovered from native metadata" not in source
    assert 'No recoverable VIN; vehicle identification is optional' not in source
    assert 'HPL profile' not in source
    assert "self._record_processing_fact('Fuel trims','Qualified' if adaptive_ok else 'Not qualified')" in source
    assert "self._record_processing_fact('Wideband','Qualified' if wideband_ok else 'Not qualified')" in source


def test_live_tools_menu_contains_only_approved_shortcuts(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1200x880')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'menu12.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity()
        ui.shell()
        bar=ui.menu_bar
        assert [bar.entrycget(i,'label') for i in range(bar.index('end')+1)]==['File','Edit','Tools','Help']
        menu=root.nametowidget(bar.entrycget(2,'menu'))
        choices=[menu.entrycget(i,'label') for i in range(menu.index('end')+1)]
        assert choices[:4]==['Downloads','Preflight','Run/Review','Results']
        assert 'Channel List' not in choices
        assert 'VE Surface Viewer' not in choices
        assert 'Diagnostics' not in choices
        assert menu.type(0)=='cascade'
        downloads=root.nametowidget(menu.entrycget(0,'menu'))
        assert downloads.index('end')==0
        assert downloads.type(0)=='command'
        assert downloads.entrycget(0,'label')=='Channel List'
        # The submenu entry, not the parent cascade, invokes the existing exporter.
        invoked=[]
        downloads.entryconfigure(0,command=lambda:invoked.append('export'))
        menu.invoke(0)
        assert invoked==[]
        downloads.invoke(0)
        assert invoked==['export']
    finally:
        if ui:ui.db.close()
        root.destroy()


def test_processing_quality_ready_message_does_not_request_run():
    """The automatic Submit path must never insert a manual Run prompt."""
    root=tk.Tk()
    root.withdraw()
    try:
        ui=app.ReviewApp.__new__(app.ReviewApp)
        ui.running=False
        ui.run_quality_activity_lines=[]
        ui.setup_progress_log=ActivityWidget()
        ui.setup_activity_state=None
        ui._progress_activity_times={}
        ui._run_quality_source_model=lambda:(None,'Not selected',None,'Unknown',{}, {})
        parent=tk.Frame(root)
        ui._build_run_quality_panel(parent)
        activity=ui.setup_progress_log.text
        assert 'Processing continues automatically' in activity
        assert 'respond to prompts when required' in activity
        assert 'Select Run' not in activity
        assert len(ui.run_quality_activity_lines)==1
    finally:
        root.destroy()


def test_v1_staging_status_does_not_ask_for_run():
    source=Path(app.__file__).read_text(encoding='utf-8')
    assert "self.vs_status.set(f'V{version_no} Log File stored; preparing correction preflight.')" in source
    assert "self.vs_status.set(f'V{version_no} ready to run.')" not in source


def test_in_app_help_reflects_new_menu():
    doc=(Path(app.__file__).resolve().parent/'help/VE_Optimizer_Help_Version_2.txt').read_text(encoding='utf-8')
    assert 'Tools --> Downloads --> Channel List' in doc
    assert 'Tools --> Downloads _ Channel List' not in doc
    assert 'Tools --> Channel List' not in doc
    assert 'without requiring a separate Run action.' in doc
