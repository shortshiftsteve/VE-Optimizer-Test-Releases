"""6.2L setup support and verified PCM Method A/B switch selection.

The test-generated .htt records are synthetic; optional stock/tuned-file
regressions use the user's unmodified source files when mounted. No donor tune
is embedded in the application or shipped by this test.
"""
from pathlib import Path
import struct

import pytest

import ve_optimizer_revision9_review as ui
import ve_optimizer_wideband as wb
from ve_optimizer_htt_codec import HEADER, FOOTER, HTTDocument, HTTRecord, build_htt, parse_htt


STOCK_57 = Path('/mnt/data/2023 Challengr Stock Tune Full Engine with Fuel System(3).htt')
STOCK_64 = Path('/mnt/data/2016 Dodge Challenger 6.4L Stock Tune.htt')
STOCK_62_TRACKHAWK = Path('/mnt/data/Stock 6.2L Trackhawk (Hellcat).htt')
TUNED_62_TRACKHAWK = Path('/mnt/data/Tuned 6.2L Trackhawk (Hellcat).htt')
STOCK_62_CHALLENGER = Path('/mnt/data/2016 Dodge Challenger 6.2L Supercharged Hellcat Stock Tune.htt')
PARAMETERS_62 = Path('/mnt/data/Stock 6.2L Trackhawk (Hellcat) Parameters and descriptions.csv')


def _switch_record(key: int, value: str) -> HTTRecord:
    payload = value.encode('ascii')
    # 'Enabled' and 'Disabled' lengths fit a single-byte canonical varint.
    return HTTRecord('switch', key, struct.pack('<HHB', key, 0, len(payload)) + payload)


def _synthetic_switch_tune(destination: Path, *, proper: str | None, unrelated: str) -> Path:
    entries = [_switch_record(47500, unrelated)]
    if proper is not None:
        entries.append(_switch_record(2088, proper))
    entries.sort(key=lambda row: row.key)
    destination.write_bytes(build_htt(HTTDocument(HEADER, tuple(entries), (), (), FOOTER)))
    return destination


def test_62l_engine_is_selectable_and_vin_displacement_is_supported():
    assert ui.ENGINE_OPTIONS == ('5.7L Hemi', '6.2L Supercharged Hemi', '6.4L Hemi')
    assert ui.engine_from_displacement(5.7) == '5.7L Hemi'
    assert ui.engine_from_displacement('6.2') == '6.2L Supercharged Hemi'
    assert ui.engine_from_displacement(6.4) == '6.4L Hemi'
    assert ui.engine_from_displacement(4.0) == ''


@pytest.mark.parametrize(('proper','unrelated','expected'), [
    ('Disabled', 'Enabled', 'speed_density'),
    ('Enabled', 'Disabled', 'neural_network'),
    ('Disabled', 'Disabled', 'speed_density'),
    ('Enabled', 'Enabled', 'neural_network'),
])
def test_2088_alone_controls_method_selection(tmp_path, proper, unrelated, expected):
    tune = _synthetic_switch_tune(tmp_path/'switches.htt', proper=proper, unrelated=unrelated)
    assert wb.USE_NEURAL_NETWORK_SWITCH == 2088
    assert wb.read_switch(tune, 2088) == proper
    assert wb.read_switch(tune, 47500) == unrelated
    status = wb._airflow_model_switch_status(tune)
    assert status['airflow_model'] == expected
    assert status['detection_source'] == 'tune_switch'
    assert wb.detect_airflow_model(tune) == expected
    assert wb.detect_configuration(tune)['airflow_model'] == expected


def test_unrelated_47500_cannot_replace_missing_2088(tmp_path):
    tune = _synthetic_switch_tune(tmp_path/'missing.htt', proper=None, unrelated='Enabled')
    with pytest.raises(ValueError, match='Use Neural Network is not stored'):
        wb.detect_airflow_model(tune)


def test_explicit_switch_overrides_neural_network_presence(tmp_path):
    tune = _synthetic_switch_tune(tmp_path/'disabled.htt', proper='Disabled', unrelated='Enabled')
    # The method selection is determined before NN decode/qualification.
    assert wb.detect_configuration(tune)['wideband_sd_supported'] is True
    assert wb.detect_configuration(tune)['wideband_nn_supported'] is False


def test_62l_reference_description_covers_relevant_features():
    if not PARAMETERS_62.is_file():
        pytest.skip('External 6.2L parameter-description source is not mounted')
    import csv
    with PARAMETERS_62.open(newline='', encoding='utf-8-sig') as f:
        entries = list(csv.DictReader(f))
    assert set(entries[0]) == {'Name','Description'}  # Descriptions do NOT carry record IDs.
    names = {str(row['Name']) for row in entries}
    for name in ('Use Neural Network', 'VE Bank 1', 'VE Bank 2', 'FA Stoich',
                 'FA Stoich Even', 'FA Stoich Odd', 'FA Power Enrich Table Select',
                 'FA Power Enrich Aircharge Based', 'FA Power Enrich PRatio Based',
                 'MAP Sensor Linear'):
        assert name in names


@pytest.mark.parametrize(('tune','expect_method','expected_switch'), [
    (STOCK_57, 'neural_network', 'Enabled'),
    (STOCK_64, 'neural_network', 'Enabled'),
    (STOCK_62_TRACKHAWK, 'neural_network', 'Enabled'),
    (STOCK_62_CHALLENGER, 'neural_network', 'Enabled'),
    (TUNED_62_TRACKHAWK, 'speed_density', 'Disabled'),
])
def test_original_source_switches_select_correct_method(tune, expect_method, expected_switch):
    if not tune.is_file():
        pytest.skip('External engine .htt source is not mounted')
    doc = parse_htt(tune.read_bytes())
    assert doc.by_key()[2088].kind == 'switch'
    assert doc.by_key()[47500].kind == 'switch'
    assert wb.read_switch(tune, 2088) == expected_switch
    assert wb.read_switch(tune, 47500) == 'Enabled'
    assert wb.detect_airflow_model(tune) == expect_method


@pytest.mark.parametrize('tune', [STOCK_62_TRACKHAWK, STOCK_62_CHALLENGER, TUNED_62_TRACKHAWK])
def test_62l_calibration_has_expected_identified_records_and_types(tune):
    if not tune.is_file():
        pytest.skip('External 6.2L engine .htt source is not mounted')
    by_key = parse_htt(tune.read_bytes()).by_key()
    required_switches = (2088, 34229)
    required_scalars = (3601,3394,3395,3396,3397, 44271,4011,44272, 44490)
    required_tables = (3589,3585,3597,3593,3581,3577,3602,
                       44273,44274,34290,34292,34294,34230,34243)
    for key in required_switches:
        assert by_key[key].kind == 'switch', key
    for key in required_scalars:
        assert by_key[key].kind == 'scalar', key
    for key in required_tables:
        assert by_key[key].kind == 'table', key
    assert wb.parse_ve_table(tune,44273)[3].shape == (17,17)
    assert wb.parse_ve_table(tune,44274)[3].shape == (17,17)
    assert wb.parse_numeric_2d_table(tune,34230)['z'].shape == (17,17)
    assert wb.parse_numeric_2d_table(tune,34243)['z'].shape == (17,17)


def test_tuned_62l_speed_density_axis_uses_its_own_rpm_and_map1():
    if not TUNED_62_TRACKHAWK.is_file():
        pytest.skip('External tuned Trackhawk source is not mounted')
    domain = wb.speed_density_axis_preflight(TUNED_62_TRACKHAWK)
    assert domain['rpm_source_record'] == 44490
    assert domain['recommended_rpm_min'] == 0.0
    assert domain['recommended_rpm_max'] == 6500.0
    assert domain['pratio_source'] == 'MAP1 calibrated 0-5V transfer'
    assert domain['map1_sensor_class']
    assert domain['proposed_rpm_axis'].size == 17
    assert domain['proposed_pratio_axis'].size == 17
