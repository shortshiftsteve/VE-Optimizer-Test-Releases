from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_revision9_review as app


def test_release_identity():
    assert app.APP_VERSION=='2.4.52'
    assert app.BUILD_ID=='2.4.52-Release'
    assert app.RELEASE_STAGE=='Release'


def test_single_user_is_default_and_multi_user_persists(tmp_path):
    db=app.ReviewDatabase(tmp_path/'ve_optimizer.db')
    try:
        assert db.multi_user_enabled() is False
        u=db.single_user_identity()
        assert u.id>0 and u.role=='admin'
        db.set_multi_user_enabled(True)
        assert db.multi_user_enabled() is True
        db.set_multi_user_enabled(False)
        assert db.multi_user_enabled() is False
    finally:
        db.close()


def test_navigation_contract_and_start_page_source():
    import inspect
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "NAV=(('projects','Projects'),('setup','New Project')" in src
    assert "self.root.after(1200,self.startup)" in src
    assert "Enable Multi User mode (requires sign-in at startup)" in src
    single=inspect.getsource(app.ReviewApp._enter_single_user_mode)
    login=inspect.getsource(app.ReviewApp.login)
    eula=inspect.getsource(app.ReviewApp.show_eula_acceptance)
    assert "goto('setup')" in single
    assert "goto('projects')" in login
    assert "goto('projects')" in eula
    assert "goto('setup')" not in eula


def test_log_validation_has_vertical_scrollbar():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "table_scroll=tk.Scrollbar(table_host,orient='vertical')" in src
    assert "yscrollcommand=table_scroll.set" in src
    assert "table_scroll.config(command=table_canvas.yview)" in src


def test_preflight_statuses_are_pass_fail_for_requested_rows():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "Automatic Airflow Preparation','PASS' if airmap.get('automatic_change_allowed') else 'FAIL'" in src
    assert "ad_status='PASS' if ad.get('valid') else ('AVAILABLE' if stft_available else 'FAIL')" in src
    assert "Automatic Airflow Preparation','WILL FIX'" not in src
    assert "source_row(ad_label,'VALID'" not in src


def test_module_review_functions_use_version_baseline_not_gui_self():
    import inspect
    for fn in (app.execute_review,app.execute_wideband_review,app.execute_combined_review):
        src=inspect.getsource(fn)
        assert "self._surface_baseline_path" not in src
        assert "baseline=Path(v['baseline_htt_path'])" in src


def test_wideband_review_nn_disabled_path_no_nameerror(tmp_path,monkeypatch):
    baseline=tmp_path/'baseline.htt';baseline.write_bytes(b'baseline')
    log=tmp_path/'log.hpl';log.write_bytes(b'log')
    out=tmp_path/'project'/'V0';out.mkdir(parents=True)

    class Conn:
        def execute(self,*a,**k): return self
        def commit(self): return None
    class DB:
        conn=Conn()
        path=tmp_path/'db.sqlite'
        def _assert_owner(self,pid,uid): pass
        def get_version(self,pid,vn):
            return {'version_no':0,'run_completed':0,'log_local_path':str(log),'baseline_htt_path':str(baseline),
                    'log_sha256':app.s5.sha256_file(log),'baseline_htt_sha256':app.s5.sha256_file(baseline)}
        def latest_version(self,pid): return self.get_version(pid,0)
        def version_setup_complete(self,pid,vn): return True
        def validate_initial_htt(self,p): return None
        def version_dir(self,pid,vn): return out
        def record_event(self,*a,**k): return None
        def project_state(self,*a,**k): return {'state':'READY_TO_APPLY'}

    candidate=out/'candidate.htt';candidate.write_bytes(b'candidate')
    accepted=out/'accepted.csv';accepted.write_text('x\n',encoding='utf-8')
    metrics={'method_id':'wideband-speed-density-0.1','qualifying_cells':1,'rescaled':False}
    payload={'method_id':'wideband-speed-density-0.1','levels':{'50':{}},'accepted_csv':str(accepted),
             'accepted_sha256':app.s5.sha256_file(accepted),'baseline_htt':str(baseline),
             'baseline_sha256':app.s5.sha256_file(baseline),'log_sha256':app.s5.sha256_file(log)}
    monkeypatch.setattr(app,'verify_assets',lambda _p:None)
    monkeypatch.setattr(app.wideband_integration,'build_wideband_preview',lambda *a,**k:{'payload':payload,'metrics':metrics,'candidate':candidate})
    result=app.execute_wideband_review(DB(),1,1,ROOT/'a',version_no=0)
    assert result['version_no']==0
    assert result['metrics']['qualifying_cells']==1


def test_run_review_uses_universal_live_quality_panel():
    import inspect
    page=inspect.getsource(app.ReviewApp.page_review)
    progress=inspect.getsource(app.ReviewApp._set_progress)
    assert "self._build_run_quality_panel(b,results_ready=results_ready)" in page
    assert "_build_run_trim_chart" not in page
    assert "_append_run_quality_activity" in progress
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "text='Processing Quality'" in src
    assert "Accepted samples" in src and "Qualified cells" in src and "Verification" in src


def test_missing_nn_switch_uses_verified_legacy_nn_compatibility(monkeypatch,tmp_path):
    import ve_optimizer_wideband as wb
    tune=tmp_path/'legacy.htt';tune.write_bytes(b'legacy')
    monkeypatch.setattr(wb,'read_switch',lambda path,key: (_ for _ in ()).throw(KeyError('missing')) if key==wb.USE_NEURAL_NETWORK_SWITCH else 'Aircharge')
    monkeypatch.setattr(wb.htt,'load_network',lambda path:{'meta':{'neurons':6},'Wo':[1,2,3,4,5,6]})
    assert wb.detect_airflow_model(tune)=='neural_network'
    status=wb._airflow_model_switch_status(tune)
    assert status['detection_source']=='legacy_nn_compatibility'
    assert status['use_neural_network']=='Enabled (legacy compatibility)'
    assert 'not stored' in status['warning']


def test_missing_nn_switch_fails_if_no_complete_nn(monkeypatch,tmp_path):
    import ve_optimizer_wideband as wb
    tune=tmp_path/'bad.htt';tune.write_bytes(b'bad')
    monkeypatch.setattr(wb,'read_switch',lambda path,key: (_ for _ in ()).throw(KeyError('missing')) if key==wb.USE_NEURAL_NETWORK_SWITCH else 'Aircharge')
    monkeypatch.setattr(wb.htt,'load_network',lambda path: (_ for _ in ()).throw(KeyError('no network')))
    try:
        wb.detect_airflow_model(tune)
    except ValueError as exc:
        assert 'legacy Neural Network compatibility check also failed' in str(exc)
    else:
        raise AssertionError('Expected missing switch without a complete NN to fail')


def test_preflight_ui_surfaces_legacy_airflow_warning():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "cfg.get('airflow_model_warning')" in src
    assert "str(cfg.get('airflow_model_warning'))" in src


def test_file_menu_new_project_is_true_fresh_project_action():
    import inspect
    shell=inspect.getsource(app.ReviewApp.shell)
    new_project=inspect.getsource(app.ReviewApp._new_project_setup)
    reset=inspect.getsource(app.ReviewApp._reset_project_workflow_state)
    assert "file_menu.add_command(label='New Project',command=self._new_project_setup)" in shell
    assert "self._reset_project_workflow_state()" in new_project
    for token in ("self.project=None","self.active_version_no=None","self.correction_preflight_cache=None",
                  "self.correction_source_selection=None","self.run_quality_activity_lines=[]",
                  "self.progress.set(0)","self.page_history=[]"):
        assert token in reset


def test_log_validation_details_are_never_skipped_for_qualified_alternate_path():
    import inspect
    qualify=inspect.getsource(app.ReviewApp._qualify_log_file)
    select=inspect.getsource(app.ReviewApp._submit_selected_log)
    dialog=inspect.getsource(app.ReviewApp._show_log_validation)
    assert "qualified_override=passed" in qualify
    # The full channel inventory is now View-only. Preserve the combined
    # log/correction qualification in its on-demand dialog.
    assert "qualified_override=False" in inspect.getsource(app.ReviewApp._view_failed_log_diagnostics)
    assert "_show_log_validation(report,require_decision=True" not in select
    assert "qualified_override" in dialog
    assert "action='continue'" not in select
    assert "self.vs_log_validation_action='continue'" not in qualify


def test_processing_activity_labels_historical_overall_percent_and_finishes_at_100():
    import inspect
    activity=inspect.getsource(app.ReviewApp._append_run_quality_activity)
    done=inspect.getsource(app.ReviewApp._review_ok)
    assert "OVERALL" in activity
    assert "COMPLETE • 100%" in done
    processing=(ROOT/'ve_optimizer_processing.py').read_text(encoding='utf-8')
    assert "% of solver limit" in processing


def test_preflight_accepts_legacy_tune_missing_optional_pe_selector_and_tables(tmp_path):
    import ve_optimizer_wideband as wb
    from ve_optimizer_htt_codec import parse_htt
    original=ROOT/'tests'/'fixtures'/'stock.htt'
    log=ROOT/'tests'/'fixtures'/'fresh_log.hpl'
    # The historical fixture's actual switch 2088 says Disabled (Method B),
    # while its incomplete .htt lacks the Maximum RPM needed for Method B.
    # Isolate the original PE-optional compatibility assertion in an explicit
    # Method A copy. Never mistake switch 47500 for Use Neural Network.
    tune=tmp_path/'legacy_nn_no_pe.htt'
    tune.write_bytes(wb._replace_length_payload(original.read_bytes(),
                                                wb.USE_NEURAL_NETWORK_SWITCH, b'Enabled'))
    assert parse_htt(tune.read_bytes()).by_key()[2088].kind == 'switch'
    assert wb.detect_airflow_model(tune) == 'neural_network'
    status=wb._pe_table_axis_status(tune)
    assert status['present'] is False
    assert status['value'] is None
    pf=wb.build_correction_preflight(log,tune)
    assert pf['configuration']['pe_table_axis']=='Not stored'
    assert pf['pe_preflight']=={}  # PE calibration is not part of correction preflight
    adaptive=next(x for x in pf['choices'] if x['id']=='adaptive')
    assert adaptive['enabled'] is True


def test_missing_pe_selector_is_blocking_only_when_boosted_pe_requires_it(monkeypatch):
    import ve_optimizer_wideband as wb
    tune=ROOT/'tests'/'fixtures'/'stock.htt'
    log=ROOT/'tests'/'fixtures'/'fresh_log.hpl'
    monkeypatch.setattr(wb,'_pe_operating_pratio_status',lambda *a,**k:{
        'valid':True,'missing':[],'dual_gate_samples':10,'boosted_samples':10,
        'boosted_detected':True,'boost_threshold':1.06,'minimum_boost_samples':5,
        'observed_pratio_min':1.10,'observed_pratio_max':1.25,'reason':None})
    pf=wb.pe_strategy_preflight(log,tune)
    assert pf['blocking'] is True
    assert 'stored FA Power Enrich Table Select' in '; '.join(pf['issues'])
    assert 'Internal key' not in '; '.join(pf['issues'])


def test_pe_calibration_review_not_shown_or_used_as_source_gate():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "cfg.get('pe_table_axis_warning')" not in src
    assert "source_row('PE Calibration Safety'" not in src
    assert "pe_status,pe_kind='AUTO PREP'" not in src
    assert "VE Optimizer will automatically rescale the PE PRatio table" not in src


def test_update5_preflight_visible_continue_and_single_source_defensive_selection():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "enabled_sources=[k for k in ('adaptive','wideband') if choices.get(k,{}).get('enabled')]" in src
    assert "if self.correction_source_selection not in enabled_sources:" in src
    assert "self.correction_source_selection=(enabled_sources[0] if len(enabled_sources)==1 else None)" in src
    assert "self._show_preflight_prompt()" in src
    assert "label='Continue';callback=self._run_selected_correction" in src


def test_update5_setup_action_buttons_match_and_working_text_is_white():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "self.vs_log_button=input_row" in src
    assert "self.setup_workflow_button=ttk.Button(self.setup_primary_actions" in src
    assert "WorkingPrimary.TButton" in src
    assert "foreground=[('disabled','white'),('!disabled','white')]" in src
    assert "button.config(text='Processing',style='WorkingPrimary.TButton')" in src
    assert "button.config(text='Build',style='Primary.TButton')" in src


def test_approved_ui_removes_sidebar_and_customer_photo():
    import inspect
    shell=inspect.getsource(app.ReviewApp.shell)
    setup=inspect.getsource(app.ReviewApp.page_setup)
    settings=inspect.getsource(app.ReviewApp.page_settings)
    assert 'bar.add_cascade' in shell
    assert "side=tk.Frame(self.root" not in shell
    assert 'CUSTOMER PHOTO' not in setup
    assert 'CUSTOMER PHOTO' not in settings
    assert 'self.setup_message_host=' in setup
    assert 'self.setup_processing_host=' in setup
