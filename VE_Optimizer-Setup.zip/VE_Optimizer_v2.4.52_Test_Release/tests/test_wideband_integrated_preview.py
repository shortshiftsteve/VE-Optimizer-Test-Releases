from pathlib import Path
import sys
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

import ve_optimizer_logcheck as logcheck
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integration

SD_TUNE=Path('/mnt/data/RV_TH8.1_HE5.htt')
WB_LOG=Path('/mnt/data/091225_RV_TH8_HE5_2 reformatted.hpl')

_REQUIRED_EXTERNAL_FIXTURES=[SD_TUNE,WB_LOG]
if not all(p.is_file() for p in _REQUIRED_EXTERNAL_FIXTURES):
    pytestmark=pytest.mark.skip(reason='External wideband development fixtures are not bundled with this release source package.')



def test_wideband_only_log_qualifies_for_selected_tune():
    standard=logcheck.analyze_log(WB_LOG)
    assert standard['passed'] is False
    q=integration.qualify_log_for_tune(WB_LOG,SD_TUNE,standard)
    assert q['passed'] is True
    assert q['adaptive_ready'] is False
    assert q['wideband_ready'] is True
    assert q['qualification_basis']=='wideband'
    assert q['wideband_correction_blocked'] is False
    airflow=q['correction_preflight']['airflow_map_preflight']
    assert airflow['blocking'] is False
    assert airflow['auto_fix_required'] is True
    assert airflow['pressure_ratio_max_change_required'] is True
    assert airflow['sensed_map_enable_change_required'] is False


def test_integrated_speed_density_preview_auto_prepares_and_rescales(tmp_path):
    built=integration.build_wideband_preview(
        SD_TUNE,WB_LOG,tmp_path/'auto'
    )
    metrics=built['metrics']
    assert metrics['airflow_prepared'] is True
    assert metrics['rescaled'] is True
    assert Path(built['candidate']).is_file()
    airflow_prepare=metrics['airflow_prepare']
    assert airflow_prepare['scope_verified'] is True
    changed={item['parameter'] for item in airflow_prepare['changes']}
    assert changed=={'Pressure Ratio Max'}


def test_boosted_preflight_reports_exact_airflow_repairs_before_ve_rescale():
    pf=wb.build_correction_preflight(WB_LOG,SD_TUNE,delay_ms=60)
    airflow=pf['airflow_map_preflight']
    assert airflow['observed_pratio_max'] > 2.0
    assert airflow['pressure_ratio_max'] == 1.0
    assert airflow['sensed_map_enable'] == 'Disabled'
    assert airflow['throttle_based_map_multiplier']['rpm_covered'] is True
    assert airflow['map1']['sensor_class'] == '3-bar'
    assert airflow['map2']['sensor_class'] == '3-bar'
    assert airflow['baro_status'] == 'operating_reference_only'
    assert airflow['auto_fix_required'] is True
    assert airflow['blocking'] is False
    assert {x['id']:x for x in pf['choices']}['wideband']['enabled'] is True


def test_current_method_ids_include_combined_routes():
    assert integration.WB_SD_METHOD in integration.CURRENT_METHOD_IDS
    assert integration.WB_NN_METHOD in integration.CURRENT_METHOD_IDS
    assert integration.COMBINED_SD_METHOD in integration.CURRENT_METHOD_IDS
    assert integration.COMBINED_NN_METHOD in integration.CURRENT_METHOD_IDS
