"""Native HPL VIN prefill and Trackhawk Verify -> Submit regression.

The visible Decode/Autofill feature has been retired; log-selected metadata
triggers the optional VIN lookup. All tests use synthetic VINs, never network.
"""
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk

import pytest

import ve_optimizer_revision9_review as app


TRACKHAWK_VIN = '1C4RJFN9XJC000000'  # Synthetic test VIN; no live lookup.


def _urlopen_trackhawk(_request, timeout=8):
    class Response:
        def __enter__(self):return self
        def __exit__(self, *_):return None
        def read(self):
            return json.dumps({'Results':[{'ModelYear':'2018','Make':'JEEP',
                'Model':'Grand Cherokee','Trim':'Trackhawk','DisplacementL':'6.2',
                'TransmissionStyle':'Automatic'}]}).encode()
    return Response()


def _descendants(widget):
    for child in widget.winfo_children():
        yield child
        yield from _descendants(child)


def _button(parent, name):
    return next(w for w in _descendants(parent) if isinstance(w, ttk.Button) and w.cget('text') == name)


def test_jeep_trackhawk_vin_maps_to_supported_setup_choice(monkeypatch):
    monkeypatch.setattr(app.urllib.request, 'urlopen', _urlopen_trackhawk)
    decoded=app.decode_vin_optional(TRACKHAWK_VIN)
    assert decoded['model_name']=='Trackhawk'
    assert decoded['model_name'] in app.MODEL_OPTIONS
    assert decoded['engine']=='6.2L Supercharged Hemi'
    assert decoded['transmission']=='Auto'
    assert decoded['model_year']=='2018'


@pytest.fixture
def setup_with_log(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1300x850')
    inst=app.ReviewApp(root,tmp_path/'data.db',Path(app.__file__).resolve().parent/'a')
    inst.user=inst.db.single_user_identity()
    inst.shell();inst.goto('setup');root.update()
    htt=tmp_path/'source.htt';htt.write_bytes(b'test fixture')
    hpl=tmp_path/'log.hpl';hpl.write_bytes(b'test fixture')
    monkeypatch.setattr(inst,'_setup_candidate_tune_path',lambda:htt)
    inst.vs_vars['htt'].set(str(htt))
    monkeypatch.setattr(app.filedialog,'askopenfilename',lambda **_:str(hpl))
    try:
        yield root,inst
    finally:
        inst._stop_setup_verify_blink()
        inst.db.close()
        root.destroy()


def _select_with_vin(root,inst,monkeypatch,decoded=None):
    monkeypatch.setattr(app,'extract_hpl_vin',lambda _path:TRACKHAWK_VIN)
    monkeypatch.setattr(app.urllib.request,'urlopen',_urlopen_trackhawk)
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda worker,done:jobs.append((worker,done)))
    inst._select_current_log();root.update()
    assert inst.vs_vars['vin'].get()==TRACKHAWK_VIN
    assert inst.vs_vin_entry.cget('state')=='readonly'
    assert inst.vs_vin_button is None
    assert not any(w.cget('text')=='Decode / Autofill' for w in _descendants(inst.content)
                   if isinstance(w,ttk.Button))
    assert inst._vin_lookup_pending
    assert inst.setup_workflow_button.cget('text')=='Processing'
    assert len(jobs)==1
    worker,done=jobs.pop()
    done(decoded if decoded is not None else worker())
    root.update()
    assert not inst._vin_lookup_pending
    assert inst.setup_workflow_button.cget('text')=='Verify'
    return jobs


def test_native_log_vin_autofills_then_allows_verify_and_submit(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    jobs=_select_with_vin(root,inst,monkeypatch)
    assert inst.vs_vars['model'].get()=='Trackhawk'
    assert inst.vs_vars['engine'].get()=='6.2L Supercharged Hemi'
    assert inst.vs_vars['year'].get()=='2018'
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    assert inst.vs_log_submit_button is inst.setup_workflow_button
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFIED'
    inst.vs_log_submit_button.invoke();root.update()
    assert len(jobs)==1
    assert inst.setup_panel_message['heading']=='Log File Validation'


def test_no_vin_remains_blank_without_blocking_verify(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    monkeypatch.setattr(app,'extract_hpl_vin',lambda _p:'')
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda worker,done:jobs.append((worker,done)))
    inst._select_current_log();root.update()
    assert inst.vs_vars['vin'].get()==''
    assert not inst._vin_lookup_pending
    assert not jobs
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()
    assert inst.setup_workflow_button.cget('text')=='Submit'


def test_editing_autofilled_vehicle_revokes_verify(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    _select_with_vin(root,inst,monkeypatch)
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst.vs_log_submit_button.winfo_manager()=='pack'
    inst.vs_vars['engine'].set('6.4L Hemi');root.update()
    assert not inst._setup_vehicle_is_verified()
    assert inst.vs_log_submit_button is inst.setup_workflow_button
    assert inst.setup_workflow_button.cget('text')=='Verify'
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()


def test_nonlisted_decoded_vehicle_type_and_year_can_be_verified(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    decoded={'vin':TRACKHAWK_VIN,'model_year':'2025',
             'model_name':'Jeep Grand Cherokee Trackhawk Custom',
             'engine':'6.2L Supercharged Hemi','transmission':'Auto'}
    _select_with_vin(root,inst,monkeypatch,decoded)
    assert inst.vs_vars['model'].get()==decoded['model_name']
    assert decoded['model_name'] not in app.MODEL_OPTIONS
    assert inst.vs_vars['year'].get()=='2025'
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()
    assert inst.setup_workflow_button.cget('text')=='Submit'


def test_unavailable_vin_service_keeps_vin_and_allows_verify(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    monkeypatch.setattr(app,'extract_hpl_vin',lambda _p:TRACKHAWK_VIN)
    monkeypatch.setattr(app,'decode_vin_optional',lambda _vin:(_ for _ in ()).throw(OSError('offline')))
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda worker,done:jobs.append((worker,done)))
    inst._select_current_log();root.update()
    worker,done=jobs.pop()
    done(worker());root.update()
    assert inst.vs_vars['vin'].get()==TRACKHAWK_VIN
    assert inst.vs_vars['model'].get()=='Dodge Challenger'
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()


def test_reselect_log_ignores_stale_vin_lookup(setup_with_log,monkeypatch,tmp_path):
    root,inst=setup_with_log
    first=tmp_path/'log.hpl'
    second=tmp_path/'other.hpl';second.write_bytes(b'other fake log')
    paths=iter((str(first),str(second)))
    monkeypatch.setattr(app.filedialog,'askopenfilename',lambda **_:next(paths))
    monkeypatch.setattr(app,'extract_hpl_vin',lambda path:TRACKHAWK_VIN if str(path)==str(first) else '')
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda worker,done:jobs.append((worker,done)))
    inst._select_current_log();root.update()
    old_worker,old_done=jobs.pop()
    inst._select_current_log();root.update()
    assert inst.vs_vars['vin'].get()==''
    old_done({'model_year':'2018','model_name':'Trackhawk','engine':'6.2L Supercharged Hemi'})
    root.update()
    assert inst.vs_vars['model'].get()=='Dodge Challenger'
    assert inst.vs_vars['vin'].get()==''
    assert inst.setup_workflow_button.cget('text')=='Verify'


def test_transmission_change_revokes_verified_vehicle(setup_with_log,monkeypatch):
    root,inst=setup_with_log
    _select_with_vin(root,inst,monkeypatch)
    _button(inst.setup_primary_actions,'Verify').invoke();root.update()
    assert inst._setup_vehicle_is_verified()
    inst.vs_vars['transmission'].set('Manual');root.update()
    assert not inst._setup_vehicle_is_verified()
    assert inst.setup_workflow_button.cget('text')=='Verify'
    details=[w.cget('text') for w in _descendants(inst.setup_message_host)
             if isinstance(w,tk.Label)]
    assert any('VIN: '+TRACKHAWK_VIN in t and 'Transmission: Manual' in t for t in details)


def test_vehicle_decoder_preserves_unknown_stellantis_engine_description(monkeypatch):
    def lookup(_request, timeout=8):
        class Response:
            def __enter__(self):return self
            def __exit__(self,*_):pass
            def read(self):
                return json.dumps({'Results':[{'ModelYear':'2024','Make':'Jeep',
                     'Model':'Grand Cherokee','Trim':'Limited','DisplacementL':'3.6',
                     'TransmissionType':'Automatic'}]}).encode()
        return Response()
    monkeypatch.setattr(app.urllib.request,'urlopen',lookup)
    result=app.decode_vin_optional(TRACKHAWK_VIN)
    assert result['model_name']=='Jeep Grand Cherokee Limited'
    assert result['engine']=='3.6L Engine'  # Informational; not a tuning-method selector.
    assert result['transmission']=='Auto'
