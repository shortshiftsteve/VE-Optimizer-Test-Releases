"""Method B Fuel Flow Rate must never block STFT preflight or correction.

Change scope: NN-disabled Speed Density only.  The accepted Method A Fuel Flow
requirement remains unchanged.  This tests both missing and recorded flow data.
"""
from pathlib import Path
from unittest.mock import patch
import sys

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_logcheck as logcheck
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integration


def decoded_log(*, flow='absent', ltft=False):
    fields = [
        ('rpm', 'Engine RPM', 'rpm', 2135),
        ('torque', 'Actual Torque', 'lb-ft', 2706),
        ('map', 'MAP - Hi-Res', 'kPa', 2335),
        ('baro', 'Barometric Pressure', 'kPa', 2410),
        ('ect', 'Engine Coolant Temp', 'deg F', 2124),
        ('fa', 'FA Enrichment', '', 6056),
        ('pe', 'FA Power Enrichment', '', 6080),
        ('b1', 'Short Term Fuel Trim Bank 1 (SAE)', '%', 6),
        ('b2', 'Short Term Fuel Trim Bank 2 (SAE)', '%', 8),
    ]
    if flow != 'absent':
        fields.append(('flow', 'Fuel Flow Rate', 'lb/h', wb.FUEL_FLOW_PID))
    if ltft:
        fields.extend([
            ('ltft_b1', 'Long Term Fuel Trim Bank 1 (SAE)', '%', 7),
            ('ltft_b2', 'Long Term Fuel Trim Bank 2 (SAE)', '%', 9),
        ])
    values = {
        'rpm': 1500., 'torque': 30., 'map': 80., 'baro': 100., 'ect': 190.,
        'fa': 0., 'pe': 0., 'b1': 4., 'b2': -2.,
        'flow': 0. if flow == 'zero' else 15.,
        'ltft_b1': 2., 'ltft_b2': -1.,
    }
    return {
        'channels': {i: {'name': name, 'unit': unit, 'parameter_id': pid}
                     for i, (_, name, unit, pid) in enumerate(fields)},
        'frames': [
            {'timestamp_ms': i * 100,
             'updates': {j: values[key] for j, (key, _, _, _) in enumerate(fields)}}
            for i in range(12)
        ],
    }


def test_independent_channel_requirements():
    assert 'fuel_flow' in logcheck.METHOD_A_MANDATORY_KEYS
    assert 'fuel_flow' not in logcheck.METHOD_B_MANDATORY_KEYS
    a = {s.key: s for s in logcheck.METHOD_A_CHANNELS}
    b = {s.key: s for s in logcheck.METHOD_B_CHANNELS}
    assert a['fuel_flow'].required is True
    assert b['fuel_flow'].required is False
    assert a['fuel_flow'] is not b['fuel_flow']
    assert logcheck._profile_required(b['fuel_flow'], 'speed_density') is False


@pytest.mark.parametrize('flow', ['absent', 'zero', 'present'])
@pytest.mark.parametrize('ltft', [False, True])
def test_speed_density_preflight_and_real_calculation_ignore_fuel_flow(flow, ltft):
    decoded = decoded_log(flow=flow, ltft=ltft)
    pf = wb._adaptive_trim_status(decoded, 'speed_density')
    assert pf['valid'], pf
    assert pf['missing'] == []
    assert pf['accepted_events_bank1'] == 12
    assert pf['accepted_events_bank2'] == 12
    rpm_axis = np.array([0., 1500., 3000.])
    pr_axis = np.array([0.5, 0.8, 1.5])
    z = np.ones((3, 3))
    with patch.object(wb, 'decode_hpl', return_value=decoded), \
         patch.object(wb, 'parse_ve_table', return_value=(b'table', rpm_axis, pr_axis, z)):
        result = integration._adaptive_sd_analysis(Path('sample.hpl'), Path('sample.htt'))
    assert result['trim_mode'] == ('ltft_plus_stft' if ltft else 'stft_only')
    assert result['qualifying_cell_count'] == 1
    assert result['hit_counts'][:, 1, 1].tolist() == [12, 12]
    assert result['full_correction_pct'][1, 1] == (6.0 if ltft else 4.0)
    assert result['applied_correction_pct'][1, 1] == (3.0 if ltft else 2.0)


def test_neural_network_requires_fuel_flow_without_changing_other_rules():
    decoded = decoded_log(flow='absent', ltft=True)
    pf = wb._adaptive_trim_status(decoded, 'neural_network')
    assert not pf['valid']
    assert 'fuel_flow' in pf['missing']


def test_real_maggi_missing_fuel_flow_qualifies_for_method_b():
    path = Path('/mnt/data/5.7L with a Maggi Shortened.hpl')
    if not path.is_file():
        pytest.skip('External Maggi validation Log File is not available')
    from hpl_decoder_v1_0_0 import decode_hpl
    pf = wb._adaptive_trim_status(decode_hpl(path), 'speed_density')
    assert pf['valid'], pf
    assert (pf['accepted_events_bank1'], pf['accepted_events_bank2']) == (265, 264)
    assert pf['missing'] == []
