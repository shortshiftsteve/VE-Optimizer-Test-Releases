"""Regression for Test 3: a native .hpl must not become Log.csv in storage."""
from pathlib import Path
import sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_revision9_review as app

REFERENCE=ROOT/'tests'/'fixtures'/'fresh_log.hpl'


def test_fresh_setup_retains_native_hpl_filename(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'local'))
    db=app.ReviewDatabase(tmp_path/'test.db')
    try:
        user=db.authenticate('admin','admin')
        p=db.create_project_draft(user.id,2023,'Dodge Challenger','',engine='5.7L Hemi')
        report={'passed':True,'airflow_model':'neural_network'}
        with patch.object(app,'validate_hp_tuners_log',return_value=(True,'')), \
             patch.object(app.logcheck,'analyze_log',return_value=report):
            setup=db.save_project_setup(p.id,user.id,'',2023,'Dodge Challenger','5.7L Hemi','Auto',REFERENCE)
        stored=Path(setup['log_local_path'])
        assert stored.suffix.lower()=='.hpl'
        assert stored.read_bytes()[:6]==b'HPT \x60\x09'
        assert app.s5.sha256_file(stored)==app.s5.sha256_file(REFERENCE)
    finally:
        db.close()


def test_existing_native_hpl_with_csv_filename_is_repaired_idempotently(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'local'))
    database=tmp_path/'test.db'
    db=app.ReviewDatabase(database)
    try:
        user=db.authenticate('admin','admin')
        p=db.create_project_draft(user.id,2023,'Dodge Challenger','',engine='5.7L Hemi')
        store=tmp_path/'existing_project'/'V0';store.mkdir(parents=True)
        old=store/'Log.csv';old.write_bytes(REFERENCE.read_bytes())
        digest=app.s5.sha256_file(old)
        db.conn.execute('INSERT INTO project_versions(project_id,version_no,log_local_path,log_sha256) VALUES(?,?,?,?)',
                        (p.id,0,str(old),digest))
        db.conn.execute('INSERT INTO project_setup(project_id,log_local_path,log_sha256) VALUES(?,?,?)',
                        (p.id,str(old),digest))
        db.conn.commit()
    finally:
        db.close()
    for _ in range(2):
        db=app.ReviewDatabase(database)
        try:
            v=db.get_version(p.id,0)
            s=db.get_project_setup(p.id)
            assert Path(v['log_local_path'])==old.with_suffix('.hpl')
            assert Path(s['log_local_path'])==old.with_suffix('.hpl')
            assert old.is_file()  # preserve the existing project file
            assert app.s5.sha256_file(old)==digest
            assert app.s5.sha256_file(old.with_suffix('.hpl'))==digest
            assert Path(v['log_local_path']).suffix=='.hpl'
        finally:
            db.close()


def test_actual_csv_is_not_silently_reclassified_as_hpl(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'local'))
    db=app.ReviewDatabase(tmp_path/'test.db')
    try:
        user=db.authenticate('admin','admin')
        p=db.create_project_draft(user.id,2023,'Dodge Charger','',engine='5.7L Hemi')
        other=tmp_path/'Legitimate.csv';other.write_text('Time,Engine RPM\n0,800\n')
        digest=app.s5.sha256_file(other)
        db.conn.execute('INSERT INTO project_versions(project_id,version_no,log_local_path,log_sha256) VALUES(?,?,?,?)',
                        (p.id,0,str(other),digest))
        db.conn.commit()
        db._restore_stored_hpl_extensions()
        assert Path(db.get_version(p.id,0)['log_local_path'])==other
        assert not other.with_suffix('.hpl').exists()
    finally:
        db.close()
