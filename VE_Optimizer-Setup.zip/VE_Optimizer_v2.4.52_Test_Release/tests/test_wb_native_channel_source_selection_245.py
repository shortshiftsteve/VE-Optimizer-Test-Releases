"""Regression checks for native WB EQ Ratio channel aliases and source reporting.

The existing single-stream wideband correction arithmetic is intentionally
unchanged: a second Lambda stream may be reported but not silently substituted.
"""
from pathlib import Path
from unittest.mock import patch
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_wideband as wb


def _decoded(*, first='WB EQ Ratio 1', second=True, ect='Engine Coolant Temp'):
    chans = {
        1: {'name': first, 'parameter_id': 6181 if '1' in first else 6182, 'unit': 'λ'},
        2: {'name': wb.FA_ENRICH_NAME, 'parameter_id': 6056, 'unit': ''},
        3: {'name': wb.FA_PE_NAME, 'parameter_id': 6080, 'unit': ''},
        4: {'name': ect, 'parameter_id': 2124, 'unit': '°C'},
        5: {'name': wb.CMD_LAMBDA_NAME, 'parameter_id': 68, 'unit': 'λ'},
        6: {'name': wb.RPM_NAME, 'parameter_id': 2135, 'unit': 'rpm'},
        7: {'name': wb.TORQUE_NAME, 'parameter_id': 2706, 'unit': 'N m'},
    }
    if second:
        chans[8] = {'name': 'WB EQ Ratio 2', 'parameter_id': 6182, 'unit': 'λ'}
    frames = []
    for i in range(8):
        updates = {1: 0.89, 2: 0.015, 3: 0.015, 4: 90.0,
                   5: 0.89, 6: 3000.0, 7: 100.0}
        if second:
            updates[8] = 0.96
        frames.append({'timestamp_ms': i * 100, 'updates': updates})
    return {'channels': chans, 'frames': frames}


def test_native_wb1_qualifies_and_secondary_is_reported_but_not_used():
    d = _decoded()
    result = wb._wideband_data_status(d)
    assert result['valid'] is True
    assert result['channel_name'] == 'WB EQ Ratio 1'
    assert result['dual_gate_updates'] == 8
    assert result['secondary_channel_name'] == 'WB EQ Ratio 2'
    assert result['secondary_used_for_correction'] is False


def test_legacy_sae_wb_name_remains_accepted():
    result = wb._wideband_data_status(_decoded(first=wb.WB_NAME, second=False))
    assert result['valid'] is True
    assert result['channel_name'] == wb.WB_NAME


def test_wb2_alone_never_substitutes_for_wb1():
    d = _decoded(second=False)
    d['channels'][1]['name'] = 'WB EQ Ratio 2'
    d['channels'][1]['parameter_id'] = 6182
    result = wb._wideband_data_status(d)
    assert result['present'] is True
    assert result['valid'] is False
    assert 'WB EQ Ratio 1' in result['reason']


def test_native_ect_name_accepted_by_wideband_processing():
    d = _decoded()
    with patch('ve_optimizer_map_sources.select_hpl_map',return_value={
        'valid':True,'source':{'channel_index':6},'baro_index':7}):
        indices,histories = wb._build_histories(d)
    assert indices['ect'] == 4
    assert indices['wb'] == 1
    assert histories['ect'][1][0] == 90.0


def test_source_inspection_native_wb1_enables_wideband_without_stft_bank2():
    d = _decoded()
    with patch.object(wb,'decode_hpl',return_value=d), \
         patch.object(wb,'_adaptive_trim_status',return_value={'present':False,'valid':False,'reason':'STFT Bank 2 absent','mode':'stft_only'}), \
         patch.object(wb,'_narrowband_status',return_value={'valid':False}), \
         patch.object(wb,'_maf_status',return_value={'valid':False}):
        result = wb.inspect_correction_sources(Path('synthetic.hpl'),airflow_model='speed_density')
    choices = {row['id']:row for row in result['choices']}
    assert choices['adaptive']['enabled'] is False
    assert choices['wideband']['enabled'] is True
    assert result['wideband']['channel_name'] == 'WB EQ Ratio 1'


def test_one_qualified_wideband_source_reports_auto_selection_explicitly():
    import ve_optimizer_revision9_review as app
    obj = app.ReviewApp.__new__(app.ReviewApp)
    obj.correction_source_selection = None
    obj.correction_preflight_cache = {
        'choices': [
            {'id': 'adaptive', 'label': 'Short Term Fuel Trims (STFT)', 'enabled': False},
            {'id': 'wideband', 'label': 'Wideband O2', 'enabled': True},
        ],
        'sources': {'wideband': {'channel_name': 'WB EQ Ratio 1'}},
    }
    shown = {}
    obj._set_setup_panel_message = lambda heading, message, builder=None, requires_action=True: shown.update(
        heading=heading, message=message, builder=builder, requires_action=requires_action)
    obj._show_correction_source_message()
    assert obj.correction_source_selection == 'wideband'
    assert shown['heading'] == 'CORRECTION SOURCE'
    assert 'Wideband O2 (WB EQ Ratio 1) qualified and selected automatically' in shown['message']
    assert shown['requires_action'] is False
