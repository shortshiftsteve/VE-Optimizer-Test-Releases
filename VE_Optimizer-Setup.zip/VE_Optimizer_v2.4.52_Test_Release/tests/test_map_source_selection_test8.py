"""Test 8: generic MAP is disallowed; validated alternate wins in all methods."""
import unittest
from pathlib import Path
from unittest.mock import patch

import ve_optimizer_logcheck as logcheck
import ve_optimizer_map_sources as sources
import ve_optimizer_wideband as wb


def sample_channels(with_alternate=True):
    ch = {
        1: {'name':'Barometric Pressure', 'unit':'kPa', 'parameter_id':57},
        2: {'name':'Manifold Absolute Pressure', 'unit':'kPa', 'parameter_id':50},
    }
    if with_alternate:
        ch[3] = {'name':'MAP - Hi-Res', 'unit':'kPa', 'parameter_id':55}
        ch[4] = {'name':'Sensed MAP', 'unit':'kPa', 'parameter_id':52}
    frames=[]
    for n in range(10):
        updates={1:100.2,2:(202 if n==9 else 50)}
        if with_alternate:
            updates[3] = 160.8 if n==9 else 40
            updates[4] = 158.8 if n==9 else 40
        frames.append({'timestamp_ms':n*100,'updates':updates})
    return {'channels':ch,'frames':frames}


class TestMapSourcePolicy(unittest.TestCase):
    def test_reject_generic_only(self):
        report=sources.select_hpl_map(sample_channels(with_alternate=False))
        self.assertFalse(report['valid'])
        self.assertIn('different MAP channel',report['reason'])

    def test_select_hires_instead_of_generic(self):
        r=sources.select_hpl_map(sample_channels())
        self.assertTrue(r['valid'])
        self.assertEqual(r['source']['name'],'MAP - Hi-Res')
        self.assertEqual(r['source']['max_map_kpa'],160.8)
        self.assertEqual(r['source']['exceeds_baro'],1)
        self.assertEqual([a['name'] for a in r['alternatives']],['Sensed MAP'])

    def test_sd_uses_correct_source(self):
        data=sample_channels()
        r=wb._sd_pressure_input_indices(data['channels'],data)
        self.assertEqual(data['channels'][r['map']]['name'],'MAP - Hi-Res')
        self.assertEqual(data['channels'][r['baro']]['name'],'Barometric Pressure')
        self.assertIsNone(wb._sd_pressure_input_indices(sample_channels(False)['channels'], sample_channels(False))['map'])

    def test_reject_baro_without_comparable_values(self):
        d=sample_channels();d['frames']=[{'timestamp_ms':0,'updates':{2:202,3:40,4:41}}]
        self.assertFalse(sources.select_hpl_map(d)['valid'])

    def test_original_nn_logcheck_does_not_use_generic_fallback(self):
        fixture=Path(__file__).parent/'fixtures'/'fresh_log.hpl'
        for has_alt in (True,False):
            data=sample_channels(has_alt)
            with patch.object(logcheck,'_native',return_value=data):
                meta=logcheck.read_metadata(fixture)
                resolved=logcheck.resolve_indices(fixture,meta,'neural_network')
                named=[meta.names[i] for i in resolved['map']]
                self.assertEqual(named, ['MAP - Hi-Res'] if has_alt else [])
                result=logcheck.analyze_log(fixture,'neural_network')
                self.assertTrue(any('MAP source' in b or 'MAP channel' in b for b in result['blocking']) if not has_alt else True)
                if has_alt:self.assertEqual(next(s['count'] for s in result['signals'] if s['key']=='map'),10)

    def test_invalid_only_map_early_stop_message(self):
        fixture=Path(__file__).parent/'fixtures'/'fresh_log.hpl'
        with patch.object(logcheck,'_native',return_value=sample_channels(False)):
            report=logcheck.analyze_log(fixture,airflow_model='speed_density')
            self.assertFalse(report['passed'])
            self.assertIn('different MAP channel', ' '.join(report['blocking']))

if __name__=='__main__': unittest.main()
