from pathlib import Path
import sys
import numpy as np
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_wideband as wb

SD_TUNE=Path('/mnt/data/RV_TH8.1_HE5.htt')
WB_LOG=Path('/mnt/data/091225_RV_TH8_HE5_2 reformatted.hpl')
FRESH_LOG=Path('/mnt/data/wb_search/fresh log.hpl')
STOCK_57=Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt')
STOCK_64=Path('/mnt/data/2016 Dodge Challenger 6.4L Engine and fuel system tune file.htt')

_REQUIRED_EXTERNAL_FIXTURES=[SD_TUNE,WB_LOG,FRESH_LOG,STOCK_57,STOCK_64]
if not all(p.is_file() for p in _REQUIRED_EXTERNAL_FIXTURES):
    pytestmark=pytest.mark.skip(reason='External wideband development fixtures are not bundled with this release source package.')



def test_model_detection():
    assert wb.detect_airflow_model(SD_TUNE)=='speed_density'
    assert wb.detect_pe_table_axis(SD_TUNE)=='PRatio'
    assert wb.detect_airflow_model(STOCK_57)=='neural_network'
    assert wb.detect_pe_table_axis(STOCK_57)=='Aircharge'
    assert wb.detect_airflow_model(STOCK_64)=='neural_network'
    assert wb.detect_pe_table_axis(STOCK_64)=='Aircharge'


def test_speed_density_requires_rescale_before_export(tmp_path):
    a=wb.analyze_speed_density(WB_LOG,SD_TUNE,delay_ms=60)
    assert a['qualifying_cell_count']==14
    assert a['stages']['dual_gate_pass']==2539
    assert a['stages']['inside_sd_table_domain']==1043
    assert a['stages']['outside_sd_table_domain']==1496
    assert a['banks_identical'] is True

    pf=wb.speed_density_domain_preflight(a)
    assert pf['needs_rescale'] is True
    assert pf['pratio_rescale_required'] is True
    assert pf['rpm_rescale_required'] is False
    assert pf['observed_pratio_max'] > pf['current_pratio_max']
    assert pf['recommended_pratio_max'] >= pf['observed_pratio_max']
    assert pf['removed_pratio_breakpoint'] is not None
    assert pf['proposed_pratio_axis'][-2] == pf['current_pratio_max']
    assert pf['estimated_regrid_error_b1']['maximum_absolute_ve_error'] < 1.1

    out=tmp_path/'should_not_export.htt'
    import pytest
    with pytest.raises(wb.DomainRescaleRequired):
        wb.export_speed_density_candidate(SD_TUNE,a,out)


def test_speed_density_rescale_then_wideband_export(tmp_path):
    original=wb.analyze_speed_density(WB_LOG,SD_TUNE,delay_ms=60)
    pf=wb.speed_density_domain_preflight(original)
    rescaled=tmp_path/'rescaled.htt'
    rr=wb.rescale_speed_density_pratio(
        SD_TUNE,rescaled,new_pratio_max=pf['recommended_pratio_max']
    )
    assert rr['surface_regridded'] is True
    assert rr['top_row_held_above_old_max'] is True
    assert rr['rpm_axis_unchanged'] is True
    assert rr['removed_pratio_breakpoint'] < rr['old_pratio_max']
    assert rr['regrid_error_b1']['maximum_absolute_ve_error'] < 1.1
    assert rr['regrid_error_b2']['maximum_absolute_ve_error'] < 1.1
    assert rr['new_pratio_max'] >= pf['observed_pratio_max']

    a=wb.analyze_speed_density(WB_LOG,rescaled,delay_ms=60)
    pf2=wb.speed_density_domain_preflight(a)
    assert pf2['needs_rescale'] is False
    assert a['stages']['outside_sd_table_domain']==0
    assert a['qualifying_cell_count'] > 14

    out=tmp_path/'wb_after_rescale.htt'
    r=wb.export_speed_density_candidate(rescaled,a,out)
    assert r['changed_cells_b1']==a['qualifying_cell_count']
    assert r['changed_cells_b2']==a['qualifying_cell_count']
    assert r['banks_identical_after'] is True


def test_source_selection_preflight():
    boosted=wb.build_correction_preflight(WB_LOG,SD_TUNE,delay_ms=60)
    assert boosted['sources']['wideband']['valid'] is True
    assert boosted['sources']['maf']['present'] is True
    assert boosted['sources']['maf']['valid'] is False
    assert boosted['sources']['maf']['status'] == 'invalid'
    assert boosted['sources']['maf']['primary']['name'] == 'Mass Airflow Sensor 1'
    assert boosted['sources']['maf']['primary']['maximum'] == 0.0
    assert boosted['sources']['maf']['primary']['nonzero_updates'] == 0
    assert boosted['sources']['narrowband']['present'] is True
    assert boosted['sources']['narrowband']['valid'] is True
    # Missing Fuel Flow Rate is no longer a Speed Density STFT restriction.
    # Whether the source qualifies still depends on its other recorded inputs.
    assert 'fuel_flow' not in boosted['sources']['adaptive'].get('missing', [])
    assert boosted['domain_preflight']['needs_rescale'] is True
    choices={x['id']:x for x in boosted['choices']}
    assert boosted['airflow_map_preflight']['blocking'] is False
    assert boosted['airflow_map_preflight']['auto_fix_required'] is True
    assert choices['wideband']['enabled'] is True
    assert choices['narrowband']['enabled'] is False
    assert choices['narrowband']['available'] is True

    stock=wb.build_correction_preflight(FRESH_LOG,STOCK_57,delay_ms=60)
    assert stock['sources']['wideband']['present'] is False
    assert stock['sources']['maf']['present'] is False
    assert stock['sources']['maf']['status'] == 'not_logged'
    assert stock['sources']['adaptive']['valid'] is True
    assert stock['sources']['narrowband']['valid'] is True
    choices={x['id']:x for x in stock['choices']}
    assert choices['wideband']['enabled'] is False
    assert choices['narrowband']['enabled'] is False
    assert choices['narrowband']['available'] is True
    assert 'combined' not in choices


def test_neural_network_synthetic_fit_and_export(tmp_path):
    import ve_optimizer_stage3 as s3
    import ve_optimizer_processing as processing

    cfg = wb.detect_configuration(STOCK_57)
    assert cfg["airflow_model"] == "neural_network"
    assert cfg["wideband_nn_supported"] is True

    net = s3.load_network(STOCK_57)
    domain = processing.model_domain(net)

    # One qualifying WOT-like cell is enough to prove that the wideband NN path
    # runs through the quantized all-layer solver and round-trips an HTT.
    target = {
        "row": 16,
        "column": 15,
        "cell_index": 16 * 20 + 15,
        "hits": 6,
        "full_correction_pct": -4.0,
        "applied_correction_pct": -2.0,
        "average_intake_cam": domain["cam_pairs"][2][0],
        "average_exhaust_cam": domain["cam_pairs"][2][1],
        "reference_pair_index": 2,
        "reference_intake_cam": domain["cam_pairs"][2][0],
        "reference_exhaust_cam": domain["cam_pairs"][2][1],
        "rpm": domain["rpms"][15],
        "pratio": domain["pratios"][16],
    }
    analysis = {
        "airflow_model": "neural_network",
        "source_sha256": "synthetic-test",
        "delay_ms": 60,
        "minimum_hits": 5,
        "correction_fraction": 0.50,
        "rpm_axis": np.asarray(domain["rpms"], dtype=float),
        "pratio_axis": np.asarray(domain["pratios"], dtype=float),
        "qualifying_cell_count": 1,
        "targets": [target],
    }

    out = tmp_path / "nn_wideband_candidate.htt"
    result = wb.fit_neural_network_candidate(STOCK_57, analysis, out)

    meta = result["wideband"]
    assert meta["qualifying_nn_targets"] == 1
    assert meta["reverse_targets"] == 0
    assert meta["overshoot_targets"] == 0
    assert sum(meta["coefficient_changes"].values()) > 0
    achieved = meta["achieved_targets"][0]["achieved_correction_pct"]
    assert -4.0 <= achieved < 0.0

    exported = s3.load_network(out)
    baseline = s3.load_network(STOCK_57)
    assert not s3.network_equivalent(exported, baseline, tol=0.0)


def test_maf_valid_when_nonzero_varying():
    decoded = {
        'channels': {
            7: {'name': 'Mass Airflow Sensor 1', 'parameter_id': 2219, 'unit': 'g/s'},
        },
        'frames': [
            {'timestamp_ms': i * 10, 'updates': {7: float(v)}}
            for i, v in enumerate((0.0, 12.0, 15.0, 18.0, 22.0, 30.0, 35.0))
        ],
    }
    status = wb._maf_status(decoded)
    assert status['present'] is True
    assert status['valid'] is True
    assert status['status'] == 'valid'
    assert status['usable_as_airflow_reference'] is True
    assert status['pcm_use_inferred'] is False
    assert status['primary']['nonzero_updates'] == 6


def test_pe_strategy_preflight_identifies_manual_pratio_coverage_issue(tmp_path):
    pf = wb.pe_strategy_preflight(WB_LOG, SD_TUNE)
    assert pf['boosted_detected'] is True
    assert pf['current_pe_method'] == 'PRatio'
    assert pf['required_pe_method'] == 'PRatio'
    assert not pf['switch_change_required']
    assert pf['pratio_rescale_required']
    assert pf['blocking'] and pf['manual_review_required']
    assert pf['automatic_change_allowed'] is False
    assert pf['recommended_pratio_table_max'] is None
    out=tmp_path/'must_not_prepare.htt'
    with pytest.raises(RuntimeError,match='removed'):
        wb.prepare_pe_strategy(WB_LOG,SD_TUNE,out)
    assert not out.exists()


def test_pe_strategy_does_not_auto_switch_aircharge_for_boost(tmp_path):
    pf = wb.pe_strategy_preflight(WB_LOG, STOCK_57)
    assert pf['boosted_detected'] is True
    assert pf['current_pe_method'] == 'Aircharge'
    assert pf['switch_change_required'] is True
    assert pf['blocking'] and pf['manual_review_required']
    out=tmp_path/'must_not_switch.htt'
    with pytest.raises(RuntimeError,match='removed'):
        wb.prepare_pe_strategy(WB_LOG, STOCK_57, out)
    assert not out.exists()


def test_speed_density_stft_only_is_valid_source():
    channels = {
        1: {'name': wb.STFT_B1_NAME, 'parameter_id': 1, 'unit': '%'},
        2: {'name': wb.STFT_B2_NAME, 'parameter_id': 2, 'unit': '%'},
        3: {'name': wb.RPM_NAME, 'parameter_id': 3, 'unit': 'rpm'},
        4: {'name': wb.TORQUE_NAME, 'parameter_id': 4, 'unit': 'N m'},
        5: {'name': wb.FA_ENRICH_NAME, 'parameter_id': 5, 'unit': ''},
        6: {'name': wb.FA_PE_NAME, 'parameter_id': 6, 'unit': ''},
        7: {'name': wb.ECT_NAME, 'parameter_id': 7, 'unit': 'C'},
        8: {'name': 'Fuel Flow', 'parameter_id': wb.FUEL_FLOW_PID, 'unit': 'lb/h'},
    }
    frames = []
    for i in range(8):
        frames.append({
            'timestamp_ms': i * 20,
            'updates': {
                1: 1.0 + i * 0.1,
                2: 0.5 + i * 0.1,
                3: 1800.0,
                4: 100.0,
                5: 0.0,
                6: 0.0,
                7: 90.0,
                8: 10.0,
            },
        })
    decoded = {'channels': channels, 'frames': frames}
    sd = wb._adaptive_trim_status(decoded, airflow_model='speed_density')
    assert sd['valid'] is True
    assert sd['mode'] == 'stft_only'
    assert sd['ltft_available'] is False
    nn = wb._adaptive_trim_status(decoded, airflow_model='neural_network')
    assert nn['valid'] is False
    assert 'ltft_b1' in nn['missing'] and 'ltft_b2' in nn['missing']


def test_pe_strategy_keeps_aircharge_for_nn_wot_without_boost(tmp_path):
    hpl=Path('/mnt/data/5 min with WOT.hpl')
    pf=wb.pe_strategy_preflight(hpl,STOCK_57)
    assert pf['operating']['valid'] is True
    assert pf['boosted_detected'] is False
    assert pf['current_pe_method']=='Aircharge'
    assert pf['required_pe_method']=='Aircharge'
    assert pf['switch_change_required'] is False
    assert pf['pratio_rescale_required'] is False
    assert pf['automatic_change_allowed'] is False
    out=tmp_path/'must_not_create.htt'
    with pytest.raises(RuntimeError,match='removed'):
        wb.prepare_pe_strategy(hpl,STOCK_57,out)
    assert not out.exists()


def test_log_qualification_marks_ltft_optional_in_speed_density():
    import ve_optimizer_logcheck as logcheck
    sd={r['key']:r for r in logcheck.required_channel_guide('speed_density')}
    nn={r['key']:r for r in logcheck.required_channel_guide('neural_network')}
    assert sd['ltft_b1']['required'] is False
    assert sd['ltft_b2']['required'] is False
    assert sd['intake_cam']['required'] is False
    assert sd['exhaust_cam']['required'] is False
    assert sd['fuel_flow']['required'] is False
    assert sd['fuel_flow']['advisory'] is False
    assert sd['stft_b1']['required'] is True
    assert sd['stft_b2']['required'] is True
    assert sd['ect']['required'] is True
    assert nn['ltft_b1']['required'] is True
    assert nn['ltft_b2']['required'] is True
    assert nn['intake_cam']['required'] is True
    assert nn['exhaust_cam']['required'] is True
    assert nn['fuel_flow']['required'] is True


def test_airflow_map_preflight_flags_boosted_calibration_limits():
    pf = wb.airflow_map_preflight(WB_LOG, SD_TUNE)
    assert pf['map1']['sensor_class'] == '3-bar'
    assert pf['map2']['sensor_class'] == '3-bar'
    assert pf['map_sensors_covering_observed_range']
    assert pf['observed_pratio_max'] > 2.0
    assert pf['pressure_ratio_max'] == 1.0
    assert pf['pressure_ratio_max_valid'] is False
    assert pf['logged_baro_median_kpa'] == pytest.approx(100.2, abs=0.01)
    assert pf['baro_status'] == 'operating_reference_only'
    assert pf['throttle_based_map_multiplier']['airflow_covered'] is True
    assert pf['throttle_based_map_multiplier']['rpm_covered'] is True
    assert pf['blocking'] is False
    assert pf['auto_fix_required'] is True
    assert pf['pressure_ratio_max_change_required'] is True
    assert pf['recommended_pressure_ratio_max'] == pytest.approx(2.1)
    assert pf['sensed_map_enable_change_required'] is False
    assert pf['recommended_sensed_map_enable'] == pf['sensed_map_enable']


def test_airflow_map_preflight_stock_nn_wot_sensor_classes():
    hpl = Path('/mnt/data/5 min with WOT.hpl')
    pf = wb.airflow_map_preflight(hpl, STOCK_57)
    assert pf['map1']['sensor_class'] == '1-bar'
    assert pf['map2']['sensor_class'] == '2-bar'
    assert pf['observed_pratio_max'] < 1.02
    assert pf['pressure_ratio_max_valid'] is True
    assert pf['logged_baro_median_kpa'] < wb.SEA_LEVEL_BARO_KPA
    assert pf['baro_status'] == 'operating_reference_only'
    assert pf['blocking'] is False


def test_logged_baro_is_not_used_to_validate_map_scaling_even_when_sea_level_is_assumed():
    # Logged Baro may be MAP-derived and varies with altitude/weather.  It is
    # only the operating denominator for PRatio, never the independent MAP
    # sensor-calibration baseline.
    original = wb.decode_hpl
    try:
        decoded = {
            'channels': {
                1: {'name': 'MAP - Hi-Res', 'parameter_id': 1, 'unit': 'kPa'},
                2: {'name': wb.BARO_NAME, 'parameter_id': 2, 'unit': 'kPa'},
                3: {'name': wb.RPM_NAME, 'parameter_id': 3, 'unit': 'rpm'},
            },
            'frames': [
                {'timestamp_ms': i * 10, 'updates': {1: 100.0, 2: 105.0, 3: 2000.0}}
                for i in range(10)
            ],
        }
        wb.decode_hpl = lambda _path: decoded
        pf = wb.airflow_map_preflight(Path('synthetic.hpl'), STOCK_57, assume_sea_level=True)
        assert pf['logged_baro_median_kpa'] == pytest.approx(105.0)
        assert pf['baro_status'] == 'operating_reference_only'
        assert pf['baro_delta_from_sea_level_kpa'] is None
        assert not any('sea-level baseline' in item for item in pf['issues'])
    finally:
        wb.decode_hpl = original


def test_prepare_airflow_strategy_repairs_boosted_pressure_model(tmp_path):
    out=tmp_path/'airflow_prepared.htt'
    r=wb.prepare_airflow_strategy(WB_LOG,SD_TUNE,out)
    assert r['changed'] is True
    assert r['scope_verified'] is True
    assert {x['parameter'] for x in r['changes']}=={'Pressure Ratio Max'}
    post=r['post_preflight']
    assert post['blocking'] is False
    assert post['auto_fix_required'] is False
    assert post['pressure_ratio_max'] == pytest.approx(2.1)
    assert post['sensed_map_enable'] == r['sensed_map_enable']
    assert post['throttle_based_map_multiplier']['covered'] is True


def test_build_preflight_includes_airflow_map_section():
    pf = wb.build_correction_preflight(WB_LOG, SD_TUNE, delay_ms=60)
    assert 'airflow_map_preflight' in pf
    assert pf['airflow_map_preflight']['blocking'] is False
    assert pf['airflow_map_preflight']['auto_fix_required'] is True
    choices={x['id']:x for x in pf['choices']}
    assert choices['wideband']['enabled'] is True
