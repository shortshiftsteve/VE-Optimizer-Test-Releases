import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import ve_optimizer_wideband as wb
import ve_optimizer_stage3 as htt

class ChangedOnlySpeedDensityExportTests(unittest.TestCase):
    def test_modified_bank_only_and_round_trip(self):
        src=Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt')
        if not src.is_file(): self.skipTest('External full-engine source not bundled')
        with tempfile.TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'candidate.htt'
            export=Path(tmp)/'export.htt'
            source=src.read_bytes()
            key=wb.VE_BANK1_TABLE
            original,_,_,z=wb.parse_ve_table(src,key)
            edited=z.copy(); edited[0,0]+=wb.VE_QUANTUM
            new=wb._rebuild_ve_table(original,edited)
            _, lp, _, end=htt._find_length_payload(source,key)
            candidate.write_bytes(source[:lp]+htt._encode_uleb128(len(new))+new+source[end:])
            info=wb.export_speed_density_changed_tables(src,candidate,export)
            self.assertEqual(info['changed_tables'], [key])
            self.assertLess(export.stat().st_size,src.stat().st_size/20)
            _,_,_,out=wb.parse_ve_table(export,key)
            self.assertEqual(float(out[0,0]),float(edited[0,0]))
            with self.assertRaises(KeyError):
                htt._find_length_payload(export.read_bytes(),wb.VE_BANK2_TABLE)

if __name__=='__main__': unittest.main()
