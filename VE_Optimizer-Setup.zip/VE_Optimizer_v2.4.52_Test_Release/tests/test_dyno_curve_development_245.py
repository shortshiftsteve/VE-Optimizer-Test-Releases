"""Read-only full-log composite PCM-estimated dyno plotting, no tuner dependencies."""
import math
from pathlib import Path
import pytest
import ve_optimizer_dyno as dyno


def fake_native(samples, channels=None):
    channels=channels or {1:{'name':'Engine RPM','unit':'rpm'},2:{'name':'Actual Torque','unit':'N m'},
                         3:{'name':'Accelerator Pedal Effective Position','unit':'%'},
                         4:{'name':'Trans Current Gear','unit':''}}
    frames=[]
    for ms,rpm,tq,app,gear in samples:
        frames.append({'timestamp_ms':ms,'updates':{1:rpm,2:tq,3:app,4:gear}})
    return {'source_sha256':'f'*64,'channels':channels,'frames':frames}


def ramp(start=1500,end=6100,gear='5',t0=0,step_ms=20,app=95):
    n=(end-start)//25+1
    return [(t0+i*step_ms,start+25*i,(400+0.018*(start+25*i))*1.35581794833,app,gear)
            for i in range(n)]


def test_native_nm_torque_and_hp_both_use_lbft(monkeypatch,tmp_path):
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(ramp()))
    out=dyno.build_dyno_curve(tmp_path/'test.hpl')
    assert out['status']=='ready' and out['logged_bins']>30
    assert out['first_logged_rpm']<=1600 and out['last_logged_rpm']>=6000
    for p in out['points']:
        assert math.isclose(p['hp'],p['torque_lbft']*p['rpm']/5252.0,rel_tol=1e-13)
    assert all(p['kind']=='logged' for p in out['points']
               if out['first_logged_rpm']<=p['rpm']<=out['last_logged_rpm'])
    assert all(p['kind']=='illustrative' for p in out['points']
               if p['rpm']<out['first_logged_rpm'])
    assert 425<out['peak_logged_torque_lbft']<550


def test_high_rpm_start_is_illustrative_not_a_logged_peak(monkeypatch,tmp_path):
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(ramp(3600,6100)))
    out=dyno.build_dyno_curve(tmp_path/'test.hpl')
    assert out['status']=='ready'
    assert out['points'][0]['rpm']==1000
    assert out['points'][0]['kind']=='illustrative' and out['points'][0]['samples']==0
    assert out['first_logged_rpm']>=3500
    assert out['last_logged_rpm']==out['points'][-1]['rpm']  # never fabricate higher RPM
    assert out['peak_logged_hp']==max(p['hp'] for p in out['points'] if p['kind']=='logged')


def test_multiple_gears_combine_wot_but_keep_synthetic_gaps(monkeypatch,tmp_path):
    a=ramp(1700,3550,'4')
    b=ramp(3800,6050,'5',t0=a[-1][0]+400)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(a+b))
    out=dyno.build_dyno_curve(tmp_path/'test.hpl')
    assert out['status']=='ready' and out['sweep_count']==2
    assert out['gears']==['4','5']
    assert {p['kind'] for p in out['points']}=={'logged','interpolated','illustrative'}
    assert out['reconstructed_bins']>0
    assert out['first_logged_rpm']<2000 and out['last_logged_rpm']>=6000


def test_short_wot_burst_is_eligible_without_a_full_sweep(monkeypatch,tmp_path):
    short=ramp(2000,2300)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(short))
    out=dyno.build_dyno_curve(tmp_path/'test.hpl')
    assert out['status']=='ready' and out['logged_bins']>=3
    assert out['reconstructed_bins']>out['logged_bins']
    assert out['basis']=='WOT' and out['sweep_count']==1


def test_missing_channels_and_stale_pairs_no_curve(monkeypatch,tmp_path):
    bad=fake_native([])
    bad['frames']=[{'timestamp_ms':0,'updates':{1:3500.,3:100.}},
                   {'timestamp_ms':400,'updates':{2:650.,4:'5'}}]
    monkeypatch.setattr(dyno,'_native',lambda _:bad)
    out=dyno.build_dyno_curve(tmp_path/'test.hpl')
    assert out['status']=='unavailable'


def test_dyno_data_cannot_change_method_a_b_coefficients_or_tables():
    from inspect import getsource
    src=getsource(dyno)
    assert 've_optimizer_processing' not in src
    assert 've_optimizer_wideband' not in src
    assert '.htt' in src  # docstring only


def test_real_trackhawk_hpl_if_available():
    path=Path('/mnt/data/re-save  DYNO.hpl')
    if not path.is_file(): pytest.skip('External user HPL not included in distribution')
    result=dyno.build_dyno_curve(path)
    assert result['status']=='ready'
    assert result['logged_bins']>=25
    assert result['first_logged_rpm']<2500
    assert result['last_logged_rpm']>=5800
    assert max(p['rpm'] for p in result['points'])==result['last_logged_rpm']
    assert result['peak_logged_hp']<1200


def _labels(widget):
    import tkinter as tk
    for child in widget.winfo_children():
        if isinstance(child,tk.Label):yield child
        yield from _labels(child)


def test_lower_panel_graph_and_version_selector_keep_upper_right_summary(tmp_path,monkeypatch):
    import tkinter as tk
    import ve_optimizer_revision9_review as app
    from types import SimpleNamespace
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1360x850+0+0')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        original_panel=ui.setup_performance_panel
        ui.project=SimpleNamespace(id=321)
        ui._setup_lower_mode='status'
        sample=fake_native(ramp())
        monkeypatch.setattr(dyno,'_native',lambda _:sample)
        result=dyno.build_dyno_curve(tmp_path/'dummy.hpl')
        path=tmp_path/'dummy.hpl';path.write_bytes(b'dummy')
        file_hash='f'*64
        data_key=(str(path),file_hash)
        ui._dyno_curve_cache[data_key]=result
        monkeypatch.setattr(ui,'_dyno_processed_versions',lambda:[(0,path,file_hash),(1,path,file_hash)])
        ui._render_setup_lower_view();root.update()
        assert ui.dyno_canvas.winfo_exists() and ui.dyno_canvas.winfo_width()>600
        assert ui.dyno_canvas.winfo_rootx() < ui.setup_performance_panel.winfo_rootx()
        assert ui.dyno_canvas.winfo_width()>ui.setup_performance_panel.winfo_width()
        assert ui.setup_performance_panel is original_panel
        assert ui.dyno_version_picker.get()=='V1'
        assert {'V0 (Baseline)','V1'} == set(ui.dyno_version_picker.cget('values'))
        assert any(
            'lb-ft' in ui.dyno_canvas.itemcget(i,'text') for i in ui.dyno_canvas.find_all()
            if ui.dyno_canvas.type(i)=='text')
        assert 'WOT RPM bins' in ui.dyno_caption.get()
        assert not any('HP = PCM Actual Torque' in w.cget('text') for w in _labels(ui.setup_processing_host))
        ui.dyno_version_picker.set('V0 (Baseline)')
        ui.dyno_version_picker.event_generate('<<ComboboxSelected>>');root.update()
        assert ui._dyno_selected==(321,0)
    finally:
        if ui:ui.db.close()
        root.destroy()


def test_dyno_hidden_until_a_project_log_is_processed(tmp_path,monkeypatch):
    import tkinter as tk
    import ve_optimizer_revision9_review as app
    from types import SimpleNamespace
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1360x850+0+0')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        ui.project=SimpleNamespace(id=345)
        monkeypatch.setattr(ui,'_dyno_processed_versions',lambda:[])
        ui._render_setup_lower_view();root.update()
        assert ui.dyno_canvas is None
        assert ui.setup_performance_panel.winfo_exists()
        assert not any('Dyno-Style Performance' in w.cget('text')
                       for w in _labels(ui.setup_processing_host))
    finally:
        if ui:ui.db.close()
        root.destroy()


def test_short_separate_wot_bursts_are_combined_across_the_full_log(monkeypatch,tmp_path):
    # Neither 1800..1975 nor 4100..4300 reaches the old 450-RPM segment gate.
    a=ramp(1800,1975,gear='6',t0=0)
    b=ramp(4100,4300,gear='4',t0=110_000)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(a+b))
    result=dyno.build_dyno_curve(tmp_path/'bursts.hpl')
    assert result['status']=='ready' and result['sweep_count']==2
    observed=[p['rpm'] for p in result['points'] if p['kind']=='logged']
    assert min(observed)<=1800 and max(observed)>=4300
    gap=[p for p in result['points'] if 2200<=p['rpm']<=3900]
    assert gap and all(p['kind']=='interpolated' and p['samples']==0 for p in gap)
    assert all(math.isclose(p['hp'],p['torque_lbft']*p['rpm']/5252) for p in result['points'])
    assert result['peak_logged_hp']==max(p['hp'] for p in result['points'] if p['kind']=='logged')


def test_other_high_load_samples_can_support_reconstruction_without_claiming_wot(monkeypatch,tmp_path):
    brief=ramp(1800,1950,gear='5',t0=0)
    # Other, separated non-WOT observations extend the operating RPM domain.
    other=ramp(2600,4700,gear='6',t0=260_000,app=48)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(brief+other))
    out=dyno.build_dyno_curve(tmp_path/'partial.hpl')
    assert out['status']=='ready' and out['basis']=='WOT'
    assert out['last_logged_rpm']<=2000 and out['points'][-1]['rpm']>=4600
    assert all(p['kind']!='logged' for p in out['points'] if p['rpm']>2000)
    assert out['peak_logged_hp']<max(p['hp'] for p in out['points'])


def test_no_wot_is_only_a_partial_load_illustration(monkeypatch,tmp_path):
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(ramp(1900,4500,app=45)))
    out=dyno.build_dyno_curve(tmp_path/'no_wot.hpl')
    assert out['status']=='ready' and out['basis']=='partial_load_only'
    assert out['logged_bins']==0 and out['peak_logged_hp'] is None
    assert all(p['kind']!='logged' for p in out['points'])


def test_one_wot_rpm_bin_and_other_logged_operating_points(monkeypatch,tmp_path):
    tiny=ramp(1850,1880,gear='5',t0=0)
    supporting=ramp(2200,2600,gear='5',t0=30000,app=60)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(tiny+supporting))
    out=dyno.build_dyno_curve(tmp_path/'one_bin.hpl')
    assert out['status']=='ready'
    assert out['logged_bins']==1 and out['reconstructed_bins']>1
    assert out['points'][-1]['rpm']>=2600
    assert out['peak_logged_hp']==max(p['hp'] for p in out['points'] if p['kind']=='logged')


def test_irrelevant_cruise_has_no_independent_fake_wot_peak(monkeypatch,tmp_path):
    barely=ramp(1700,2600,gear='5',app=9)
    monkeypatch.setattr(dyno,'_native',lambda _:fake_native(barely))
    result=dyno.build_dyno_curve(tmp_path/'cruise.hpl')
    assert result['status']=='unavailable' and result['points']==[]
