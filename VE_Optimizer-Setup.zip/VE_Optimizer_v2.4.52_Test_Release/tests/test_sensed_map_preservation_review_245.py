"""Review Update 1 Sensed MAP correction: preserve switch 2100, check actual routing."""
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import tempfile

import pytest

import ve_optimizer_wideband as wb
import ve_optimizer_revision9_review as app
from ve_optimizer_htt_codec import parse_htt, build_htt
import ve_optimizer_stage3 as stage3

TRACKHAWK=Path('/mnt/data/Tuned 6.2L Trackhawk (Hellcat).htt')
TRACKHAWK_LOG=Path('/mnt/data/Re-save rev04-TCM_PCM-second-drive+O2.hpl')


def synthetic_boosted_log(rpm=2200.0, map_kpa=180.0, baro_kpa=100.0):
    channels = {
        1: {'name':'MAP - Hi-Res', 'parameter_id':1, 'unit':'kPa'},
        2: {'name':wb.BARO_NAME, 'parameter_id':2, 'unit':'kPa'},
        3: {'name':wb.RPM_NAME, 'parameter_id':3, 'unit':'rpm'},
    }
    frames=[{'timestamp_ms':n*10, 'updates':{1:map_kpa,2:baro_kpa,3:rpm}}
            for n in range(12)]
    return {'channels':channels,'frames':frames}


def _change_switch(doc, key, value):
    encoded=value.encode('ascii')
    records=tuple(replace(rec,raw=rec.raw[:4]+stage3._encode_uleb128(len(encoded))+encoded)
                  if rec.key==key else rec for rec in doc.switches)
    return build_htt(replace(doc,switches=records))


@pytest.mark.skipif(not TRACKHAWK.is_file(),reason='Tuned Trackhawk user fixture unavailable')
def test_boosted_disabled_does_not_request_or_perform_switch_change(tmp_path):
    original=parse_htt(TRACKHAWK.read_bytes())
    with patch.object(wb,'decode_hpl',return_value=synthetic_boosted_log()):
        pf=wb.airflow_map_preflight(Path('synthetic.hpl'),TRACKHAWK)
        assert pf['boosted_detected']
        assert pf['sensed_map_enable']=='Disabled'
        assert pf['recommended_sensed_map_enable']=='Disabled'
        assert pf['sensed_map_enable_change_required'] is False
        assert all('enable Sensed MAP' not in x for x in pf['auto_actions'])
        assert pf['blocking'] is False
        output=tmp_path/'prepared.htt'
        result=wb.prepare_airflow_strategy(Path('synthetic.hpl'),TRACKHAWK,output)
        assert result['changed'] and result['scope_verified']
        assert [c['key'] for c in result['changes']]==[wb.PRESSURE_RATIO_MAX_SCALAR]
        after=parse_htt(output.read_bytes())
        assert after.by_key()[2100].raw==original.by_key()[2100].raw
        assert {k for k in original.by_key() if original.by_key()[k].raw!=after.by_key()[k].raw}=={wb.PRESSURE_RATIO_MAX_SCALAR}
        assert result['post_preflight']['blocking'] is False


@pytest.mark.skipif(not TRACKHAWK.is_file(),reason='Tuned Trackhawk user fixture unavailable')
def test_enabled_strategy_uses_stored_threshold_and_never_changes_switch(tmp_path):
    doc=parse_htt(TRACKHAWK.read_bytes())
    enabled=tmp_path/'enabled.htt';enabled.write_bytes(_change_switch(doc,2100,'Enabled'))
    # Recorded RPM is beyond the TMAP table maximum, but all boosted points
    # are routed above the stored threshold with the existing switch Enabled.
    with patch.object(wb,'decode_hpl',return_value=synthetic_boosted_log(rpm=6259)):
        pf=wb.airflow_map_preflight(Path('synthetic.hpl'),enabled)
    assert pf['sensed_map_enable']=='Enabled'
    assert pf['sensed_map_enable_change_required'] is False
    assert pf['recommended_sensed_map_enable']=='Enabled'
    assert pf['throttle_based_map_multiplier']['covered'] is True
    assert pf['throttle_based_map_multiplier']['sample_count']==0


@pytest.mark.skipif(not TRACKHAWK.is_file(),reason='Tuned Trackhawk user fixture unavailable')
def test_unverified_switch_blocks_instead_of_guessing(tmp_path):
    doc=parse_htt(TRACKHAWK.read_bytes());unknown=tmp_path/'unknown.htt'
    unknown.write_bytes(_change_switch(doc,2100,'Unknown'))
    with patch.object(wb,'decode_hpl',return_value=synthetic_boosted_log()):
        pf=wb.airflow_map_preflight(Path('synthetic.hpl'),unknown)
    assert pf['blocking'] is True
    assert any('missing or unrecognized' in issue for issue in pf['issues'])
    assert pf['sensed_map_enable_change_required'] is False


@pytest.mark.skipif(not TRACKHAWK.is_file(),reason='Tuned Trackhawk user fixture unavailable')
def test_export_refuses_2100_writeback(tmp_path):
    original=parse_htt(TRACKHAWK.read_bytes());altered=tmp_path/'altered.htt'
    altered.write_bytes(_change_switch(original,2100,'Enabled'))
    output=tmp_path/'import.htt';output.write_bytes(b'untouched')
    with pytest.raises(ValueError,match='must remain unchanged'):
        wb.export_speed_density_changed_tables(TRACKHAWK,altered,output)
    assert output.read_bytes()==b'untouched'


@pytest.mark.skipif(not (TRACKHAWK.is_file() and TRACKHAWK_LOG.is_file()),reason='Real Trackhawk files not available')
def test_actual_trackhawk_rpm_overrun_is_advisory_not_blocker():
    report=wb.build_correction_preflight(TRACKHAWK_LOG,TRACKHAWK)
    pf=report['airflow_map_preflight']
    assert pf['sensed_map_enable']=='Disabled'
    assert pf['sensed_map_enable_change_required'] is False
    assert pf['boosted_detected']
    assert pf['blocking'] is False
    assert pf['automatic_change_allowed'] is True  # Pressure Ratio Max scalar only
    tmap=pf['throttle_based_map_multiplier']
    assert tmap['observed_rpm_max']==pytest.approx(6259)
    assert tmap['rpm_axis_max']==pytest.approx(6208)
    assert tmap['rpm_covered'] is False
    assert tmap['airflow_covered'] is True
    assert tmap['rpm_endpoint_advisory'] is True
    assert any('6259 RPM' in msg and '6208 RPM' in msg for msg in pf['warnings'])
    assert not any('6259' in issue for issue in pf['issues'])
    assert {choice['id'] for choice in report['choices'] if choice['enabled']} == {'adaptive', 'wideband'}


def test_ui_offers_no_run_when_map_preflight_blocks():
    import tkinter as tk
    root=tk.Tk()
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.setup_message_host=tk.Frame(root,bg='white')
        obj.setup_message_host.pack(fill='both',expand=True)
        obj.setup_header_label=tk.Label(obj.setup_message_host,text='PROGRESS')
        obj.setup_header_label.pack()
        obj.setup_action_view=tk.Frame(obj.setup_message_host,bg='white')
        obj.setup_workflow_button=None
        obj.setup_progress_view=tk.Frame(obj.setup_message_host,bg='white')
        obj.setup_activity_state=None
        obj.current_page='setup'
        obj._setup_header_mode=None
        obj._setup_header_blink_after_id=None
        obj.setup_panel_message=None
        obj.correction_preflight_cache={
            'choices':[{'id':'adaptive','label':'STFT','enabled':False,'reason':'MAP preflight'}],
            'airflow_map_preflight':{'blocking':True,'issues':['airflow 1200 > 1152 g/s']},
        }
        obj.correction_source_selection=None
        obj._show_correction_source_message()
        root.update()
        assert getattr(obj,'correction_continue_button',None) is None
        assert obj.setup_panel_message['heading']=='CORRECTION SOURCE'
        buttons=[]
        labels=[]
        def visit(w):
            for c in w.winfo_children():
                if isinstance(c,tk.Label): labels.append(c.cget('text'))
                if isinstance(c,tk.Button): buttons.append(c.cget('text'))
                visit(c)
        visit(root)
        assert 'Run' not in buttons
        assert any('airflow 1200 > 1152' in item for item in labels)
    finally:
        obj._stop_setup_header_blink()
        root.destroy()
