from pathlib import Path
import sys, tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_processing as p
import ve_optimizer_revision9_review as app

def row(bank, cell, total, intake, exhaust, t):
    return dict(Bank=bank,Time_s=t,RPM=1926,MAP_kPa=38,Baro_kPa=100,PRatio=.38,
                Torque_lbft=10,Coolant_F=200,FuelFlow_lbh=5,FA_Enrichment=0,
                FA_PowerEnrichment=0,LTFT_pct=total,STFT_pct=0,CellIndex=cell,
                IntakeCam_deg=intake,ExhaustCam_deg=exhaust)

net=p.htt.load_network(ROOT/'tests'/'fixtures'/'stock.htt')
cell=106
# One hit at each of the five cam references = five pooled hits in ONE bank/RPM/PR cell.
s=[]
for i,(inc,exc) in enumerate(p.CAM_PAIRS):
    s.append(row(1,cell,-8,inc,exc,i))
    s.append(row(2,cell, 2,inc,exc,i))
counts,totals=p.aggregate(s)
assert counts.shape==(2,400)
assert counts[0,cell]==5 and counts[1,cell]==5
assert totals[0][cell]==-8 and totals[1][cell]==2
rows,_,_,_=p.make_targets(s,net)
matched=[r for r in rows if r['row']*20+r['column']==cell]
assert len(matched)==5
assert all(r['n1']==5 and r['n2']==5 for r in matched)
assert all(r['covered'] and r['full_correction']==2 and r['correction']==1 for r in matched)
# Four total hits remain unqualified regardless of cam distribution.
s4=[row(1,cell,-8,*p.CAM_PAIRS[i],i) for i in range(4)]
rows4,_,_,_=p.make_targets(s4,net)
assert not any(r['covered'] for r in rows4 if r['row']*20+r['column']==cell)
# Run Review must use the identical pooled-hit rule.
with tempfile.TemporaryDirectory() as td:
    f=Path(td)/'events.csv';p.write_samples(f,s)
    snap=app.run_trim_chart_snapshot(f)
    assert snap['cells'][(cell//20,cell%20)]==2
print('POOLED_HIT_QUALIFICATION_PASS')
