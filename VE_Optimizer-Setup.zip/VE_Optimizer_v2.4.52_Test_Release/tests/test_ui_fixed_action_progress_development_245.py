"""v2.4.5 Review Update 6 + authorized UI development: single action and status.

These tests are display/workflow-only: neither correction mathematics nor tuning
conditions are substituted in production code.
"""
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
from tkinter import ttk

import pytest
import ve_optimizer_revision9_review as app


def nested_widgets(root):
    for widget in root.winfo_children():
        yield widget
        yield from nested_widgets(widget)


@pytest.fixture
def ui_setup(tmp_path, monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA', str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH', '1')
    root=tk.Tk();root.geometry('1360x850+0+0')
    ui=app.ReviewApp(root,tmp_path/'current.db',Path(app.__file__).resolve().parent/'a')
    ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
    try:
        yield root,ui
    finally:
        ui._stop_setup_verify_blink();ui._stop_setup_header_blink()
        ui.db.close();root.destroy()


def test_right_panel_replaces_lower_progress_and_keeps_one_fixed_workflow_button(ui_setup,monkeypatch,tmp_path):
    root,ui=ui_setup
    button=ui.setup_workflow_button
    assert button is ui.vs_save is ui.vs_log_submit_button
    assert button.winfo_manager()=='pack'
    assert ui.setup_header_label.cget('text')=='WARNING'
    assert ui.setup_progress_view.winfo_manager()==''
    assert ui.setup_activity_host is ui.setup_progress_view
    assert not any(widget.cget('text')=='Progress'
                   for widget in nested_widgets(ui.setup_processing_viewport)
                   if isinstance(widget,tk.Label))
    assert len([w for w in nested_widgets(ui.setup_primary_actions) if isinstance(w,ttk.Button)])==1
    button_width=button.winfo_width();button_height=button.winfo_height()
    button_x=button.winfo_rootx();button_y=button.winfo_rooty()

    tune=tmp_path/'full.htt';tune.write_bytes(b'fixture')
    log=tmp_path/'native.hpl';log.write_bytes(b'fixture')
    monkeypatch.setattr(ui,'_setup_candidate_tune_path',lambda:tune)
    ui.vs_vars['htt'].set(str(tune))
    monkeypatch.setattr(app.filedialog,'askopenfilename',lambda **_:str(log))
    ui._select_current_log();root.update()
    assert ui.setup_header_label.cget('text')=='MESSAGE'
    assert button.cget('text')=='Verify'
    assert (button.winfo_rootx(),button.winfo_rooty(),button.winfo_width(),button.winfo_height())==(
        button_x,button_y,button_width,button_height)
    assert not button.instate(['disabled'])
    assert ui.setup_action_view.winfo_viewable()
    assert not any(isinstance(w,ttk.Button) for w in nested_widgets(ui.setup_action_view))
    assert root.focus_get()==button
    button.invoke();root.update()
    assert ui._setup_vehicle_is_verified()
    assert button.cget('text')=='Submit'
    assert ui.setup_header_label.cget('text')=='PROGRESS'
    assert ui.setup_progress_view.winfo_viewable()
    assert ui.setup_action_view.winfo_manager()==''

    jobs=[]
    monkeypatch.setattr(ui,'_run_background_task',lambda worker,done:jobs.append((worker,done)))
    button.invoke();root.update()
    assert len(jobs)==1
    assert button.cget('text')=='Processing'
    assert button.instate(['disabled'])
    assert ui.setup_header_label.cget('text')=='PROCESSING'
    # This simulates only the display update after completed qualification.
    ui.vs_log_report={'passed':True};ui.vs_log_staged=False;ui.vs_log_valid=True
    ui._set_setup_activity('Log File qualified','Data accepted',busy=False)
    ui._set_setup_panel_message('LOG FILE READY','Data accepted',requires_action=False)
    ui._vehicle_form_update();root.update()
    assert button.cget('text')=='Build'
    assert not button.instate(['disabled'])
    assert (button.winfo_rootx(),button.winfo_rooty(),button.winfo_width(),button.winfo_height())==(
        button_x,button_y,button_width,button_height)


def test_header_flashes_processing_and_message_without_losing_progress(ui_setup):
    root,ui=ui_setup
    ui._set_setup_panel_message('READY','Status',requires_action=False)
    ui._set_setup_activity('Rescale VE tables','Calibrating grid',percent=38,step=2,total=5,busy=True)
    root.update()
    assert ui.setup_header_label.cget('text')=='PROCESSING'
    assert int(float(ui.setup_activity_bar['value']))==38
    first_fg=ui.setup_header_label.cget('fg')
    root.after(520,root.quit);root.mainloop()
    assert ui.setup_header_label.cget('fg')!=first_fg
    selections=[]
    ui._set_setup_panel_message('KNOCK DATA NOT FOUND','Choose Yes or No.',
        actions=(('Yes',lambda:selections.append('yes')),('No',lambda:selections.append('no'))))
    root.update()
    assert ui.setup_header_label.cget('text')=='MESSAGE'
    message_fg=ui.setup_header_label.cget('fg')
    root.after(520,root.quit);root.mainloop()
    assert ui.setup_header_label.cget('fg')!=message_fg  # MESSAGE flashes too
    assert int(float(ui.setup_activity_bar['value']))==38
    assert ui.setup_progress_view.winfo_manager()==''
    assert ui.setup_workflow_button.cget('text')=='Continue'
    assert ui.setup_workflow_button.instate(['disabled'])
    choices=[w for w in nested_widgets(ui.setup_action_view) if isinstance(w,ttk.Radiobutton)]
    assert {w.cget('text') for w in choices}=={'Yes','No'}
    next(w for w in choices if w.cget('text')=='No').invoke();root.update()
    assert not ui.setup_workflow_button.instate(['disabled'])
    ui.setup_workflow_button.invoke()
    assert selections==['no']
    ui._set_setup_panel_message('CONTINUE','Approved',requires_action=False)
    root.update()
    assert ui.setup_header_label.cget('text')=='PROCESSING'
    ui._set_setup_activity('Complete','Candidate ready',percent=100,step=5,total=5,busy=False)
    root.update()
    assert ui.setup_header_label.cget('text')=='PROGRESS'
    assert ui.setup_progress_view.winfo_viewable()
    assert int(float(ui.setup_activity_bar['value']))==100
    assert ui._setup_header_blink_after_id is None


def test_source_radio_and_run_move_to_fixed_button(ui_setup,monkeypatch):
    root,ui=ui_setup
    button=ui.setup_workflow_button
    initial_width=button.winfo_width();initial_height=button.winfo_height()
    ui.project=SimpleNamespace(id=17)
    ui._setup_lower_mode='preflight';ui.correction_preflight_context='fake'
    ui.correction_preflight_cache={
        'configuration':{'airflow_model':'speed_density'},
        'choices':[{'id':'adaptive','label':'Fuel Trims','enabled':True},
                   {'id':'wideband','label':'Wideband O2','enabled':True}],
        'sources':{'wideband':{'present':True}},
    }
    ui.correction_source_selection=None
    monkeypatch.setattr(ui,'_render_setup_lower_view',lambda:None)
    monkeypatch.setattr(ui,'_review_result_ready',lambda:False)
    seen=[]
    monkeypatch.setattr(ui,'goto',lambda dest,*args,**kwargs:(seen.append(dest),setattr(ui,'_setup_lower_mode',dest)))
    monkeypatch.setattr(ui,'start_review',lambda:seen.append('start_review'))
    ui._show_correction_source_message();root.update()
    assert button.cget('text')=='Continue' and button.instate(['disabled'])
    assert ui.setup_header_label.cget('text')=='MESSAGE'
    assert not [w for w in nested_widgets(ui.setup_action_view) if isinstance(w,ttk.Button)]
    radios=[w for w in nested_widgets(ui.setup_action_view) if isinstance(w,ttk.Radiobutton)]
    next(w for w in radios if w.cget('text')=='Wideband O2').invoke();root.update()
    assert ui.correction_source_selection=='wideband'
    assert button.cget('text')=='Continue' and not button.instate(['disabled'])
    assert (button.winfo_width(),button.winfo_height())==(initial_width,initial_height)
    button.invoke();root.update()
    assert seen==['review','start_review']


def test_completed_review_results_action_uses_same_physical_button(ui_setup,monkeypatch):
    root,ui=ui_setup
    button=ui.setup_workflow_button
    xy=(button.winfo_rootx(),button.winfo_rooty(),button.winfo_width(),button.winfo_height())
    ui.project=SimpleNamespace(id=15)
    ui._setup_lower_mode='review';ui.running=False
    monkeypatch.setattr(ui,'_review_result_ready',lambda:True)
    navigated=[]
    monkeypatch.setattr(ui,'goto',lambda page:navigated.append(page))
    ui._set_setup_panel_message('REVIEW COMPLETE','Candidate verified',requires_action=False)
    ui._set_setup_activity('Processing complete','Candidate verified',percent=100,step=5,total=5,busy=False)
    ui._update_setup_workflow_action();root.update()
    assert ui.setup_header_label.cget('text')=='PROGRESS'
    assert button.cget('text')=='Results' and not button.instate(['disabled'])
    assert (button.winfo_rootx(),button.winfo_rooty(),button.winfo_width(),button.winfo_height())==xy
    assert not any(w.cget('text')=='Results' for w in nested_widgets(ui.setup_action_view)
                   if isinstance(w,ttk.Button))
    button.invoke();assert navigated==['results']
