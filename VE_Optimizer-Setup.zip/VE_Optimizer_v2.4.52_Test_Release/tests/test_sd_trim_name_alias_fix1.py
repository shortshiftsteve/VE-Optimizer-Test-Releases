"""Native/SAE HPL fuel-trim aliases must qualify and process identically.

Regression for a 2026-10-10 NN-disabled VCM Scanner log with 9,393 STFT
observations per bank whose displayed names omit the '(SAE)' suffix.
The fixture is synthetic: user HPL for that screenshot has not been provided.
"""
from pathlib import Path
from unittest.mock import patch
import sys
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integ


def fake_decoded(*, sae=False, ltft=False):
    name=lambda base: base + (' (SAE)' if sae else '')
    names=[
        ('rpm','Engine RPM','rpm',21),
        ('torque','Actual Torque','lb-ft',22),
        ('map','MAP - Hi-Res','kPa',23),
        ('baro','Barometric Pressure','kPa',24),
        ('ect','Engine Coolant Temp','deg F',25),
        ('fa','FA Enrichment','',26),
        ('pe','FA Power Enrichment','',27),
        ('flow','Fuel Flow Rate','lb/h',wb.FUEL_FLOW_PID),
        ('stft_b1',name('Short Term Fuel Trim Bank 1'), '%',30),
        ('stft_b2',name('Short Term Fuel Trim Bank 2'), '%',31),
    ]
    if ltft:
        names += [('ltft_b1',name('Long Term Fuel Trim Bank 1'), '%',32),
                  ('ltft_b2',name('Long Term Fuel Trim Bank 2'), '%',33)]
    channels={i:{'name':n,'unit':u,'parameter_id':pid} for i, (_,n,u,pid) in enumerate(names)}
    values={'rpm':1500.,'torque':30.,'map':80.,'baro':100.,'ect':190.,
            'fa':0.,'pe':0.,'flow':15.,'stft_b1':4.,'stft_b2':-2.,
            'ltft_b1':1.,'ltft_b2':-1.}
    frames=[{'timestamp_ms':100*i,'updates':{index:values[k] for index,(k,_,_,_) in enumerate(names)}}
             for i in range(12)]
    return {'channels':channels,'frames':frames}


@pytest.mark.parametrize('sae',[False,True])
@pytest.mark.parametrize('ltft',[False,True])
def test_trim_source_aliases_recognized_in_preflight(sae,ltft):
    d=fake_decoded(sae=sae,ltft=ltft)
    r=wb._adaptive_trim_status(d,airflow_model='speed_density')
    assert r['valid'] is True,r
    assert r['missing']==[]
    assert r['accepted_events_bank1']==12
    assert r['accepted_events_bank2']==12
    assert r['mode']==('ltft_plus_stft' if ltft else 'stft_only')
    assert r['ltft_available'] is ltft


@pytest.mark.parametrize('sae',[False,True])
@pytest.mark.parametrize('ltft',[False,True])
def test_aliases_produce_same_real_sd_event_math(sae,ltft):
    d=fake_decoded(sae=sae,ltft=ltft)
    rpm=np.array([0.,1500.,3000.]);pr=np.array([0.5,0.8,1.5]);z=np.ones((3,3))
    with patch.object(wb,'decode_hpl',return_value=d),\
         patch.object(wb,'parse_ve_table',return_value=(b'fake',rpm,pr,z)):
        result=integ._adaptive_sd_analysis(Path('dummy.hpl'),Path('dummy.htt'))
    assert result['qualifying_cell_count']==1
    assert result['hit_counts'][0,1,1]==12
    assert result['hit_counts'][1,1,1]==12
    expected=5.0 if ltft else 4.0  # dominant bank 1: STFT + optional LTFT
    assert result['full_correction_pct'][1,1]==expected
    assert result['applied_correction_pct'][1,1]==0.5*expected
    assert result['trim_mode']==('ltft_plus_stft' if ltft else 'stft_only')


def test_nn_keeps_its_ltft_requirement():
    d=fake_decoded(sae=False,ltft=False)
    result=wb._adaptive_trim_status(d,airflow_model='neural_network')
    assert not result['valid']
    assert result['missing']==['ltft_b1','ltft_b2']


def test_trim_resolution_never_invents_missing_bank():
    d=fake_decoded(sae=False,ltft=False)
    channels={i:v for i,v in d['channels'].items() if v['name']!='Short Term Fuel Trim Bank 2'}
    result=wb._adaptive_trim_status({**d,'channels':channels},airflow_model='speed_density')
    assert not result['valid']
    assert 'stft_b2' in result['missing']


def test_prefer_sae_when_both_are_present():
    d=fake_decoded(sae=False,ltft=False)
    d['channels'][101]={'name':'Short Term Fuel Trim Bank 1 (SAE)','unit':'%', 'parameter_id':12345}
    assert wb._resolve_trim_channel(d['channels'],'Short Term',1)==101


def test_same_trim_source_identity_used_by_both_paths():
    # Read the actual module source; inspect.getsource() can be stale after
    # other tests patch/reload linecache or dynamically create module objects.
    preflight_source=(ROOT/'ve_optimizer_wideband.py').read_text(encoding='utf-8')
    processor_source=(ROOT/'ve_optimizer_wideband_integration.py').read_text(encoding='utf-8')
    assert 'idx.update(_resolve_trim_inputs(channels, decoded=decoded))' in preflight_source
    assert 'wb._speed_density_trim_inputs(decoded)' in processor_source
    assert '_speed_density_trim_inputs(decoded)' in preflight_source
    assert '_resolve_trim_channel(channels, "Short Term", 1, decoded=decoded)' not in processor_source


def test_ui_distinguishes_channel_and_source_failures():
    source=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert 'CORRECTION SOURCE NOT QUALIFIED' in source
    assert 'Adaptive/STFT: ' in source
    assert 'preflight_error' in source


@pytest.mark.parametrize('sae', [False, True])
@pytest.mark.parametrize('ltft', [False, True])
def test_sd_trim_no_nn_enrichment_gate_and_uses_optional_ltft(sae, ltft):
    d = fake_decoded(sae=sae, ltft=ltft)
    # NN zero-enrichment gates are not part of NN-disabled STFT processing.
    for frame in d['frames']:
        frame['updates'][5] = 1.0  # FA Enrichment
        frame['updates'][6] = 1.0  # FA Power Enrichment
    preflight = wb._adaptive_trim_status(d, airflow_model='speed_density')
    assert preflight['valid'], preflight
    assert (preflight['accepted_events_bank1'], preflight['accepted_events_bank2']) == (12, 12)
    assert preflight['mode'] == ('ltft_plus_stft' if ltft else 'stft_only')
    rpm=np.array([0.,1500.,3000.]);pr=np.array([0.5,0.8,1.5]);z=np.ones((3,3))
    with patch.object(wb,'decode_hpl',return_value=d), \
         patch.object(wb,'parse_ve_table',return_value=(b'fake',rpm,pr,z)):
        result=integ._adaptive_sd_analysis(Path('dummy.hpl'),Path('dummy.htt'))
    assert int(result['hit_counts'][0].sum()) == 12
    assert int(result['hit_counts'][1].sum()) == 12
    assert result['trim_mode'] == ('ltft_plus_stft' if ltft else 'stft_only')
    assert result['full_correction_pct'][1,1] == (5.0 if ltft else 4.0)
    assert result['applied_correction_pct'][1,1] == (2.5 if ltft else 2.0)


def test_sd_does_not_require_ltft_or_fa_pe_channels():
    d = fake_decoded(sae=False, ltft=True)
    forbidden = {'FA Enrichment', 'FA Power Enrichment',
                 'Long Term Fuel Trim Bank 1', 'Long Term Fuel Trim Bank 2'}
    d['channels'] = {k: v for k,v in d['channels'].items()
                     if v['name'] not in forbidden}
    result=wb._adaptive_trim_status(d, airflow_model='speed_density')
    assert result['valid'], result
    assert result['mode'] == 'stft_only'
    rpm=np.array([0.,1500.,3000.]);pr=np.array([0.5,0.8,1.5]);z=np.ones((3,3))
    with patch.object(wb,'decode_hpl',return_value=d), \
         patch.object(wb,'parse_ve_table',return_value=(b'fake',rpm,pr,z)):
        calc=integ._adaptive_sd_analysis(Path('dummy.hpl'),Path('dummy.htt'))
    assert calc['trim_mode'] == 'stft_only'
    assert calc['qualifying_cell_count']==1


def test_nn_enrichment_values_are_qualifiers_not_hard_trim_gates():
    d = fake_decoded(sae=False, ltft=True)
    baseline=wb._adaptive_trim_status(d,airflow_model='neural_network')
    assert baseline['mode']=='ltft_plus_stft'
    assert baseline['valid']
    assert baseline['accepted_events_bank1']==12
    for frame in d['frames']:
        frame['updates'][5] = 1.0
    gated=wb._adaptive_trim_status(d,airflow_model='neural_network')
    assert gated['valid']
    assert gated['accepted_events_bank1']==baseline['accepted_events_bank1']
    assert gated['accepted_events_bank2']==baseline['accepted_events_bank2']


def test_sd_preflight_and_processor_require_same_core_channels():
    d = fake_decoded(sae=False, ltft=False)
    for missing in ('MAP - Hi-Res','Barometric Pressure',
                    'Short Term Fuel Trim Bank 2'):
        other={**d, 'channels':{i:v for i,v in d['channels'].items() if v['name'] != missing}}
        pf=wb._adaptive_trim_status(other,airflow_model='speed_density')
        assert not pf['valid']
        assert pf['missing']
        rpm=np.array([0.,1500.,3000.]);pr=np.array([0.5,0.8,1.5]);z=np.ones((3,3))
        with patch.object(wb,'decode_hpl',return_value=other), \
             patch.object(wb,'parse_ve_table',return_value=(b'fake',rpm,pr,z)):
            with pytest.raises(ValueError,match='Speed Density STFT processing is missing'):
                integ._adaptive_sd_analysis(Path('dummy.hpl'),Path('dummy.htt'))
