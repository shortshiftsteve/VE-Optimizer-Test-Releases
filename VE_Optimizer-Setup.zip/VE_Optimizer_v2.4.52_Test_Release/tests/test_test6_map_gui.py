"""Removal of physical MAP sensor confirmation; data-driven airflow safety retained."""
import inspect
from pathlib import Path
import tkinter as tk
import ve_optimizer_revision9_review as app
import ve_optimizer_wideband as wb


def _walk(parent):
    for child in parent.winfo_children():
        yield child
        yield from _walk(child)


def test_no_map_yes_no_ui_or_pe_manual_review_gate():
    assert not hasattr(app.ReviewApp,'_review_map_and_pe')
    ui=inspect.getsource(app.ReviewApp._show_preflight_prompt)
    assert 'self._show_correction_source_message()' in ui
    assert '_review_map_and_pe' not in ui
    source=Path(app.__file__).read_text(encoding='utf-8')
    assert 'PE Calibration Safety' not in source
    assert 'Have you positively verified' not in source


def test_qualifying_boost_uses_normal_source_selection_without_confirmation():
    root=tk.Tk();root.geometry('1000x700')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.setup_message_host=tk.Frame(root,bg='white')
        obj.setup_message_host.pack(fill='both',expand=True)
        obj.setup_panel_message=None
        obj.correction_preflight_cache={
            'engine_review':{'boost_review_required':True},
            'choices':[{'id':'adaptive','label':'STFT','enabled':True}]}
        obj.correction_source_selection=None
        obj._show_preflight_prompt();root.update()
        assert obj.setup_panel_message['heading']=='CORRECTION SOURCE'
        assert obj.correction_source_selection=='adaptive'
        text=' '.join(w.cget('text') for w in _walk(root) if isinstance(w,tk.Label))
        assert 'positively verified' not in text.lower()
        assert not any(isinstance(w,tk.Radiobutton) and w.cget('text') in ('Yes','No') for w in _walk(root))
    finally:
        root.destroy()


def test_independent_airflow_safety_gate_is_retained():
    preflight=inspect.getsource(wb.build_correction_preflight)
    assert 'if airflow_preflight.get("blocking"):' in preflight
    assert 'if pe_preflight.get("blocking"):' not in preflight
    assert 'hardware_review_pending = False' in preflight


def test_automatic_map_preparation_never_writes_sensor_transfer():
    auto=inspect.getsource(wb.prepare_airflow_strategy)
    assert 'MAP1_LINEAR_SCALAR' not in auto
    assert 'MAP2_LINEAR_SCALAR' not in auto
    assert 'SENSED_MAP_ENABLE_SWITCH' not in auto
