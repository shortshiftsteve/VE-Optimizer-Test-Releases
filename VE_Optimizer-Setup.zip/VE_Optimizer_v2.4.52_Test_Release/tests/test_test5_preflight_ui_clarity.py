"""Test 5: source availability and completion-display regressions.

These tests do not modify tuning, log decoding, or solver arithmetic.
"""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_wideband as wb
import ve_optimizer_revision9_review as app


def test_sae_stft_preferred_when_native_variant_is_also_present():
    chans={0:{'name':'Short Term Fuel Trim Bank 1'},
           1:{'name':'Short Term Fuel Trim Bank 1 (SAE)'},
           2:{'name':'Short Term Fuel Trim Bank 2'},
           3:{'name':'Short Term Fuel Trim Bank 2 (SAE)'}}
    assert wb._resolve_trim_channel(chans,'Short Term',1)==1
    assert wb._resolve_trim_channel(chans,'Short Term',2)==3
    assert wb._resolve_trim_channel({0:chans[0],2:chans[2]},'Short Term',1)==0
    assert wb._resolve_trim_channel({0:chans[0],2:chans[2]},'Short Term',2)==2


def test_wideband_status_identifies_actual_logged_channel():
    # The metadata annotation is independent of actual quantitative choices.
    channels={0:{'name':wb.WB_NAME},1:{'name':wb.FA_ENRICH_NAME},2:{'name':wb.FA_PE_NAME}}
    frames=[{'timestamp_ms':i*100,'updates':{0:0.82,1:0.01,2:0.01}} for i in range(8)]
    result=wb._wideband_data_status({'channels':channels,'frames':frames})
    assert result['present'] and result['valid']
    assert result['channel_name']==wb.WB_NAME
    assert result['wideband_updates']==8
    assert result['dual_gate_updates']==8


def test_preflight_source_visibility_preserves_data_gates_without_hardware_prompt():
    ui=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "if len(valid)==2:" in ui
    assert "if self.correction_source_selection not in valid:" in ui
    assert "if pf.get('hardware_review_pending'):" not in ui
    assert "display_names={'fuel_flow':'Fuel Flow Rate'" in ui
    assert "Selected STFT: Bank 1" in ui
    wb_source=(ROOT/'ve_optimizer_wideband.py').read_text(encoding='utf-8')
    assert "hardware_review_pending = False" in wb_source
    assert 'if airflow_preflight.get("blocking"):' in wb_source
    assert 'if pe_preflight.get("blocking"):' not in wb_source


def test_completed_run_rebuild_always_shows_100_percent():
    ui=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "if not self.run_quality_activity_lines or not self.run_quality_activity_lines[-1].startswith('OVERALL 100%')" in ui
    assert "widget.see('end')" in ui  # Approved Progress event log is now pinned above details
    assert "if not self.running and self.run_pct.get().startswith('COMPLETE'):return" in ui


def test_knock_prompt_is_short_and_retains_explicit_fa_gates():
    ui=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "self._set_setup_panel_message('KNOCK DATA NOT FOUND'" in ui
    assert "messagebox.askyesno" not in ui.split('def _prompt_na_closed_loop_only',1)[1].split('def ',1)[0]
    assert 'Select Yes to proceed or No to select a different log file.' in ui
    # The prompt is deliberately concise; the established physical
    # zero-enrichment gates remain in the numerical processing code.
    processing=(ROOT/'ve_optimizer_processing.py').read_text(encoding='utf-8')
    assert "closed_loop_only and" in processing
    assert "closed_loop_only" in processing and "fa_enrichment" in processing.lower() and "fa_power" in processing.lower()
