"""Prevents build-required root files from being moved into history."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
HISTORY = ROOT / "development_history" / "v2.4.1_release_history"


def test_release_root_requirements_and_validation_are_retained():
    for name in ("requirements.txt", "VALIDATION.json"):
        required = ROOT / name
        archived = HISTORY / name
        assert required.is_file(), f"Windows build input absent from release root: {name}"
        assert archived.is_file(), f"Archived baseline missing: {name}"
        assert required.read_bytes() == archived.read_bytes()


def test_windows_build_references_existing_release_inputs():
    batch = (ROOT / "installer" / "Build_VE_Optimizer_v2.4.52_Installer.bat").read_text()
    spec = (ROOT / "installer" / "VE_Optimizer.spec").read_text()
    assert r"%~dp0..\requirements.txt" in batch
    assert "'VALIDATION.json'" in spec
    assert (ROOT / "requirements.txt").is_file()
    assert (ROOT / "VALIDATION.json").is_file()
