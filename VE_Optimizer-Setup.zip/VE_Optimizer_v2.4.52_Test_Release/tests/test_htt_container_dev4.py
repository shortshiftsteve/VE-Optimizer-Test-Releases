"""Development 4 verification: exact HPT R v3 framing and selective SD records."""
from __future__ import annotations

from dataclasses import replace
import struct
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ve_optimizer_htt_codec import parse_htt, build_htt, UnsupportedHTTFormat
import ve_optimizer_stage3 as s3
import ve_optimizer_wideband as wb

FULL_SAMPLES = (
    Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt'),
    Path('/mnt/data/STOCK_2023_Dodge_Challenger 5_7_MDS_Disabled.htt'),
    Path('/mnt/data/2016 Dodge Challenger 6.4L Engine and fuel system tune file.htt'),
    Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt'),
)
PARTIAL_SAMPLES = (
    Path('/mnt/data/5_7_2010-2014 6.4L Cam Swap to 5.7L.htt'),
    Path('/mnt/data/6_4 _2010-2014 6.4L Cam Swap to 5.7.htt'),
    Path(__file__).resolve().parents[1] / 'a/stock_nn.htt',
)


def edited_table_blob(blob: bytes, key: int) -> bytes:
    """Preserve all other source bytes while changing one table payload."""
    _, pos, start, end = s3._find_length_payload(blob, key)
    payload = blob[start:end]
    text = payload.decode('utf-8')
    # One harmless text token mutation for binary framing regression only.
    # No actual output of this test is intended for an ECU.
    p = text.index('\t')
    replacement = text[:p+1] + '1234.567890123' + text[p+1:]
    new = replacement.encode('utf-8')
    return blob[:pos] + s3._encode_uleb128(len(new)) + new + blob[end:]


class HTTRoundTripTests(unittest.TestCase):
    def test_full_engine_and_partial_templates_round_trip_exact(self):
        for f in (*FULL_SAMPLES, *PARTIAL_SAMPLES):
            if not f.is_file():
                continue
            with self.subTest(filename=f.name):
                src = f.read_bytes()
                parsed = parse_htt(src)
                self.assertEqual(build_htt(parsed), src)
                self.assertEqual(len(parsed.by_key()),
                                 len(parsed.switches)+len(parsed.scalars)+len(parsed.tables))

    def test_new_vcm_suite_engine_record_counts(self):
        f = FULL_SAMPLES[-1]
        if not f.exists(): self.skipTest('External VCM Suite reference missing')
        doc = parse_htt(f.read_bytes())
        self.assertEqual((len(doc.switches), len(doc.scalars), len(doc.tables)),
                         (73, 377, 513))

    def test_failed_development3_file_detected(self):
        f = Path('/mnt/data/Test 3 NN Off.htt')
        if not f.exists(): self.skipTest('External failed source missing')
        with self.assertRaises(UnsupportedHTTFormat):
            parse_htt(f.read_bytes())

    def test_unknown_format_version_rejected(self):
        f = PARTIAL_SAMPLES[-1]
        b = bytearray(f.read_bytes())
        b[5] = 4
        with self.assertRaises(UnsupportedHTTFormat): parse_htt(bytes(b))

    def test_corrupt_record_count_rejected(self):
        b = bytearray(PARTIAL_SAMPLES[-1].read_bytes())
        b[20:22] = struct.pack('<H', 4)
        with self.assertRaises(UnsupportedHTTFormat): parse_htt(bytes(b))

    def test_corrupt_table_suffix_rejected(self):
        b = PARTIAL_SAMPLES[-1].read_bytes()
        doc = parse_htt(b)
        record = doc.tables[0]
        malformed = replace(record, raw=record.raw[:-2] + b'\x00\x01')
        doc = replace(doc, tables=(malformed,) + doc.tables[1:])
        with self.assertRaises(UnsupportedHTTFormat):
            build_htt(doc)

    def test_unexpected_trailing_content_rejected(self):
        b = PARTIAL_SAMPLES[-1].read_bytes()
        with self.assertRaises(UnsupportedHTTFormat): parse_htt(b + b'x')

    def test_duplicate_record_identifier_rejected(self):
        doc = parse_htt(PARTIAL_SAMPLES[-1].read_bytes())
        bad = replace(doc, tables=(doc.tables[0], doc.tables[0]) + doc.tables[1:])
        with self.assertRaises(UnsupportedHTTFormat): build_htt(bad)

    def test_empty_sections_can_be_constructed(self):
        doc = parse_htt(PARTIAL_SAMPLES[-1].read_bytes())
        raw = build_htt(doc, {doc.tables[0].key})
        out = parse_htt(raw)
        self.assertEqual((len(out.switches),len(out.scalars),len(out.tables)),(0,0,1))
        self.assertEqual(out.tables[0].raw, doc.tables[0].raw)


class HTTSelectiveExportTests(unittest.TestCase):
    def _sample(self):
        f = FULL_SAMPLES[-1]
        if not f.is_file(): self.skipTest('External VCM Suite reference missing')
        return f

    def test_one_changed_table_selective_export(self):
        src = self._sample()
        with tempfile.TemporaryDirectory() as folder:
            candidate = Path(folder)/'candidate.htt'; output = Path(folder)/'output.htt'
            candidate.write_bytes(edited_table_blob(src.read_bytes(), wb.VE_BANK1_TABLE))
            result = wb.export_speed_density_changed_tables(src, candidate, output)
            doc = parse_htt(output.read_bytes())
            self.assertEqual(result['changed_tables'], [wb.VE_BANK1_TABLE])
            self.assertEqual((len(doc.switches),len(doc.scalars),len(doc.tables)),(0,0,1))
            self.assertEqual(doc.tables[0].raw,parse_htt(candidate.read_bytes()).by_key()[wb.VE_BANK1_TABLE].raw)
            self.assertLess(output.stat().st_size, src.stat().st_size / 20)
            self.assertEqual(build_htt(doc),output.read_bytes())

    def test_two_banks_and_pe_mutation_is_rejected(self):
        src = self._sample()
        with tempfile.TemporaryDirectory() as folder:
            cand = Path(folder)/'candidate.htt'; out = Path(folder)/'export.htt'
            blob = src.read_bytes()
            for key in (wb.VE_BANK1_TABLE,wb.VE_BANK2_TABLE,wb.PE_PRATIO_TABLE):
                blob=edited_table_blob(blob,key)
            cand.write_bytes(blob)
            with self.assertRaisesRegex(ValueError,'unrelated table record'):
                wb.export_speed_density_changed_tables(src,cand,out)
            self.assertFalse(out.exists())

    def test_mixed_switch_scalar_table(self):
        src = self._sample()
        with tempfile.TemporaryDirectory() as folder:
            cand=Path(folder)/'candidate.htt';out=Path(folder)/'export.htt'
            doc=parse_htt(src.read_bytes())
            recs=doc.by_key()
            sw = recs[wb.SENSED_MAP_ENABLE_SWITCH]
            # Only the independently authorized Disabled -> Enabled MAP switch
            # is eligible for selective export. PE selector changes are banned.
            if sw.raw[5:] != b'Disabled':
                self.skipTest('Sample Sensed MAP must begin Disabled')
            other = b'Enabled'
            new_switch=sw.raw[:4]+s3._encode_uleb128(len(other))+other
            scalar=recs[wb.PRESSURE_RATIO_MAX_SCALAR]
            new_scalar=scalar.raw[:4]+struct.pack('<d', 2.0)+scalar.raw[12:]
            cand_blob = edited_table_blob(src.read_bytes(),wb.VE_BANK1_TABLE)
            tmpdoc=parse_htt(cand_blob)
            candrecs=tmpdoc.by_key()
            modified={wb.SENSED_MAP_ENABLE_SWITCH:new_switch, wb.PRESSURE_RATIO_MAX_SCALAR:new_scalar}
            def updated(kind):
                return tuple(replace(rec, raw=modified.get(rec.key,rec.raw)) for rec in tmpdoc.group(kind))
            cand_blob=build_htt(replace(tmpdoc,switches=updated('switch'),scalars=updated('scalar')))
            cand.write_bytes(cand_blob)
            result=wb.export_speed_density_changed_tables(src,cand,out)
            exp=parse_htt(out.read_bytes())
            self.assertEqual(result['record_counts'],{'switch':1,'scalar':1,'table':1})
            self.assertEqual(set(result['changed_records']),set(modified)|{wb.VE_BANK1_TABLE})
            for key,record in exp.by_key().items():
                self.assertEqual(record.raw,candrecs[key].raw if key not in modified else modified[key])

    def test_unapproved_changed_record_fails_and_preserves_output(self):
        src=self._sample()
        with tempfile.TemporaryDirectory() as folder:
            cand=Path(folder)/'candidate.htt';out=Path(folder)/'output.htt'
            cand.write_bytes(edited_table_blob(src.read_bytes(),324))
            out.write_bytes(b'old export')
            with self.assertRaisesRegex(ValueError,'unrelated table record'):
                wb.export_speed_density_changed_tables(src,cand,out)
            self.assertEqual(out.read_bytes(),b'old export')

    def test_source_overwrite_prevented(self):
        src=self._sample()
        with tempfile.TemporaryDirectory() as folder:
            cand=Path(folder)/'candidate.htt'
            cand.write_bytes(edited_table_blob(src.read_bytes(),wb.VE_BANK1_TABLE))
            with self.assertRaisesRegex(ValueError,'overwrite'):
                wb.export_speed_density_changed_tables(src,cand,src)

    def test_no_changes_fail(self):
        src=self._sample()
        with tempfile.TemporaryDirectory() as folder:
            cand=Path(folder)/'candidate.htt';cand.write_bytes(src.read_bytes())
            with self.assertRaisesRegex(ValueError,'No modified'):
                wb.export_speed_density_changed_tables(src,cand,Path(folder)/'out.htt')


if __name__ == '__main__':
    unittest.main(verbosity=2)
