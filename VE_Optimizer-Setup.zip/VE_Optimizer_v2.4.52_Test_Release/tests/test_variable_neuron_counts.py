import copy
import math
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

import ve_optimizer_processing as processing
import ve_optimizer_stage3 as htt


class VariableNeuronCountTests(unittest.TestCase):
    def _with_neuron_count(self, source:Path, destination:Path, n:int):
        blob=source.read_bytes()
        blob=htt._patch_scalar_value(blob,htt.SCALAR_KEYS['neurons'],float(n))
        destination.write_bytes(blob)

    def test_every_supported_neuron_count_loads_evaluates_and_exports(self):
        source=ROOT/'tests/fixtures/stock.htt'
        carrier=ROOT/'a/stock_nn.htt'
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            for n in range(1,htt.MAX_NEURONS+1):
                base=td/f'base_{n}.htt'
                full=td/f'candidate_{n}.htt'
                exported=td/f'exported_{n}.htt'
                self._with_neuron_count(source,base,n)
                net=htt.load_network(base)
                self.assertEqual(net['meta']['neurons'],n)

                coeff=processing.coefficients(net)
                self.assertEqual(len(coeff),n*n+7*n+1)
                w1,b1,w2,b2,wo,bo=processing.unpack(coeff)
                self.assertEqual(w1.shape,(n,4))
                self.assertEqual(w2.shape,(n,n))
                self.assertEqual(len(wo),n)

                model=processing.FrozenModel(processing.config(net))
                physical=np.array([[122.0,106.5,2000.0,0.5]],dtype=float)
                normalized=model.normalize(physical)
                value=model.forward(coeff,normalized,exact=True)
                self.assertTrue(np.isfinite(value).all(),n)

                changed=copy.deepcopy(net)
                changed['bo']=[float(changed['bo'][0])+1.0/2048.0]
                htt.write_candidate(base,full,changed)
                reloaded=htt.load_network(full)
                self.assertEqual(reloaded['meta']['neurons'],n)
                self.assertAlmostEqual(reloaded['bo'][0],changed['bo'][0],places=12)

                changed_names=htt.write_changed_nn_template(base,full,exported,carrier_htt=carrier)
                self.assertIn('bo',changed_names)
                final=htt.load_network(exported)
                self.assertEqual(final['meta']['neurons'],n)
                self.assertTrue(htt.network_equivalent(final,reloaded,tol=0.0))

    def test_out_of_range_neuron_counts_are_rejected(self):
        source=ROOT/'tests/fixtures/stock.htt'
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            for n in (0,htt.MAX_NEURONS+1):
                f=td/f'bad_{n}.htt'
                self._with_neuron_count(source,f,n)
                with self.assertRaisesRegex(ValueError,'Unsupported Number of Neurons'):
                    htt.load_network(f)


if __name__=='__main__':
    unittest.main(verbosity=2)
