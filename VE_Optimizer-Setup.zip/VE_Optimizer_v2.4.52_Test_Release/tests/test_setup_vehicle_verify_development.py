"""6.2L/5.7L/6.4L Setup vehicle verification before native HPL Submit.

These tests exercise the live Tk message host; HPL decoding and correction math
are intentionally outside the UI-only change scope.
"""
from pathlib import Path
import tkinter as tk
from tkinter import ttk

import pytest
import ve_optimizer_revision9_review as app


def descendants(parent):
    for widget in parent.winfo_children():
        yield widget
        yield from descendants(widget)


def button_by_text(parent,text):
    return next(widget for widget in descendants(parent)
                if isinstance(widget,ttk.Button) and widget.cget('text')==text)


@pytest.fixture
def ready_setup(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'appdata'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1300x850')
    inst=app.ReviewApp(root,tmp_path/'data.db',Path(app.__file__).resolve().parent/'a')
    inst.user=inst.db.single_user_identity()
    inst.shell();inst.goto('setup');root.update()
    tune=tmp_path/'selected.htt';tune.write_bytes(b'fixture selected full tune')
    log=tmp_path/'selected.hpl';log.write_bytes(b'fixture selected native log')
    # A log may only be browsed after a tune exists. UI tests isolate this
    # precondition without bypassing the Submit verification gate.
    monkeypatch.setattr(inst,'_setup_candidate_tune_path',lambda:tune)
    inst.vs_vars['htt'].set(str(tune))
    try:
        yield root,inst,tune,log
    finally:
        inst._stop_setup_verify_blink()
        inst.db.close()
        root.destroy()


def select_log(monkeypatch,setup,log):
    root,inst,*_=setup
    monkeypatch.setattr(app.filedialog,'askopenfilename',lambda **_kw:str(log))
    inst._select_current_log();root.update()
    assert inst.setup_workflow_button.cget('text')=='Verify'
    return inst.setup_workflow_button


def test_verify_prompts_with_three_vehicle_fields_and_focus_before_submit(ready_setup,monkeypatch):
    root,inst,_tune,log=ready_setup
    assert inst.setup_workflow_button.winfo_manager()=='pack'
    assert inst.setup_workflow_button.cget('text')=='Build'
    assert inst.setup_workflow_button.instate(['disabled'])
    inst.vs_vars['year'].set('2020')
    inst.vs_vars['engine'].set('6.2L Supercharged Hemi')
    inst.vs_vars['model'].set('Trackhawk')
    verify=select_log(monkeypatch,ready_setup,log)
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    heading=[w for w in descendants(inst.setup_message_host) if isinstance(w,tk.Label) and w.cget('text')=='MESSAGE']
    assert heading
    labels=[w.cget('text') for w in descendants(inst.setup_message_host) if isinstance(w,tk.Label)]
    assert any('Model Year: 2020' in t and 'Engine: 6.2L Supercharged Hemi' in t
               and 'Vehicle Type: Trackhawk' in t for t in labels)
    assert inst.setup_workflow_button.cget('text')=='Verify'
    assert verify.cget('style')=='VerifyBright.TButton'
    assert root.focus_get()==verify
    # The flashing yellow state is real, not a static or disabled button.
    root.after(510,root.quit);root.mainloop()
    assert verify.cget('style')=='VerifySoft.TButton'
    verify.invoke();root.update()
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFIED'
    assert inst._setup_vehicle_is_verified()
    assert inst._setup_verify_blink_after_id is None
    assert inst.setup_workflow_button.cget('text')=='Submit'
    assert inst.vs_save is inst.vs_log_submit_button


@pytest.mark.parametrize('key,new_value',[
    ('year','2022'),('engine','6.4L Hemi'),('model','Hellcat'),
])
def test_vehicle_change_requires_reverification(ready_setup,monkeypatch,key,new_value):
    root,inst,_tune,log=ready_setup
    verify=select_log(monkeypatch,ready_setup,log)
    verify.invoke();root.update()
    assert inst.setup_workflow_button.cget('text')=='Submit'
    inst.vs_vars[key].set(new_value);root.update()
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    assert not inst._setup_vehicle_is_verified()
    assert inst.setup_workflow_button.cget('text')=='Verify'
    verify=inst.setup_workflow_button
    verify.invoke();root.update()
    assert inst._setup_vehicle_is_verified()
    assert inst.setup_workflow_button.cget('text')=='Submit'


def test_reselecting_log_revokes_previous_verification(ready_setup,monkeypatch,tmp_path):
    root,inst,_tune,log=ready_setup
    select_log(monkeypatch,ready_setup,log).invoke();root.update()
    second=tmp_path/'different.hpl';second.write_bytes(b'second fixture')
    select_log(monkeypatch,ready_setup,second)
    assert not inst._setup_vehicle_is_verified()
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    assert inst.setup_workflow_button.cget('text')=='Verify'


def test_submit_cannot_enter_log_worker_without_verify(ready_setup,monkeypatch):
    root,inst,_tune,log=ready_setup
    select_log(monkeypatch,ready_setup,log)
    jobs=[]
    monkeypatch.setattr(inst,'_run_background_task',lambda work,done:jobs.append((work,done)))
    inst._submit_selected_log();root.update()
    assert jobs==[]
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    inst.setup_workflow_button.invoke();root.update()
    inst.vs_log_submit_button.invoke();root.update()
    assert len(jobs)==1
    assert inst.setup_panel_message['heading']=='Log File Validation'


def test_after_log_qualification_build_requires_same_verification(ready_setup,monkeypatch):
    root,inst,_tune,log=ready_setup
    select_log(monkeypatch,ready_setup,log)
    inst.setup_workflow_button.invoke();root.update()
    inst.vs_log_report={'passed':True,'signals':[]}
    inst.vs_log_staged=False;inst.vs_log_valid=True
    inst._vehicle_form_update();root.update()
    assert inst.setup_workflow_button.cget('text')=='Build'
    inst.vs_vars['model'].set('Hellcat');root.update()
    assert inst.setup_workflow_button.cget('text')=='Verify'
    assert inst.vs_save is inst.vs_log_submit_button
    assert inst.setup_panel_message['heading']=='VEHICLE VERIFICATION'
    inst.setup_workflow_button.invoke();root.update()
    assert inst.setup_workflow_button.cget('text')=='Build'


def test_both_new_vehicle_types_are_setup_choices(ready_setup):
    root,inst,_tune,_log=ready_setup
    assert app.MODEL_OPTIONS==('Dodge Challenger','Dodge Charger','Hellcat','Trackhawk')
    labels=[w for w in descendants(inst.content) if isinstance(w,tk.Label)
            and w.cget('text')=='Vehicle Type']
    assert len(labels)==1
    for choice in ('Hellcat','Trackhawk'):
        inst.vs_vars['model'].set(choice)
        assert inst.vs_vars['model'].get()==choice


def test_reopening_new_project_returns_to_initial_centered_warning(ready_setup,monkeypatch):
    root,inst,_tune,log=ready_setup
    select_log(monkeypatch,ready_setup,log).invoke();root.update()
    inst.goto('projects')
    inst.goto('setup');root.update()
    assert inst.setup_panel_message['heading']=='WARNING'
    assert inst.setup_workflow_button.cget('text')=='Build'
    assert inst.setup_workflow_button.instate(['disabled'])
    warning=next(w for w in descendants(inst.setup_message_host)
                 if isinstance(w,tk.Label) and w.cget('text')==app.OPENING_EMISSIONS_WARNING)
    assert warning.cget('justify')=='center'
