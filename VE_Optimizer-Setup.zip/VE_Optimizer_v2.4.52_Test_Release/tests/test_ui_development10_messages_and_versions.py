"""Development 10: approved message typography and V0...Vn performance columns."""
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
from tkinter import ttk

import ve_optimizer_revision9_review as app


def all_widgets(widget):
    for child in widget.winfo_children():
        yield child
        yield from all_widgets(child)


def test_initial_warning_is_readable_center_justified_wrapped_and_replaceable(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1360x900+0+0')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'v10.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        labels=[w for w in all_widgets(ui.setup_message_host) if isinstance(w,tk.Label)]
        message=next(w for w in labels if w.cget('text')==app.OPENING_EMISSIONS_WARNING)
        assert message.cget('justify')=='center'
        assert message.cget('anchor')=='n'
        assert int(message.cget('wraplength'))>=200
        assert message.cget('font').endswith('11 bold') or 'bold' in message.cget('font')
        assert message.winfo_width()<=ui.setup_message_host.winfo_width()
        ui._set_setup_panel_message('KNOCK DATA NOT FOUND',
            'The current log file does not include monitoring knock status. Without this information, ' \
            'it would be too risky to attempt anything other than a closed loop tune. ' \
            'Select Yes to proceed or No to select a different log file.',
            align='center',actions=(('Yes',lambda:None),('No',lambda:None)))
        root.update()
        labels=[w for w in all_widgets(ui.setup_message_host) if isinstance(w,tk.Label)]
        assert not any(w.cget('text')==app.OPENING_EMISSIONS_WARNING for w in labels)
        knock=next(w for w in labels if 'monitoring knock status' in w.cget('text'))
        assert knock.cget('justify')=='left'
        assert int(knock.cget('wraplength'))>=190
        assert knock.winfo_width()<=ui.setup_message_host.winfo_width()
        radios=[w for w in all_widgets(ui.setup_message_host) if isinstance(w,ttk.Radiobutton) and w.cget('text') in ('Yes','No')]
        assert len(radios)==2
        assert ui.setup_workflow_button.cget('text')=='Continue'
        assert ui.setup_workflow_button.instate(['disabled'])
        assert all(w.winfo_rooty()>=knock.winfo_rooty() for w in radios)
    finally:
        if ui:ui.db.close()
        root.destroy()


def test_performance_history_shows_completed_v0_during_v1_and_v1_only_on_completion():
    root=tk.Tk();root.geometry('1280x900')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root;obj.project=SimpleNamespace(id=12);obj.active_version_no=1
        active={'version_no':1,'run_completed':0,'preview_ready':0}
        versions={0:{'version_no':0,'run_completed':1,'preview_ready':0},1:active}
        metrics={0:{'max_rpm':6100,'max_torque_lbft':379.4,'max_hp':440.0},
                 1:{'max_rpm':6300,'max_torque_lbft':401.0,'max_hp':470.0}}
        class DB:
            def get_version(self,pid,vn):return versions.get(vn)
            def get_version_performance(self,pid,vn):return metrics.get(vn)
        obj.db=DB()
        obj._active_version=lambda:active
        pane=tk.Frame(root);pane.pack(fill='x')
        obj._build_performance_summary(pane);root.update()
        assert list(obj.performance_cells)==[0,1,2,3]
        assert obj.performance_cells[0]['rpm'].get()=='6,100'
        assert obj.performance_cells[0]['torque'].get()=='379 lb-ft'
        assert obj.performance_cells[1]['hp'].get()=='—'
        assert obj.performance_cells[2]['rpm'].get()=='—'
        assert all('delta' not in k for k in obj.performance_vars)
        assert not any('Performance Summary' in w.cget('text')
            for w in all_widgets(pane) if isinstance(w,tk.Label))
        active['preview_ready']=1
        obj._refresh_performance_summary();root.update()
        assert obj.performance_cells[1]['hp'].get()=='470 hp'
        assert obj.performance_cells[1]['rpm'].get()=='6,300'
        assert obj.performance_cells[0]['rpm'].get()=='6,100'
    finally:root.destroy()


def test_later_versions_append_without_losing_v0():
    root=tk.Tk()
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root;obj.project=SimpleNamespace(id=7);obj.active_version_no=5
        obj._active_version=lambda:{'version_no':5}
        obj.db=SimpleNamespace(get_version=lambda *_:{'run_completed':0},get_version_performance=lambda *_:None)
        container=tk.Frame(root);container.pack(fill='both',expand=True)
        obj._build_performance_summary(container)
        assert list(obj.performance_cells)==[0,1,2,3,4,5]
        assert all(obj.performance_cells[v]['hp'].get()=='—' for v in range(6))
    finally:root.destroy()


def test_saved_v0_shown_in_v1_live_database_then_v1_after_review(tmp_path,monkeypatch):
    """The database's preview_ready flag, not final Apply, unlocks the V1 cell."""
    import hashlib
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    db=app.ReviewDatabase(tmp_path/'version_history.db')
    root=tk.Tk()
    try:
        uid=db.single_user_identity().id
        project=db.create_project_draft(uid,2023,'Dodge Challenger','',engine='5.7L Hemi')
        for vn in (0,1):
            log=tmp_path/f'v{vn}.hpl';log.write_bytes(f'LOG {vn}'.encode())
            digest=hashlib.sha256(log.read_bytes()).hexdigest()
            db.conn.execute('''INSERT INTO project_versions(
                project_id,version_no,log_local_path,log_sha256,run_completed,preview_ready)
                VALUES(?,?,?,?,?,?)''',
                (project.id,vn,str(log),digest,1 if vn==0 else 0,0))
            db.conn.execute('''INSERT INTO project_version_performance(
                project_id,version_no,log_sha256,max_rpm,max_torque_lbft,max_hp,
                rpm_samples,torque_samples,paired_samples) VALUES(?,?,?,?,?,?,?,?,?)''',
                (project.id,vn,digest,6000+vn*200,350+vn*15,400+vn*20,100,100,90))
        db.conn.commit()
        ui=app.ReviewApp.__new__(app.ReviewApp)
        ui.root=root;ui.db=db;ui.project=project;ui.active_version_no=1
        ui._active_version=lambda:db.get_version(project.id,1)
        pane=tk.Frame(root);pane.pack()
        ui._build_performance_summary(pane)
        assert ui.performance_cells[0]['hp'].get()=='400 hp'
        assert ui.performance_cells[1]['hp'].get()=='—'
        db.conn.execute('UPDATE project_versions SET preview_ready=1 WHERE project_id=? AND version_no=1',
                        (project.id,));db.conn.commit()
        ui._refresh_performance_summary()
        assert ui.performance_cells[1]['hp'].get()=='420 hp'
        assert ui.performance_cells[0]['hp'].get()=='400 hp'
    finally:
        db.close();root.destroy()
