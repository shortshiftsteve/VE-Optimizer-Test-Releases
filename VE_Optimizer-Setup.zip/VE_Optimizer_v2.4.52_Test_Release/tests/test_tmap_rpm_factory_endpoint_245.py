"""Factory-derived TMAP RPM endpoint handling; no automatic table rescaling.

This table is a throttle-based MAP *estimation multiplier*, not an SD VE
lookup.  Factory 2016 6.4L ends at 6016 RPM while Maximum RPM is 6600.
The PCM's actual beyond-endpoint lookup behavior is not established here.
"""
from pathlib import Path
from unittest.mock import patch

import pytest

import ve_optimizer_stage3 as stage3
import ve_optimizer_wideband as wb
from ve_optimizer_htt_codec import parse_htt

ROOT = Path('/mnt/data')
STOCK_57 = ROOT / '2023 Challengr Stock Tune Full Engine with Fuel System(3).htt'
STOCK_64 = ROOT / '2016 Dodge Challenger 6.4L Stock Tune.htt'
STOCK_62 = ROOT / 'Stock 6.2L Trackhawk (Hellcat).htt'
TUNED_62 = ROOT / 'Tuned 6.2L Trackhawk (Hellcat).htt'


def _log(*, rpm=6259.0, map_kpa=180.0, airflow=None):
    channels = {
        1: {'name': 'MAP - Hi-Res', 'parameter_id': 2106, 'unit': 'kPa'},
        2: {'name': 'Barometric Pressure', 'parameter_id': 2105, 'unit': 'kPa'},
        3: {'name': 'Engine RPM', 'parameter_id': 2135, 'unit': 'rpm'},
    }
    if airflow is not None:
        channels[4] = {'name': 'Total Airflow', 'parameter_id': 4000, 'unit': 'g/s'}
    frames = []
    for n in range(12):
        updates = {1: map_kpa, 2: 100.0, 3: rpm}
        if airflow is not None:
            updates[4] = airflow
        frames.append({'timestamp_ms': n * 50, 'updates': updates})
    return {'channels': channels, 'frames': frames}


@pytest.mark.skipif(not all(p.is_file() for p in (STOCK_57,STOCK_64,STOCK_62,TUNED_62)),
                    reason='Stock/tuned Hemi calibration fixtures unavailable')
def test_factory_tmap_table_rpm_breakpoints_are_not_engine_maximum_rpm():
    expectations = (
        (STOCK_57, 6000.0, 6016.0),
        (STOCK_64, 6600.0, 6016.0),
        (STOCK_62, 6400.0, 6208.0),
        (TUNED_62, 6500.0, 6208.0),
    )
    for tune, max_rpm, end in expectations:
        assert stage3.read_scalar(tune,wb.MAXIMUM_RPM_SCALAR) == max_rpm
        tmap = wb._parse_throttle_based_map_multiplier(tune)
        assert tmap['shape'] == (17,17)
        assert tmap['rpm_axis'][-1] == end


@pytest.mark.skipif(not STOCK_64.is_file(),reason='Stock 6.4L not available')
def test_stock_64_operating_above_tmap_axis_is_advisory_only():
    # Maximum RPM=6600; its unmodified factory TMAP table ends at 6016.
    with patch.object(wb,'decode_hpl',return_value=_log(rpm=6500, map_kpa=96)):
        pf = wb.airflow_map_preflight(Path('synthetic.hpl'),STOCK_64)
    assert pf['blocking'] is False
    assert pf['auto_fix_required'] is False
    tmap = pf['throttle_based_map_multiplier']
    assert tmap['rpm_axis_max'] == 6016
    assert tmap['observed_rpm_max'] == 6500
    assert tmap['rpm_covered'] is False
    assert tmap['rpm_endpoint_advisory'] is True
    assert tmap['airflow_covered'] is True
    assert pf['issues'] == []
    assert any('6500 RPM' in item and '6016 RPM' in item for item in pf['warnings'])


@pytest.mark.skipif(not TUNED_62.is_file(),reason='Tuned 6.2L not available')
def test_trackhawk_can_prepare_pratio_without_tmap_or_sensed_map_writeback(tmp_path):
    doc_before = parse_htt(TUNED_62.read_bytes()).by_key()
    with patch.object(wb,'decode_hpl',return_value=_log()):
        pf=wb.airflow_map_preflight(Path('synthetic.hpl'),TUNED_62)
        assert pf['blocking'] is False
        assert pf['pressure_ratio_max_change_required'] is True
        assert pf['throttle_based_map_multiplier']['rpm_endpoint_advisory']
        target=tmp_path/'airflow_prepared.htt'
        result=wb.prepare_airflow_strategy(Path('synthetic.hpl'),TUNED_62,target)
    assert result['changed'] is True
    assert result['scope_verified'] is True
    assert [item['key'] for item in result['changes']] == [wb.PRESSURE_RATIO_MAX_SCALAR]
    doc_after = parse_htt(target.read_bytes()).by_key()
    assert doc_after[2100].raw == doc_before[2100].raw
    assert doc_after[44395].raw == doc_before[44395].raw
    assert {k for k in doc_before if doc_before[k].raw != doc_after[k].raw} == {18912}


@pytest.mark.skipif(not TUNED_62.is_file(),reason='Tuned 6.2L not available')
def test_airflow_axis_excess_remains_blocking():
    with patch.object(wb,'decode_hpl',return_value=_log(airflow=1200)):
        pf=wb.airflow_map_preflight(Path('synthetic.hpl'),TUNED_62)
    assert pf['blocking'] is True
    assert pf['throttle_based_map_multiplier']['airflow_covered'] is False
    assert pf['throttle_based_map_multiplier']['rpm_endpoint_advisory'] is True
    assert any('1200.0 > 1152.0 g/s' in issue for issue in pf['issues'])
    assert not pf['automatic_change_allowed']
