"""Private 2.4.52 test Release identity and actual updater artifact contract."""
from pathlib import Path
import re
import ve_optimizer_license as licensing
import ve_optimizer_updates as updates
import ve_optimizer_revision9_review as app

ROOT = Path(__file__).resolve().parents[1]
ISS = (ROOT / 'installer' / 'VE_Optimizer_v2.4.52.iss').read_text(encoding='utf-8')
BATCH = (ROOT / 'installer' / 'Build_VE_Optimizer_v2.4.52_Installer.bat').read_text(encoding='utf-8')

def test_test_release_version_and_stage():
    assert (app.APP_VERSION, app.BUILD_ID, app.RELEASE_STAGE) == ('2.4.52', '2.4.52-Release', 'Release')
    assert (licensing.RELEASE_VERSION, licensing.RELEASE_STAGE) == ('2.4.52', 'Release')

def test_2451_to_2452_release_is_detected():
    assert updates.newer_than('2.4.52', '2.4.51')
    assert updates.newer_than('v2.4.52', 'v2.4.51')
    assert updates.filename_for_version('2.4.52') == 'VE Optimizer v2.4.52 Release Setup.exe'

def test_installer_version_name_and_upgrade_identity_preserved():
    assert '#define MyAppVersion "2.4.52"' in ISS
    assert 'OutputBaseFilename=VE Optimizer v2.4.52 Release Setup' in ISS
    assert 'UninstallDisplayName=VE Optimizer 2.4.52 Release' in ISS
    assert 'AppId={{6D4E4C12-8E21-4D2A-9A8C-0E0100000001}' in ISS
    assert r'DefaultDirName={localappdata}\Programs\Short Shift Garage' in ISS
    assert 'UsePreviousAppDir=yes' in ISS
    assert 'if not UninstallSilent then' in ISS
    assert 'SignTool=VEArtifactSign' in ISS and 'SignedUninstaller=yes' in ISS

def test_build_produces_exact_expected_signed_installer():
    assert r'set "SETUP=%~dp0Output\VE Optimizer v2.4.52 Release Setup.exe"' in BATCH
    assert 'call :SignFile "%APP_EXE%"' in BATCH
    assert 'call :VerifyFile "%SETUP%"' in BATCH

def test_public_updater_destination_not_silently_changed():
    assert updates.REPOSITORY == 'shortshiftsteve/Software-Distribution'
    assert updates.ASSET_NAME == 'VE-Optimizer-Setup.zip'
