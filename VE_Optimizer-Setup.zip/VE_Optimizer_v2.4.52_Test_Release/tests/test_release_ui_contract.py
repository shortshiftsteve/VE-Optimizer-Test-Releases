from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
app=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
iss=(ROOT/'installer'/'VE_Optimizer_v2.4.52.iss').read_text(encoding='utf-8')
help_text=(ROOT/'help'/'VE_Optimizer_Help_Version_2.txt').read_text(encoding='utf-8')

assert "LicenseAcceptCheck.Caption := '';" in iss
assert "LicenseAcceptLabel.WordWrap := True;" in iss
assert "InfoAcceptCheck.Caption := '';" in iss
assert "Refund Policy Version 1.2" in iss
assert "TrialInstalledUtc" in iss
# Approved 2.4.5 UI Development1 replaces old Setup buttons/photo with
# a traditional menu and dynamic message and processing panels.
assert "file_menu.add_command(label='New Project'" in app
assert "bar.add_cascade(label='File'" in app
assert "bar.add_cascade(label='Edit'" in app
assert "bar.add_cascade(label='Tools'" in app
assert "bar.add_cascade(label='Help'" in app
assert "def _set_setup_panel_message(" in app
assert "OPENING_EMISSIONS_WARNING" in app
assert "self.setup_workflow_button=ttk.Button(self.setup_primary_actions" in app
assert "self.vs_save=self.setup_workflow_button" in app
assert "text='CUSTOMER PHOTO'" not in app
assert "text='Change Photo...'" not in app
assert "text='Restore Default'" not in app
assert "MODEL_YEAR_OPTIONS=tuple(str(y) for y in range(2023,2009,-1))" in app
assert "MODEL_OPTIONS=('Dodge Challenger','Dodge Charger','Hellcat','Trackhawk')" in app
assert "ENGINE_OPTIONS=('5.7L Hemi','6.2L Supercharged Hemi','6.4L Hemi')" in app
assert "combo_cell(1,0,'Engine','engine',ENGINE_OPTIONS,not self.project)" in app
assert "asksaveasfilename" in app and "confirmoverwrite=True" in app
assert "mode in ('licensed','trial')" in app
assert "login_license_text=self.license.trial_expiration_label() if st['mode']=='trial' else self.license.mode_summary()" in app
assert "('review','Run/Review')" in app
assert "text='Processing Quality'" in app
assert "Live processing status and data-quality results" in app
assert "self._build_run_quality_panel(b,results_ready=results_ready)" in app
assert "text='  Apply full correction?'" in app
assert "text='  Reduce by half (%)'" in app
assert "self.surface_map=tk.StringVar(value='combined');self.surface_map_buttons={}" in app
assert '72-hour Trial' in help_text
print('RELEASE_UI_CONTRACT_PASS')
assert "('neural_network','Neural Network'),('speed_density','Speed Density')" in app
assert "self._set_surface_format(k)" in app
assert "Speed Density uses exact NN evaluation at the 17x17 workbook breakpoints; no 20x20 interpolation." in app
