"""Development 5: one visible Setup progress strip and fail-closed V0 -> V1 full tune lineage.

These tests do not exercise the VE solver or alter an installed Windows tune.
"""
from __future__ import annotations

import hashlib
import shutil
import threading
from pathlib import Path
from types import SimpleNamespace

import pytest
import tkinter as tk
from tkinter import ttk

import ve_optimizer_revision9_review as app
import ve_optimizer_htt_codec as codec


FULL=Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt')


def make_completed_original(tmp_path,monkeypatch,partial=False):
    if not FULL.exists():pytest.skip('External full-engine test tune is not available')
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'local'))
    db=app.ReviewDatabase(tmp_path/'projects.sqlite')
    uid=db.single_user_identity().id
    project=db.create_project_draft(uid,2023,'Dodge Challenger','',engine='5.7L Hemi')
    pid=project.id
    db.conn.execute('INSERT INTO project_setup(project_id,project_name) VALUES(?,?)',(pid,'Lineage Test'))
    vd=db.version_dir(pid,0)
    original=vd/'Baseline.htt';shutil.copy2(FULL,original)
    if partial:
        doc=codec.parse_htt(original.read_bytes())
        result=vd/'_Diagnostics'/'Partial_Export.htt';result.parent.mkdir(parents=True,exist_ok=True)
        result.write_bytes(codec.build_htt(doc,{doc.tables[0].key}))
    else:
        result=vd/'_Diagnostics'/'Full_Applied_Result.htt';result.parent.mkdir(parents=True,exist_ok=True)
        nn=app.s3.load_network(original)
        nn['Wo'][0]=float(nn['Wo'][0])+1/2048
        app.s3.write_candidate(original,result,nn)
        assert result.read_bytes()!=original.read_bytes()
        base=codec.parse_htt(original.read_bytes())
        updated=codec.parse_htt(result.read_bytes())
        assert set(base.by_key())==set(updated.by_key())
    db.conn.execute('''INSERT INTO project_versions
        (project_id,version_no,baseline_htt_path,baseline_htt_sha256,
         result_htt_path,result_htt_sha256,run_completed)
        VALUES(?,?,?,?,?,?,1)''',(
        pid,0,str(original),app.s5.sha256_file(original),str(result),app.s5.sha256_file(result)))
    db.conn.commit()
    return db,uid,project,original,result


def test_v1_contains_all_original_records_with_v0_applied_values(tmp_path,monkeypatch):
    db,uid,project,original,result=make_completed_original(tmp_path,monkeypatch)
    try:
        successor=db.create_successor_after_build(project.id,0,uid)
        inherited=Path(successor['baseline_htt_path'])
        assert inherited.name=='Baseline.htt'
        assert inherited.is_file() and inherited.read_bytes()==result.read_bytes()
        assert inherited.read_bytes()!=original.read_bytes()
        assert successor['baseline_htt_sha256']==app.s5.sha256_file(result)
        assert codec.parse_htt(inherited.read_bytes()).by_key().keys()==codec.parse_htt(original.read_bytes()).by_key().keys()
        assert app.s3.load_network(inherited)['Wo']==app.s3.load_network(result)['Wo']
        assert db.get_version(project.id,0)['baseline_htt_sha256']==app.s5.sha256_file(original)
    finally:db.close()


def test_v1_rejects_partial_customer_export_as_source(tmp_path,monkeypatch):
    db,uid,project,original,partial=make_completed_original(tmp_path,monkeypatch,partial=True)
    try:
        with pytest.raises(ValueError,match='full original Tune File'):
            db.create_successor_after_build(project.id,0,uid)
        assert db.get_version(project.id,1) is None
        assert original.is_file()
    finally:db.close()


def test_v1_existing_baseline_missing_restored_only_from_same_verified_full_result(tmp_path,monkeypatch):
    db,uid,project,original,result=make_completed_original(tmp_path,monkeypatch)
    try:
        successor=db.create_successor_after_build(project.id,0,uid)
        inherited=Path(successor['baseline_htt_path']);inherited.unlink()
        assert not inherited.exists()
        restored=db.create_successor_after_build(project.id,0,uid)
        assert Path(restored['baseline_htt_path']).read_bytes()==result.read_bytes()
        with inherited.open('ab') as f:f.write(b'CORRUPTED')
        with pytest.raises(ValueError,match='failed integrity'):
            db.create_successor_after_build(project.id,0,uid)
        assert inherited.read_bytes().endswith(b'CORRUPTED')  # fail closed, no overwrite
    finally:db.close()


def test_log_validation_worker_uses_verified_v1_path_without_sqlite_or_tk(monkeypatch,tmp_path):
    db,uid,project,original,result=make_completed_original(tmp_path,monkeypatch)
    root=tk.Tk();root.geometry('1200x850')
    ui=None
    try:
        successor=db.create_successor_after_build(project.id,0,uid)
        log=tmp_path/'new_version_log.hpl';log.write_bytes(b'fixture only')
        monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
        ui=app.ReviewApp(root,Path(db.path),Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity()
        ui.project=ui.db.get_project(project.id)
        ui.active_version_no=1
        ui.shell();ui.goto('setup');root.update()
        assert ui._setup_candidate_tune_path()==Path(successor['baseline_htt_path'])
        ui.vs_vars['log'].set(str(log))
        ui.vs_log_staged=True
        ui._show_setup_vehicle_verification()
        ui._confirm_setup_vehicle()
        worker_names=[]
        def mock_analyze(_path,airflow_model):
            worker_names.append(threading.current_thread().name)
            assert airflow_model=='neural_network'
            return {'passed':True,'airflow_model':'neural_network'}
        monkeypatch.setattr(app,'validate_hp_tuners_log',lambda _p:(True,''))
        monkeypatch.setattr(app.wideband,'detect_airflow_model',lambda _p:'neural_network')
        monkeypatch.setattr(app.logcheck,'analyze_log',mock_analyze)
        monkeypatch.setattr(app.logcheck,'summary_text',lambda _r:'PASS')
        monkeypatch.setattr(app.wideband_integration,'qualify_log_for_tune',lambda *_a,**_kw:{'adaptive_ready':True,'wideband_ready':False})
        monkeypatch.setattr(ui,'_prompt_na_closed_loop_only',lambda report,tune,log,decision:decision(report,False))
        def run_in_thread(worker,done):
            box=[]
            thread=threading.Thread(target=lambda:box.append(worker()),name='LogWorker')
            thread.start();thread.join(timeout=6)
            assert not thread.is_alive(), 'Worker unexpectedly blocked on the Tk main thread'
            done(box[0])
        monkeypatch.setattr(ui,'_run_background_task',run_in_thread)
        auto_build_calls=[]
        # The workflow now starts project preparation automatically after a
        # qualified log; isolate the V1 worker test from its fixture-only HPL.
        monkeypatch.setattr(ui,'_save_vehicle_setup',lambda:auto_build_calls.append('build'))
        ui._submit_selected_log();root.update()
        assert auto_build_calls==['build']
        assert worker_names==['LogWorker']
        assert ui.vs_log_valid is True
        assert ui.setup_panel_message['heading']=='LOG FILE READY'
        assert ui._setup_candidate_tune_path()==Path(successor['baseline_htt_path'])
    finally:
        if ui:ui.db.close()
        root.destroy()
        db.close()


def test_only_one_review_progress_strip_in_three_panel_setup(monkeypatch,tmp_path):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1250x900')
    ui=None
    try:
        ui=app.ReviewApp(root,tmp_path/'ui.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        ui.project=SimpleNamespace(id=8)
        ui.state=lambda:{'state':'READY_TO_RUN'}
        ui.correction_preflight_cache={'choices':[{'id':'adaptive','enabled':True}]}
        ui.correction_source_selection='adaptive'
        ui.correction_preflight_context='context'
        ui._correction_context=lambda:'context'
        ui._application_payload=lambda:None
        ui._build_run_quality_panel=lambda parent,results_ready=False:tk.Label(parent,text='Processing Quality').pack()
        ui._setup_lower_mode='review';ui._render_setup_lower_view()
        ui._set_setup_activity('Fit Neural Network','Process targets',percent=36,step=4,total=5,busy=True)
        root.update()
        assert ui.run_progressbar is None
        def visible_progressbars(widget):
            found=[]
            for child in widget.winfo_children():
                if isinstance(child,ttk.Progressbar) and child.winfo_viewable():found.append(child)
                found+=visible_progressbars(child)
            return found
        bars=visible_progressbars(ui.setup_message_host)
        assert bars==[ui.setup_activity_bar]  # now one upper-right progress bar
        assert not visible_progressbars(ui.setup_processing_viewport.master)
        assert ui.setup_activity_state['percent']==36
    finally:
        if ui:ui.db.close()
        root.destroy()
