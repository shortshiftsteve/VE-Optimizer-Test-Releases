"""User-approved A/B checkpoint separation and complete HPL channel inventory.

Only log qualification/presentation is changing. Existing correction calculations,
solvers, data decoders and exported tune-file logic remain unchanged.
"""
from pathlib import Path
from unittest.mock import patch
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_logcheck as lc
import ve_optimizer_wideband as wb


def simulated_report(tmp_path, model):
    # The physical HPL supplies these eight configured channels. Other minimum
    # channel definitions still appear in the display as No Data entries.
    names = ['Offset','Engine RPM','Short Term Fuel Trim Bank 1',
             'Short Term Fuel Trim Bank 2','WB Lambda','Optional Empty',
             'Fuel System #1 Status (SAE)','Engine Coolant Temp (SAE)']
    units = ['s','rpm','%','%','lambda','', '', '°F']
    meta = lc.Metadata(list(map(str,range(len(names)))),names,units,1)
    frames = [
        (0.0,['0','1800','0.5','-1.2','0.94','','CL - Normal','185']),
        (1.0,['1','1810','0.8','-1.0','0.95','','CL - Normal','187']),
        (2.0,['2','1830','0.7','-0.7','0.93','','OL - Drive','188']),
    ]
    path=tmp_path/'sample.hpl'
    path.write_bytes(b'fake HPL; mock reader')
    with patch.object(lc,'read_metadata',return_value=meta), \
         patch.object(lc,'_pressure_stats',return_value=[]), \
         patch.object(lc,'iter_data',side_effect=lambda *_:iter(frames)):
        return lc.analyze_log(path,airflow_model=model)


def test_independent_method_checkpoints_and_minimum_lists():
    assert lc.METHOD_A_CHECKPOINT is not lc.METHOD_B_CHECKPOINT
    assert lc.METHOD_A_CHANNELS is not lc.METHOD_B_CHANNELS
    assert [x.key for x in lc.METHOD_A_CHANNELS]==[x.key for x in lc.METHOD_B_CHANNELS]
    assert len(lc.METHOD_A_CHANNELS)==len(lc.METHOD_B_CHANNELS)==len(lc.SPECS)
    assert all(a is not b for a,b in zip(lc.METHOD_A_CHANNELS,lc.METHOD_B_CHANNELS))
    assert lc.METHOD_A_MANDATORY_KEYS != lc.METHOD_B_MANDATORY_KEYS
    assert lc.METHOD_B_MANDATORY_KEYS == {'rpm','ect','actual_torque','fa_enrichment','fa_power_enrichment','map','baro','stft_b1','stft_b2','knock_long','knock_short','knock_total'}
    assert lc.METHOD_CHECKPOINTS['neural_network']['channels'] is lc.METHOD_A_CHANNELS
    assert lc.METHOD_CHECKPOINTS['speed_density']['channels'] is lc.METHOD_B_CHANNELS


def test_method_b_all_required_channels_must_be_present(tmp_path):
    report=simulated_report(tmp_path,'speed_density')
    assert report['passed'] is False  # other newly required Method B channels are missing
    assert report['checkpoint']=='Method B'
    assert report['optimization_method']=='Speed Density Optimization'
    logical={q['key']:q for q in report['signals']}
    assert {x['key'] for x in report['signals'] if x['required']}==lc.METHOD_B_MANDATORY_KEYS
    assert logical['ltft_b1']['required'] is False
    assert logical['fuel_air_stoich']['required'] is False
    assert logical['intake_cam']['required'] is False
    channels={q['name']:q for q in report['logged_channels']}
    assert len([q for q in report['logged_channels'] if q['index'] is not None])==7
    assert channels['Short Term Fuel Trim Bank 1']['status']=='Pass'
    assert channels['Short Term Fuel Trim Bank 2']['status']=='Pass'
    assert channels['Engine RPM']['status']=='Pass'
    assert channels['WB Lambda']['status']=='Available'
    assert channels['Fuel System #1 Status (SAE)']['status']=='Available'
    assert channels['Optional Empty']['status']=='No Data'
    assert channels['Optional Empty']['updates']==0
    assert channels['Long Term Fuel Trim Bank 1 (SAE)']['status']=='No Data'
    assert channels['WB Lambda']['updates']==3


def test_method_b_fails_if_required_stft_bank_has_no_data(tmp_path):
    report=simulated_report(tmp_path,'speed_density')
    # Remove just Bank 2 data from the same raw channel rows.
    meta=lc.Metadata(['0','1','2'],['Offset','Short Term Fuel Trim Bank 1','Short Term Fuel Trim Bank 2'],['s','%','%'],1)
    frames=[(0,['0','1','']),(1,['1','1','']),(2,['2','1',''])]
    path=tmp_path/'only_bank1.hpl';path.write_bytes(b'fixture')
    with patch.object(lc,'read_metadata',return_value=meta),\
         patch.object(lc,'_pressure_stats',return_value=[]),\
         patch.object(lc,'iter_data',side_effect=lambda *_:iter(frames)):
        missing=lc.analyze_log(path,airflow_model='speed_density')
    assert not missing['passed']
    assert any('Bank 2' in x for x in missing['blocking'])
    assert next(x for x in missing['logged_channels'] if x['name']=='Short Term Fuel Trim Bank 2')['status']=='No Data'


def test_method_a_strict_qualification_unchanged(tmp_path):
    report=simulated_report(tmp_path,'neural_network')
    assert report['checkpoint']=='Method A'
    assert not report['passed']
    assert len([x for x in report['signals'] if x['required']])==18
    assert any('Intake Cam' in text for text in report['blocking'])
    channels={q['name']:q for q in report['logged_channels']}
    assert channels['Intake Cam Center Pos']['status']=='No Data'
    assert channels['WB Lambda']['status']=='Available'


def test_separate_channel_resolution_lists_can_diverge_without_cross_talk(tmp_path):
    original_A=lc.METHOD_A_CHECKPOINT['channels']
    original_B=lc.METHOD_B_CHECKPOINT['channels']
    from dataclasses import replace
    try:
        spec=replace(original_B[0],patterns=(r'OTHER_TEST_RPM',))
        lc.METHOD_B_CHECKPOINT['channels']=(spec,*original_B[1:])
        # These are two distinct checkpoints with their own matching patterns.
        meta=lc.Metadata(['0','1'],['Offset','Engine RPM'],['s','rpm'],1)
        with patch.object(lc,'_pressure_stats',return_value=[]):
            a=lc.resolve_indices(tmp_path/'t.hpl',meta,'neural_network')
            b=lc.resolve_indices(tmp_path/'t.hpl',meta,'speed_density')
        assert a['rpm']==[1]
        assert b['rpm']==[]
    finally:
        lc.METHOD_A_CHECKPOINT['channels']=original_A
        lc.METHOD_B_CHECKPOINT['channels']=original_B


def test_stft_and_wideband_remain_independent_sources_for_both_methods():
    def adaptive_for_model(*args,airflow_model='neural_network',**kwargs):
        return {'valid':True,'mode':'stft_only' if airflow_model=='speed_density' else 'ltft_plus_stft'}
    with patch.object(wb,'decode_hpl',return_value={'channels':{},'frames':[]}),\
         patch.object(wb,'_adaptive_trim_status',side_effect=adaptive_for_model),\
         patch.object(wb,'_narrowband_status',return_value={'valid':False}),\
         patch.object(wb,'_wideband_data_status',return_value={'valid':True}),\
         patch.object(wb,'_maf_status',return_value={'valid':False}):
        a=wb.inspect_correction_sources(Path('f.hpl'),airflow_model='neural_network')
        b=wb.inspect_correction_sources(Path('f.hpl'),airflow_model='speed_density')
    assert {x['id'] for x in a['choices']}=={'adaptive','narrowband','wideband'}
    assert {x['id'] for x in b['choices']}=={'adaptive','narrowband','wideband'}
    assert next(x['label'] for x in b['choices'] if x['id']=='wideband')=='Wideband O2'
    assert next(x['label'] for x in b['choices'] if x['id']=='adaptive')=='Short Term Fuel Trims (STFT)'
    assert next(x['label'] for x in a['choices'] if x['id']=='adaptive')=='Adaptive Fuel Trims (LTFT + STFT)'


def test_application_displays_all_channels_in_required_colors():
    ui=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    assert "report.get('logged_channels',[])" in ui
    assert "status_text in ('Pass','Available')" in ui
    assert "'#000000' if status_text=='No Data'" in ui
    assert "input_row(1,'Tune File (.htt)'" in ui
    assert "input_row(2,'Log File (.hpl):'" in ui
