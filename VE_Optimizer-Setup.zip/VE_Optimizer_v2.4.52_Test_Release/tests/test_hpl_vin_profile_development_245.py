"""Optional MET/VIN parser: native log frames and qualification are untouched."""
import struct
import zlib
from pathlib import Path
import hpl_decoder_v1_0_0 as hpl


VIN='1C4RJFN9XJC000000'  # synthetic VIN for unit tests
TAG=b'\x01\x30\x0b\x11'


def fixture_hpl(vins=(VIN,),corrupt=False,met=True):
    data=bytearray(39)
    data[:6]=b'HPT \x60\x09'
    data[10:14]=b'SYNC'
    data[20:22]=b'SC'
    data+=struct.pack('<H',1)
    data+=struct.pack('<HHHdd',0,12,10 << 8,1.0,0.0)
    data+=bytes([10])+b'Engine RPM'+bytes([3])+b'rpm'
    if met:
        raw=b'\x06\x00\x01\x00'+b''.join(TAG+v.encode() for v in vins)
        encoder=zlib.compressobj(wbits=-15)
        compressed=encoder.compress(raw)+encoder.flush()
        declared=len(raw)+(5 if corrupt else 0)
        data+=(b'MET\x00'+b'\x01\x00\x00\x00'+struct.pack('>I',len(compressed))+
               b'\x01\x00\x00'+struct.pack('<I',declared)+compressed)
    data+=b'SS\x00\x00SYNC'+b'\0'*5+b'CDG\0'+TAG+VIN.encode()
    return bytes(data)


def test_extract_native_metadata_vin(tmp_path):
    p=tmp_path/'test.hpl';p.write_bytes(fixture_hpl())
    assert hpl.extract_hpl_vin(p)==VIN


def test_optional_missing_metadata_does_not_scan_frame_bytes(tmp_path):
    p=tmp_path/'test.hpl';p.write_bytes(fixture_hpl(met=False))
    assert hpl.extract_hpl_vin(p)==''


def test_corrupt_or_ambiguous_metadata_is_ignored(tmp_path):
    p=tmp_path/'test.hpl'
    p.write_bytes(fixture_hpl(corrupt=True))
    assert hpl.extract_hpl_vin(p)==''
    p.write_bytes(fixture_hpl(vins=(VIN,'2C3CDZBT6PH000000')))
    assert hpl.extract_hpl_vin(p)==''


def test_real_project_hpl_samples_when_available():
    for name,prefix in [('re-save  DYNO.hpl','1C4RJFN9'),('fresh log_latest_VCM Ver.hpl','2C3CDZBT')]:
        p=Path('/mnt/data')/name
        if p.exists():
            vin=hpl.extract_hpl_vin(p)
            assert len(vin)==17
            assert vin.startswith(prefix)
