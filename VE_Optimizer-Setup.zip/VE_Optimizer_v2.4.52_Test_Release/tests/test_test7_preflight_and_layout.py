"""Test 7: STFT data visibility, preflight safety and Setup alignment."""
from pathlib import Path
import inspect
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import ve_optimizer_revision9_review as app
import ve_optimizer_wideband as wb


def test_real_mag_log_records_sae_stft_while_missing_fuel_flow():
    log=Path('/mnt/data/5.7L with a Maggi Shortened.hpl')
    if not log.is_file():
        import pytest
        pytest.skip('External Maggi log not bundled')
    from hpl_decoder_v1_0_0 import decode_hpl
    result=wb._adaptive_trim_status(decode_hpl(log),'speed_density')
    assert result['stft_data_available'] is True
    assert result['stft_updates']=={'bank1':419,'bank2':419}
    assert result['stft_channels']=={
        'bank1':'Short Term Fuel Trim Bank 1 (SAE)',
        'bank2':'Short Term Fuel Trim Bank 2 (SAE)'}
    assert result['valid'] is True
    assert result['missing'] == []
    assert result['accepted_events_bank1'] > 0
    assert result['accepted_events_bank2'] > 0


def test_confirmed_boosted_pe_change_is_prepared_automatically():
    tune=Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt')
    log=Path('/mnt/data/5.7L with a Maggi Shortened.hpl')
    if not tune.is_file() or not log.is_file():
        import pytest
        pytest.skip('External Maggi pair not bundled')
    report=wb.build_correction_preflight(log,tune,hardware_review_approved=True)
    assert report['hardware_review_pending'] is False
    assert report['pe_calibration_pending'] is False
    assert report['pe_preparation_required'] is True
    assert report['sources']['wideband']['processor_ready'] is True
    choices={x['id']:x for x in report['choices']}
    assert choices['wideband']['enabled']
    assert choices['adaptive']['enabled']


def test_run_review_guard_refuses_stale_or_unapproved_preflight():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.correction_source_selection='wideband'
    obj.correction_preflight_cache={
        'hardware_review_pending':True,
        'pe_calibration_pending':False,
        'choices':[{'id':'wideband','enabled':True}]
    }
    # Obsolete hardware-confirmation flag must not disqualify valid VE data.
    assert obj._review_source_block_reason() is None
    obj.correction_preflight_cache['hardware_review_pending']=False
    obj.correction_preflight_cache['pe_preparation_required']=True
    assert obj._review_source_block_reason() is None
    obj.correction_preflight_cache['choices'][0]['enabled']=False
    obj.correction_preflight_cache['choices'][0]['reason']='source not qualified'
    assert obj._review_source_block_reason()=='source not qualified'
    obj.correction_preflight_cache['choices'][0]['enabled']=True
    assert obj._review_source_block_reason() is None


def test_confirmation_guards_run_and_navigation():
    review_source=inspect.getsource(app.ReviewApp.page_review)
    start_source=inspect.getsource(app.ReviewApp.start_review)
    assert 'self._review_source_block_reason()' in review_source
    assert 'self._review_source_block_reason()' in start_source


def test_requested_submit_build_view_layout():
    setup=inspect.getsource(app.ReviewApp.page_setup)
    gating=inspect.getsource(app.ReviewApp._vehicle_form_update)
    lower=inspect.getsource(app.ReviewApp._render_setup_lower_view)
    assert "text='Submit'" in setup
    assert "text='Build'" not in setup  # label changes dynamically
    assert 'self.setup_workflow_button=ttk.Button' in setup
    assert "self.setup_workflow_button.pack(side='left')" in setup
    assert "label='Build'" in inspect.getsource(app.ReviewApp._update_setup_workflow_action)
    assert "text='View'" in lower
    assert "self.vs_log_details_btn.pack(side='left')" not in lower
    assert 'self.vs_log_submit_button.pack_forget()' not in gating
    assert 'self.vs_save.pack(' not in gating  # fixed button never re-packed
    assert "self.vs_log_details_btn.pack(side='left')" not in lower
    assert "text='Validation'" not in setup
    assert "self.vs_save.pack(" not in setup
    assert "self.vs_log_details_btn.pack(" not in setup

