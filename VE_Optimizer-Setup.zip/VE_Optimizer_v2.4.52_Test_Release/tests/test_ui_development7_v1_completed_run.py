"""Development 7: completed V1 review must not be misclassified as missing setup.

Only Run command state handling is under test.  No candidate or calibration is
changed by these tests, and no optimization worker is allowed to execute.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from types import SimpleNamespace

import pytest
import tkinter as tk

import ve_optimizer_revision9_review as app


@pytest.fixture
def ui(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path/'local'))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1250x850')
    inst=app.ReviewApp(root,tmp_path/'ui.sqlite',Path(app.__file__).resolve().parent/'a')
    inst.user=inst.db.single_user_identity()
    inst.shell();inst.goto('setup');root.update()
    try:
        yield root,inst
    finally:
        try:inst.db.close()
        finally:root.destroy()


def forbid_modal(monkeypatch):
    def unexpected(*args,**kwargs):
        pytest.fail(f'Unexpected modal dialog after a completed V1 review: {args}')
    monkeypatch.setattr(app.messagebox,'showinfo',unexpected)
    monkeypatch.setattr(app.messagebox,'showwarning',unexpected)


def test_v1_completed_review_ignores_late_run_with_results_still_visible(ui,monkeypatch):
    _root,inst=ui
    inst.project=SimpleNamespace(id=41)
    inst.active_version_no=1
    inst._setup_lower_mode='review';inst.current_page='setup'
    inst.setup_panel_message={'heading':'REVIEW COMPLETE','body':'Results are ready.','align':'left','actions':()}
    monkeypatch.setattr(inst,'state',lambda:{'state':'READY_TO_APPLY'})
    monkeypatch.setattr(inst,'_application_payload',lambda:{'method_id':app.processing.METHOD_ID})
    monkeypatch.setattr(inst,'_active_version',lambda:{'version_no':1})
    monkeypatch.setattr(inst.db,'version_setup_complete',lambda *_:pytest.fail('Completed result should not be requalified'))
    monkeypatch.setattr(inst,'goto',lambda *_a,**_k:pytest.fail('Completed Results pane should not be reset'))
    forbid_modal(monkeypatch)
    inst.start_review()
    assert inst.setup_panel_message['heading']=='REVIEW COMPLETE'
    assert inst.running is False


def test_queued_run_after_completed_v1_navigates_to_results_without_new_worker(ui,monkeypatch):
    _root,inst=ui
    inst.project=SimpleNamespace(id=41)
    inst.active_version_no=1
    inst._setup_lower_mode='preflight';inst.current_page='setup'
    inst.correction_source_selection='wideband'
    inst.correction_preflight_cache={'choices':[{'id':'wideband','enabled':True}]}
    monkeypatch.setattr(inst,'state',lambda:{'state':'READY_TO_APPLY'})
    monkeypatch.setattr(inst,'_application_payload',lambda:{'method_id':app.processing.METHOD_ID})
    forbid_modal(monkeypatch)
    monkeypatch.setattr(inst,'_review_source_block_reason',lambda:pytest.fail('Do not re-evaluate old preflight'))
    opened=[]
    monkeypatch.setattr(inst,'goto',lambda page,**_kw:opened.append(page))
    inst._run_selected_correction()
    assert opened==['review']
    assert inst.running is False


def test_running_v1_ignores_duplicate_callback_before_db_state_check(ui,monkeypatch):
    _root,inst=ui
    inst.project=SimpleNamespace(id=41)
    inst.active_version_no=1
    inst.running=True
    monkeypatch.setattr(inst,'state',lambda:pytest.fail('No state queries during an active worker'))
    forbid_modal(monkeypatch)
    inst.start_review()
    assert inst.running is True


def test_genuinely_unqualified_v1_stays_blocked_with_message_in_right_panel(ui,tmp_path,monkeypatch):
    _root,inst=ui
    _create_stored_v1_candidate(ui,tmp_path)
    inst.db.conn.execute("""UPDATE project_versions SET log_local_path='', preview_ready=0,
        preview_json_path='' WHERE project_id=? AND version_no=1""",(inst.project.id,))
    inst.db.conn.commit()
    assert inst.state()['state']=='SETUP_REQUIRED'
    forbid_modal(monkeypatch)
    inst.start_review()
    assert inst.setup_panel_message['heading']=='SETUP REQUIRED'
    assert 'qualified Log File' in inst.setup_panel_message['body']
    assert inst.running is False


def _create_stored_v1_candidate(ui,tmp_path):
    """Real SQLite V0+V1 fixture; uses package tune bytes, no tuning work."""
    _root,inst=ui
    db=inst.db
    p=db.create_project_draft(inst.user.id,2023,'Dodge Challenger','',engine='5.7L Hemi')
    db.conn.execute('INSERT INTO project_setup(project_id,project_name) VALUES(?,?)',(p.id,'V1 Review Guard Test'))
    model_path=Path(app.__file__).resolve().parent/'a'/'stock_nn.htt'
    assert model_path.is_file()
    for vn in (0,1):
        vdir=db.version_dir(p.id,vn)
        tune=vdir/'Baseline.htt';shutil.copy2(model_path,tune)
        tune_hash=app.s5.sha256_file(tune)
        hpl=vdir/'Log.hpl';hpl.write_bytes(f'stored HPL for V{vn} UI-only fixture'.encode())
        log_hash=app.s5.sha256_file(hpl)
        preview=vdir/'_Application_Preview'/'Candidate.json'
        preview.parent.mkdir(exist_ok=True)
        preview.write_text(json.dumps({'method_id':app.processing.METHOD_ID}),encoding='utf-8')
        db.conn.execute('''INSERT INTO project_versions
            (project_id,version_no,baseline_htt_path,baseline_htt_sha256,
             log_local_path,log_sha256,preview_ready,preview_json_path)
            VALUES(?,?,?,?,?,?,?,?)''',
            (p.id,vn,str(tune),tune_hash,str(hpl),log_hash,int(vn==1),str(preview) if vn==1 else ''))
    db.conn.commit()
    inst.project=db.get_project(p.id)
    inst.active_version_no=1
    return inst


def test_real_saved_v1_ready_to_apply_run_does_not_raise_false_setup(ui,tmp_path,monkeypatch):
    _root,inst=ui
    _create_stored_v1_candidate(ui,tmp_path)
    assert inst.state()['state']=='READY_TO_APPLY'
    assert inst._application_payload() is not None
    assert inst.db.version_setup_complete(inst.project.id,1)
    forbid_modal(monkeypatch)
    inst._setup_lower_mode='review'
    inst.goto('review');_root.update()
    assert inst.setup_panel_message['heading']=='REVIEW COMPLETE'
    inst.start_review()
    assert inst.setup_panel_message['heading']=='REVIEW COMPLETE'
    assert inst.active_version_no==1
    assert inst.db.get_version(inst.project.id,1)['preview_ready']==1
    assert inst.db.get_version(inst.project.id,1)['run_completed']==0
