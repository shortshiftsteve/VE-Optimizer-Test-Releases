import math
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

import ve_optimizer_logcheck as logcheck
import ve_optimizer_processing as processing


class InternationalUnitConversionTests(unittest.TestCase):
    def assertClose(self, actual, expected, places=9):
        self.assertAlmostEqual(actual, expected, places=places)

    def test_coolant_temperature_units_to_fahrenheit(self):
        for unit in ('°C','C','deg C','Celsius','Centigrade'):
            self.assertClose(processing._convert('ect',unit,100.0),212.0)
        for unit in ('°F','F','deg F','Fahrenheit'):
            self.assertClose(processing._convert('ect',unit,212.0),212.0)
        self.assertClose(processing._convert('ect','K',373.15),212.0)
        self.assertClose(processing._convert('ect','Rankine',671.67),212.0)

    def test_torque_units_to_lbft(self):
        for unit in ('lb-ft','lb ft','ft-lb','lbf-ft'):
            self.assertClose(processing._convert('actual_torque',unit,10.0),10.0)
        self.assertClose(processing._convert('actual_torque','N m',13.5581794833),10.0)
        self.assertClose(processing._convert('actual_torque','in-lb',120.0),10.0)

    def test_pressure_units_to_kpa(self):
        self.assertClose(processing._convert('map','kPa',100.0),100.0)
        self.assertClose(processing._convert('map','Pa',100000.0),100.0)
        self.assertClose(processing._convert('map','bar',1.0),100.0)
        self.assertClose(processing._convert('map','hPa',1000.0),100.0)
        self.assertClose(processing._convert('map','MPa',0.1),100.0)
        self.assertClose(processing._convert('map','atm',100.0/101.325),100.0)

    def test_fuel_mass_flow_units_to_lbh(self):
        self.assertClose(processing._convert('fuel_flow','lb/h',10.0),10.0)
        self.assertClose(processing._convert('fuel_flow','g/s',1.0),7.936641438)
        self.assertClose(processing._convert('fuel_flow','kg/h',1.0),2.20462262185)
        self.assertClose(processing._convert('fuel_flow','lb/min',1.0),60.0)
        self.assertClose(processing._convert('fuel_flow','mg/s',1000.0),7.936641438)

    def test_engine_speed_units_to_rpm(self):
        for unit in ('rpm','rev/min','r/min','1/min'):
            self.assertClose(processing._convert('rpm',unit,3000.0),3000.0)
        self.assertClose(processing._convert('rpm','Hz',50.0),3000.0)

    def test_fuel_trim_units_to_percent(self):
        self.assertClose(processing._convert('ltft_b1','%',5.0),5.0)
        self.assertClose(processing._convert('stft_b2','percent',5.0),5.0)
        self.assertClose(processing._convert('ltft_b2','ratio',0.05),5.0)

    def test_cam_angle_units_to_degrees(self):
        self.assertClose(processing._convert('intake_cam','°',120.0),120.0)
        self.assertClose(processing._convert('exhaust_cam','deg',120.0),120.0)
        self.assertClose(processing._convert('exhaust_cam','rad',math.pi),180.0)

    def test_unsupported_physical_units_fail_explicitly(self):
        with self.assertRaisesRegex(ValueError,'coolant-temperature'):
            processing._convert('ect','widgets',100.0)
        with self.assertRaisesRegex(ValueError,'torque'):
            processing._convert('actual_torque','widgets',10.0)
        with self.assertRaisesRegex(ValueError,'fuel-flow'):
            processing._convert('fuel_flow','L/h',1.0)

    def test_fuel_flow_is_required_log_signal(self):
        spec=logcheck.SPEC_BY_KEY['fuel_flow']
        self.assertTrue(spec.required)
        self.assertEqual(spec.recommended_ms,200)


    def test_bundled_metric_hpl_end_to_end(self):
        log=ROOT/'tests/fixtures/fresh_log.hpl'
        report=logcheck.analyze_log(log)
        # Reference fixture was recorded before knock-retard channels became
        # mandatory. Its stored samples remain a valid decoder/unit test, but
        # it may no longer qualify as a complete log under the new policy.
        self.assertFalse(report['passed'])
        self.assertEqual(set(report['blocking']), {
            'Knock Retard Long Term: missing',
            'Knock Retard Short Term: missing',
            'Total Knock Retard: missing',
        })
        units={s['key']:s['units'] for s in report['signals']}
        self.assertEqual(units['ect'],['°C'])
        self.assertEqual(units['actual_torque'],['N m'])
        self.assertEqual(units['fuel_flow'],['g/s'])
        rows,meta=processing.prepare_samples(log)
        self.assertEqual(len(rows),14055)
        self.assertEqual(meta['accepted_bank_samples'],[7029,7026])
        first=rows[0]
        self.assertClose(first['Coolant_F'],204.8)
        self.assertClose(first['Torque_lbft'],1.8070272657311668)
        self.assertClose(first['FuelFlow_lbh'],4.249926811689453)

    def test_all_unit_sensitive_signals_have_canonical_targets(self):
        for key in logcheck.UNIT_SENSITIVE_KEYS:
            self.assertIsNotNone(logcheck.canonical_unit(key),key)


if __name__=='__main__':
    unittest.main(verbosity=2)
