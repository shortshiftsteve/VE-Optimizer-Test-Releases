"""Review trial does not consume the matching future Release trial."""
from datetime import datetime,timedelta,timezone
import json
import ve_optimizer_license as licensing


def test_review_trial_and_release_trial_are_distinct(tmp_path,monkeypatch):
    monkeypatch.setenv('VE_OPTIMIZER_LICENSE_STATE_DIR', str(tmp_path))
    t=datetime(2026,10,13,17,tzinfo=timezone.utc)
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.5')
    monkeypatch.setattr(licensing,'RELEASE_STAGE','Review')
    first=licensing.LicenseManager(now=t)
    assert first.status()['mode']=='trial'
    assert first.status()['trial_started_at']==licensing.iso(t)
    assert licensing.LicenseManager(now=t+timedelta(hours=74)).status()['mode']=='demo'
    monkeypatch.setattr(licensing,'RELEASE_STAGE','Release')
    future=licensing.LicenseManager(now=t+timedelta(days=5))
    assert future.status()['mode']=='trial'
    assert future.status()['trial_started_at']==licensing.iso(t+timedelta(days=5))
    monkeypatch.setattr(licensing,'RELEASE_STAGE','Review')
    assert licensing.LicenseManager(now=t+timedelta(days=5)).status()['mode']=='demo'
    state=json.loads((tmp_path/licensing.TRIAL_FILE).read_text())
    assert set(state['release_starts'])=={'2.4.5-Review','2.4.5'}


def test_review_same_version_reinstall_keeps_earliest_start(tmp_path,monkeypatch):
    monkeypatch.setenv('VE_OPTIMIZER_LICENSE_STATE_DIR',str(tmp_path))
    monkeypatch.setattr(licensing,'RELEASE_VERSION','2.4.5')
    monkeypatch.setattr(licensing,'RELEASE_STAGE','Review')
    t=datetime(2026,10,13,17,tzinfo=timezone.utc)
    assert licensing.LicenseManager(now=t).status()['mode']=='trial'
    after=licensing.LicenseManager(now=t+timedelta(hours=50))
    assert after.status()['trial_started_at']==licensing.iso(t)
