"""Development 4 GUI acceptance for the three approved changes.

Focus: fixed scroll-independent stage progress, scoped View action, and
Run/Results action migration into the replaceable right-side message panel.
"""
import inspect
import os
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
from tkinter import ttk

import pytest
import ve_optimizer_revision9_review as app


def find_buttons(parent,text):
    hits=[]
    def walk(node):
        for child in node.winfo_children():
            if isinstance(child,ttk.Button) and child.cget('text')==text and child.winfo_manager():
                hits.append(child)
            walk(child)
    walk(parent)
    return hits


@pytest.fixture
def live_ui(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk();root.geometry('1200x860')
    ui=app.ReviewApp(root,tmp_path/'live.db',Path(app.__file__).resolve().parent/'a')
    ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
    try:yield root,ui
    finally:
        try:
            if ui.setup_activity_bar is not None:
                ui.setup_activity_bar.stop()
            ui.db.close()
        finally:root.destroy()


def test_log_validation_has_fixed_nonflashing_progress(live_ui):
    root,ui=live_ui
    assert ui.setup_activity_host.winfo_manager()==''  # opening WARNING has priority until work starts
    ui._show_working_overlay('Log File validation','Checking required channels')
    root.update()
    assert ui._working_overlay is None
    assert ui.setup_activity_host.winfo_viewable()
    assert ui.setup_activity_state['busy'] is True
    assert ui.setup_activity_state['percent'] is None
    assert str(ui.setup_activity_bar.cget('mode'))=='indeterminate'
    assert ui.setup_activity_host.winfo_rooty() < ui.setup_processing_viewport.winfo_rooty()
    ui._hide_working_overlay();root.update()
    assert ui.setup_activity_state['busy'] is False
    assert ui.setup_activity_status_var.get().startswith('FINISHED')
    assert str(ui.setup_activity_bar.cget('mode'))=='indeterminate'  # no invented %


def test_step_progress_and_completion_are_visible_above_scroller(live_ui):
    root,ui=live_ui
    ui.running=True
    ui._set_progress(36,'Fit Neural Network','Fitting VE targets: 2,000 evaluations.')
    root.update()
    assert ui.setup_activity_state['percent']==36
    assert ui.setup_activity_state['step']==4
    assert ui.setup_activity_status_var.get()=='IN PROGRESS  •  STEP 4 OF 5  •  36%'
    assert str(ui.setup_activity_bar.cget('mode'))=='determinate'
    assert int(float(ui.setup_activity_bar.cget('value')))==36
    assert ui.setup_activity_host.winfo_viewable()
    ui._set_setup_activity('Processing complete','Candidate verified.',percent=100,step=5,total=5,busy=False)
    root.update()
    assert ui.setup_activity_status_var.get()=='FINISHED  •  STEP 5 OF 5  •  100%'
    assert int(float(ui.setup_activity_bar.cget('value')))==100
    assert ui.setup_activity_host.winfo_rooty() < ui.setup_processing_viewport.winfo_rooty()


def test_view_button_only_during_qualification_not_preflight_or_review(live_ui):
    root,ui=live_ui
    ui.vs_log_report={'passed':True};ui.vs_log_valid=True
    ui._setup_lower_mode='status';ui._render_setup_lower_view();root.update()
    assert not find_buttons(ui.setup_processing_host,'View')
    assert not find_buttons(ui.setup_primary_actions,'VIEW')  # passing log
    ui.project=SimpleNamespace(id=10)
    ui.page_preflight=lambda host:tk.Label(host,text='Correction Preflight').pack()
    ui._setup_lower_mode='preflight';ui._render_setup_lower_view();root.update()
    assert not find_buttons(ui.setup_processing_host,'View')
    ui._setup_lower_mode='review';ui.state=lambda:{'state':'READY_TO_APPLY'}
    ui._application_payload=lambda:{'method_id':'test_method','levels':{}}
    ui.correction_preflight_cache={}
    ui.correction_preflight_context='context'
    ui._correction_context=lambda:'context'
    ui._build_run_quality_panel=lambda host,results_ready=False:tk.Label(host,text='Quality details').pack()
    ui._render_setup_lower_view();root.update()
    assert not find_buttons(ui.setup_processing_host,'View')


def test_results_navigation_and_heading_are_in_right_panel(live_ui):
    root,ui=live_ui
    ui.project=SimpleNamespace(id=10)
    ui.state=lambda:{'state':'READY_TO_APPLY'}
    ui._application_payload=lambda:{'method_id':'test_method','levels':{}}
    ui.correction_preflight_cache={}
    ui.correction_preflight_context='context'
    ui._correction_context=lambda:'context'
    ui._build_run_quality_panel=lambda host,results_ready=False:tk.Label(host,text='Processing Quality').pack()
    ui._setup_lower_mode='review';ui._render_setup_lower_view();root.update()
    assert ui.setup_panel_message['heading']=='REVIEW COMPLETE'
    assert len(find_buttons(ui.setup_primary_actions,'Results'))==1
    assert not find_buttons(ui.setup_message_host,'Results')
    assert not find_buttons(ui.setup_processing_host,'Results')
    assert not find_buttons(ui.setup_processing_host,'View')
    assert not find_buttons(ui.setup_processing_host,'Run')
    assert ui.run_btn.winfo_viewable()
    events=[];ui.goto=lambda page:events.append(page)
    ui.run_btn.invoke()
    assert events==['results']


def test_uncompleted_review_run_button_also_belongs_to_right_panel(live_ui):
    root,ui=live_ui
    ui.project=SimpleNamespace(id=10)
    ui.state=lambda:{'state':'READY_TO_RUN'}
    ui.correction_preflight_cache={'choices':[{'id':'adaptive','enabled':True}]}
    ui.correction_source_selection='adaptive'
    ui.correction_preflight_context='context'
    ui._correction_context=lambda:'context'
    ui._application_payload=lambda:None
    ui._build_run_quality_panel=lambda host,results_ready=False:tk.Label(host,text='Processing Quality').pack()
    ui._setup_lower_mode='review';ui._render_setup_lower_view();root.update()
    assert ui.setup_panel_message['heading']=='RUN / REVIEW'
    assert len(find_buttons(ui.setup_primary_actions,'Continue'))==1
    assert not find_buttons(ui.setup_message_host,'Run')
    assert not find_buttons(ui.setup_processing_host,'Run')
    assert not find_buttons(ui.setup_processing_host,'View')


def test_no_flashing_working_text_or_review_controls_in_lower_source():
    src=inspect.getsource(app.ReviewApp._start_working_blink)
    assert 'self.root.after' not in src
    lower=inspect.getsource(app.ReviewApp.page_review)
    assert "text='Run / Review'" not in lower
    assert 'self._set_setup_panel_message(heading,body,requires_action=False)' in lower
    assert 'self.run_btn=self.setup_workflow_button' in lower
