"""v2.4.1: separate raw MAP>Baro evidence from qualifying boost review.

Tests use synthetic logged values, not a claim about the customer's .hpl.
"""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

import pytest
import ve_optimizer_boost_review as review
import ve_optimizer_wideband as wb
import ve_optimizer_revision9_review as app


def logged_pressure_ratios(pratios):
    return {
        'channels':{
            1:{'name':'MAP - Hi-Res','unit':'kPa'},
            2:{'name':'Barometric Pressure','unit':'kPa'},
        },
        'frames':[
            {'timestamp_ms':n*50,'updates':{1:100*ratio,2:100.0}}
            for n,ratio in enumerate(pratios)
        ],
    }


def inspect_ratios(tmp_path,ratios):
    log=tmp_path/'synthetic.hpl';log.write_bytes(b'SYNTHETIC')
    with patch.object(review,'decode_hpl',return_value=logged_pressure_ratios(ratios)), \
         patch.object(review,'_tune_characteristics',return_value={}):
        return review.inspect('unused.htt',log,'neural_network')


@pytest.mark.parametrize(('ratios','expected_above','expected_review'), [
    ([0.90]*20,0,False),
    ([1.0003]*20,0,False),
    ([1.0599]*20,0,False),
    ([1.06]*20,0,False),
    ([1.0601]*4,4,False),
    ([1.0601]*5,5,True),
    ([1.06]*50+[1.25]*5,5,True),
])
def test_hardware_review_requires_five_ratios_above_1_06(tmp_path,ratios,expected_above,expected_review):
    result=inspect_ratios(tmp_path,ratios)
    assert result['map_source']['boost_pratio_hits']==expected_above
    assert result['boost_review_required'] is expected_review
    assert result['boost_review_pratio_threshold']==1.06
    assert result['boost_review_min_samples']==5
    assert result['pressure_exceeds_baro'] is (max(ratios)>1.0)


def fake_preflight(pressure_exceeds_baro,boost_review_required,approved=False):
    source={'choices':[{'id':'adaptive','label':'Adaptive','enabled':True}],
            'adaptive':{'valid':True},'wideband':{'valid':False}}
    engine={'pressure_exceeds_baro':pressure_exceeds_baro,
            'boost_review_required':boost_review_required}
    with patch.object(wb,'detect_configuration',return_value={'airflow_model':'speed_density'}), \
         patch.object(wb,'inspect_correction_sources',return_value=source), \
         patch.object(wb,'airflow_map_preflight',return_value={'blocking':False}), \
         patch.object(wb,'speed_density_axis_preflight',return_value={'needs_rescale':False,'blocking':False,'message':'Mock calibrated axes valid'}), \
         patch.object(wb,'pe_strategy_preflight',return_value={'blocking':False}), \
         patch.object(review,'inspect',return_value=engine):
        return wb.build_correction_preflight(Path('not_a_real.hpl'),Path('not_a_real.htt'),
                                             hardware_review_approved=approved)


def test_raw_slight_map_over_baro_does_not_disable_sources():
    result=fake_preflight(True,False)
    assert result['hardware_review_pending'] is False
    assert result['choices'][0]['enabled'] is True


def test_qualifying_boost_does_not_require_physical_sensor_confirmation():
    pending=fake_preflight(True,True)
    assert pending['hardware_review_pending'] is False
    assert pending['choices'][0]['enabled'] is True
    approved=fake_preflight(True,True,approved=True)
    assert approved['choices'][0]['enabled'] is True


def test_setup_prompt_checks_qualifying_boost_not_raw_positive_map():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    actions=[]
    obj._correction_context=lambda:('test','context')
    obj.boost_review_approval_context=None
    obj._review_map_and_pe=lambda:actions.append('map review')
    obj._show_correction_source_message=lambda:actions.append('normal processing')
    obj.correction_preflight_cache={
        'hardware_review_pending':False,
        'engine_review':{'pressure_exceeds_baro':True,'boost_review_required':False},
    }
    obj._show_preflight_prompt()
    assert actions==['normal processing']
    obj.correction_preflight_cache={
        'hardware_review_pending':True,
        'engine_review':{'pressure_exceeds_baro':True,'boost_review_required':True},
    }
    obj._show_preflight_prompt()
    assert actions==['normal processing','normal processing']


def test_na_missing_knock_exception_keeps_strict_raw_map_rule():
    # Keep distinct NA safety policy unchanged by the new hardware-review gate.
    with patch.object(review,'inspect',return_value={
        'map_source':{'compared':100},
        'pressure_exceeds_baro':True,
        'boost_review_required':False,
    }):
        qualifies,_=review.na_closed_loop_evidence('tune.htt','log.hpl','neural_network')
    assert qualifies is False
