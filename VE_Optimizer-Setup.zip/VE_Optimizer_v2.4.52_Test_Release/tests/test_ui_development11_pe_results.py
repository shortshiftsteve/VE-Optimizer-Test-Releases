"""Build-button placement and removal of PE Results controls."""
import inspect
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
import pytest
import ve_optimizer_revision9_review as app


def test_build_only_in_apply_toolbar_and_existing_gate_unchanged():
    apply_src=inspect.getsource(app.ReviewApp._build_application_section)
    viewer_src=inspect.getsource(app.ReviewApp._build_surface_viewer)
    assert "text='Apply Changes'" in apply_src
    assert "text='Build It'" in apply_src
    assert apply_src.index("text='Build It'")>apply_src.index("text='Apply Changes'")
    assert "text='Build It'" not in viewer_src
    assert "('pe','PE')" not in viewer_src
    assert app.build_it_application_gate(None,50)[0] is False
    assert app.build_it_application_gate({'run_completed':0},50)[0] is False

def test_build_button_is_gray_until_apply_verified(tmp_path):
    import json
    from tkinter import ttk
    root=tk.Tk();root.geometry('750x400')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root
        obj.user=SimpleNamespace(role='admin')
        obj.application_selected_percent=50
        obj.build_it_btn=ttk.Button(root,text='Build It');obj.build_it_btn.pack()
        version={'run_completed':0}
        obj._active_version=lambda:version
        obj._update_build_it_gate()
        assert 'disabled' in obj.build_it_btn.state()
        stored=tmp_path/'metrics.json'
        stored.write_text(json.dumps({'method_id':app.wideband_integration.WB_SD_METHOD,
                                      'verification_passed':True,'scope_verified':True}))
        version.update(run_completed=1,metrics_json=str(stored),application_percent=50)
        obj._update_build_it_gate()
        assert 'disabled' not in obj.build_it_btn.state()
        # Another preview percentage is not an applied selection.
        obj.application_selected_percent=25
        obj._update_build_it_gate()
        assert 'disabled' in obj.build_it_btn.state()
    finally:
        root.destroy()
