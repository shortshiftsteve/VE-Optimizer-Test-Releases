"""UI Development 2: six approved workflow changes; no solver fixtures required."""
from pathlib import Path
from types import SimpleNamespace
import json, tempfile, os, inspect, hashlib
import tkinter as tk
import pytest
import ve_optimizer_revision9_review as app


def test_submit_to_build_uses_the_same_upper_left_location():
    setup=inspect.getsource(app.ReviewApp.page_setup)
    update=inspect.getsource(app.ReviewApp._vehicle_form_update)
    assert "self.setup_primary_actions=tk.Frame(left" in setup
    assert 'self.setup_workflow_button=ttk.Button(self.setup_primary_actions' in setup
    assert 'self.vs_save=self.setup_workflow_button' in setup
    assert 'self.vs_log_submit_button=self.setup_workflow_button' in setup
    assert 'self._update_setup_workflow_action()' in update
    assert "self.vs_log_details_btn.pack(side='left')" not in inspect.getsource(app.ReviewApp._render_setup_lower_view)
    assert "qualified_override=False" in inspect.getsource(app.ReviewApp._view_failed_log_diagnostics)


def test_submit_keeps_detail_view_on_demand_and_knock_panel_decision():
    submit=inspect.getsource(app.ReviewApp._submit_selected_log)
    assert "_show_log_validation(report,require_decision=True" not in submit
    assert "self._prompt_na_closed_loop_only(report,tune,Path(p),decision)" in submit
    assert "self._render_setup_lower_view()" in submit
    assert 'self.vs_log_validation_action=None' in submit
    assert "messagebox.askyesno" not in inspect.getsource(app.ReviewApp._prompt_na_closed_loop_only)


def test_lower_panel_is_scrollable_and_preflight_stays_in_message_panel():
    setup=inspect.getsource(app.ReviewApp.page_setup)
    assert "self.setup_processing_scroll=tk.Canvas" in setup
    assert "scrollbar.configure(command=self.setup_processing_scroll.yview)" in setup
    assert "self.setup_processing_window=self.setup_processing_scroll.create_window" in setup
    lower=inspect.getsource(app.ReviewApp._render_setup_lower_view)
    assert 'self.page_preflight(host)' not in lower  # obsolete white lower panel
    assert 'self._build_run_quality_panel(host)' in lower
    assert 'self.root.after(40,self._run_correction_preflight)' in lower
    assert 'self.page_review(host)' in lower
    assert "self._setup_lower_mode=requested" in inspect.getsource(app.ReviewApp.goto)
    assert "self._set_setup_activity(title,detail,busy=True)" in inspect.getsource(app.ReviewApp._show_working_overlay)


def test_build_creates_hidden_temp_project_until_apply_names_it():
    build=inspect.getsource(app.ReviewApp._save_vehicle_setup)
    apply=inspect.getsource(app.ReviewApp._apply_selected_changes)
    assert 'db.create_staged_initial_project(' in build
    assert 'simpledialog.askstring' not in build
    assert 'proposed_name=self._request_staged_project_name()' in apply
    assert 'db.finalize_staged_project(pid,uid,proposed_name)' in apply
    assert 'db.is_staged_project' in inspect.getsource(app.ReviewApp._request_staged_project_name)


def test_staged_project_is_hidden_then_renamed_preserving_paths(monkeypatch,tmp_path):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    db=app.ReviewDatabase(tmp_path/'stage.db')
    try:
        user=db.single_user_identity();uid=user.id
        pr=db.create_project_draft(uid,2023,'Dodge Challenger','',engine='5.7L Hemi')
        pid=pr.id
        temp_name=f'VE_Temporary_{pid}'
        db.conn.execute('UPDATE projects SET name=? WHERE id=?',(temp_name,pid))
        db.conn.execute('INSERT INTO project_setup(project_id,project_name) VALUES(?,?)',(pid,temp_name))
        root=db.project_root(pid)
        v0=root/'V0';v0.mkdir(parents=True,exist_ok=True)
        htt=v0/'Baseline.htt';htt.write_bytes(b'Unchanged demo file bytes')
        preview=v0/'Candidate_Preview.json'
        payload={'baseline_htt':str(htt),'log_sha256':'abc',
                 'levels':{'50':{'candidate_htt':str(htt)}},'external':str(tmp_path/'external.hpl')}
        preview.write_text(json.dumps(payload))
        db.conn.execute('INSERT INTO project_versions(project_id,version_no,baseline_htt_path,preview_json_path,log_source_path) VALUES(?,?,?,?,?)',
                        (pid,0,str(htt),str(preview),str(tmp_path/'external.hpl')))
        db.conn.execute('UPDATE projects SET output_dir=? WHERE id=?',(str(root),pid))
        db.conn.execute('INSERT INTO staged_projects(project_id,created_by) VALUES(?,?)',(pid,uid))
        db.conn.commit()
        assert db.is_staged_project(pid)
        assert not any(int(r['id'])==pid for r in db.list_user_projects(uid))
        initial_hash=hashlib.sha256(htt.read_bytes()).hexdigest()
        promoted=db.finalize_staged_project(pid,uid,'Accepted Road Test')
        assert not db.is_staged_project(pid)
        assert any(int(r['id'])==pid for r in db.list_user_projects(uid))
        assert db.project_display_name(pid)=='Accepted Road Test'
        new_root=Path(promoted.output_dir)
        assert new_root.is_dir() and not root.exists()
        assert new_root.name=='Accepted Road Test'
        version=db.get_version(pid,0)
        assert Path(version['baseline_htt_path']).is_file()
        assert hashlib.sha256(Path(version['baseline_htt_path']).read_bytes()).hexdigest()==initial_hash
        assert Path(version['preview_json_path']).is_file()
        changed=json.loads(Path(version['preview_json_path']).read_text())
        assert changed['baseline_htt']==version['baseline_htt_path']
        assert changed['levels']['50']['candidate_htt']==version['baseline_htt_path']
        assert changed['external']==str(tmp_path/'external.hpl')
        assert version['log_source_path']==str(tmp_path/'external.hpl')
    finally:db.close()


def test_live_three_panel_and_lower_processing_only(tmp_path,monkeypatch):
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk()
    try:
        root.geometry('1200x800')
        base=Path(app.__file__).resolve().parent
        ui=app.ReviewApp(root,tmp_path/'live.db',base/'a')
        ui.user=ui.db.single_user_identity();ui.shell();ui.goto('setup');root.update()
        assert ui.setup_panel_message['heading']=='WARNING'
        assert ui.setup_workflow_button.winfo_manager()=='pack'
        assert ui.setup_workflow_button.instate(['disabled'])
        assert ui.vs_save is ui.vs_log_submit_button
        assert not ui.vs_log_details_btn.winfo_manager()
        assert not any(widget.winfo_manager() for widget in ui.setup_processing_host.winfo_children())
        ui._show_working_overlay();root.update()
        assert ui._working_overlay is None
        assert ui.setup_activity_host.winfo_exists()
        assert ui.setup_activity_state['busy']
        assert ui.setup_message_host.winfo_viewable()
        ui._hide_working_overlay()
        ui.vs_log_report={'passed':True,'signals':[]}
        ui.vs_log_valid=True;ui.vs_log_staged=False
        ui.vs_vars['htt'].set(str(base/'a'/'stock_nn.htt'))
        ui.vs_vars['log'].set('sample.hpl')
        ui._setup_verified_signature=ui._setup_vehicle_signature()
        ui._render_setup_lower_view();ui._vehicle_form_update();root.update()
        assert ui.setup_workflow_button.cget('text')=='Build'
        assert ui.vs_save is ui.vs_log_submit_button
        assert not ui.vs_log_details_btn.winfo_manager()
        assert ui.vs_log_details_btn.cget('text')=='View'
    finally:root.destroy()


def test_inline_preflight_render_handles_missing_sensor_specs(tmp_path, monkeypatch):
    """Missing nullable MAP hardware metrics must render as No Data."""
    monkeypatch.setenv('LOCALAPPDATA',str(tmp_path))
    monkeypatch.setenv('VE_OPTIMIZER_SKIP_SPLASH','1')
    root=tk.Tk()
    try:
        ui=app.ReviewApp(root,tmp_path/'live.db',Path(app.__file__).resolve().parent/'a')
        ui.user=ui.db.single_user_identity()
        ui.project=SimpleNamespace(id=87)
        ui._active_version=lambda:{'version_no':0,'log_sha256':'abc'}
        ui.db.version_setup_complete=lambda pid,vn:True
        ui._correction_context=lambda:'fixture-context'
        ui.correction_preflight_context='fixture-context'
        ui.correction_preflight_cache={
            'configuration':{'airflow_model':'neural_network','pe_table_axis':'Aircharge'},
            'choices':[],
            'sources':{},
            'airflow_map_preflight':{
                'observed_map_max_kpa':None,'observed_pratio_max':None,
                'logged_baro_median_kpa':None,'sea_level_reference_kpa':None,
                'map1':{'sensor_class':None,'full_scale_kpa':None,'sea_level_boost_capacity_psi':None},
                'map2':{'sensor_class':None,'full_scale_kpa':None,'sea_level_boost_capacity_psi':None},
                'throttle_based_map_multiplier':{'rpm_axis_max':None,'observed_rpm_max':None,
                   'airflow_axis_max_gps':None,'observed_airflow_max_gps':None},
            },
        }
        host=tk.Frame(root);host.pack(fill='both',expand=True)
        ui.page_preflight(host)
        root.update_idletasks()
        labels=[]
        def gather(widget):
            if isinstance(widget,tk.Label):labels.append(str(widget.cget('text')))
            for child in widget.winfo_children():gather(child)
        gather(host)
        assert any('No Data' in item and 'MAP1' in item for item in labels)
    finally:root.destroy()
