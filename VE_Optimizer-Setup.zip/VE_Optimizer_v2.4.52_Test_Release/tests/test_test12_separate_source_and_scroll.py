"""Test 12: STFT and Wideband are independent choices; preflight scrolls to source controls."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import inspect
import tkinter as tk

import ve_optimizer_revision9_review as app
import ve_optimizer_wideband as wb


def test_source_inspection_never_offers_combined():
    adaptive={'valid':True,'mode':'stft_only'}
    with patch.object(wb,'decode_hpl',return_value={'channels':{},'frames':[]}), \
         patch.object(wb,'_adaptive_trim_status',return_value=adaptive), \
         patch.object(wb,'_narrowband_status',return_value={'valid':False}), \
         patch.object(wb,'_wideband_data_status',return_value={'valid':True}), \
         patch.object(wb,'_maf_status',return_value={'valid':False}):
        for model in ('speed_density','neural_network'):
            report=wb.inspect_correction_sources(Path('sample.hpl'),airflow_model=model)
            allowed={q['id'] for q in report['choices'] if q['enabled']}
            assert allowed=={'adaptive','wideband'}
            assert 'combined' not in {q['id'] for q in report['choices']}


def test_previous_combined_selection_blocked_even_when_cached():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.correction_source_selection='combined'
    obj.correction_preflight_cache={'choices':[{'id':'combined','enabled':True}],
                                    'hardware_review_pending':False}
    assert 'separately' in obj._review_source_block_reason()


def test_invalid_source_selection_does_not_change_prior_choice():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.correction_source_selection='adaptive'
    obj.correction_rescale_approved=False
    obj.current_page='preflight'
    obj.goto=lambda *a,**k: (_ for _ in ()).throw(AssertionError('not allowed'))
    obj._select_correction_source('combined')
    assert obj.correction_source_selection=='adaptive'


def test_preflight_scroll_reveals_bottom_controls():
    root=tk.Tk();root.geometry('1050x650')
    try:
        obj=app.ReviewApp.__new__(app.ReviewApp)
        obj.root=root;obj.current_page='preflight'
        obj.correction_preflight_cache={'choices':[{'id':'adaptive','enabled':True}]}
        obj.page_canvas=tk.Canvas(root,height=500)
        obj.page_canvas.pack(fill='both',expand=True)
        long_frame=tk.Frame(obj.page_canvas)
        window=obj.page_canvas.create_window((0,0),window=long_frame,anchor='nw')
        obj.page_canvas.bind('<Configure>',lambda e:obj.page_canvas.itemconfigure(window,width=e.width))
        long_frame.bind('<Configure>',lambda e:obj.page_canvas.configure(scrollregion=obj.page_canvas.bbox('all')))
        for index in range(65):
            tk.Label(long_frame,text=f'Preflight check {index}').pack()
        tk.Label(long_frame,text='CORRECTION SOURCE').pack()
        tk.Label(long_frame,text='STFT or Wideband O2').pack()
        root.update()
        assert obj.page_canvas.yview()[0] < .01
        app.ReviewApp._scroll_preflight_to_options(obj)
        root.update()
        assert obj.page_canvas.yview()[1] >= .999
        # Reproduce goto() resetting the page to the top after page_preflight()
        # returns, then verify the delayed callback reveals the options.
        obj.page_canvas.yview_moveto(0.0)
        root.after(50,lambda:app.ReviewApp._scroll_preflight_to_options(obj))
        obj.page_canvas.update_idletasks()
        obj.page_canvas.yview_moveto(0.0)
        root.after(90,root.quit)
        root.mainloop()
        assert obj.page_canvas.yview()[1] >= .999
        obj.current_page='review'
        obj.page_canvas.yview_moveto(0.0)
        app.ReviewApp._scroll_preflight_to_options(obj)
        assert obj.page_canvas.yview()[0] < .01
    finally:
        root.destroy()


def test_completed_preflight_keeps_source_choices_out_of_lower_panel():
    page=inspect.getsource(app.ReviewApp.page_preflight)
    assert 'self.root.after(50,self._scroll_preflight_to_options)' not in page
    assert "text='CORRECTION SOURCE'" not in page
    assert "text='Review'" not in page
    choice=inspect.getsource(app.ReviewApp._show_correction_source_message)
    assert "if len(valid)==2:" in choice
    assert "for sid in valid:" in choice
    assert "('adaptive','wideband','combined')" not in choice
    assert "text='Run'" not in choice  # no inline Run button
    workflow=inspect.getsource(app.ReviewApp._update_setup_workflow_action)
    assert "label='Continue'" in workflow  # same fixed Vehicle Info button
