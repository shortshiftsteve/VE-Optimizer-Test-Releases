"""Development 6: targeted regression for user-identified ECM 2100.

VCM Editor reported Sensed MAP Enable as parameter 2100.  Record 44433
was previously misidentified, and VCM Editor showed it as MDS Enable.
No test here substitutes for the user-side 2100-only VCM Editor preview.
"""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ve_optimizer_htt_codec import parse_htt, build_htt
import ve_optimizer_wideband as wb
import ve_optimizer_stage3 as stage3

MAGGI = Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt')
OLD = Path('/mnt/data/2023 Dodge Challenger 5.7L Engine and fuel system tune file.htt')


def switched(doc, key, value):
    val = value.encode('ascii')
    rows = []
    for rec in doc.switches:
        rows.append(replace(rec, raw=rec.raw[:4] + stage3._encode_uleb128(len(val)) + val) if rec.key == key else rec)
    return build_htt(replace(doc, switches=tuple(rows)))


def synthetic_boosted_log(pressure=130.0):
    channels = {
        1: {'name': 'MAP - Hi-Res', 'parameter_id': 1, 'unit': 'kPa'},
        2: {'name': wb.BARO_NAME, 'parameter_id': 2, 'unit': 'kPa'},
        3: {'name': wb.RPM_NAME, 'parameter_id': 3, 'unit': 'rpm'},
    }
    frames = [{'timestamp_ms': i * 10, 'updates': {1: pressure, 2: 100., 3: 2200.}} for i in range(12)]
    return {'channels': channels, 'frames': frames}


class SensedMap2100IdentityTests(unittest.TestCase):
    def setUp(self):
        if not (MAGGI.is_file() and OLD.is_file()):
            self.skipTest('User-provided full-engine reference templates unavailable')

    def test_2100_is_user_identified_switch_and_44433_remains_quarantined(self):
        self.assertEqual(wb.SENSED_MAP_ENABLE_SWITCH, 2100)
        self.assertEqual(wb.QUARANTINED_SWITCH_ID, 44433)
        maggi = parse_htt(MAGGI.read_bytes())
        old = parse_htt(OLD.read_bytes())
        self.assertEqual((maggi.by_key()[2100].kind, maggi.by_key()[2100].raw[5:]), ('switch', b'Enabled'))
        self.assertEqual((old.by_key()[2100].kind, old.by_key()[2100].raw[5:]), ('switch', b'Disabled'))
        self.assertEqual(maggi.by_key()[44433].raw[5:], b'Disabled')

    def test_2100_only_probe_has_no_other_records(self):
        doc = parse_htt(MAGGI.read_bytes())
        blob = build_htt(doc, {2100})
        parsed = parse_htt(blob)
        self.assertEqual((len(parsed.switches), len(parsed.scalars), len(parsed.tables)), (1, 0, 0))
        self.assertEqual(parsed.switches[0].raw, doc.by_key()[2100].raw)
        self.assertNotIn(44433, parsed.by_key())

    def test_mds_switch_change_rejected_and_existing_export_preserved(self):
        doc = parse_htt(MAGGI.read_bytes())
        with tempfile.TemporaryDirectory() as tmp:
            cand=Path(tmp)/'candidate.htt';out=Path(tmp)/'import.htt'
            cand.write_bytes(switched(doc, 44433, 'Enabled'))
            out.write_bytes(b'DO NOT OVERWRITE')
            with self.assertRaisesRegex(ValueError, 'MDS Enable'):
                wb.export_speed_density_changed_tables(MAGGI,cand,out)
            self.assertEqual(out.read_bytes(), b'DO NOT OVERWRITE')

    def test_boosted_existing_maggi_enabled_requires_no_switch_change(self):
        with patch.object(wb, 'decode_hpl', return_value=synthetic_boosted_log(200.)):
            pre=wb.airflow_map_preflight(Path('synthetic.hpl'),MAGGI)
        self.assertTrue(pre['boosted_detected'])
        self.assertEqual(pre['sensed_map_enable'],'Enabled')
        self.assertFalse(pre['sensed_map_enable_change_required'])
        self.assertFalse(pre['blocking'])
        self.assertFalse(any('unverified' in x for x in pre['issues']))

    def test_boosted_old_disabled_remains_disabled(self):
        with patch.object(wb, 'decode_hpl', return_value=synthetic_boosted_log()):
            pre=wb.airflow_map_preflight(Path('synthetic.hpl'),OLD)
        self.assertTrue(pre['boosted_detected'])
        self.assertEqual(pre['sensed_map_enable'],'Disabled')
        self.assertEqual(pre['recommended_sensed_map_enable'],'Disabled')
        self.assertFalse(pre['sensed_map_enable_change_required'])
        self.assertFalse(any('enable Sensed MAP' in x for x in pre['auto_actions']))

    def test_boosted_preparation_preserves_sensed_map_exactly(self):
        with tempfile.TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'candidate.htt'
            with patch.object(wb,'decode_hpl',return_value=synthetic_boosted_log()):
                pre=wb.airflow_map_preflight(Path('synthetic.hpl'),OLD)
                if pre['blocking']:
                    with self.assertRaises(ValueError):
                        wb.prepare_airflow_strategy(Path('synthetic.hpl'),OLD,candidate)
                    self.assertFalse(candidate.exists())
                else:
                    result=wb.prepare_airflow_strategy(Path('synthetic.hpl'),OLD,candidate)
                    self.assertTrue(result['scope_verified'])
                    self.assertEqual(wb.read_switch(candidate,2100),'Disabled')
                    self.assertEqual(parse_htt(candidate.read_bytes()).by_key()[2100].raw,
                                     parse_htt(OLD.read_bytes()).by_key()[2100].raw)
                    self.assertNotIn('Sensed MAP Enable',
                                     [row['parameter'] for row in result['changes']])

    def test_2100_enabled_to_disabled_is_not_permitted_and_preserves_output(self):
        maggi=parse_htt(MAGGI.read_bytes())
        with tempfile.TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'candidate.htt';out=Path(tmp)/'import.htt'
            candidate.write_bytes(switched(maggi, 2100, 'Disabled'))
            out.write_bytes(b'PRESERVE ME')
            with self.assertRaisesRegex(ValueError, 'must remain unchanged'):
                wb.export_speed_density_changed_tables(MAGGI,candidate,out)
            self.assertEqual(out.read_bytes(), b'PRESERVE ME')

    def test_2100_unknown_payload_rejected(self):
        old=parse_htt(OLD.read_bytes())
        with tempfile.TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'candidate.htt';out=Path(tmp)/'import.htt'
            candidate.write_bytes(switched(old, 2100, 'Maybe'))
            with self.assertRaisesRegex(ValueError, 'must remain unchanged'):
                wb.export_speed_density_changed_tables(OLD,candidate,out)
            self.assertFalse(out.exists())

if __name__=='__main__':
    unittest.main(verbosity=2)
