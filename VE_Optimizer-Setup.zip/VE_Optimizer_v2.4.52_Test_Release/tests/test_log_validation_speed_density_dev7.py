"""Regression tests for calibration-dependent HPL log validation.

Keep accepted correction filters untouched; this tests only channel/density
qualification and the visible requirements for NN-disabled vehicles.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import ve_optimizer_logcheck as lc
import ve_optimizer_revision9_review as app
import ve_optimizer_wideband as wb
import ve_optimizer_wideband_integration as integration


def fake_log_report(tmp_path, model, *, ect_label='Engine Coolant Temp (SAE)', missing=(),
                    count=1201, ect_count=None, ect_spread_count=None, fuel_count=None):
    """Feed the real density calculation representative timed channel frames."""
    names=['Offset', 'Engine RPM', 'Actual Torque', ect_label,
           'MAP - Hi-Res', 'Barometric Pressure',
           'Short Term Fuel Trim Bank 1 (SAE)',
           'Short Term Fuel Trim Bank 2 (SAE)',
           'FA Enrichment', 'FA Power Enrichment',
           'Fuel Flow Rate', 'FA Stoich', 'Knock Retard Long Term', 'Knock Retard Short Term', 'Total Knock Retard']
    units=['s','rpm','lb-ft','°F','kPa','kPa','%','%','','','g/s','','°','°','°']
    ids=[str(i) for i in range(len(names))]
    meta=lc.Metadata(ids,names,units,1)
    missing=set(missing)
    mapping={s.key:lc._matching_indices(meta,s) for s in lc.SPECS}
    for k in missing:mapping[k]=[]
    ect_indices=(set(round(i * (count - 1) / (ect_spread_count - 1))
                     for i in range(ect_spread_count))
                 if ect_spread_count is not None and ect_spread_count > 1 else None)
    def fake_frames(_p,_s):
        for i in range(count):
            t=i*0.1
            row=[str(t)]+['1']*(len(names)-1)
            if (ect_count is not None and i >= ect_count) or (
                    ect_indices is not None and i not in ect_indices):
                row[3]=''
            if fuel_count is not None and i >= fuel_count:
                row[10]=''
            yield t,row
    p=tmp_path/'representative.hpl'
    p.write_text('[fixture]',encoding='utf-8')
    # The production validator now requires a validated native HPL MAP source;
    # supply that recorded pressure evidence while retaining the artificial
    # density rows used by these tests.
    decoded={'channels':{
        1:{'name':'MAP - Hi-Res','unit':'kPa'},
        2:{'name':'Barometric Pressure','unit':'kPa'},
    },'frames':[
        {'timestamp_ms':0,'updates':{1:50.0,2:100.0}},
        {'timestamp_ms':100,'updates':{1:51.0,2:100.0}},
    ]}
    with patch.object(lc,'read_metadata',return_value=meta),\
         patch.object(lc,'resolve_indices',return_value=mapping),\
         patch.object(lc,'iter_data',side_effect=fake_frames),\
         patch.object(lc,'_native',return_value=decoded):
        return lc.analyze_log(p,airflow_model=model)


def test_speed_density_excludes_nn_cams_and_ltft_and_degrades_missing_fuel_flow(tmp_path):
    r=fake_log_report(tmp_path,'speed_density',missing={'fuel_flow'})
    q={x['key']:x for x in r['signals']}
    assert r['airflow_model']=='speed_density'
    assert r['passed'], r['blocking']
    assert not any('Fuel Flow Rate' in x for x in r['blocking'])
    assert all(not q[k]['required'] for k in ('intake_cam','exhaust_cam','ltft_b1','ltft_b2'))
    assert q['fuel_flow']['required'] is False
    assert q['fuel_flow']['status']=='OPTIONAL'
    assert q['ect']['status']=='PASS'
    assert q['ect']['candidates']==['Engine Coolant Temp (SAE)']
    assert 'Fuel Flow Rate: missing' not in ' '.join(r['blocking'])


def test_neural_network_requirements_remain_strict(tmp_path):
    r=fake_log_report(tmp_path,'neural_network',missing={'fuel_flow'})
    q={x['key']:x for x in r['signals']}
    assert not r['passed']
    assert all(q[k]['required'] for k in ('intake_cam','exhaust_cam','ltft_b1','ltft_b2','fuel_flow'))
    assert q['fuel_flow']['status']=='MISSING'
    assert 'Fuel Flow Rate: missing' in r['blocking']


def test_native_and_sae_coolant_names_are_equivalent(tmp_path):
    for label in ('Engine Coolant Temp', 'Engine Coolant Temp (SAE)'):
        r=fake_log_report(tmp_path,'speed_density',ect_label=label,missing={'fuel_flow'})
        q=next(x for x in r['signals'] if x['key']=='ect')
        assert q['status']=='PASS'
        assert q['candidates']==[label]


def test_sae_name_recognized_even_when_density_too_low(tmp_path):
    r=fake_log_report(tmp_path,'speed_density',missing={'fuel_flow'},ect_count=60)
    ect=next(x for x in r['signals'] if x['key']=='ect')
    assert ect['candidates']==['Engine Coolant Temp (SAE)']
    assert ect['status']=='PASS'
    assert r['passed']  # Method B requires STFT presence, not Fuel Flow or the Method A ECT density gate.


def test_377_coolant_updates_across_five_minutes_pass_sd_in_both_aliases(tmp_path):
    for label in ('Engine Coolant Temp', 'Engine Coolant Temp (SAE)'):
        r=fake_log_report(tmp_path,'speed_density',ect_label=label,
                          count=3001,ect_spread_count=377,missing={'fuel_flow'})
        ect=next(x for x in r['signals'] if x['key']=='ect')
        assert r['duration_s']==300.0
        assert r['validation_policy_revision']==lc.LOG_VALIDATION_POLICY_REVISION
        assert ect['count']==377
        assert abs(ect['effective_hz']-377/300)<1e-9
        assert ect['status']=='PASS',ect
        assert ect['minimum_hz_for_current_duration']==1.0
        assert ect['recommended_ms']==500
        assert ect['coverage_ratio']==1.0
        assert r['passed'], r['blocking']
        assert not any('Fuel Flow Rate' in x for x in r['blocking'])
        fuel=next(x for x in r['signals'] if x['key']=='fuel_flow')
        assert fuel['status']=='OPTIONAL'
        assert lc.required_channel_guide('speed_density')[10]['polled_ms']==500


def test_nn_ect_density_unchanged_for_same_377_updates(tmp_path):
    r=fake_log_report(tmp_path,'neural_network',count=3001,
                      ect_spread_count=377,missing={'fuel_flow'})
    ect=next(x for x in r['signals'] if x['key']=='ect')
    assert ect['status']=='LOW DATA DENSITY'
    assert ect['minimum_hz_for_current_duration']==1000/300
    assert ect['recommended_ms']==10
    assert not r['passed']


def test_sd_ect_fails_for_sparse_updates_or_coverage_loss(tmp_path):
    sparse=fake_log_report(tmp_path,'speed_density',count=3001,
                           ect_spread_count=60,missing={'fuel_flow'})
    ect=next(x for x in sparse['signals'] if x['key']=='ect')
    assert ect['status']=='PASS'  # Recorded but not a strict Method B channel
    assert ect['coverage_ratio']==1.0
    assert sparse['passed']  # Method B does not require Fuel Flow Rate
    short=fake_log_report(tmp_path,'speed_density',count=3001,
                          ect_count=377,missing={'fuel_flow'})
    ect=next(x for x in short['signals'] if x['key']=='ect')
    assert ect['status']=='PASS'
    assert short['passed']  # Method B does not require Fuel Flow Rate


def test_speed_density_fuel_flow_below_density_is_degraded_not_blocked(tmp_path):
    r=fake_log_report(tmp_path,'speed_density',fuel_count=419)
    q=next(x for x in r['signals'] if x['key']=='fuel_flow')
    assert q['status']=='AVAILABLE'
    assert q['count']==419
    assert q['quantity_pass']  # Informational only; no minimum for optional fuel flow
    assert r['passed'] is True
    guide={x['key']:x for x in lc.required_channel_guide('speed_density')}
    assert not guide['fuel_flow']['advisory']
    assert guide['fuel_flow']['required'] is False


def test_gui_and_persistent_validation_use_detected_airflow_model():
    src=(ROOT/'ve_optimizer_revision9_review.py').read_text(encoding='utf-8')
    ver=(ROOT/'ve_optimizer_version4.py').read_text(encoding='utf-8')
    integration_src=(ROOT/'ve_optimizer_wideband_integration.py').read_text(encoding='utf-8')
    assert src.count('airflow_model=wideband.detect_airflow_model(tune)')>=2
    assert 'airflow_model=wideband.detect_airflow_model(baseline)' in ver
    assert 'required_channel_guide(airflow_model)' in src
    assert "report.get('logged_channels',[])" in src
    assert "status_text=='No Data'" in src
    # Obsolete saved policy reports are not permitted to keep showing FAILED.
    assert "report.get('validation_policy_revision') != logcheck.LOG_VALIDATION_POLICY_REVISION" in src
    assert "standard_report.get('validation_policy_revision') != logcheck.LOG_VALIDATION_POLICY_REVISION" in integration_src



def test_airflow_model_detected_from_real_htt_reference():
    p=Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt')
    if p.is_file():
        assert wb.detect_airflow_model(p)=='speed_density'


def test_integrated_qualification_replaces_stale_nn_log_profile(tmp_path):
    wrong_profile={'airflow_model':'neural_network','passed':False,'recommendations':['missing NN cams']}
    right_profile={'airflow_model':'speed_density','passed':True,'recommendations':[]}
    pf={'configuration':{'airflow_model':'speed_density'},
        'sources':{'adaptive':{'valid':True},'wideband':{'valid':False}}}
    with patch.object(integration.wb,'detect_airflow_model',return_value='speed_density'),\
         patch.object(lc,'analyze_log',return_value=right_profile) as analyze,\
         patch.object(integration.wb,'build_correction_preflight',return_value=pf):
        out=integration.qualify_log_for_tune(tmp_path/'test.hpl',tmp_path/'test.htt',wrong_profile)
    analyze.assert_called_once_with(tmp_path/'test.hpl',airflow_model='speed_density')
    assert out['standard_report'] is right_profile
    assert out['passed'] is True
    assert out['adaptive_ready'] is True


def test_integrated_qualification_invalidates_old_density_policy(tmp_path):
    stale={'airflow_model':'speed_density','validation_policy_revision':'earlier',
           'passed':False, 'recommendations':['low ECT density']}
    fresh={'airflow_model':'speed_density',
           'validation_policy_revision':lc.LOG_VALIDATION_POLICY_REVISION,
           'passed':True,'recommendations':[]}
    preflight={'configuration':{'airflow_model':'speed_density'},
               'sources':{'adaptive':{'valid':True},'wideband':{'valid':False}}}
    with patch.object(integration.wb,'detect_airflow_model',return_value='speed_density'), \
         patch.object(lc,'analyze_log',return_value=fresh) as analyze, \
         patch.object(integration.wb,'build_correction_preflight',return_value=preflight):
        out=integration.qualify_log_for_tune(tmp_path/'test.hpl',tmp_path/'test.htt',stale)
    analyze.assert_called_once_with(tmp_path/'test.hpl',airflow_model='speed_density')
    assert out['standard_report'] is fresh
    assert out['passed']


def test_speed_density_enrichment_channels_are_required_but_not_hard_gates(tmp_path):
    r=fake_log_report(tmp_path,'speed_density',missing={'fa_enrichment','fa_power_enrichment'})
    q={x['key']:x for x in r['signals']}
    assert not r['passed']
    assert q['fa_enrichment']['required']
    assert q['fa_power_enrichment']['required']
    assert 'FA Enrichment: missing' in r['blocking']
    assert 'FA Power Enrichment: missing' in r['blocking']
    nn=fake_log_report(tmp_path,'neural_network',missing={'fa_enrichment','fa_power_enrichment'})
    q_nn={x['key']:x for x in nn['signals']}
    assert q_nn['fa_enrichment']['required']
    assert q_nn['fa_power_enrichment']['required']
    assert not nn['passed']


def test_method_b_missing_logged_fa_stoich_does_not_block_existing_stft_wideband_workflows(tmp_path):
    """Method B can operate on STFT or Wideband despite no logged FA Stoich.

    Logged FA Stoich remains visible as No Data.  Method A remains strict.
    """
    missing={'fuel_flow', 'fuel_air_stoich'}
    sd=fake_log_report(tmp_path, 'speed_density', missing=missing)
    assert sd['passed'], sd['blocking']
    stoich=next(x for x in sd['signals'] if x['key']=='fuel_air_stoich')
    assert stoich['required'] is False
    assert stoich['count']==0
    assert stoich['status']=='OPTIONAL'
    # This fixture simulates a missing logical mapping; its FA Stoich metadata
    # column still contains mock values, so assert the logical qualification only.
    assert not any('FA Stoich' in x for x in sd['blocking'])

    nn=fake_log_report(tmp_path, 'neural_network', missing=missing)
    assert not nn['passed']
    assert 'FA Stoich: missing' in nn['blocking']
    assert 'Fuel Flow Rate: missing' in nn['blocking']
