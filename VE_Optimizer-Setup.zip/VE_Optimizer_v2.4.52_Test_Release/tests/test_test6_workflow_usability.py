"""Test 6: user-requested UI corrections; no VE correction calculations changed."""
from pathlib import Path
import inspect
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import ve_optimizer_revision9_review as app
import ve_optimizer_wideband as wb


def test_each_completed_stage_reaches_100_and_stale_overall_steps_disappear():
    obj=app.ReviewApp.__new__(app.ReviewApp)
    obj.run_quality_activity_lines=[]
    obj.run_quality_activity_widget=None
    obj._run_quality_active_stage=None
    obj._run_quality_last_activity=None
    obj._append_run_quality_activity(0,'Prepare review','Start')
    obj._append_run_quality_activity(55,'Fit Neural Network','Solver 300/1000')
    obj._append_run_quality_activity(64,'Fit Neural Network','Solver 700/1000')
    obj._append_run_quality_activity(80,'Validate candidate','Verified')
    obj._append_run_quality_activity(100,'Processing complete','Candidate verified')
    assert 'COMPLETE 100%  Prepare review' in obj.run_quality_activity_lines
    assert 'COMPLETE 100%  Fit Neural Network' in obj.run_quality_activity_lines
    assert 'COMPLETE 100%  Validate candidate' in obj.run_quality_activity_lines
    assert obj.run_quality_activity_lines[-1].startswith('OVERALL 100%')
    assert not any('55%' in x or '64%' in x for x in obj.run_quality_activity_lines)


def test_file_picker_does_not_start_processing_before_submit():
    picker=inspect.getsource(app.ReviewApp._select_current_log)
    submit=inspect.getsource(app.ReviewApp._submit_selected_log)
    assert '_run_background_task' not in picker
    assert '_offer_na_closed_loop_only' not in picker
    assert 'self.vs_log_staged=True' in picker
    assert '_run_background_task' in submit
    assert "self._show_working_overlay('Log File validation'" in submit
    assert "self.vs_log_staged=False" in submit
    assert "text='Submit'" in inspect.getsource(app.ReviewApp.page_setup)


def test_knock_yes_requalifies_in_background_with_working_feedback():
    submit=inspect.getsource(app.ReviewApp._submit_selected_log)
    assert "self.vs_status.set('Validating approved closed-loop-only correction...')" in submit
    assert 'self._run_background_task(approved_worker,approved_done)' in submit
    assert 'self._hide_working_overlay()' in submit


def test_map_verification_prompt_removed_and_calibration_not_written():
    assert not hasattr(app.ReviewApp,'_review_map_and_pe')
    prompt=inspect.getsource(app.ReviewApp._show_preflight_prompt)
    assert 'self._show_correction_source_message()' in prompt
    source=inspect.getsource(wb.prepare_airflow_strategy)
    assert 'MAP1_LINEAR_SCALAR' not in source
    assert 'MAP2_LINEAR_SCALAR' not in source


def test_real_boosted_log_remains_blocked_until_hardware_review_approved():
    tune=Path('/mnt/data/5.7L with a Maggi after VCM Suite Update.htt')
    log=Path('/mnt/data/5.7L with a Maggi Shortened.hpl')
    if not tune.is_file() or not log.is_file():return
    pending=wb.build_correction_preflight(log,tune)
    verified=wb.build_correction_preflight(log,tune,hardware_review_approved=True)
    p={x['id']:x for x in pending['choices']};v={x['id']:x for x in verified['choices']}
    assert not p['wideband']['enabled']
    # Hardware confirmation removes the user-review hold. The PE axis
    # change is completed by the existing automatic PE preparation stage.
    assert verified['hardware_review_pending'] is False
    assert verified['pe_calibration_pending'] is False
    assert verified['pe_preparation_required'] is True
    assert v['wideband']['enabled']
    assert v['adaptive']['enabled']  # Method B does not require Fuel Flow Rate
