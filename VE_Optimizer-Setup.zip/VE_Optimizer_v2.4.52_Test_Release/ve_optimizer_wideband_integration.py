#!/usr/bin/env python3
"""Project-facing integration helpers for VE Optimizer wideband development.

This module deliberately keeps the accepted LTFT+STFT method intact.  It
packages the wideband core into the same preview/apply project lifecycle used
by the application without changing the accepted narrowband processing code.
"""
from __future__ import annotations

import csv
import copy
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any, Dict

import numpy as np

import ve_optimizer_processing as processing
import ve_optimizer_stage3 as s3
import ve_optimizer_wideband as wb

WB_SD_METHOD = "wideband-speed-density-half-step-0.9.0"
WB_NN_METHOD = "wideband-neural-network-half-step-0.9.0"
ADAPTIVE_SD_METHOD = "adaptive-speed-density-half-step-0.9.0"
CURRENT_METHOD_IDS = {WB_SD_METHOD, WB_NN_METHOD, ADAPTIVE_SD_METHOD}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def is_wideband_method(method_id: str | None) -> bool:
    return str(method_id or "") in CURRENT_METHOD_IDS


def _jsonable(value: Any):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _airflow_preflight_error(preflight: dict) -> str | None:
    airflow = preflight.get("airflow_map_preflight") or {}
    if not airflow.get("blocking"):
        return None
    issues = [str(x) for x in airflow.get("issues", []) if str(x).strip()]
    return "MAP/Baro airflow preflight failed: " + ("; ".join(issues) if issues else str(airflow.get("message") or "calibration review required"))


def _prepare_airflow_if_needed(log_path: Path, baseline_htt: Path, output_dir: Path) -> tuple[Path, dict | None]:
    pf = wb.airflow_map_preflight(log_path, baseline_htt)
    if pf.get("blocking"):
        issues = "; ".join(str(x) for x in pf.get("issues", []) if str(x).strip())
        raise ValueError("Pressure-model preflight has an unrepairable issue: " + (issues or str(pf.get("message") or "review required")))
    if not pf.get("auto_fix_required"):
        return baseline_htt, None
    prepared = output_dir / "Airflow_Prepared_Baseline.htt"
    result = wb.prepare_airflow_strategy(log_path, baseline_htt, prepared)
    return prepared, result


def _scale_sd_if_needed(baseline_htt: Path, output_dir: Path) -> tuple[Path, dict | None]:
    """Prepare the full calibration-derived SD RPM/MAP1 grid before correction."""
    pf = wb.speed_density_axis_preflight(baseline_htt)
    if not pf["needs_rescale"]:
        return Path(baseline_htt), None
    prepared = Path(output_dir) / "Rescaled_Baseline.htt"
    result = wb.rescale_speed_density_axes(baseline_htt, prepared)
    return prepared, result


def wideband_method_id(airflow_model: str) -> str:
    if airflow_model == "speed_density":
        return WB_SD_METHOD
    if airflow_model == "neural_network":
        return WB_NN_METHOD
    raise ValueError(f"Unsupported airflow model: {airflow_model!r}")


def qualify_log_for_tune(log_path: Path, tune_path: Path, standard_report: dict | None = None,
                         *, closed_loop_only: bool = False) -> dict:
    """Allow a wideband-capable log even when legacy adaptive logcheck fails.

    The legacy logcheck remains authoritative for the accepted adaptive method.
    A log that fails it is accepted only when the wideband processor itself is
    ready for the selected tune.
    """
    import ve_optimizer_logcheck as logcheck

    log_path = Path(log_path)
    tune_path = Path(tune_path)
    # A report produced before the tune was selected may contain the generic
    # Neural Network requirements. Never reuse it for an NN-disabled vehicle.
    active_model = wb.detect_airflow_model(tune_path)
    if (standard_report is None or
        standard_report.get('airflow_model') != active_model or
        standard_report.get('validation_policy_revision') != logcheck.LOG_VALIDATION_POLICY_REVISION):
        standard_report = logcheck.analyze_log(log_path, airflow_model=active_model)
    if closed_loop_only and not standard_report.get('na_closed_loop_only'):
        raise ValueError('Closed-loop-only correction requires a recorded, approved knock-data exception.')

    preflight = None
    preflight_error = None
    try:
        preflight = wb.build_correction_preflight(log_path, tune_path,
                                                closed_loop_only=closed_loop_only)
    except Exception as exc:
        preflight_error = str(exc)

    wb_ready = bool(
        not closed_loop_only and preflight and
        preflight.get("sources", {}).get("wideband", {}).get("valid") and
        preflight.get("sources", {}).get("wideband", {}).get("processor_ready")
    )
    airflow_blocked = bool(preflight and (preflight.get("airflow_map_preflight") or {}).get("blocking"))
    airflow_model = ((preflight or {}).get("configuration") or {}).get("airflow_model")
    if airflow_model == "speed_density":
        adaptive_ready = bool((((preflight or {}).get("sources") or {}).get("adaptive") or {}).get("valid"))
    else:
        adaptive_ready = bool(standard_report.get("passed"))
        if closed_loop_only:
            adaptive_ready = adaptive_ready and bool((((preflight or {}).get('sources') or {}).get('adaptive') or {}).get('valid'))
    # Missing required knock data cannot be bypassed by another source unless
    # the user has expressly approved the verified NA closed-loop-only exception.
    knock_unlogged = any(
        sig.get('key') in logcheck.NA_KNOCK_KEYS and int(sig.get('count') or 0) == 0
        for sig in standard_report.get('signals', []))
    if knock_unlogged and not closed_loop_only:
        adaptive_ready = False
        wb_ready = False
    # Log qualification is about whether the file contains usable data. Calibration
    # problems belong in Correction Preflight, not in the log-file rejection gate.
    passed = bool(adaptive_ready or wb_ready)

    return {
        "passed": passed,
        "adaptive_ready": adaptive_ready,
        "wideband_ready": wb_ready,
        "wideband_correction_blocked": bool(wb_ready and airflow_blocked),
        "standard_report": standard_report,
        "correction_preflight": _jsonable(preflight) if preflight else None,
        "preflight_error": preflight_error,
        "recommendations": list(standard_report.get("recommendations", [])),
        "qualification_basis": (
            "adaptive_and_wideband_preflight_blocked" if adaptive_ready and wb_ready and airflow_blocked else
            "adaptive_and_wideband" if adaptive_ready and wb_ready else
            "adaptive" if adaptive_ready else
            "wideband_preflight_blocked" if wb_ready and airflow_blocked else
            "wideband" if wb_ready else
            "none"
        ),
    }


def write_wideband_samples_csv(path: Path, analysis: dict) -> Path:
    """Write the accepted wideband event list used to derive cell targets."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = list(analysis.get("accepted_samples", []))
    fields = [
        "wb_timestamp_ms", "state_timestamp_ms", "rpm", "pratio",
        "measured_lambda", "commanded_lambda", "fa_enrichment",
        "fa_power_enrichment", "full_correction_pct", "applied_correction_pct",
        "row", "column", "intake_cam", "exhaust_cam",
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fields})
    return path


def _write_summary(path: Path, metrics: dict, preflight: dict, rescale: dict | None) -> Path:
    cfg = preflight.get("configuration", {})
    maf = preflight.get("sources", {}).get("maf", {})
    domain = preflight.get("domain_preflight") or {}
    lines = [
        "VE OPTIMIZER — WIDEBAND DEVELOPMENT RESULT",
        "",
        f"Correction source: Wideband O2",
        f"Airflow model: {metrics['airflow_model']}",
        "Power Enrichment calibration: NOT MODIFIED (fueling not verified by VE Optimizer)",
        f"Qualifying cells: {metrics.get('qualifying_cells', 0)}",
        f"Accepted wideband samples: {metrics.get('accepted', 0)}",
        f"Correction fraction: {metrics.get('application_percent', 50):.0f}% of measured error",
        f"Verification: {'PASS' if metrics.get('verification_passed') else 'FAIL'}",
    ]
    airflow_prepare = metrics.get("airflow_prepare") or {}
    if metrics.get("airflow_prepared"):
        lines += ["", "Pressure-model automatic preparation:"]
        for change in airflow_prepare.get("changes", []):
            lines.append(f"  {change.get('parameter')}: {change.get('value')}")
        lines.append("  Logged Baro was used only for operating PRatio; MAP sensor class/range used 101.325 kPa sea-level reference.")
    if rescale:
        lines += [
            "",
            "Speed Density rescale:",
            f"  Old PRatio max: {rescale.get('old_pratio_max')}",
            f"  New PRatio max: {rescale.get('new_pratio_max')}",
            f"  Table format retained: {metrics.get('sd_table_shape', '17x17')}",
            "  VE surface was regridded; RPM axis was unchanged.",
        ]
    if domain:
        lines += ["", f"Domain preflight: {domain.get('message', '')}"]
    if maf:
        p = maf.get("primary") or {}
        lines += [
            "",
            f"MAF status: {maf.get('status', 'unknown')}",
            f"MAF channel: {p.get('name', 'Not logged')}",
        ]
        if maf.get("reason"):
            lines.append(f"MAF note: {maf['reason']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _write_technical(path: Path, metrics: dict, preflight: dict, analysis: dict, rescale: dict | None) -> Path:
    payload = {
        "metrics": _jsonable(metrics),
        "preflight": _jsonable(preflight),
        "analysis_stages": _jsonable(analysis.get("stages", {})),
        "rescale": _jsonable(rescale),
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def build_wideband_preview(
    baseline_htt: Path,
    log_path: Path,
    output_dir: Path,
    *,
    rescale_approved: bool = False,
    delay_ms: int = 60,
    min_hits: int = wb.MIN_HITS,
    progress=None,
) -> dict:
    """Create one verified 50% wideband candidate and preview payload."""
    baseline_htt = Path(baseline_htt)
    log_path = Path(log_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    def upd(pct: float, title: str, detail: str):
        if progress:
            progress(float(pct), str(title), str(detail))

    upd(0, "Wideband preflight", "Validating correction sources and airflow model.")
    preflight = wb.build_correction_preflight(log_path, baseline_htt, delay_ms=delay_ms, min_hits=min_hits)
    airflow_error = _airflow_preflight_error(preflight)
    if airflow_error:
        raise ValueError(airflow_error)
    if not preflight.get("sources", {}).get("wideband", {}).get("processor_ready"):
        reason = preflight.get("sources", {}).get("wideband", {}).get("processor_error") or preflight.get("sources", {}).get("wideband", {}).get("reason")
        raise ValueError(reason or "Valid wideband PE data are not available.")

    airflow_model = preflight["configuration"]["airflow_model"]
    effective_baseline, airflow_prepare = _prepare_airflow_if_needed(log_path, baseline_htt, output_dir)
    if airflow_prepare is not None:
        upd(5, "Prepare pressure model", "Applying the preflight-approved Pressure Ratio Max scalar adjustment only.")
        preflight = wb.build_correction_preflight(log_path, effective_baseline, delay_ms=delay_ms, min_hits=min_hits)
        airflow_error = _airflow_preflight_error(preflight)
        if airflow_error:
            raise ValueError(airflow_error)
    # PE is intentionally not prepared: wideband corrects VE only, never PE.
    rescale = None

    if airflow_model == "speed_density":
        upd(10, "Rescale VE tables", "Scaling both VE-bank axes from Maximum RPM and MAP1 calibration.")
        effective_baseline, rescale = _scale_sd_if_needed(effective_baseline, output_dir)
        preflight = wb.build_correction_preflight(log_path, effective_baseline, delay_ms=delay_ms, min_hits=min_hits)
        domain2 = preflight.get("domain_preflight") or {}
        if domain2.get("needs_rescale") or domain2.get("blocking"):
            raise ValueError("The calibrated RPM/MAP1 Speed Density axes failed post-scale verification")

    upd(25, "Process wideband", "Building dual-gated PE correction targets.")
    analysis = wb.analyze_wideband(log_path, effective_baseline, delay_ms=delay_ms, min_hits=min_hits)
    if int(analysis.get("qualifying_cell_count", 0)) <= 0:
        raise processing.NoQualifyingCells("No wideband cells meet the minimum hit requirement.")

    candidate = output_dir / "Candidate_Wideband_50pct.htt"
    upd(45, "Build candidate", "Applying the 50% wideband correction to the active airflow model.")
    result = wb.export_wideband_candidate(effective_baseline, analysis, candidate, progress=(lambda pct, msg: upd(45 + 0.40 * pct, "Fit Neural Network", msg)) if airflow_model == "neural_network" else None)

    accepted_csv = write_wideband_samples_csv(output_dir / "Accepted_Wideband_Events.csv", analysis)
    processing_result = output_dir / "Wideband_Processing_Result.json"
    processing_result.write_text(json.dumps(_jsonable(result), indent=2), encoding="utf-8")

    method_id = wideband_method_id(airflow_model)
    sources = preflight.get("sources", {})
    metrics: Dict[str, Any] = {
        "method_id": method_id,
        "correction_source": "wideband",
        "airflow_model": airflow_model,
        "pe_table_axis": preflight.get("configuration", {}).get("pe_table_axis"),
        "airflow_prepared": bool(airflow_prepare),
        "airflow_prepare": _jsonable(airflow_prepare) if airflow_prepare else None,
        "pe_prepared": False,
        "pe_calibration_status": "unchanged; fueling not validated by VE Optimizer",
        "accepted": int(len(analysis.get("accepted_samples", []))),
        "qualifying_cells": int(analysis.get("qualifying_cell_count", 0)),
        "minimum_hits": int(analysis.get("minimum_hits", min_hits)),
        "application_percent": 50.0,
        "correction_fraction": float(analysis.get("correction_fraction", wb.CORRECTION_FRACTION)),
        "delay_ms": int(analysis.get("delay_ms", delay_ms)),
        "verification_passed": True,
        "source_log_sha256": _sha256(log_path),
        "baseline_htt_sha256": _sha256(baseline_htt),
        "effective_baseline_sha256": _sha256(effective_baseline),
        "candidate_htt_sha256": _sha256(candidate),
        "rescaled": bool(rescale),
        "maf_status": sources.get("maf", {}).get("status"),
        "maf_valid": bool(sources.get("maf", {}).get("valid")),
        "wideband_stages": _jsonable(analysis.get("stages", {})),
        "domain_preflight": _jsonable(preflight.get("domain_preflight")),
    }
    if airflow_model == "speed_density":
        metrics.update({
            "changed_cells_b1": int(result.get("changed_cells_b1", 0)),
            "changed_cells_b2": int(result.get("changed_cells_b2", 0)),
            "banks_identical_after": bool(result.get("banks_identical_after", False)),
            "sd_table_shape": f"{len(analysis['pratio_axis'])}x{len(analysis['rpm_axis'])}",
            "scope_verified": True,
        })
    else:
        meta = result.get("wideband", {})
        metrics.update({
            "reverse_targets": int(meta.get("reverse_targets", 0)),
            "overshoot_targets": int(meta.get("overshoot_targets", 0)),
            "zero_movement_targets": int(meta.get("zero_movement_targets", 0)),
            "coefficient_changes": _jsonable(meta.get("coefficient_changes", {})),
            "fit_verification": _jsonable(result.get("fit_verification", {})),
            "scope_verified": True,
        })
        processing.require_verified_result(result)
        if metrics["reverse_targets"] or metrics["overshoot_targets"]:
            raise ValueError("Wideband NN candidate failed direction/overshoot verification.")

    metrics_json = output_dir / "Wideband_Metrics.json"
    metrics_json.write_text(json.dumps(_jsonable(metrics), indent=2), encoding="utf-8")
    summary = _write_summary(output_dir / "Wideband_Summary.txt", metrics, preflight, rescale)
    technical = _write_technical(output_dir / "Wideband_Technical.txt", metrics, preflight, analysis, rescale)

    export = candidate
    if airflow_model == "speed_density":
        export = output_dir / "Speed_Density_Changed_Tables_IMPORT_TEST.htt"
        wb.export_speed_density_changed_tables(baseline_htt, candidate, export)
    level = {
        "candidate_htt": str(candidate),
        "export_htt": str(export),
        "summary": str(summary),
        "technical": str(technical),
        "metrics_json": str(metrics_json),
        "processing_result": str(processing_result),
    }
    level["hashes"] = {key: _sha256(Path(value)) for key, value in level.items() if key != "hashes"}

    payload = {
        "method_id": method_id,
        "correction_source": "wideband",
        "airflow_model": airflow_model,
        "levels": {"50": level},
        "accepted_csv": str(accepted_csv),
        "accepted_sha256": _sha256(accepted_csv),
        "baseline_htt": str(baseline_htt),
        "baseline_sha256": _sha256(baseline_htt),
        "effective_baseline_htt": str(effective_baseline),
        "effective_baseline_sha256": _sha256(effective_baseline),
        "log_sha256": _sha256(log_path),
        "rescale": _jsonable(rescale),
        "preflight": _jsonable(preflight),
    }
    preview_json = output_dir / "Candidate_Preview.json"
    preview_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    upd(100, "Write & store results", "Wideband candidate ready for review.")
    return {
        "payload": payload,
        "preview_json": preview_json,
        "metrics": metrics,
        "analysis": analysis,
        "preflight": preflight,
        "candidate": candidate,
        "accepted_csv": accepted_csv,
    }


def verify_wideband_preview_payload(payload: dict, percent: int = 50) -> dict:
    method_id = payload.get("method_id")
    if not is_wideband_method(method_id):
        raise ValueError("Stored preview is not a current extended correction method.")
    if _sha256(Path(payload["baseline_htt"])) != payload["baseline_sha256"]:
        raise ValueError("Stored baseline failed integrity validation.")
    if _sha256(Path(payload["accepted_csv"])) != payload["accepted_sha256"]:
        raise ValueError("Stored accepted-event file failed integrity validation.")
    level = payload.get("levels", {}).get(str(int(percent)))
    if not level:
        raise ValueError(f"Stored {int(percent)}% candidate is unavailable.")
    for key, digest in level.get("hashes", {}).items():
        if _sha256(Path(level[key])) != digest:
            raise ValueError(f"Stored wideband artifact failed integrity validation: {key}")
    metrics = json.loads(Path(level["metrics_json"]).read_text(encoding="utf-8"))
    if metrics.get("method_id") != method_id or not metrics.get("verification_passed"):
        raise ValueError("Stored wideband candidate lacks successful verification.")
    return metrics

COMBINED_SD_METHOD = "combined-adaptive-wideband-speed-density-half-step-0.9.0"
COMBINED_NN_METHOD = "combined-adaptive-wideband-neural-network-half-step-0.9.0"
CURRENT_METHOD_IDS.update({COMBINED_SD_METHOD, COMBINED_NN_METHOD})


def _adaptive_sd_analysis(log_path: Path, tune_path: Path, min_hits: int = wb.MIN_HITS,
                          *, closed_loop_only: bool = False) -> dict:
    """Calculate independent Method B bank targets from STFT-timed events.

    Use LTFT + STFT for BOTH banks when valid LTFT histories are present;
    otherwise use STFT alone for BOTH banks. Method A's event filters and
    neural-network coefficient optimization do not apply to this path.
    """
    decoded = wb.decode_hpl(Path(log_path))
    channels = decoded["channels"]
    names = {"rpm": wb.RPM_NAME, "torque": wb.TORQUE_NAME}
    idx = {k: wb._resolve_optional_name(channels, v, decoded=decoded) for k, v in names.items()}
    idx.update(wb._sd_pressure_input_indices(channels, decoded))
    trim_indices, trim_mode = wb._speed_density_trim_inputs(decoded)
    idx.update(trim_indices)
    if closed_loop_only:
        idx["fa"] = wb._resolve_optional_name(channels, wb.FA_ENRICH_NAME, decoded=decoded)
        idx["pe"] = wb._resolve_optional_name(channels, wb.FA_PE_NAME, decoded=decoded)
    idx["ect"] = wb._resolve_optional_name(channels, wb.ECT_NAME, decoded=decoded)
    if idx["ect"] is None:
        idx["ect"] = wb._resolve_optional_name(channels, "Engine Coolant Temp", decoded=decoded)
    required = ("stft_b1", "stft_b2", "rpm", "map", "baro", "torque", "ect")
    if closed_loop_only:
        required += ("fa", "pe")
    missing = [k for k in required if idx.get(k) is None]
    if missing:
        raise ValueError("Speed Density STFT processing is missing: " + ", ".join(missing))

    _, rpm_axis, pr_axis, b1 = wb.parse_ve_table(Path(tune_path), wb.VE_BANK1_TABLE)
    _, rpm2, pr2, b2 = wb.parse_ve_table(Path(tune_path), wb.VE_BANK2_TABLE)
    if not np.array_equal(rpm_axis, rpm2) or not np.array_equal(pr_axis, pr2):
        raise ValueError("Speed Density VE Bank axes differ")

    histories = {k: wb._history(decoded, v) for k, v in idx.items() if v is not None}
    ect_unit = str(channels[idx["ect"]].get("unit", ""))
    torque_unit = str(channels[idx["torque"]].get("unit", ""))

    def ect_f(v):
        v = float(v); return v * 1.8 + 32.0 if "c" in ect_unit.lower() else v
    def torque_lbft(v):
        v = float(v); return v / 1.35581794833 if "n" in torque_unit.lower() and "m" in torque_unit.lower() else v

    counts = np.zeros((2, len(pr_axis), len(rpm_axis)), dtype=int)
    sums = np.zeros_like(counts, dtype=float)
    outside = 0
    for bank in (1, 2):
        for t in sorted(set(histories[f"stft_b{bank}"][0])):
            base_keys = ("rpm", "map", "baro", "torque", "ect", f"stft_b{bank}")
            vals = {k: wb._latest(histories[k], t) for k in base_keys}
            if trim_mode == "ltft_plus_stft":
                vals[f"ltft_b{bank}"] = wb._latest(histories[f"ltft_b{bank}"], t)
            if any(v is None for v in vals.values()):
                continue
            stft = float(vals[f"stft_b{bank}"])
            ltft = float(vals[f"ltft_b{bank}"]) if trim_mode == "ltft_plus_stft" else 0.0
            if not (np.isfinite(stft) and np.isfinite(ltft)):
                continue
            if closed_loop_only:
                fa = wb._latest(histories['fa'], t)
                pe = wb._latest(histories['pe'], t)
                if fa is None or pe is None or abs(float(fa))>1e-9 or abs(float(pe))>1e-9:
                    continue
            if not wb._sd_stft_sample_valid(
                rpm=vals["rpm"], ect_f=ect_f(vals["ect"]),
                torque_lbft=torque_lbft(vals["torque"]), baro=vals["baro"],
            ):
                continue
            rpm = float(vals["rpm"])
            pr = float(vals["map"]) / float(vals["baro"])
            if rpm < rpm_axis[0] or rpm > rpm_axis[-1] or pr < pr_axis[0] or pr > pr_axis[-1]:
                outside += 1
                continue
            r = wb._nearest_index(pr_axis, pr)
            c = wb._nearest_index(rpm_axis, rpm)
            counts[bank - 1, r, c] += 1
            sums[bank - 1, r, c] += stft + ltft

    full = np.full((len(pr_axis), len(rpm_axis)), np.nan, dtype=float)
    qual = np.zeros_like(full, dtype=bool)
    for r in range(len(pr_axis)):
        for c in range(len(rpm_axis)):
            eligible = []
            for bank in (0, 1):
                n = int(counts[bank, r, c])
                if n >= int(min_hits):
                    eligible.append(float(sums[bank, r, c] / n))
            if eligible:
                qual[r, c] = True
                full[r, c] = max(eligible)
    applied = np.full_like(full, np.nan)
    applied[qual] = 0.5 * full[qual]
    return {
        "airflow_model": "speed_density", "trim_mode": trim_mode,
        "closed_loop_only": bool(closed_loop_only),
        "rpm_axis": rpm_axis, "pratio_axis": pr_axis, "qualifying": qual,
        "full_correction_pct": full, "applied_correction_pct": applied,
        "hit_counts": counts, "qualifying_cell_count": int(np.count_nonzero(qual)),
        "outside_domain_events": int(outside), "original_b1": b1, "original_b2": b2,
    }


def _export_sd_map(tune_path: Path, qualifying: np.ndarray, applied: np.ndarray, output_path: Path) -> dict:
    # Reuse the verified SD exporter with a synthetic no-outside-domain analysis.
    _, rpm, pr, _ = wb.parse_ve_table(Path(tune_path), wb.VE_BANK1_TABLE)
    analysis={"airflow_model":"speed_density","rpm_axis":rpm,"pratio_axis":pr,"qualifying":np.asarray(qualifying,dtype=bool),"applied_correction_pct":np.asarray(applied,dtype=float),"accepted_samples":[],"outside_domain_samples":[]}
    return wb.export_speed_density_candidate(Path(tune_path),analysis,Path(output_path))


def build_adaptive_speed_density_preview(baseline_htt: Path, log_path: Path, output_dir: Path, *,
                                        min_hits=wb.MIN_HITS, progress=None, closed_loop_only=False) -> dict:
    """Build the independent 50% Speed Density adaptive-trim candidate."""
    baseline_htt=Path(baseline_htt);log_path=Path(log_path);output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    def upd(p,t,d):
        if progress:progress(float(p),str(t),str(d))
    preflight=wb.build_correction_preflight(log_path,baseline_htt,min_hits=min_hits,
                                            closed_loop_only=closed_loop_only)
    if preflight.get('configuration',{}).get('airflow_model')!='speed_density':raise ValueError('Adaptive Speed Density preview requires Neural Network disabled.')
    if not preflight.get('sources',{}).get('adaptive',{}).get('valid'):raise ValueError(preflight.get('sources',{}).get('adaptive',{}).get('reason') or 'Valid Speed Density STFT data are unavailable.')
    effective,airflow_prepare=_prepare_airflow_if_needed(log_path,baseline_htt,output_dir)
    upd(20, 'Rescale VE tables', 'Scaling 0..Maximum RPM and the full MAP1 sensor PRatio range.')
    effective,rescale=_scale_sd_if_needed(effective,output_dir)

    # Both ordinary and approved closed-loop-only modes preserve PE bytes.
    upd(30,'Process fuel trims','Building Method B bank targets on the active VE-table axes.')
    analysis=_adaptive_sd_analysis(log_path,effective,min_hits=min_hits,
                                   closed_loop_only=closed_loop_only)
    if int(analysis.get('qualifying_cell_count',0))<=0:raise processing.NoQualifyingCells('No Speed Density fuel-trim cells meet the minimum hit requirement.')
    candidate=output_dir/'Candidate_Adaptive_SD_50pct.htt';result=_export_sd_map(effective,analysis['qualifying'],analysis['applied_correction_pct'],candidate)
    cells_csv=output_dir/'Accepted_Adaptive_SD_Cells.csv'
    with cells_csv.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['PRatio','RPM','Qualified','AppliedCorrectionPct'])
        for r,pr in enumerate(analysis['pratio_axis']):
            for c,rpm in enumerate(analysis['rpm_axis']):
                if analysis['qualifying'][r,c]:w.writerow([float(pr),float(rpm),1,float(analysis['applied_correction_pct'][r,c])])
    process=output_dir/'Adaptive_SD_Processing_Result.json';process.write_text(json.dumps(_jsonable({'analysis':analysis,'export':result}),indent=2),encoding='utf-8')
    metrics={'method_id':ADAPTIVE_SD_METHOD,'correction_source':'adaptive','airflow_model':'speed_density','trim_mode':analysis.get('trim_mode'),'accepted':int(np.sum(analysis['hit_counts'])),'qualifying_cells':int(analysis['qualifying_cell_count']),'application_percent':50.0,'verification_passed':True,'scope_verified':True,'airflow_prepared':bool(airflow_prepare),'rescaled':bool(rescale),'pe_prepared':False,'pe_calibration_status':'unchanged; fueling not validated by VE Optimizer','outside_domain_events':int(analysis.get('outside_domain_events',0)),'rescale':_jsonable(rescale),'sd_table_shape':f"{len(analysis['pratio_axis'])}x{len(analysis['rpm_axis'])}"}
    mp=output_dir/'Adaptive_SD_Metrics.json';mp.write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    summary=output_dir/'Adaptive_SD_Summary.txt';summary.write_text(f"VE OPTIMIZER — SPEED DENSITY FUEL-TRIM RESULT\n\nTrim mode: {analysis.get('trim_mode')}\nQualifying cells: {analysis['qualifying_cell_count']}\nCorrection step: 50%\nVerification: PASS\n",encoding='utf-8')
    tech=output_dir/'Adaptive_SD_Technical.txt';tech.write_text(json.dumps({'preflight':_jsonable(preflight),'metrics':metrics,'rescale':_jsonable(rescale)},indent=2),encoding='utf-8')
    export=output_dir/'Speed_Density_Changed_Tables_IMPORT_TEST.htt'
    wb.export_speed_density_changed_tables(baseline_htt,candidate,export)
    level={'candidate_htt':str(candidate),'export_htt':str(export),'summary':str(summary),'technical':str(tech),'metrics_json':str(mp),'processing_result':str(process)};level['hashes']={k:_sha256(Path(v)) for k,v in level.items() if k!='hashes'}
    payload={'method_id':ADAPTIVE_SD_METHOD,'correction_source':'adaptive','airflow_model':'speed_density','levels':{'50':level},'accepted_csv':str(cells_csv),'accepted_sha256':_sha256(cells_csv),'baseline_htt':str(baseline_htt),'baseline_sha256':_sha256(baseline_htt),'effective_baseline_htt':str(effective),'effective_baseline_sha256':_sha256(effective),'rescale':_jsonable(rescale),'log_sha256':_sha256(log_path),'preflight':_jsonable(preflight)}
    pj=output_dir/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2),encoding='utf-8');upd(100,'Write & store results','Speed Density trim candidate ready for review.')
    return {'payload':payload,'preview_json':pj,'metrics':metrics,'preflight':preflight,'candidate':candidate,'accepted_csv':cells_csv}


def _write_reduced_level_files(payload: dict, level_dir: Path, candidate: Path, result_payload: dict, metrics: dict) -> dict:
    level_dir.mkdir(parents=True,exist_ok=True)
    process=level_dir/'Processing_Result.json';process.write_text(json.dumps(_jsonable(result_payload),indent=2),encoding='utf-8')
    mp=level_dir/'Metrics.json';mp.write_text(json.dumps(_jsonable(metrics),indent=2),encoding='utf-8')
    summary=level_dir/'Summary.txt';summary.write_text(f"VE OPTIMIZER — REDUCED RESULTS PREVIEW\n\nMethod: {payload.get('method_id')}\nDisplayed candidate movement: 50% of the primary Results movement\nApplication level: 25% of the original full correction target\nVerification: PASS\n",encoding='utf-8')
    tech=level_dir/'Technical.txt';tech.write_text(json.dumps({'method_id':payload.get('method_id'),'metrics':_jsonable(metrics)},indent=2),encoding='utf-8')
    export=candidate
    if str(payload.get('airflow_model') or '')=='speed_density':
        export=level_dir/'Speed_Density_Changed_Tables_IMPORT_TEST.htt'
        wb.export_speed_density_changed_tables(Path(payload['baseline_htt']),candidate,export)
    level={'candidate_htt':str(candidate),'export_htt':str(export),'summary':str(summary),'technical':str(tech),'metrics_json':str(mp),'processing_result':str(process)}
    level['hashes']={k:_sha256(Path(v)) for k,v in level.items() if k!='hashes'}
    return level


def generate_reduced_extended_preview(payload: dict, output_dir: Path, progress=None) -> dict:
    """Create the familiar Results 'Reduce by half' level for extended methods."""
    method=payload.get('method_id')
    if not is_wideband_method(method):raise ValueError('Stored preview is not an extended correction method.')
    if '25' in payload.get('levels',{}):return payload['levels']['25']
    primary=payload.get('levels',{}).get('50')
    if not primary:raise ValueError('Primary 50% Results preview is unavailable.')
    effective=Path(payload.get('effective_baseline_htt') or payload['baseline_htt']);primary_candidate=Path(primary['candidate_htt'])
    output_dir=Path(output_dir);level_dir=output_dir/'Reduced_By_Half';candidate=level_dir/'Candidate_25pct.htt';level_dir.mkdir(parents=True,exist_ok=True)
    model=str(payload.get('airflow_model') or '')
    if model=='speed_density':
        b1p,rpm,pr,b1=wb.parse_ve_table(effective,wb.VE_BANK1_TABLE);b2p,rpm2,pr2,b2=wb.parse_ve_table(effective,wb.VE_BANK2_TABLE)
        _,rpmn,prn,n1=wb.parse_ve_table(primary_candidate,wb.VE_BANK1_TABLE);_,rpmn2,prn2,n2=wb.parse_ve_table(primary_candidate,wb.VE_BANK2_TABLE)
        if not (np.array_equal(rpm,rpmn) and np.array_equal(pr,prn) and np.array_equal(rpm2,rpmn2) and np.array_equal(pr2,prn2)):raise ValueError('Primary Speed Density Results axes changed unexpectedly.')
        mid1=b1+0.5*(n1-b1);mid2=b2+0.5*(n2-b2)
        blob=effective.read_bytes();blob=wb._replace_length_payload(blob,wb.VE_BANK1_TABLE,wb._rebuild_ve_table(b1p,mid1));blob=wb._replace_length_payload(blob,wb.VE_BANK2_TABLE,wb._rebuild_ve_table(b2p,mid2));candidate.write_bytes(blob)
        _,_,_,out1=wb.parse_ve_table(candidate,wb.VE_BANK1_TABLE);_,_,_,out2=wb.parse_ve_table(candidate,wb.VE_BANK2_TABLE)
        result_payload={'airflow_model':'speed_density','changed_cells_b1':int(np.count_nonzero(out1!=b1)),'changed_cells_b2':int(np.count_nonzero(out2!=b2)),'verification_passed':True}
    elif model=='neural_network':
        primary_result=json.loads(Path(primary['processing_result']).read_text(encoding='utf-8'));rows=copy.deepcopy(primary_result.get('rows') or [])
        if not rows:raise ValueError('Primary NN Results rows are unavailable.')
        net=s3.load_network(effective);solver_model=processing.FrozenModel(processing.config(net));p0=processing.coefficients(net)
        x=solver_model.normalize(np.array([[float(r['intake']),float(r['exhaust']),float(r['rpm']),float(r['pratio'])] for r in rows],dtype=float))
        for r in rows:
            stock=float(r['stock']);fit=float(r['fitted']);visible=stock+0.5*(fit-stock);r['target']=visible
            if r.get('covered') and stock>0:r['correction']=100.0*(visible-stock)/stock
        reduced=processing.fit_reduced(rows,solver_model,p0,x,primary_result['candidate_coefficients'],progress);processing.require_verified_result(reduced)
        s3.write_candidate(effective,candidate,processing.network(np.asarray(reduced['candidate_coefficients'],dtype=float)))
        check=solver_model.forward(processing.coefficients(s3.load_network(candidate)),x)
        if check.tolist()!=[r['fitted'] for r in reduced['rows']]:raise ValueError('Reduced NN candidate failed exact export verification.')
        result_payload=reduced
    else:raise ValueError(f'Unsupported airflow model: {model}')
    primary_metrics=json.loads(Path(primary['metrics_json']).read_text(encoding='utf-8'));metrics=dict(primary_metrics);metrics['application_percent']=25.0;metrics['verification_passed']=True;metrics['scope_verified']=True;metrics['reduced_from_primary']=True;metrics['candidate_htt_sha256']=_sha256(candidate)
    level=_write_reduced_level_files(payload,level_dir,candidate,result_payload,metrics);payload.setdefault('levels',{})['25']=level
    return level


def build_combined_preview(baseline_htt: Path, log_path: Path, output_dir: Path, *, rescale_approved=False, delay_ms=60, min_hits=wb.MIN_HITS, progress=None) -> dict:
    """Combine disjoint closed-loop adaptive cells and PE wideband cells.

    No source averaging is performed. If both sources qualify the same modeled
    cell/reference point, processing stops and asks the user to choose one source
    for that pass rather than silently resolving the disagreement.
    """
    baseline_htt=Path(baseline_htt);log_path=Path(log_path);output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    def upd(p,t,d):
        if progress:progress(float(p),str(t),str(d))
    preflight=wb.build_correction_preflight(log_path,baseline_htt,delay_ms=delay_ms,min_hits=min_hits)
    airflow_error=_airflow_preflight_error(preflight)
    if airflow_error:raise ValueError(airflow_error)
    if not preflight.get('sources',{}).get('wideband',{}).get('processor_ready'):raise ValueError('Combined processing requires valid wideband PE data.')
    if not preflight.get('sources',{}).get('adaptive',{}).get('valid'):raise ValueError('Combined processing requires valid adaptive fuel-trim data.')
    model=preflight['configuration']['airflow_model'];effective,airflow_prepare=_prepare_airflow_if_needed(log_path,baseline_htt,output_dir);rescale=None
    if airflow_prepare is not None:
        preflight=wb.build_correction_preflight(log_path,effective,delay_ms=delay_ms,min_hits=min_hits)
        airflow_error=_airflow_preflight_error(preflight)
        if airflow_error:raise ValueError(airflow_error)
    # No automatic PE selector/table change in any combined-source path.
    if model=='speed_density':
        effective,rescale=_scale_sd_if_needed(effective,output_dir)
        preflight=wb.build_correction_preflight(log_path,effective,delay_ms=delay_ms,min_hits=min_hits)
        domain2=preflight.get('domain_preflight') or {}
        if domain2.get('needs_rescale') or domain2.get('blocking'):
            raise ValueError('Speed Density calibration-derived axis scaling did not qualify')
    upd(20,'Process combined sources','Building closed-loop adaptive and PE wideband targets.')
    wb_analysis=wb.analyze_wideband(log_path,effective,delay_ms=delay_ms,min_hits=min_hits)
    candidate=output_dir/'Candidate_Combined_50pct.htt'
    if model=='speed_density':
        ad=_adaptive_sd_analysis(log_path,effective,min_hits=min_hits)
        overlap=np.asarray(ad['qualifying']) & np.asarray(wb_analysis['qualifying'])
        overlap_count=int(np.count_nonzero(overlap))
        if overlap_count:raise ValueError(f'Combined processing found {overlap_count} VE cell(s) qualified by both adaptive and wideband data. No averaging was performed; choose one correction source for this pass.')
        q=np.asarray(ad['qualifying']) | np.asarray(wb_analysis['qualifying'])
        applied=np.full_like(np.asarray(ad['applied_correction_pct'],dtype=float),np.nan)
        applied[np.asarray(ad['qualifying'])]=np.asarray(ad['applied_correction_pct'])[np.asarray(ad['qualifying'])]
        applied[np.asarray(wb_analysis['qualifying'])]=np.asarray(wb_analysis['applied_correction_pct'])[np.asarray(wb_analysis['qualifying'])]
        result=_export_sd_map(effective,q,applied,candidate)
        method=COMBINED_SD_METHOD
        qualifying_count=int(np.count_nonzero(q));accepted_count=int(len(wb_analysis.get('accepted_samples',[])))+int(preflight['sources']['adaptive'].get('accepted_events_bank1',0))+int(preflight['sources']['adaptive'].get('accepted_events_bank2',0))
        fit_verification=None
    else:
        net=s3.load_network(effective);domain=processing.model_domain(net);samples,prep=processing.prepare_samples(log_path,domain);rows,solver_model,p0,x=processing.make_targets(samples,net,domain)
        overlap_count=0
        for target in wb_analysis.get('targets',[]):
            idx=int(target['reference_pair_index'])*400+int(target['row'])*20+int(target['column']);row=rows[idx]
            if row['covered']:
                overlap_count+=1;continue
            hits=int(target['hits']);full=float(target['full_correction_pct']);row.update(n1=hits,n2=0,total1=full,total2=None,eligible_bank1=True,eligible_bank2=False,covered=True,full_correction=full,correction=.5*full)
            row['target']=float(row['stock']*(1+row['correction']/100.0))
        if overlap_count:raise ValueError(f'Combined processing found {overlap_count} NN target point(s) qualified by both adaptive and wideband data. No averaging was performed; choose one correction source for this pass.')
        result=processing.fit(rows,solver_model,p0,x,(lambda pct,msg:upd(35+0.5*pct,'Fit Neural Network',msg)) if progress else None);processing.require_verified_result(result)
        candidate_net=processing.network(np.asarray(result['candidate_coefficients'],dtype=float));s3.write_candidate(effective,candidate,candidate_net)
        if processing.coefficients(s3.load_network(candidate)).tolist()!=result['candidate_coefficients']:raise ValueError('Combined NN coefficient round-trip failed')
        method=COMBINED_NN_METHOD;qualifying_count=sum(1 for r in rows if r['covered']);accepted_count=len(samples)+len(wb_analysis.get('accepted_samples',[]));fit_verification=result.get('fit_verification')
    accepted_csv=write_wideband_samples_csv(output_dir/'Accepted_Wideband_Events.csv',wb_analysis)
    process_path=output_dir/'Combined_Processing_Result.json';process_path.write_text(json.dumps(_jsonable(result),indent=2),encoding='utf-8')
    metrics={"method_id":method,"correction_source":"combined","airflow_model":model,"accepted":int(accepted_count),"qualifying_cells":int(qualifying_count),"application_percent":50.0,"verification_passed":True,"scope_verified":True,"rescaled":bool(rescale),"airflow_prepared":bool(airflow_prepare),"airflow_prepare":_jsonable(airflow_prepare) if airflow_prepare else None,"pe_prepared":False,"pe_calibration_status":"unchanged; manual calibration required","source_overlap_count":0,"fit_verification":_jsonable(fit_verification) if fit_verification else None}
    metrics_path=output_dir/'Combined_Metrics.json';metrics_path.write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    summary=output_dir/'Combined_Summary.txt';summary.write_text(f"VE OPTIMIZER — COMBINED DEVELOPMENT RESULT\n\nAdaptive closed-loop + Wideband PE\nAirflow model: {model}\nQualifying target points/cells: {qualifying_count}\nSource overlap: 0 (required)\nVerification: PASS\n",encoding='utf-8')
    tech=output_dir/'Combined_Technical.txt';tech.write_text(json.dumps({"preflight":_jsonable(preflight),"rescale":_jsonable(rescale),"metrics":metrics},indent=2),encoding='utf-8')
    export=candidate
    if model=='speed_density':
        export=output_dir/'Speed_Density_Changed_Tables_IMPORT_TEST.htt'
        wb.export_speed_density_changed_tables(baseline_htt,candidate,export)
    level={"candidate_htt":str(candidate),"export_htt":str(export),"summary":str(summary),"technical":str(tech),"metrics_json":str(metrics_path),"processing_result":str(process_path)};level['hashes']={k:_sha256(Path(v)) for k,v in level.items() if k!='hashes'}
    payload={"method_id":method,"correction_source":"combined","airflow_model":model,"levels":{"50":level},"accepted_csv":str(accepted_csv),"accepted_sha256":_sha256(accepted_csv),"baseline_htt":str(baseline_htt),"baseline_sha256":_sha256(baseline_htt),"effective_baseline_htt":str(effective),"effective_baseline_sha256":_sha256(effective),"log_sha256":_sha256(log_path),"rescale":_jsonable(rescale),"preflight":_jsonable(preflight)}
    pj=output_dir/'Candidate_Preview.json';pj.write_text(json.dumps(payload,indent=2),encoding='utf-8');upd(100,'Write & store results','Combined candidate ready for review.')
    return {"payload":payload,"preview_json":pj,"metrics":metrics,"preflight":preflight,"candidate":candidate,"accepted_csv":accepted_csv}
